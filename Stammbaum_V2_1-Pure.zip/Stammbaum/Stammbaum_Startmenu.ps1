﻿##################################################################################################################################################
###                                                                                                                                            ###
###   es wird als Definitions-Datei die Datei "PowershellMenueBand_MenuSources.def" benutzt                                                    ###
###                                                                                                                                            ###
###   der Aufbau der Datei PowershellMenueBand_MenuSources.def:                                                                                ###
###                                                                                                                                            ###
###      Lnr, BasisElementLnr, Name, EndPoint, Aktion, Attribute, Description                                                                  ###
###      1, 0, Element 1,0, Element1.ps1,,                                                                                                     ###
###      2, 0, Element 2,0, Element2.ps1,,                                                                                                     ###
###      3, 2, Element 3 2,0, Element3.ps1,,                                                                                                   ###
###      4, 3, Element 4 3,1, Element4.ps1,,                                                                                                   ###
###      5, 2, Element 5 2,1, Element5.ps1, false, Beschreibungstext5                                                                          ###
###      6, 0, Element 6 (EXIT),1, exit,,                                                                                                      ###
###      7, 0, Admin Tools, 0, NIX , false, Beschreibungstext                                                                                  ###
###      8, 7, Policy Manager (bat), 1, C:\28_WsusPolicyManager\PS_Start.bat , false, Beschreibungstext                                        ###
###      9, 1, Element 1 2,1, Element9.ps1, false, Beschreibungstext9                                                                          ###
###      10, 7, Policy Manager (PS.EXE), 1, C:\28_WsusPolicyManager\PS_Start.bat , false, Beschreibungstext                                    ###
###      11, 7, Policy Manager (DirektStart UNC), 1, "& C:\28_WsusPolicyManager\PS_Start.PS1", false, Beschreibungstext                        ###
###      12, 7, Policy Manager (DirektStart relativ), 1, "& PS_Start.PS1", false, Beschreibungstext                                            ###
###                                                                                                                                            ###
###   Funktion der Parameter:                                                                                                                  ###
###                                                                                                                                            ###
###      Lnr              = die laufende Nummer des Menü-Eintrags                                                                              ###
###      BasisElementLnr  = die laufende Nummer des Menü-Eintrags, dessen Untermenü dieser Eintrag sein soll                                   ###
###      Name             = Menü-Name, der angezeigt werden soll                                                                               ###
###      EndPoint         = 0, wenn dieser Eintrag ein Untermenü enthält, 1 wenn es ein Eintrag ohne weitere Untermenüs ist                    ###
###      Aktion           = die Aktion, die Ausgeführt werden soll (wird bei Einträgen mit Untermenü ignoriert)                                ###
###      Attribute        = kommt noch                                                                                                         ###
###      Description      = das ist der Text, der bei Sicherheitsabfragen im Fenster steht. Ohne Description kommt keine Sicherheitsabfrage.   ###
###                                                                                                                                            ###   
###                                                                                                                                            ###  
###   Wird die Datei PowershellMenueBand_MenuSources.def nicht gefunden, so wird sie neu erzeugt.                                              ###  
###                                                                                                                                            ### 
##################################################################################################################################################

param (
    $DebugMode="false",
    $LogMode="false",
    $GetVersionInfo="false"
)

cls

##################################################
$Version="0.13"
$Stand="18.06.2023"
$Developper="na ich"
##################################################



#region tools

    function DetectScriptPath {
        Param(
            $PowershellVersion=0
        )
        ##################################################
        # Version V03
        # vom 18.6.2023
        ##################################################

        $DebugMode = "false"
        if ($global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
       
        if ($DebugMode -eq "true") {$text="DetectScriptPath Startet mit Parameter`nPowershellVersion:`t" + $PowershellVersion + "`nDebugMode:`t" + $DebugMode + "`n";Write-Host $text}

        $a=""
        $b=""
        $c=""

        # gezielte Versuch anhand der installierten PS-Version den Script-Pfad zu ermitteln
        if ($DebugMode -eq "true") {$text="Powershell-Version: " + $PowershellVersion  + "`tab Powershell V2.0 geht PSScriptRoot";Write-Host $text}
        if ($PowershellVersion -gt 2){
            $BasisPfad=$PSScriptRoot
            $a=$BasisPfad
            if ($DebugMode -eq "true") {$text="PSScriptRoot liefert als BasisPfad:" + $BasisPfad;Write-Host $text}
            if (Test-Path -Path ($BasisPfad + "\Stammbaum_Startmenu.ps1")) {} else {$BasisPfad=""}
        }
        
        
        if ($BasisPfad -eq ""){
            if ($DebugMode -eq "true") {$text="bei Powershell V1.0 geht ExecutionContext";Write-Host $text}
            if ($PowershellVersion -gt 1){
                $BasisPfad=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath('.\')
                $b=$BasisPfad
                if ($DebugMode -eq "true") {$text="ExecutionContext liefert als BasisPfad:" + $BasisPfad;Write-Host $text}
                if (Test-Path -Path ($BasisPfad + "\Stammbaum_Startmenu.ps1")) {} else {$BasisPfad=""}
            }
        }


        if ($BasisPfad -eq ""){
            if ($DebugMode -eq "true") {$text="letzter Versuch mit MyInvocation";Write-Host $text}
            $BasisPfad=split-path -parent $MyInvocation.MyCommand.Definition
            $c=$BasisPfad
            if ($DebugMode -eq "true") {$text="MyInvocation liefert als BasisPfad:" + $BasisPfad;Write-Host $text}
            if (Test-Path -Path ($BasisPfad + "\Stammbaum_Startmenu.ps1")) {} else {$BasisPfad=""}
        }

        if ($DebugMode -eq "true") {

            $Text="Ermitteln des ScriptPfades`n Methode 1: " + $a + "`n" + "Methode 2: " + $b + "`n" + "Methode 3: " + $c + "`n"
            $text=$Text + "DetectScriptPath endet mit Rueckgabe-Parameter`nBasisPfad:`t" + $BasisPfad + "`n"
            Write-Host  $Text
        }

        if ($DebugMode -eq "true") {$text="DetectScriptPath endet mit Rückgabe:`t" + $BasisPfad + "`n";Write-Host $text}
        return $BasisPfad
}

    function GetMenuData {
        Param(
            $MenuDataFile=""
        )

        ##################################################
        # Version V03
        # vom 19.5.2023
        ##################################################
        
        $DebugMode = "false"
        if ($global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") {$Text= "## GetMenuData startet `t- mit Parameter MenuDataFile: (" + $MenuDataFile + ")";Write-Host $text}

        $Import=$true
        if (Test-Path -Path $MenuDataFile) {
                $SourceData=Get-Content $MenuDataFile
                if ($SourceData.Length -eq 0){   
                    $Import=$false
                }     
            } else {
                $Import=$false
        }
        
        if ($Import -eq $false){
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei existiert nicht/oder ist leer"}

            # Standard-Trennzeichen ist TAB ( `t )
            $SourceData=""
            $jetzt=Get-Date
            $SourceData=$SourceData + "Lnr, BasisElementLnr, Name, EndPoint, Aktion, Attribute, Description" + ",restored am """ + $jetzt + """`n"
            $SourceData=$SourceData + "1, 0, Datei,0, Untermenue1.ps1,," + "`n"
            $SourceData=$SourceData + "3, 1,  Export,1,  ""& Stammbaum_Export2HTML.ps1"",," + "`n"
            $SourceData=$SourceData + "4, 1,  MAP,1,  ""& Stammbaum_Map.ps1"",," + "`n"
            $SourceData=$SourceData + "10, 0, Eingabe,1, ""& Stammbaum_DatenEingabe.ps1"",,Personendaten anpassen" + "`n"
            $SourceData=$SourceData + "11, 0, Einstellungen,0, Sub-Menü 11,," + "`n"
            $SourceData=$SourceData + "12, 11, Einstellungen,1, ""& Stammbaum_SettingsManager.ps1"",," + "`n"
            $SourceData=$SourceData + "14, 0, Tools,0, Sub-Menü 14,," + "`n"
            $SourceData=$SourceData + "15, 14, Tools,1, ""& Stammbaum_Tools.ps1"",," + "`n"
            $SourceData=$SourceData + "17, 0, EXIT,1, exit,," + "`n"


            $SourceData| Out-File -FilePath $MenuDataFile
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei wurde erzeugt"}
        
            $SourceData=Get-Content $MenuDataFile
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei wurde frisch eingelesen"}

            if ($SourceData.Length -eq 0){
                if ($DebugMode -eq "true") {Write-Host "Settings-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!"}
                #read-host “Press ENTER to continue...”
                $erg=[System.Windows.Forms.MessageBox]::Show("Settings-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!", "FileSystem Zugriffs-Fehler", "1", "None" )
                $host.Exit()
            }
        }
        
        if ($DebugMode -eq "true") {$Text= "## GetMenuData endet `t- mit Rückgabe-Parameter SourceData: (" + $SourceData + ")";Write-Host $text}
        return $SourceData
    }

    function GetSettingsData {
        Param(
            $SourceDataFile
        )

        ##################################################
        # Version V06
        # vom 13.6.2023
        ##################################################
        
        $DebugMode = "false"
        if ($global:DebugMode -eq "true") {$DebugMode = "true"}

        if ($DebugMode -eq "true") {$Text="## GetSettingsData startet `t- mit Parameter SourceDataFile: (" + $SourceDataFile + ")";Write-Host $text}

        $Import=$true
        if (Test-Path -Path $SourceDataFile) {
                $SourceData=Get-Content $SourceDataFile
                if ($SourceData.Length -eq 0){
                    $Import=$false
                }
            } else {
                $Import=$false
        }

        if ($Import -eq $false){
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei existiert nicht/oder ist leer"}

            # Standard-Trennzeichen ist TAB ( `t )
            $SourceData="Lnr	Kategorie	Namen	Wert	Beschreibung" + "`n"
            $SourceData=$SourceData + "1`tallgemein`tDatenquelle`t1`tSpeicherort der Daten, 1=interne ExcelSheets (noch nicht verfügber: , 2=SQL-DB, 3=Spreadsheet-Datei)" + "`n"
            $SourceData=$SourceData + "2`tallgemein`tFeldTrenner`tTAB`tSpalten-Trennzeichen aller interner Datensätze" + "`n"

            $SourceData=$SourceData + "3`tallgemein`tSprache`t`tSprache des Tools (DE-DE, EN-EN, ...). bleibt der Parameter leer, so wird die aktive Sprach-Einstellung des Systems benutzt" + "`n"
            $SourceData=$SourceData + "4`tFileSystem`tExportZielPfad`t" +  $BasisPfad + "\ZielDateien`tZielordner für DatenExporte" + "`n"
            $SourceData=$SourceData + "5`tFileSystem`tDatenZielPfad`t" +  $BasisPfad + "\DBDaten`tOrdner der DB-Daten" + "`n"
            $SourceData=$SourceData + "6`tFileSystem`tPersonenDatei`tPersonen.sdb`tDB-Datei für Personendaten" + "`n"
            $SourceData=$SourceData + "7`tFileSystem`tAdresseDatei`tAdressen.sdb`tDB-Datei für Adressdaten" + "`n"
            $SourceData=$SourceData + "8`tFileSystem`tKnotenDatei`tKnoten.sdb`tDB-Datei für Knotendaten" + "`n"
            $SourceData=$SourceData + "9`tDarstellung`tGeborenZeichen`t*`tZeichen für ""geboren""" + "`n"
            $SourceData=$SourceData + "10`tDarstellung`tGestorbenZeichen`t[char]0x2020`tZeichen für ""gestorben""" + "`n"
            $SourceData=$SourceData + "11`tDarstellung`tHochzeitZeichen`t[char]0x26AD`tZeichen für ""Hochzeit""" + "`n"
            $SourceData=$SourceData + "12`tDarstellung`tScheidungsZeichen`t[char]0x26AE`tZeichen für ""Trennung""" + "`n"
            $SourceData=$SourceData + "13`tDarstellung`tNodeBreite`t120`tBreite der Person bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "14`tDarstellung`tNodeHoehe`t100`tHöhe der Person bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "15`tDarstellung`tPersonBreite`t100`tBreite der Verbindungskästen bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "16`tDarstellung`tPersonHoehe`t130`tHöhe der Verbindungskästen bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "17`tDarstellung`tZeilenabstand`t50`tZeilenabstand zwischen den Kästen bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "18`tDarstellung`tSpaltenAbstand`t50`tHorrizontaler Abstand zwischen den Kästen bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "19`tDarstellung`tHintergrundFarbe`tgreen`tFarbe des Seiten-Hintergrunds bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "20`tDarstellung`tPersonenFarbe`tgrey`tFarbe der Personenkaestchen bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "21`tDarstellung`tWdhPersonenFarbe`tgreen`tFarbe der Personenkaestchen bei Wiederholungen (weiterer Partner) bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "22`tDarstellung`tKnotenFarbe`tblue`tFarbe der Personenkaestchen bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "23`tDarstellung`tPersonenSchriftFarbe`t#ada`tFarbe der Personenkaestchen bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "24`tDarstellung`tWdhPersonenSchriftFarbe`t#ada`tFarbe der Personenkaestchen bei Wiederholungen (weiterer Partner) bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "25`tDarstellung`tKnotenSchriftFarbe`t#dad`tFarbe der Personenkaestchen bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "26`tDarstellung`tPersonenSchriftGroesse`t12`tGroesse der Schrift (in px) in den Personenkaestchen bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "27`tDarstellung`tWdhPersonenSchriftGroesse`t12`tGroesse der Schrift (in px) in den Personenkaestchen bei Wiederholungen (weiterer Partner) bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "28`tDarstellung`tKnotenSchriftGroesse`t12`tGroesse der Schrift (in px) in den Personenkaestchen bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "29`tDarstellung`tPersonInhalt`t+,+,-,+,+,+,-,-,-,-,-,-,-`tInhalt der Personenkaestchen bei Objektbasierter Darstellung (Lnr,Vorname,ZusatzVorname,Nachname,GebName,GebDatum,GeburtsOrt,Sterbedatum,SterbeOrt_Friedhof,Bemerkung,religion,geschl,nationalität)" + "`n"
            $SourceData=$SourceData + "30`tDarstellung`tKnotenInhalt`t+,+,-,-`tInhalt der Knotenkaestchen bei Objektbasierter Darstellung (Lnr,TrauDatum,TrauOrt,ScheidungsDatum)" + "`n"
            $SourceData=$SourceData + "31`tDebugging`tDebugMode`tWAHR`tDebug-Log-Datei wird erzeugt" + "`n"
            $SourceData=$SourceData + "32`tDebugging`tLogMode`t1`t(an = 1, aus = 0) Log-Datei(en) werden erzeugt" + "`n"
            $SourceData=$SourceData + "33`tDebugging`tLogFileZielPfad`t" +  $BasisPfad + "\ZielDateien`tSpeicherPfad der Debug-Log-Datei" + "`n"
            $SourceData=$SourceData + "34`tDebugging`tLogFileDateiname`tDebugLog.log`tDateiname der Debug-Log-Datei" + "`n"
            $SourceData=$SourceData + "35`tFileSystem`tSeleniumPfad	`t`tPfad zum Selenium-Verzeichnis (""...\selenium-powershell-master"")" + "`n"
            $SourceData=$SourceData + "36`tFileSystem`tChromeDriverPfad`t`tPfad zum ChromeDriver (""...\chromedriver\win32\113"")" + "`n"
            $SourceData=$SourceData + "37`tFileSystem`tGoogleMapsUsername`t`tUsername (mail adresse) zum Anmelden bei Google Maps" + "`n"
            $SourceData=$SourceData + "38`tFileSystem`tGoogleMapsPassword`t`tPasswort (passend zur mail adresse) zum Anmelden bei Google Maps" + "`n"
            $SourceData=$SourceData + "39`tDarstellung`tGoogleMapsImportDetails`t+,+,+,+,-,+`tInhalt, der bei Google Maps dargestellt werden soll (GebOrt,WohnOrt, SterbeOrt,HochzeitsOrt,ScheidungsOrt,Verbinder)" + "`n"
            $SourceData=$SourceData + "40`tDarstellung`tGoogleMapsPosIconGebOrt`t1844`tIcon-Nummer, das bei Google Maps als Geburtsort dargestellt werden soll" + "`n"
            $SourceData=$SourceData + "41`tDarstellung`tGoogleMapsPosFarbeGebOrt`t1`tFarb-Nummer, in der bei Google Maps der Geburtsort dargestellt werden soll (0=schwarz, 1=dunkelgrün, 2=lila, 3=rot, 4=gelb)" + "`n"
            $SourceData=$SourceData + "42`tDarstellung`tGoogleMapsPosIconWohnOrt`t1603`tIcon-Nummer, das bei Google Maps als Wohnort dargestellt werden soll" + "`n"
            $SourceData=$SourceData + "43`tDarstellung`tGoogleMapsPosFarbeWohnOrt`t2`tFarb-Nummer, in der bei Google Maps der Wohnort dargestellt werden soll (0=schwarz, 1=dunkelgrün, 2=lila, 3=rot, 4=gelb)" + "`n"
            $SourceData=$SourceData + "44`tDarstellung`tGoogleMapsPosIconSterbeOrt`t1670`tIcon-Nummer, das bei Google Maps als Sterbeort dargestellt werden soll" + "`n"
            $SourceData=$SourceData + "45`tDarstellung`tGoogleMapsPosFarbeSterbeOrt`t0`tFarb-Nummer, in der bei Google Maps der Sterbeort dargestellt werden soll (0=schwarz, 1=dunkelgrün, 2=lila, 3=rot, 4=gelb)" + "`n"
            $SourceData=$SourceData + "46`tDarstellung`tGoogleMapsPosIconHochzeitsOrt`t1592`tIcon-Nummer, das bei Google Maps als Hochzeitsort dargestellt werden soll" + "`n"
            $SourceData=$SourceData + "47`tDarstellung`tGoogleMapsPosFarbeHochzeitsOrt`t3`tFarb-Nummer, in der bei Google Maps der Hochzeitsort dargestellt werden soll (0=schwarz, 1=dunkelgrün, 2=lila, 3=rot, 4=gelb)" + "`n"
            $SourceData=$SourceData + "48`tDarstellung`tGoogleMapsPosIconScheidungsOrt`t1516`tIcon-Nummer, das bei Google Maps als Scheidungsort dargestellt werden soll" + "`n"
            $SourceData=$SourceData + "49`tDarstellung`tGoogleMapsPosFarbeScheidungsOrt`t4`tFarb-Nummer, in der bei Google Maps der Scheidungsort dargestellt werden soll (0=schwarz, 1=dunkelgrün, 2=lila, 3=rot, 4=gelb)" + "`n"
            $SourceData=$SourceData + "50`tDarstellung`tGoogleMapsFarbPalette`tVIpgJd-nEeMgc-eEDwDf12,VIpgJd-nEeMgc-eEDwDf20,VIpgJd-nEeMgc-eEDwDf11,VIpgJd-nEeMgc-eEDwDf14,VIpgJd-nEeMgc-eEDwDf4`tFarb-Namen-Liste - Liste der benutztenm Farben bei Google Maps (standard: schwarz, 1=dunkelgrün, lila, rot, gelb)" + "`n"
            $SourceData=$SourceData + "51`tDarstellung`tGoogleMapsMaxPointerLines`t2000`tMaximale Anzahl an Pointzer oder Linien in einer KML-Datei zum Einlesen bei Google Maps (Verkleinern als Maßnahme bei zu großer KML-Datei)" + "`n"


            $SourceData| Out-File -FilePath $SourceDataFile
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei wurde erzeugt"}
        
            $SourceData=Get-Content $SourceDataFile
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei wurde frisch eingelesen"}

            if ($SourceData.Length -eq 0){
                if ($DebugMode -eq "true") {Write-Host "Settings-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!"}
                #read-host “Press ENTER to continue...”
                $erg=[System.Windows.Forms.MessageBox]::Show("Settings-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!", "FileSystem Zugriffs-Fehler", "1", "None" )
                $host.Exit()
            }
        }
        
        if ($DebugMode -eq "true") {$text= "## GetSettingsData endet `t- mit Rückgabe-Parameter SourceData: (" + $SourceData + ")";Write-Host $text}
        return $SourceData
    }

    function GetParameterFromSettings {
        param (
            $Parametername=""
        )
        ##################################################
        # Version V02
        # vom 7.4.2023
        ##################################################

        $DebugMode = "false"
        if ($global:DebugMode -eq "true") {$DebugMode = "true"}
            
        if ($DebugMode -eq "true") {$text= "## GetParameterFromSettings startet `t- mit Parameter Parametername: (" + $Parametername + ")";Write-Host $text}

        $DummyText=""
        # Achtung Namensaenderung!
        $SourceDataZeilenSpit=$global:SettingsData.Split("`n")

        for($i=0; $i -lt $SourceDataZeilenSpit.count; $i++){

                if ($SourceDataZeilenSpit[$i].length -ne 0)                            
                {
                    $SourceDataSplit=$SourceDataZeilenSpit[$i].Split("`t")

                    if ($DebugMode -eq "true") { $text="Parmeter " + $SourceDataSplit[2];Write-Host $text}
                    if ($Parametername -eq $SourceDataSplit[2]){
                        
                        $DummyText=$SourceDataSplit[3]

                        if ($Parametername -eq "LogMode"){
                            if ($SourceDataSplit[3] -eq "wahr"){
                                    $DummyText="true"
                                } elseif ($SourceDataSplit[3] -eq "true"){
                                    $DummyText="true"
                                }elseif ($SourceDataSplit[3] -eq "falsch"){
                                    $DummyText="false"
                                } elseif ($SourceDataSplit[3] -eq "false"){
                                    $DummyText="false"
                            }
                        } 
                        if ($Parametername -eq "DebugMode"){
                            if ($SourceDataSplit[3] -eq "wahr"){
                                    $DummyText="true"
                                } elseif ($SourceDataSplit[3] -eq "true"){
                                    $DummyText="true"
                                } elseif ($SourceDataSplit[3] -eq "falsch"){
                                    $DummyText="false"
                                } elseif ($SourceDataSplit[3] -eq "false"){
                                    $DummyText="false"
                            }
                        } 
                    }
                }   
        } 
    
        if ($DebugMode -eq "true") {$text="## GetParameterFromSettings endet `t- mit Rückgabe-Parameter DummyText: (" + $DummyText + ")";Write-Host $text}
        return $DummyText
    }

    function GetLanguageFileName() {
        Param(
            $ActiveLanguage
        )
        ##################################################
        # Version V03
        # vom 20.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") {$text="## GetLanguageFileName startet `t- mit Parameter ActiveLanguage: (" + $ActiveLanguage + ")";Write-Host $text}

        $DBPfad=""

        $DBPfad=GetParameterFromSettings -Parametername "DatenZielPfad"
        if ($DebugMode -eq "true") {$text="## `t`t-- DBPfad aus Settings: (" + $DBPfad + ")";Write-Host $text}

        if (Test-Path -Path $DBPfad) {
            } else {

                New-Item -Path $DBPfad -ItemType Directory

                if (Test-Path -Path $DBPfad) {
                    } else {
                        $DBPfad = $global:BasisPfad + "\DBDaten"
                        if ($DebugMode -eq "true") {$text="## `t`t-- DBPfad aus Settings nicht gefunden. teste jetzt: (" + $DBPfad + ")";Write-Host $text}
                        if (Test-Path -Path $DBPfad) {
                            } else {
                                $DBPfad = $global:BasisPfad
                                if ($DebugMode -eq "true") {$text="## `t`t-- Standard-DBPfad als Kombination Basispfad\DBDaten nicht gefunden. teste jetzt: (" + $DBPfad + ")";Write-Host $text}
                                if (Test-Path -Path $DBPfad) {
                                    } else {
                                        $DBPfad = ""
                                        if ($DebugMode -eq "true") {$text="## `t`t-- Auch nicht gefunden. ich gebe auf - das wird nix mehr!";Write-Host $text}
                                }
                        }
                }
        }

        $LanguageFileName=""

        if ($DBPfad -eq "") {
                #$Abbbruch=$true
            } else {
                
             #   if ($ActiveLanguage -eq "DE-DE") {$LanguageFileName=$DBPfad + "\SprachPaket_DE.sdb"}
              #  if ($ActiveLanguage -eq "EN-DE") {$LanguageFileName=$DBPfad + "\SprachPaket_DE.sdb"}
              #  if ($ActiveLanguage -eq "EN-EN") {$LanguageFileName=$DBPfad + "\SprachPaket_EN.sdb"}
                if ($ActiveLanguage -like "*-DE") {$LanguageFileName=$DBPfad + "\SprachPaket_DE.sdb";if ($DebugMode -eq "true") {$text="DE erkannt";Write-Host $text}}
                if ($ActiveLanguage -like "*-EN") {$LanguageFileName=$DBPfad + "\SprachPaket_EN.sdb";if ($DebugMode -eq "true") {$text="EN erkannt";Write-Host $text}}

                if ($LanguageFileName -eq "") {$LanguageFileName=$DBPfad + "\SprachPaket_EN.sdb";if ($DebugMode -eq "true") {$text="NIX erkannt - EN gestzt";Write-Host $text}}

                if (Test-Path -Path $LanguageFileName) {
                    } else {
                        $text="LanguageFile: (" + $LanguageFileName + ") nicht gefunden!";Write-Host $text
                }
        }
                        
        if ($DebugMode -eq "true") {$text="## GetLanguageFileName endet `t- mit Rückgabe-Parameter LanguageFileName: (" + $LanguageFileName + ")";Write-Host $text}
        
        if ($DebugMode -eq "true") {$text="Notbremse"; read-host $Text}
        return $LanguageFileName
    }

    function SonderzeichenPrepare {
        Param(
            $Quelltext
        )
        ##################################################
        # Version V02
        # vom 8.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($global:DebugMode -eq "true") {$DebugMode = "true"}

        if ($DebugMode -eq "true") {$text="## SonderzeichenPrepare startet `t- mit Parameter Quelltext: (" + $Quelltext + ")";Write-Host $text}

        $DummyText=$Quelltext

        $DummyText2=$DummyText.Replace("$","`$")
        if ($DebugMode -eq "true") {$AusgabeText1="-- 1 `$ wird ersetze durch ```$: " + $DummyText2 + "`n"}
        if ($DebugMode -eq "true") {Write-Host $AusgabeText1}
        $DummyText3=$DummyText.Replace("`"","```"")
        if ($DebugMode -eq "true") {$AusgabeText2="-- 2 `" wird ersetze durch ```": " + $DummyText3 + "`n"}
        if ($DebugMode -eq "true") {Write-Host $AusgabeText2}

        
        if ($DebugMode -eq "true") {$text="## SonderzeichenPrepare endet `t- mit Rückgabe-Parameter DummyText3: (" + $DummyText3 + ")";Write-Host $text}
        return $DummyText3
    }

    function GetLanguageData {
        Param(
            $LanguageDBFileName=""
        )
        ##################################################
        # Version V02
        # vom 18.6.2023
        ##################################################

        $DebugMode = "false"
        if ($global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") {$text="## GetLanguageData startet `t- mit Parameter LanguageDBFileName: (" + $LanguageDBFileName + ")";Write-Host $text}

        $SourceData=""
        if ($LanguageDBFileName -ne "") {
            $SourceData=Get-Content $LanguageDBFileName
        }

        if ($SourceData.Length -eq 0){
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei existiert nicht/oder ist leer"}
        }

        $Erg=""
        foreach ($Zeile in $SourceData){
            $Erg=$Erg + $Zeile + "`n"
        }
        
        if ($DebugMode -eq "true") {$text="## GetLanguageData endet `t- mit Rückgabe-Parameter: (" + $Erg + ")";Write-Host $text}
        return $Erg
    }

    function GetTextFromLanguageDB {
        param (
            $ID=""
        )
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################
    
        $DebugMode = "false"
        if ($global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
        
        if ($DebugMode -eq "true") { $text="## GetTextFromLanguageDB startet zum Auslesen von ID:`t(" + $ID + ")";Write-Host $text}

        $DummyText=""
        $DummyDB="" + $global:SprachDB
        # Achtung Namensaenderung!
        $SourceDataZeilenSpit=$DummyDB.Split("`n")

        if ($SourceDataZeilenSpit.count -lt 30) {
            if ($DebugMode -eq "true") { $text="falsches ZeilenTrennZeichen - neuer Versuch";Write-Host $text}
            $SourceDataZeilenSpit=$DummyDB.Split("`r`n")
        }

        
        if ($DebugMode -eq "true") { $text="LanguageDB hat " + $SourceDataZeilenSpit.count + " Einträge";Write-Host $text}
        for($i=0; $i -lt $SourceDataZeilenSpit.count; $i++){
                
                if ($DebugMode -eq "true") { $text="Eintrag " + $i + " hat Länge " + $SourceDataZeilenSpit[$i].length + " : " + $SourceDataZeilenSpit[$i] + "`n";Write-Host $text}
                if ($SourceDataZeilenSpit[$i].length -ne 0)                            
                {
                    $SourceDataSplit=$SourceDataZeilenSpit[$i].Split("`t")

                    if ($DebugMode -eq "true") { $text="Prüfe Parmeter (" + $SourceDataSplit[1] + ") hat Wert: (" + $SourceDataSplit[2] + ")`n";Write-Host $text}
                    if ($ID -eq $SourceDataSplit[1]){
                        $DummyText=$SourceDataSplit[2]
                        $i = $SourceDataZeilenSpit.count
                        if ($DebugMode -eq "true") { $text="Treffer";Write-Host $text}
                    }
                }   
        } 


        if ($DebugMode -eq "true") {read-host “Press ENTER to continue...”}


        if ($DebugMode -eq "true") {$text="## GetTextFromLanguageDB endet `t- mit Rückgabe-Parameter DummyText: (" + $DummyText + ")";Write-Host $text}
        return $DummyText
    }

    function DetectOsUserLanguage() {
        
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################

        $DebugMode = "false"
        if ($global:DebugMode -eq "true") {$DebugMode = "true"}

        $UserLanguageList=Get-WinUserLanguageList
        $MainLanguage=$UserLanguageList[0].languagetag.ToUpper()

        return $MainLanguage
    }

    function DetectPSVersion() {
        
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################

        $DebugMode = "false"
        if ($global:DebugMode -eq "true") {$DebugMode = "true"}

        $PSVersion=""
        $PSVersion=$PSVersionTable.PSVersion.Major

        return $PSVersion
    }   
    
    function SetGlobalParameterStartMenu(){
        
        ##################################################
        # Version V03
        # vom 18.6.2023
        ##################################################

        $DebugMode = "false"
        if ($global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
       
        if ($DebugMode -eq "true") {$text="## SetGlobalParameterStartMenu startet ";Write-Host $text}

        $Fehler=$false
        $FehlerText=""

        $PSVersion=DetectPSVersion
        $global:BasisPfad=""
        $global:BasisPfad=DetectScriptPath -PowershellVersion  $PSVersion

        if ($global:BasisPfad -eq "") {$Fehler=$true;$FehlerText=$FehlerText + "`nDas aktuelle Verzeichnis konnte nicht ermittelt werden!"}

        if (Test-Path -Path $global:BasisPfad) {} else {New-Item -Path $global:BasisPfad -ItemType Directory}

        $global:SettingsDataFile = $global:BasisPfad + "\Settings.def"
        $global:MenuDataFile = $global:BasisPfad + "\PowershellMenueBand_MenuSources.def"
        $global:FertigesScriptFile = $global:BasisPfad + "\TestExport.ps1"      

        if ($DebugMode -eq "true") {
            $Text="## SetGlobalParameter`t- gesetzte globale Parameter" + "`n"
            $text=$Text + "`t`t- global:BasisPfad:`t" + $global:BasisPfad + "`n"
            $text=$Text + "`t`t- Global:SettingsDataFile:`t" + $global:SettingsDataFile + "`n"
            $text=$Text + "`t`t- Global:MenuDataFile:`t" + $global:MenuDataFile + "`n"
            $text=$Text + "`t`t- global:FertigesScriptFile:`t" + $global:FertigesScriptFile + "`n"
            $text=$Text +  "`n"
            Write-Host  $Text
        }

        $global:MenuData=GetMenuData -MenuDataFile $global:MenuDataFile
        if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:MenuData :(" + $global:MenuData + ")";Write-Host $Text}
        if ($global:MenuData -eq "") {$Fehler=$true;$FehlerText=$FehlerText + "`nDie MenüDaten aus der Datei " + $global:MenuDataFile + " konnten nicht gefunden werden!"}

        $global:SettingsData=GetSettingsData -SourceDataFile $global:SettingsDataFile
        if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:SettingsData :(" + $global:SettingsData + ")";Write-Host $Text}
        if ($global:SettingsData -eq "") {$Fehler=$true;$FehlerText=$FehlerText + "`nDie Einstellungen aus der Datei " + $global:SettingsDataFile + " konnten nicht gefunden werden!"}

        $DebugDummy=GetParameterFromSettings -Parametername "DebugMode"
        if ($DebugDummy -eq "1") {$global:DebugMode= "true"}
        $LogDummy=GetParameterFromSettings -Parametername "LogMode"
        if ($LogDummy -eq "1") {$global:LogMode= "true"}

        $Language=GetParameterFromSettings -Parametername "Sprache"
        if ($Language -eq "") {
                $global:Language=DetectOsUserLanguage 
                if ($DebugMode -eq "true") { $text="## `t- Sprach-Feld in den Settings ist leer => erkannte User-Profil-Haupt-Sprache:`t" + $global:Language + " wird benutzt"; Write-Host $text}
            } else {
                $global:Language=$Language.ToUpper()
                if ($DebugMode -eq "true") { $text="## `t- Sprach-Feld in den Settings ist definiert:`t" + $global:Language + " wird benutzt"; Write-Host $text}
        }

        $SprachDBFileName=GetLanguageFileName -ActiveLanguage $global:Language
        if ($DebugMode -eq "true") {$Text="## `t- Parameter SprachDBFileName :(" + $SprachDBFileName + ")";Write-Host $Text}
        if ($SprachDBFileName -eq "") {
            $Fehler=$true;$FehlerText=$FehlerText + "`nDie SprachDBFileName ist leer!: " + $SprachDBFileName 
            if ($DebugMode -eq "true") {$Text="## `t- Parameter SprachDBFileName ==> Fehler!";Write-Host $Text}
        }

        $MyDummy=GetLanguageData -LanguageDBFileName  $SprachDBFileName 
        if ($DebugMode -eq "true") {$Text="## `t- Eingelesene SprachDB (MyDummy):(" + $MyDummy + ")";Write-Host $Text}
        $global:SprachDB="" + $MyDummy
        if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:SprachDB :(" + $global:SprachDB + ")";Write-Host $Text}
        if ($global:SprachDB -eq "") {
            $Fehler=$true
            $FehlerText=$FehlerText + "`nDie Datei " + $SprachDBFileName + " konnten nicht gefunden werden!"
            if ($DebugMode -eq "true") {$Text="## `t- SprachDBFehler: " + $FehlerText;Write-Host $Text}
        }
        
        
        $MyDummy=TranslateMenuData
        if ($DebugMode -eq "true") {$Text="## `t- Menü-Texte übersetzen (MyDummy):(" + $MyDummy + ")";Write-Host $Text}
        $global:MenuData = $MyDummy
        if ($global:MenuData -eq "") {
            $Fehler=$true
            $FehlerText=$FehlerText + "`nDie Übersetung der MenüDatei war nicht erfolgreich!"
            if ($DebugMode -eq "true") {$Text="## `t- MenüDatenFehler: " + $FehlerText;Write-Host $Text}
        }



        if ($DebugMode -eq "true") {$text="Notbremse im SetGlobalParameterStartMenu"; read-host $Text}
        if ($Fehler -eq $true) { $Ausgabe=$FehlerText} else { $Ausgabe="Ok"}
        
        if ($DebugMode -eq "true") {$text="## SetGlobalParameterStartMenu endet `t- mit Rückgabe-Parameter Ausgabe: (" + $Ausgabe + ")";Write-Host $text}
        return $Ausgabe
    }
     
    function TranslateMenuData() {
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################

        $DebugMode = "false"
        if ($global:DebugMode -eq "true") {$DebugMode = "true"}

       # $DebugMode = "true"
        
        if ($DebugMode -eq "true") { $text="## TranslateMenuData startet";Write-Host $text}

        $MenuData=@()
        $MenuData=$MenuData + $global:MenuData
        if ($DebugMode -eq "true") { $text="## `t- MenuData:`t(" + $MenuData + ")";Write-Host $text}

        if ($DebugMode -eq "true") {$text="## `t- ZeilenAnzahl: (" + $MenuData.count + ")";Write-Host $text}

        $NeuesMenu=""
        foreach ($MenuZeile in $MenuData) {
            $ZeilenSplit= $MenuZeile.split(",")
            $Lnr=$ZeilenSplit[0]
            $Name=$ZeilenSplit[2]
            $Description=$ZeilenSplit[6]
            if ($DebugMode -eq "true") {$text="## `t- Lnr: (" + $Lnr + ")`t- Name: (" + $Name + ")`t- Description: (" + $Description + ")";Write-Host $text}

            $TrName=""
            $TrDescription=""
            if ($Lnr -ne "") {
                $TrName=GetTextFromLanguageDB -ID ("1_M_" + $Lnr + "_1")
                $TrDescription=GetTextFromLanguageDB -ID ("1_M_" + $Lnr + "_2")
                if ($DebugMode -eq "true") {$text="## `t- TrName: (" + $TrName + ")`t- TrDescription: (" + $TrDescription + ")";Write-Host $text}
                if ($TrName -ne "") {$Name=$TrName}
                if ($TrDescription -ne "") {$Description=$TrDescription}

                try {
                    $NeuesMenu=$NeuesMenu + $Lnr.Trim() + ", " + $ZeilenSplit[1].Trim()
                    $NeuesMenu=$NeuesMenu + ", " + $Name.Trim() + ", " + $ZeilenSplit[3].Trim()
                    $NeuesMenu=$NeuesMenu + ", " + $ZeilenSplit[4].Trim() + ", " + $ZeilenSplit[5].Trim()
                    $NeuesMenu=$NeuesMenu + ", " + $Description.Trim() + "`n" 
                } catch{}
            }

        }
        
        if ($DebugMode -eq "true") {$text="## `t- NeuesMenu: (`n" + $NeuesMenu + "`n)";Write-Host $text}
        if ($DebugMode -eq "true") {$text="Notbremse"; read-host $Text}
        
        if ($NeuesMenu -ne "") {$MenuData = $NeuesMenu}
        
        if ($DebugMode -eq "true") {$text="## TranslateMenuData endet `t- mit Rückgabe-Parameter MenuData: (" + $MenuData + ")";Write-Host $text}
        if ($DebugMode -eq "true") {$text="Notbremse"; read-host $Text}
        return $MenuData
    }

#endregion tools


function ErzeugeSourceCode() {
    ##################################################
    # Version V02
    # vom 11.4.2023
    ##################################################

    $DebugMode = "false"
    if ($global:DebugMode -eq "true") {$DebugMode = "true"}

    $ErgText1=""
    $ErgText2=""
    $ErgText3=""
    $ErgText4=""
    $ErgText5=""
    $ErgText6=""

    # Auftrennen in Zeilen
    $SourceDataZeile =$global:MenuData.Split("`n")
    for ($i=0; $i -lt $SourceDataZeile.length; $i++){ 
    
        if ($DebugMode -eq "true") {$AusgabeText="Zeile " + $i + ": "+ "`t"  + $SourceDataZeile[$i]}
        if ($DebugMode -eq "true") {Write-Host $AusgabeText}

        # erste Zeile ist Ueberschrift ... ignorieren
        if ($i -ne 0) {
            # leere Zeilen ignoroieren
            if ($SourceDataZeile[$i] -ne "") {
                # Auftrennen in ELemente
                $Lnr=""
                $BaseLnr=""
                $Name=""
                $EndPoint=""
                $Action=""
                $Attribute=""
                $Description=""

                if ($DebugMode -eq "true") {$AusgabeTextSpalten=""}
                $SourceDataSpalte =$SourceDataZeile[$i].Split(",")
                for ($j=0; $j -lt $SourceDataSpalte.length; $j++){ 
                    if ($DebugMode -eq "true") {$AusgabeTextSpalten=$AusgabeTextSpalten + $SourceDataSpalte[$j] + "`t"}

                    if ($j -eq "0") {$Lnr=$SourceDataSpalte[$J].trim()}
                    if ($j -eq "1") {$BaseLnr=$SourceDataSpalte[$J].trim()}
                    if ($j -eq "2") {$Name=$SourceDataSpalte[$J].trim()}
                    if ($j -eq "3") {$EndPoint=$SourceDataSpalte[$J].trim()}
                    if ($j -eq "4") {$Action=$SourceDataSpalte[$J].trim()}
                    if ($j -eq "5") {$Attribute=$SourceDataSpalte[$J].trim()}
                    if ($j -eq "6") {$Description=$SourceDataSpalte[$J].trim()}


                }
                $DescriptionOld=$Description 
                       
                $Descriptiontemp=""
                if ($Description.Length -gt 0) {
                    $Descriptiontemp=SonderzeichenPrepare -Quelltext $Description
                    $Description=$Descriptiontemp
                }


                if ($DebugMode -eq "true") { $AusgabeTextSpalten1="V1: Description(original):"+ "`t" +  $DescriptionOld + "`n" + "    Description(angepasst):"+ "`t" + $Description + "`n Ende V1" + "`n"}
                if ($DebugMode -eq "true") {Write-Host $AusgabeTextSpalten1}


                if ($DebugMode -eq "true") { $AusgabeTextSpalten="alles:    "+ "`t"  +$AusgabeTextSpalten + "`n"}
                if ($DebugMode -eq "true") {Write-Host $AusgabeTextSpalten}
                if ($DebugMode -eq "true") { $AusgabeTextSpalten="Parameter:"+ "`t" +$Lnr + "`t" + $BaseLnr + "`t" + $Name + "`t" + $EndPoint + "`t" + $Action + "`t" + $Attribute + "`t" + $Description+ "`n"}
                if ($DebugMode -eq "true") {Write-Host $AusgabeTextSpalten}
                if ($DebugMode -eq "true") { $AusgabeTextSpalten="V2: Description(original):"+ "`t" +  $DescriptionOld + "`n" + "Description(angepasst):"+ "`t" + $Description + "`n"}
                if ($DebugMode -eq "true") {Write-Host $AusgabeTextSpalten}

    
                $ErgText2=$ErgText2 + "`$menu" + $lnr + " = New-Object System.Windows.Forms.ToolStripMenuItem"+ "`n"

                $ErgText4=$ErgText4 + "`$menu" + $lnr + ".Text = `"" + $Name + "`"`n"

                if ($EndPoint -eq 1) {
                    $ErgText4=$ErgText4 + "`$menu" + $lnr + ".Add_Click({Fkt"  + $Lnr + "})" + "`n"
                }

               if ($BaseLnr -eq "0") {
                    $ErgText4=$ErgText4 + "# Basemenu.item muss es sein (wegen BaseLnr: " + $BaseLnr  + ") `n"
                    $ErgText4=$ErgText4 + "[void]`$menuMain.Items.Add(" + "`$menu" + $lnr + ")"+ "`n"
                } else {
                    $ErgText4=$ErgText4 + "# menuX muss es sein (wegen BaseLnr: " + $BaseLnr  + ") `n"
                    $ErgText4=$ErgText4 + "[void]`$menu" + $BaseLnr + ".DropDownItems.Add(" + "`$menu" + $lnr + ")"+ "`n"
                }

                if ($EndPoint -eq "1") {

                    $ErgText5=$ErgText5 + "function Fkt"  + $Lnr  + "{"+ "`n"

                    if ($Description -ne "") {
                        $msgboxtext="`"" + $Description + "`""
                        $msgboxtitel="`"Fkt" + $Lnr +  "  " + $Name + "`""
                        if ($DebugMode -eq "true") {Write-Host $msgboxtext}

                        $ErgText5=$ErgText5 + "    `$erg=[System.Windows.Forms.MessageBox]::Show(" + $msgboxtext + ", " + $msgboxtitel + ", `"1`", `"None`" )"+ "`n"
                        if ($DebugMode -eq "true") {$ErgText5=$ErgText5 + "    Write-Host `$erg"+ "`n"}
                        $ErgText5=$ErgText5 + "    If (`$erg -eq `"OK`") {"+ "`n"

                        if ($Action.ToUpper().Trim() -eq "EXIT"){
                                $ErgText5=$ErgText5 + "    `$main_Form.Close()`n"
                            } else {
                                if ($Action.substring(0,2) -eq """&") {
                                    $ErgText5=$ErgText5 + "        # hier muss " + $Action + " gestartet werden - direkt-Powershell-start mit & `n"
                                    if ($Action -like "*:\*") {
                                            $ErgText5=$ErgText5 + "        & " + $Action.substring(3,($Action.length-4)) + "`n"
                                        } else {
                                            $ErgText5=$ErgText5 + "        & " + $global:BasisPfad + "\" + $Action.substring(3,($Action.length-4)) + "`n"
                                            
                                    }

                                } else {             
                                    $ErgText5=$ErgText5 + "        # hier muss " + $Action + " gestartet werden`n"
                                    if ($EndPoint.Trim() -eq "1") {
                                        $ErgText5=$ErgText5 + "        # EndPoint: " + $EndPoint + " erkannt`n"


                                        if ($DebugMode -eq "true") {Write-Host $Action}
                                        if ($Attribute.Length -eq 0){
                                                $ErgText5=$ErgText5 + "        Start-Process -FilePath " + $Action + " -Wait`n"
                                            } else {
                                                $ErgText5=$ErgText5 + "        Start-Process -FilePath " + $Action + " -ArgumentList " + $Attribute + " -Wait`n"
                                        }
                                    }

                                }
                                    $ErgText5=$ErgText5 + "    }"+ "`n"
                        }
                        $ErgText5=$ErgText5 + "}"+ "`n"+ "`n"
                    } else {
                        if ($Action.ToUpper().Trim() -eq "EXIT"){
                                $ErgText5=$ErgText5 + "    `$main_Form.Close()`n"
                            } else {

                            if ($Action.substring(0,2) -eq """&") {
                                
                                $ErgText5=$ErgText5 + "        # hier muss " + $Action + " gestartet werden - direkt-Powershell-start mit & `n"

                                    if ($Action -like "*:\*") {
                                            $ErgText5=$ErgText5 + "        & " + $Action.substring(3,($Action.length-4)) + "`n"
                                        } else {
                                            $ErgText5=$ErgText5 + "        & " + $global:BasisPfad + "\" + $Action.substring(3,($Action.length-4)) + "`n"   
                                    }

                            } else {
                                     
                                $ErgText5=$ErgText5 + "        # hier muss " + $Action + " gestartet werden`n"
                                if ($EndPoint.Trim() -eq "1") {
                                    $ErgText5=$ErgText5 + "        # EndPoint: " + $EndPoint + " erkannt`n"

                
                                    if ($DebugMode -eq "true") {Write-Host $Action}
                                    if ($Attribute.Length -eq 0){
                                            $ErgText5=$ErgText5 + "        Start-Process -FilePath " + $Action + " -Wait`n"
                                        } else {
                                            $ErgText5=$ErgText5 + "        Start-Process -FilePath " + $Action + " -ArgumentList " + $Attribute + " -Wait`n"
                                    }
                                 }
                             }
                        }
                        $ErgText5=$ErgText5 + "}"+ "`n"+ "`n"
                    }
                }
            }
            
        }

    }

    #region BasicFormDefinitions
        $HeaderText=GetTextFromLanguageDB -ID ("1_1")

        $ErgText1=$ErgText1 + "cls"+ "`n"
        $ErgText1=$ErgText1 + "`n"
        $ErgText1=$ErgText1 + "Add-Type -assembly System.Windows.Forms"+ "`n"
        $ErgText1=$ErgText1 + "`n"
        $ErgText1=$ErgText1 + "`$main_form = New-Object System.Windows.Forms.Form"+ "`n"
        $ErgText1=$ErgText1 + "`$main_form.Text ='" + $HeaderText + "'"+ "`n" # seither Powershell StammbaumManager V1.0
        $ErgText1=$ErgText1 + "`$main_form.Width = 600"+ "`n"
        $ErgText1=$ErgText1 + "`$main_form.Height = 400"+ "`n"

        $ErgText1=$ErgText1 + "`$main_form.AutoSize = `$true"+ "`n"

    
        $ErgText1=$ErgText1 + "`$menuMain         = New-Object System.Windows.Forms.MenuStrip"+ "`n"
        $ErgText1=$ErgText1 + "`$mainToolStrip    = New-Object System.Windows.Forms.ToolStrip"+ "`n"

    #endregion BasicFormDefinitions

    #region BasisStripDefinition
        $ErgText3=$ErgText3 + "#region BindYourMenuToTheGUIForm"+ "`n"
        $ErgText3=$ErgText3 + "    `$main_form.MainMenuStrip = `$menuMain"+ "`n"
        $ErgText3=$ErgText3 + "    `$main_form.Controls.Add(`$menuMain)"+ "`n"
        $ErgText3=$ErgText3 + "    # add Toostrip line"+ "`n"
        $ErgText3=$ErgText3 + "    # [void]`$main_Form.Controls.Add(`$mainToolStrip)"+ "`n"
        $ErgText3=$ErgText3 + "#endregion BindYourMenuToTheGUIForm"+ "`n"

    
        $ErgText3=$ErgText3 + " # Show Menu Bar"+ "`n"
        $ErgText3=$ErgText3 + "[void]`$main_Form.Controls.Add(`$menuMain)"+ "`n"
    #endregion BasisStripDefinition

    #region GuiGestaltung
    $ErgText6= @"
        # hier muss alles rein was in die GUI muss
        #
        ################################################################
        #   Achtung:
        #        Sonderzeichen wie bei Variablen muessen maskiet werden.
        #        also :   `$Variable
        #        anstatt: $Variable
        ################################################################


        # zum Beispiel ein Label text
        #  `$objLabel = New-Object System.Windows.Forms.Label
        #  `$objLabel.Location = New-Object System.Drawing.Size(300,60)
        #  `$objLabel.Size = New-Object System.Drawing.Size(800,20)
        #  `$objLabel.Text = "Das ist ein vollautomatisches Menü-Generierungs-Script"
        #  `$main_form.Controls.Add(`$objLabel)



        
"@ + "`n"# Achtung - das muß am Zeilenbeginn stehen - nix mit TAB!!
    #endregion GuiGestaltung


    $GesText=""
    $GesText=$ErgText5 + $ErgText1 + $ErgText2 + $ErgText3 + $ErgText4   + $ErgText6 + "`$main_form.ShowDialog()"+ "`n"

    return $GesText
}

#region Main

    $DebugMode = "false"
    if ($global:DebugMode -eq "true"){$DebugMode="true"}
    #$DebugMode="true"


    if ($GetVersionInfo -eq "true") {            
            $ErgText=$ErgText + "Version:`t" + $Version + "`n"
            $ErgText=$ErgText + "Stand:`t" + $Stand + "`n"
            $ErgText=$ErgText + "Developper:`t" + $Developper + "`n"
            return  $ErgText

        } else {

            if ($DebugMode -eq "true"){$global:Debugmode="true"} else {$global:Debugmode="false"}
            if ($LogMode -eq "true"){$global:LogMode="true"} else {$global:LogMode="false"}


            if ($DebugMode -eq "true") { $text="#######################################################################################`n## Stammbaum_Startmenu.ps1 startet im Debugmode`n drück [enter], dann geht`s los`n"; Write-Host $text; read-host $Text}

            $global:Language=""         # installierte User-Profil-SPrache
            $global:BasisPfad=""        # FS-Pfad des Stammbaum-Tools
            $global:MenuDataFile=""     # Datei-Pfad der Menu-Definitionen
            $global:MenuData=""         # eingelesene Menu-Definitionen
            $global:SprachDB=""         # Inhalt der aktuellen SprachDB-Datei

            $global:SettingsDataFile=""
            $global:SettingsData=""
            $global:FertigesScriptFile=""



            $Vorbereitung=SetGlobalParameterStartMenu

            if ($Vorbereitung -eq "OK") {

                    #Write-Host ($DebugMode)
                    #Write-Host ($LogMode) 
                    #read-host "was"

                    $GesText = ErzeugeSourceCode
                    $GesText| Out-File -FilePath $global:FertigesScriptFile

                    if ($DebugMode -eq "true") {read-host “Press ENTER to continue...”}
                    #read-host “Press ENTER to continue...”

                    # FertigesScript starten
                    & $global:FertigesScriptFile

                    # FertigesScript loeschen
                    Remove-Item $global:FertigesScriptFile
                } else {
                    Write-Host "Fehler in der Vorbereitung - bitte Verzeichnisse prüfen!"
            }
    }
#endregion Main