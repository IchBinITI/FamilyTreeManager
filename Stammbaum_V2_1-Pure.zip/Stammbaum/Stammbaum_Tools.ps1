﻿param (
    $DebugMode="false",
    $GetVersionInfo="false"
)

cls

##################################################
$Version="0.13"
$Stand="18.06.2023"
$Developper="na ich"
##################################################


#region Tools

    function DetectScriptPath {
        Param(
            $PowershellVersion
        )
        ##################################################
        # Version V02
        # vom 8.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        if ($DebugMode -eq "true") {
            $text="DetectScriptPath Startet mit Parameter`nPowershellVersion:`t" + $PowershellVersion + "`nDebugMode:`t" + $DebugMode + "`n"
            Write-Host  $Text
        }

        # gezielte Versuch anhand der installierten PS-Version den Script-Pfad zu ermitteln
        if ($PowershellVersion -gt 2){
            $BasisPfad=$PSScriptRoot
        }
        if ($PowershellVersion -gt 1){
            $BasisPfad=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath('.\')
        }

        # falls nichts funktioniert, dann wird stumpf versucht
        if ($BasisPfad -eq ""){
            $BasisPfad=$PSScriptRoot
        }
        if ($BasisPfad -eq ""){
            $BasisPfad=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath('.\')
        }
        if ($BasisPfad -eq ""){
            $BasisPfad=split-path -parent $MyInvocation.MyCommand.Definition
        }

        if ($DebugMode -eq "true") {
            $a=$PSScriptRoot
            $b=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath('.\')
            $c=split-path -parent $MyInvocation.MyCommand.Definition

            $Text="Ermitteln des ScriptPfades`n Methode 1: " + $a + "`n" + "Methode 2: " + $b + "`n" + "Methode 3: " + $c + "`n"
            $text=$Text + "DetectScriptPath endet mit Rueckgabe-Parameter`nBasisPfad:`t" + $BasisPfad + "`n"
            Write-Host  $Text
        }
        return $BasisPfad
}

    function DetectPSVersion() {
        
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        $PSVersion=""
        $PSVersion=$PSVersionTable.PSVersion.Major

        return $PSVersion
    }   

    function GetSettingsData {
        Param(
            $SourceDataFile
        )

        ##################################################
        # Version V04
        # vom 11.6.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") {$Text="## GetSettingsData startet `t- mit Parameter SourceDataFile: (" + $SourceDataFile + ")";Write-Host $text}
        $SourceData=Get-Content $SourceDataFile

        if ($SourceData.Length -eq 0){
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei existiert nicht/oder ist leer"}


            # Standard-Trennzeichen ist TAB ( `t )
            $SourceData="Lnr	Kategorie	Namen	Wert	Beschreibung" + "`n"
            $SourceData=$SourceData + "1`tallgemein`tDatenquelle`t1`tSpeicherort der Daten, 1=interne ExcelSheets (noch nicht verfügber: , 2=SQL-DB, 3=Spreadsheet-Datei)" + "`n"
            $SourceData=$SourceData + "2`tallgemein`tFeldTrenner`tTAB`tSpalten-Trennzeichen aller interner Datensätze" + "`n"

            $SourceData=$SourceData + "3`tallgemein`tSprache`t`tSprache des Tools (DE-DE, EN-EN, ...). bleibt der Parameter leer, so wird die aktive Sprach-Einstellung des Systems benutzt" + "`n"
            $SourceData=$SourceData + "4`tFileSystem`tExportZielPfad`t" +  $BasisPfad + "\ZielDateien`tZielordner für DatenExporte" + "`n"
            $SourceData=$SourceData + "5`tFileSystem`tDatenZielPfad`t" +  $BasisPfad + "\DBDaten`tOrdner der DB-Daten" + "`n"
            $SourceData=$SourceData + "6`tFileSystem`tPersonenDatei`tPersonen.sdb`tDB-Datei für Personendaten" + "`n"
            $SourceData=$SourceData + "7`tFileSystem`tAdresseDatei`tAdressen.sdb`tDB-Datei für Adressdaten" + "`n"
            $SourceData=$SourceData + "8`tFileSystem`tKnotenDatei`tKnoten.sdb`tDB-Datei für Knotendaten" + "`n"
            $SourceData=$SourceData + "9`tDarstellung`tGeborenZeichen`t*`tZeichen für ""geboren""" + "`n"
            $SourceData=$SourceData + "10`tDarstellung`tGestorbenZeichen`t[char]0x2020`tZeichen für ""gestorben""" + "`n"
            $SourceData=$SourceData + "11`tDarstellung`tHochzeitZeichen`t[char]0x26AD`tZeichen für ""Hochzeit""" + "`n"
            $SourceData=$SourceData + "12`tDarstellung`tScheidungsZeichen`t[char]0x26AE`tZeichen für ""Trennung""" + "`n"
            $SourceData=$SourceData + "13`tDarstellung`tNodeBreite`t120`tBreite der Person bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "14`tDarstellung`tNodeHoehe`t100`tHöhe der Person bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "15`tDarstellung`tPersonBreite`t100`tBreite der Verbindungskästen bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "16`tDarstellung`tPersonHoehe`t130`tHöhe der Verbindungskästen bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "17`tDarstellung`tZeilenabstand`t50`tZeilenabstand zwischen den Kästen bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "18`tDarstellung`tSpaltenAbstand`t50`tHorrizontaler Abstand zwischen den Kästen bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "19`tDarstellung`tHintergrundFarbe`tgreen`tFarbe des Seiten-Hintergrunds bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "20`tDarstellung`tPersonenFarbe`tgrey`tFarbe der Personenkaestchen bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "21`tDarstellung`tWdhPersonenFarbe`tgreen`tFarbe der Personenkaestchen bei Wiederholungen (weiterer Partner) bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "22`tDarstellung`tKnotenFarbe`tblue`tFarbe der Personenkaestchen bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "23`tDarstellung`tPersonenSchriftFarbe`t#ada`tFarbe der Personenkaestchen bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "24`tDarstellung`tWdhPersonenSchriftFarbe`t#ada`tFarbe der Personenkaestchen bei Wiederholungen (weiterer Partner) bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "25`tDarstellung`tKnotenSchriftFarbe`t#dad`tFarbe der Personenkaestchen bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "26`tDarstellung`tPersonenSchriftGroesse`t12`tGroesse der Schrift (in px) in den Personenkaestchen bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "27`tDarstellung`tWdhPersonenSchriftGroesse`t12`tGroesse der Schrift (in px) in den Personenkaestchen bei Wiederholungen (weiterer Partner) bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "28`tDarstellung`tKnotenSchriftGroesse`t12`tGroesse der Schrift (in px) in den Personenkaestchen bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "29`tDarstellung`tPersonInhalt`t+,+,-,+,+,+,-,-,-,-,-,-,-`tInhalt der Personenkaestchen bei Objektbasierter Darstellung (Lnr,Vorname,ZusatzVorname,Nachname,GebName,GebDatum,GeburtsOrt,Sterbedatum,SterbeOrt_Friedhof,Bemerkung,religion,geschl,nationalität)" + "`n"
            $SourceData=$SourceData + "30`tDarstellung`tKnotenInhalt`t+,+,-,-`tInhalt der Knotenkaestchen bei Objektbasierter Darstellung (Lnr,TrauDatum,TrauOrt,ScheidungsDatum)" + "`n"
            $SourceData=$SourceData + "31`tDebugging`tDebugMode`tWAHR`tDebug-Log-Datei wird erzeugt" + "`n"
            $SourceData=$SourceData + "32`tDebugging`tLogMode`t1`t(an = 1, aus = 0) Log-Datei(en) werden erzeugt" + "`n"
            $SourceData=$SourceData + "33`tDebugging`tLogFileZielPfad`t" +  $BasisPfad + "\ZielDateien`tSpeicherPfad der Debug-Log-Datei" + "`n"
            $SourceData=$SourceData + "34`tDebugging`tLogFileDateiname`tDebugLog.log`tDateiname der Debug-Log-Datei" + "`n"
            $SourceData=$SourceData + "35`tFileSystem`tSeleniumPfad	`t`tPfad zum Selenium-Verzeichnis (""...\selenium-powershell-master"")" + "`n"
            $SourceData=$SourceData + "36`tFileSystem`tChromeDriverPfad`t`tPfad zum ChromeDriver (""...\chromedriver\win32\113"")" + "`n"
            $SourceData=$SourceData + "37`tFileSystem`tGoogleMapsUsername`t`tUsername (mail adresse) zum Anmelden bei Google Maps" + "`n"
            $SourceData=$SourceData + "38`tFileSystem`tGoogleMapsPassword`t`tPasswort (passend zur mail adresse) zum Anmelden bei Google Maps" + "`n"
            $SourceData=$SourceData + "39`tDarstellung`tGoogleMapsImportDetails`t+,+,+,+,-,+`tInhalt, der bei Google Maps dargestellt werden soll (GebOrt,WohnOrt, SterbeOrt,HochzeitsOrt,ScheidungsOrt,Verbinder)" + "`n"
            $SourceData=$SourceData + "40`tDarstellung`tGoogleMapsPosIconGebOrt`t1844`tIcon-Nummer, das bei Google Maps als Geburtsort dargestellt werden soll" + "`n"
            $SourceData=$SourceData + "41`tDarstellung`tGoogleMapsPosFarbeGebOrt`t1`tFarb-Nummer, in der bei Google Maps der Geburtsort dargestellt werden soll (0=schwarz, 1=dunkelgrün, 2=lila, 3=rot, 4=gelb)" + "`n"
            $SourceData=$SourceData + "42`tDarstellung`tGoogleMapsPosIconWohnOrt`t1603`tIcon-Nummer, das bei Google Maps als Wohnort dargestellt werden soll" + "`n"
            $SourceData=$SourceData + "43`tDarstellung`tGoogleMapsPosFarbeWohnOrt`t2`tFarb-Nummer, in der bei Google Maps der Wohnort dargestellt werden soll (0=schwarz, 1=dunkelgrün, 2=lila, 3=rot, 4=gelb)" + "`n"
            $SourceData=$SourceData + "44`tDarstellung`tGoogleMapsPosIconSterbeOrt`t1670`tIcon-Nummer, das bei Google Maps als Sterbeort dargestellt werden soll" + "`n"
            $SourceData=$SourceData + "45`tDarstellung`tGoogleMapsPosFarbeSterbeOrt`t0`tFarb-Nummer, in der bei Google Maps der Sterbeort dargestellt werden soll (0=schwarz, 1=dunkelgrün, 2=lila, 3=rot, 4=gelb)" + "`n"
            $SourceData=$SourceData + "46`tDarstellung`tGoogleMapsPosIconHochzeitsOrt`t1592`tIcon-Nummer, das bei Google Maps als Hochzeitsort dargestellt werden soll" + "`n"
            $SourceData=$SourceData + "47`tDarstellung`tGoogleMapsPosFarbeHochzeitsOrt`t3`tFarb-Nummer, in der bei Google Maps der Hochzeitsort dargestellt werden soll (0=schwarz, 1=dunkelgrün, 2=lila, 3=rot, 4=gelb)" + "`n"
            $SourceData=$SourceData + "48`tDarstellung`tGoogleMapsPosIconScheidungsOrt`t1516`tIcon-Nummer, das bei Google Maps als Scheidungsort dargestellt werden soll" + "`n"
            $SourceData=$SourceData + "49`tDarstellung`tGoogleMapsPosFarbeScheidungsOrt`t4`tFarb-Nummer, in der bei Google Maps der Scheidungsort dargestellt werden soll (0=schwarz, 1=dunkelgrün, 2=lila, 3=rot, 4=gelb)" + "`n"
            $SourceData=$SourceData + "50`tDarstellung`tGoogleMapsFarbPalette`tVIpgJd-nEeMgc-eEDwDf12,VIpgJd-nEeMgc-eEDwDf20,VIpgJd-nEeMgc-eEDwDf11,VIpgJd-nEeMgc-eEDwDf14,VIpgJd-nEeMgc-eEDwDf4`tFarb-Namen-Liste - Liste der benutztenm Farben bei Google Maps (standard: schwarz, 1=dunkelgrün, lila, rot, gelb)" + "`n"


            $SourceData| Out-File -FilePath $SourceDataFile
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei wurde erzeugt"}
        
            $SourceData=Get-Content $SourceDataFile
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei wurde frisch eingelesen"}

            if ($SourceData.Length -eq 0){
                if ($DebugMode -eq "true") {Write-Host "Settings-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!"}
                #read-host “Press ENTER to continue...”
                $erg=[System.Windows.Forms.MessageBox]::Show("Settings-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!", "FileSystem Zugriffs-Fehler", "1", "None" )
                $host.Exit()
            }
        }
        
        if ($DebugMode -eq "true") {$text= "## GetSettingsData endet `t- mit Rückgabe-Parameter SourceData: (" + $SourceData + ")";Write-Host $text}
        return $SourceData
    }

    function GetParameterFromSettings {
        param (
            $Parametername=""
        )
        ##################################################
        # Version V02
        # vom 7.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
   
        if ($DebugMode -eq "true") {$text= "## GetParameterFromSettings startet `t- mit Parameter Parametername: (" + $Parametername + ")";Write-Host $text}

        $DummyText=""
        # Achtung Namensaenderung!
        if ($DebugMode -eq "true") { $text="global:SettingsData: " + $global:SettingsData;Write-Host $text}
        $SourceDataZeilenSpit=$global:SettingsData.Split("`n")

        for($i=0; $i -lt $SourceDataZeilenSpit.count; $i++){
                if ($DebugMode -eq "true") { $text="prüfe Parameter-Zeile " + $i + ": " + $SourceDataZeilenSpit[$i];Write-Host $text}

                if ($SourceDataZeilenSpit[$i].length -ne 0)                            
                {
                    $SourceDataSplit=$SourceDataZeilenSpit[$i].Split("`t")

                    if ($DebugMode -eq "true") { $text="Parmeter " + $SourceDataSplit[2];Write-Host $text}
                    if ($Parametername -eq $SourceDataSplit[2]){
                        
                        $DummyText=$SourceDataSplit[3]

                        if ($Parametername -eq "LogMode"){
                            if ($SourceDataSplit[3] -eq "wahr"){
                                    $DummyText="true"
                                } elseif ($SourceDataSplit[3] -eq "true"){
                                    $DummyText="true"
                                }elseif ($SourceDataSplit[3] -eq "falsch"){
                                    $DummyText="false"
                                } elseif ($SourceDataSplit[3] -eq "false"){
                                    $DummyText="false"
                            }
                        } 
                        if ($Parametername -eq "DebugMode"){
                            if ($SourceDataSplit[3] -eq "wahr"){
                                    $DummyText="true"
                                } elseif ($SourceDataSplit[3] -eq "true"){
                                    $DummyText="true"
                                } elseif ($SourceDataSplit[3] -eq "falsch"){
                                    $DummyText="false"
                                } elseif ($SourceDataSplit[3] -eq "false"){
                                    $DummyText="false"
                            }
                        } 
                    }
                }   
        } 
    
        if ($DebugMode -eq "true") {$text="## GetParameterFromSettings endet `t- mit Rückgabe-Parameter DummyText: (" + $DummyText + ")";Write-Host $text}
        return $DummyText
    }
        
    function DetectOsUserLanguage() {
        
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        $UserLanguageList=Get-WinUserLanguageList
        $MainLanguage=$UserLanguageList[0].languagetag.ToUpper()

        return $MainLanguage
    }

    function GetLanguageFileName() {
        Param(
            $ActiveLanguage
        )
        ##################################################
        # Version V02
        # vom 11.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        
        if ($DebugMode -eq "true") {$text="## GetLanguageFileName startet `t- mit Parameter ActiveLanguage: (" + $ActiveLanguage + ")";Write-Host $text}

        $DBPfad=GetParameterFromSettings -Parametername "DatenZielPfad"

        if (Test-Path -Path $DBPfad) {
            } else {
                $DBPfad = $global:BasisPfad + "\DBDaten"
                if (Test-Path -Path $DBPfad) {
                    } else {
                        $DBPfad = $global:BasisPfad
                }
        }

        if ($ActiveLanguage -eq "DE-DE") {$LanguageFileName=$DBPfad + "\SprachPaket_DE.sdb"}
        if ($ActiveLanguage -eq "EN-EN") {$LanguageFileName=$DBPfad + "\SprachPaket_EN.sdb"}

        if ($LanguageFileName -eq "") {$LanguageFileName=$DBPfad + "\SprachPaket_EN.sdb"}

        if (Test-Path -Path $LanguageFileName) {
            } else {
                $text="LanguageFile: (" + $LanguageFileName + ") nicht gefunden!";Write-Host $text
        }
                        
        if ($DebugMode -eq "true") {$text="## GetLanguageFileName endet `t- mit Rückgabe-Parameter LanguageFileName: (" + $LanguageFileName + ")";Write-Host $text}
        return $LanguageFileName
    }

    function GetLanguageData {
        Param(
            $LanguageDBFileName=""
        )
        ##################################################
        # Version V02
        # vom 18.6.2023
        ##################################################

        $DebugMode = "false"
        if ($global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") {$text="## GetLanguageData startet `t- mit Parameter LanguageDBFileName: (" + $LanguageDBFileName + ")";Write-Host $text}

        $SourceData=""
        if ($LanguageDBFileName -ne "") {
            $SourceData=Get-Content $LanguageDBFileName
        }

        if ($SourceData.Length -eq 0){
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei existiert nicht/oder ist leer"}
        }

        $Erg=""
        foreach ($Zeile in $SourceData){
            $Erg=$Erg + $Zeile + "`n"
        }
        
        if ($DebugMode -eq "true") {$text="## GetLanguageData endet `t- mit Rückgabe-Parameter: (" + $Erg + ")";Write-Host $text}
        return $Erg
    }


    function GetTextFromLanguageDB {
        param (
            $ID=""
        )
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        if ($DebugMode -eq "true") { $text="## GetTextFromLanguageDB startet zum Auslesen von ID:`t" + $ID;Write-Host $text}

        $DummyText=""
        # Achtung Namensaenderung!
        $SourceDataZeilenSpit=$Global:SprachDB.Split("`n")

        for($i=0; $i -lt $SourceDataZeilenSpit.count; $i++){

                if ($SourceDataZeilenSpit[$i].length -ne 0)                            
                {
                    $SourceDataSplit=$SourceDataZeilenSpit[$i].Split("`t")

                    if ($DebugMode -eq "true") { $text="Prüfe Parmeter (`t" + $SourceDataSplit[1] + ") hat Wert:(`t" + $SourceDataSplit[2] + ")";Write-Host $text}
                    if ($ID -eq $SourceDataSplit[1]){
                        $DummyText=$SourceDataSplit[2]
                        $i = $SourceDataZeilenSpit.count
                    }
                }   
        } 
    
        if ($DebugMode -eq "true") {Write-Host "## GetTextFromLanguageDB endet `t- mit Rückgabe-Parameter DummyText: (" + $DummyText + ")"}
        return $DummyText
    }

    function GetPersonenData {
        ##################################################
        # Version V04
        # vom 17.5.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") { $text="## GetPersonenData startet";Write-Host $text}


        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {Write-Host "DBOrdner:`t";  Write-Host  $DBOrdner}
        $PersonenDBDateiName=GetParameterFromSettings ("PersonenDatei")
        if ($DebugMode -eq "true") {Write-Host "PersonenDBDateiName:`t";  Write-Host  $PersonenDBDateiName}
        $PersonenDBDatei=$DBOrdner + "\" + $PersonenDBDateiName

        $Neu=""
        if (Test-Path -Path $PersonenDBDatei) {


                $PersonenDB=Get-Content $PersonenDBDatei

                if ($PersonenDB.Length -eq 0){
                    if ($DebugMode -eq "true") {Write-Host "Personen-DB-Datei existiert nicht/oder ist leer"}

                    # Standard-Trennzeichen ist TAB ( `t )
                    $SourceData="LNr`tVorname`tName`tGeburtsname`tGeburtsdatum`tSterbedatum`tBemerkung`tZusatzVornamen`tmobil`tmail`tGeburtsOrt`tSterbeOrt/Friedhof`treligion`tgeschl`tnationalität`t(HeinzStammbaumLnr)" + "`n"


                    $SourceData| Out-File -FilePath $PersonenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Personen-DB-Datei wurde erzeugt"}
        
                    $PersonenDB=Get-Content $PersonenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Personen-DB-Datei wurde frisch eingelesen"}

                    if ($PersonenDB.Length -eq 0){
                        if ($DebugMode -eq "true") {Write-Host "Personen-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!"}
                        #read-host “Press ENTER to continue...”
                        $erg=[System.Windows.Forms.MessageBox]::Show("Personen-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!", "FileSystem Zugriffs-Fehler", "1", "None" )
                        $host.Exit()
                    }
                }

                # Cleanup
                $ErgText=""
                $PersonenDBSplit=$PersonenDB.split("`n")
                for($i=0; $i -lt $PersonenDBSplit.count; $i++){
                    if ($DebugMode -eq "true") {$Text="Cleanup Person " + $i + " : " + $PersonenDBSplit[$i]; Write-Host $Text}
                    if ($PersonenDBSplit[$i] -ne ""){
                        if ($ErgText -eq "") {
                                $ErgText="" + $PersonenDBSplit[$i]
                            } else {
                                $ErgText=$ErgText + "`n" + $PersonenDBSplit[$i]
                        }
                    }
                    if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}
                }
        
                if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}

                $ErgText| Out-File -FilePath $PersonenDBDatei

                $Neu=Get-Content $PersonenDBDatei
            } else {
                $text="PersonenDB-Datei: (" + $PersonenDBDatei + ") nicht gefunden!";Write-Host $text

        }
        
        if ($DebugMode -eq "true") { $text="## GetPersonenData endet mit übergabe: " + $Neu;Write-Host $text}
        return $Neu
    }

    function GetKnotenData {
        ##################################################
        # Version V04
        # vom 17.5.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") { $text="## GetKnotenData startet";Write-Host $text}



        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {Write-Host "DBOrdner:`t";  Write-Host  $DBOrdner}
        $KnotenDBDateiName=GetParameterFromSettings ("KnotenDatei")
        if ($DebugMode -eq "true") {Write-Host "KnotenDateiName:`t";  Write-Host  $KnotenDBDateiName}
        $KnotenDBDatei=$DBOrdner + "\" + $KnotenDBDateiName

        
        $Neu=""
        if (Test-Path -Path $KnotenDBDatei) {


                $KnotenDB=Get-Content $KnotenDBDatei

                if ($KnotenDB.Length -eq 0){
                    if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei existiert nicht/oder ist leer"}

                    # Standard-Trennzeichen ist TAB ( `t )
                    $SourceData="LNr`tPersonLNr`tVaterLNr`tMutterLNr`tPartnerLNr`tKnoten2LNr`tKnoten3LNr`tKnoten4LNr`tKind1LNr`tKind2LNr`tKind3LNr`tKind4LNr`tKind5LNr`tKind6LNr`tKind7LNr`tKind8LNr`tKind9LNr`tKind10LNr`tKind11LNr`tKind12LNr`tKind13LNr`tKind14LNr`tStartDatum`tEndDatum`tTrau-Ort" + "`n"

                    $SourceData| Out-File -FilePath $KnotenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde erzeugt"}
        
                    $KnotenDB=Get-Content $KnotenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde frisch eingelesen"}

                    if ($KnotenDB.Length -eq 0){
                        if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!"}
                        #read-host “Press ENTER to continue...”
                        $erg=[System.Windows.Forms.MessageBox]::Show("Knoten-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!", "FileSystem Zugriffs-Fehler", "1", "None" )
                        $host.Exit()
                    }
                }
    

    
                # Cleanup
                $ErgText=""
                $KnotenDBSplit=$KnotenDB.split("`n")
                for($i=0; $i -lt $KnotenDBSplit.count; $i++){
                    if ($DebugMode -eq "true") {$Text="Cleanup Person " + $i + " : " + $KnotenDBSplit[$i]; Write-Host $Text}
                    if ($KnotenDBSplit[$i] -ne ""){
                        if ($ErgText -eq "") {
                                $ErgText="" + $KnotenDBSplit[$i]
                            } else {
                                $ErgText=$ErgText + "`n" + $KnotenDBSplit[$i]
                        }
                    }
                    if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}
                }
        
                if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}

                $ErgText| Out-File -FilePath $KnotenDBDatei

                $Neu=Get-Content $KnotenDBDatei
            } else {
                $text="KnotenDB-Datei: (" + $KnotenDBDatei + ") nicht gefunden!";Write-Host $text

        }
        if ($DebugMode -eq "true") { $text="## GetKnotenData endet mit übergabe: " + $Neu;Write-Host $text}
        return $Neu
    }

    function GetKnotenHeaderListe(){
        ##################################################
        # Version V02
        # vom 14.4.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") { $text="## GetKnotenHeaderListe startet ";Write-Host $text}

        $KnotenHeaderListe=@()
        $KnotenDBSplit=$Global:KnotenDB.Split("`n")
        $KnotenheaderSplit=$KnotenDBSplit[0].Split("`t")
        # leere Liste erzeugen
        for($i=0; $i -lt $KnotenheaderSplit.count+$global:KindStartNr; $i++){
            $KnotenHeaderListe=$KnotenHeaderListe + 0
        }

        if ($DebugMode -eq "true") { $text="## GetKnotenHeaderListe `t-- leere KnotenHeaderListe: [" +  $KnotenHeaderListe + "]";Write-Host $text}
        
        # Liste fuellen
        $MaxKindNr=0
        for($i=0; $i -lt $KnotenheaderSplit.count; $i++){
            if ($DebugMode -eq "true") { $text=" `t-- Element [" + $i + "] : [" +  $KnotenheaderSplit[$i] + "]";Write-Host $text}
            switch ( $KnotenheaderSplit[$i].ToUpper() ) {
                "LNR".ToUpper() {       $KnotenHeaderListe[0] = $i}
                "PersonLNr".ToUpper() { $KnotenHeaderListe[1] = $i}
                "VaterLNr".ToUpper() {  $KnotenHeaderListe[2] = $i}
                "MutterLNr".ToUpper() { $KnotenHeaderListe[3] = $i}
                "PartnerLNr".ToUpper() {$KnotenHeaderListe[4] = $i}
                "StartDatum".ToUpper() {$KnotenHeaderListe[5] = $i}
                "EndDatum".ToUpper() {  $KnotenHeaderListe[6] = $i}
                "Trau-Ort".ToUpper() {  $KnotenHeaderListe[7] = $i}
            }
            $Dummy2=""
            $dummy=$KnotenheaderSplit[$i].ToUpper() + "D"
            if ($DebugMode -eq "true") { $text=" `t-- Kind : [" +  $KnotenheaderSplit[$i] + "]";Write-Host $text}
            $KindSplit=$dummy.split("D")
            if ($KindSplit.count -gt 1) {
                if ($DebugMode -eq "true") { $text=" `t-- KindSplit[1] : [" +  $KindSplit[1] + "]";Write-Host $text}
                $Dummy2=$KindSplit[1] + "L"
                $KindNrSplit=$Dummy2.split("L")
                if ($DebugMode -eq "true") { $text=" `t-- KindNrSplit[1] : [" +  $KindNrSplit[1] + "]";Write-Host $text}
                if ($DebugMode -eq "true") { $text=" `t-- KindNrSplit.count : [" +  $KindNrSplit.count + "]";Write-Host $text}
                if ($KindNrSplit.count -eq 3) { 
                    if ($KindNrSplit[1] -eq "NR") {
                        if ($DebugMode -eq "true") { $text=" `t-- KindNr : [" +  $KindNrSplit[0] + "] - MaxKindNr:" + $MaxKindNr;Write-Host $text}
                        [int]$KindNr=$KindNrSplit[0]
                        $KnotenHeaderListe[$global:KindStartNr + $KindNr-1]=$i
                        if ($DebugMode -eq "true") { $text=" `t-- KindNr : [" +  $KindNr + "] - MaxKindNr:[" + $MaxKindNr + "]";Write-Host $text}
                        if ($MaxKindNr -lt $KindNr) {
                                $MaxKindNr = $KindNr
                                if ($DebugMode -eq "true") { $text=" `t-- Ja! MaxKindNr:[" + $MaxKindNr + "]";Write-Host $text}
                            } else {
                                if ($DebugMode -eq "true") { $text=" `t-- Nö! KindNr : [" +  $KindNr + "] - MaxKindNr:[" + $MaxKindNr + "]";Write-Host $text}
                        }
                    }
                }
            }
        }

        if ($DebugMode -eq "true") { $text="## GetKnotenHeaderListe `t-- befüllte KnotenHeaderListe: [" +  $KnotenHeaderListe + "]";Write-Host $text}

        if ($DebugMode -eq "true") { $text="## GetKnotenHeaderListe `t-- Anzahl Stellen: [" +  ($global:KindStartNr + $MaxKindNr) + "]";Write-Host $text}

        $NeueListe="" + $KnotenHeaderListe[0]
        for($i=1; $i -lt ($global:KindStartNr + $MaxKindNr); $i++){

            $NeueListe=$NeueListe + "`t" + $KnotenHeaderListe[$i]
        }

        if ($DebugMode -eq "true") { $text="## GetKnotenHeaderListe endet mit Rückgabe der KnotenHeaderListe: [" + $NeueListe + "]";Write-Host $text}
        return $NeueListe
    }

    function GetPersonMitNr {
        param (
            $PersonLnr="0"
        )
        ##################################################
        # Version V02
        # vom 7.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
                
        if ($DebugMode -eq "true"){$Text= "## CheckKnPe`t--`tstartet"; Write-Host $Text}    


        if ($DebugMode -eq "true") { Write-Host "PersonenDB:";Write-Host $global:PersonenDB}
    
        $PersonenDBZeilenSplit=$global:PersonenDB.Split("`n")

        #$PersonenDB
        $ErgText=""
    
        if ($DebugMode -eq "true") {$Text="Suche Daten von Person Nr:" +  $PersonLnr;Write-Host $Text}
        if ($PersonenDBZeilenSplit.count -gt 1) {
            for($i=1; $i -lt $PersonenDBZeilenSplit.count; $i++){
                if ($DebugMode -eq "true") {$Text="Eintrag:" +  $i + " von " + $global:PersonenDB.count + " : " + $global:PersonenDB[$i];Write-Host $Text}

                if ($PersonenDBZeilenSplit[$i] -ne "")                            
                {
                    $PersonenDBSplit=$PersonenDBZeilenSplit[$i].Split("`t")
                
                    if ($DebugMode -eq "true") {$Text="Treffer wenn :" +  $PersonLnr + " == " + $PersonenDBSplit[0];Write-Host $Text}
                    if ($PersonLnr -eq $PersonenDBSplit[0]) {
                        if ($DebugMode -eq "true") {Write-Host "getroffen"}
                        $ErgText=$PersonenDBZeilenSplit[$i]
                    }
                }   
            } 
        }

        if ($DebugMode -eq "true") {$Text="ErgText:" +  $ErgText;Write-Host $Text}
        return $ErgText
    }

    function FindeAlleKnotenVonPersonNr {
        param (
            $PersonLnr="0"
        )
        ##################################################
        # Version V02
        # vom 14.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") {$Text= Write-Host "starte FindeAlleKnotenVonPersonNr mit Person Nr.:" + $PersonLnr;Write-Host $Text}


        #$global:KindStartNr=0
        #$global:KnotenHeaderListe=@()
        
        if ($DebugMode -eq "true") {$Text="global:KnotenHeaderListe:" +  $global:KnotenHeaderListe;Write-Host $Text}
        $KnotenHeaderListeSplit=$global:KnotenHeaderListe.split("`t")

        $ErgText=""
    
        if ($DebugMode -eq "true") {$Text="Suche Knoten von Person Nr:" +  $PersonLnr;Write-Host $Text}
        for($i=0; $i -lt $global:KnotenDB.count; $i++){
            if ($DebugMode -eq "true") {$Text="Eintrag:" +  $i + " von " + $global:KnotenDB.count + " : " + $global:KnotenDB[$i];Write-Host $Text}

                if ($global:KnotenDB[$i].length -ne 0)                            
                {
                    $KnotenDBSplit=$global:KnotenDB[$i].Split("`t")
                
                    if ($DebugMode -eq "true") {$Text="Treffer wenn :" +  $PersonLnr + " == " + $KnotenDBSplit[0];Write-Host $Text}
                    $KnotenDBPersonPos=$KnotenHeaderListeSplit[1]
                    if ($PersonLnr -eq $KnotenDBSplit[$KnotenDBPersonPos]) {

                        if ($DebugMode -eq "true") {Write-Host "getroffen"}
                        if ($ErgText -eq "") {
                                $ErgText = "" + $i
                            } else{
                                $ErgText=$ErgText + "`t" + $i
                        }
                    }
                }   
        } 
    
        if ($DebugMode -eq "true") {$Text="ErgText:" +  $ErgText;Write-Host $Text}
        return $ErgText
    }

    function FindePartnerKnotenVonKnoten {
        param (
            $KnotenNr="0"
        )
        ##################################################
        # Version V02
        # vom 14.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        $PaKnoten=0
        
        $KnotenHeaderListeSplit=$global:KnotenHeaderListe.split("`t")

        if ($KnotenNr -gt 0) {
            $KnotenDBSplit=$global:KnotenDB.split("`n")
            $KnotenSplit=$KnotenDBSplit[$KnotenNr].split("`t")
            $KnotenDBPePos=$KnotenHeaderListeSplit[1]
            $KnotenDBPaPos=$KnotenHeaderListeSplit[4]
            $PeNr=$KnotenSplit[$KnotenDBPePos]
            $PaNr=$KnotenSplit[$KnotenDBPaPos]
            
            $PaKnotenListe=FindeAlleKnotenVonPersonNr($PaNr)   

            if ($PaKnotenListe -ne "") {
                $PaKnotenListeSplit = ($PaKnotenListe + "`t").split("`t")

                for($i=0; $i -lt $PaKnotenListeSplit.count; $i++){
                    $MglPaKnotenNr=$PaKnotenListeSplit[$i]
                    $MglPaKnotenSplit=$KnotenDBSplit[$MglPaKnotenNr].split("`t")
                    if ($MglPaKnotenSplit[$KnotenDBPaPos] -eq $PeNr) {
                        $PaKnoten=$MglPaKnotenNr
                    }
                }
            }

        }
        if ($DebugMode -eq "true"){$Text="Knoten (" + $PaKnoten + ") ist gefundener PartnerKnoten zu Knoten (" + $KnotenNr + ")";Write-Host $Text}
        return $PaKnoten
    }

    function WritePersonenData() {
        param (
            $NeueDaten=""
        )
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        # Neue Personendb speichern
        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {Write-Host "DBOrdner:`t";  Write-Host  $DBOrdner}
        $PersonenDBDateiName=GetParameterFromSettings ("PersonenDatei")
        if ($DebugMode -eq "true") {Write-Host "PersonenDBDateiName:`t";  Write-Host  $PersonenDBDateiName}
        $PersonenDBDatei=$DBOrdner + "\" + $PersonenDBDateiName
        $NeueDaten| Out-File -FilePath $PersonenDBDatei

    }

    function WriteKnotenData() {
        param (
            $NeueDaten=""
        )
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################

        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        # Neue Personendb speichern
        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {Write-Host "DBOrdner:`t";  Write-Host  $DBOrdner}

        $KnotenDBDateiName=GetParameterFromSettings ("KnotenDatei")
        if ($DebugMode -eq "true") {Write-Host "KnotenDateiName:`t";  Write-Host  $KnotenDBDateiName}
        $KnotenDBDatei=$DBOrdner + "\" + $KnotenDBDateiName

        $NeueDaten| Out-File -FilePath $KnotenDBDatei

    }
    
    function WriteAdressData() {
        param (
            $NeueDaten=""
        )
        ##################################################
        # Version V01
        # vom 17.5.2023
        ##################################################

        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        # Neue Personendb speichern
        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {Write-Host "DBOrdner:`t";  Write-Host  $DBOrdner}

        $AdressDBDateiName=GetParameterFromSettings ("AdresseDatei")
        if ($DebugMode -eq "true") {Write-Host "AdressDateiName:`t";  Write-Host  $AdressDBDateiName}
        $AdressDBDatei=$DBOrdner + "\" + $AdressDBDateiName

        $NeueDaten| Out-File -FilePath $AdressDBDatei


    }

    function SetGlobalParameterTM(){
        
        ##################################################
        # Version V3
        # vom 2.5.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        $global:BasisPfad=DetectScriptPath -PowershellVersion  DetectPSVersion

        $Global:SettingsDataFile = $global:BasisPfad + "\Settings.def"

        if ($DebugMode -eq "true") {
            $Text="## SetGlobalParameter`t- gesetzte globale Parameter" + "`n"
            $text=$Text + "`t`t- global:BasisPfad:`t" + $global:BasisPfad + "`n"
            $text=$Text + "`t`t- Global:SettingsDataFile:`t" + $Global:SettingsDataFile + "`n"
            $text=$Text +  "`n"
            Write-Host  $Text
        }

        $Global:SettingsData=GetSettingsData -SourceDataFile $Global:SettingsDataFile
        if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:SettingsData :(" + $Global:SettingsData + ")";Write-Host $Text}

        $DebugDummy=GetParameterFromSettings -Parametername "DebugMode"
        if ($DebugDummy -eq "1") {$Global:DebugMode= "true"}
        $LogDummy=GetParameterFromSettings -Parametername "LogMode"
        if ($LogDummy -eq "1") {$Global:LogMode= "true"}

        $Language=GetParameterFromSettings -Parametername "Sprache"
        if ($Language -eq "") {
                $Global:Language=DetectOsUserLanguage 
                if ($DebugMode -eq "true") { $text="## `t- Sprach-Feld in den Settings ist leer => erkannte User-Profil-Haupt-Sprache:`t" + $Global:Language + " wird benutzt"; Write-Host $text}
            } else {
                $Global:Language=$Language.ToUpper()
                if ($DebugMode -eq "true") { $text="## `t- Sprach-Feld in den Settings ist definiert:`t" + $Global:Language + " wird benutzt"; Write-Host $text}
        }

        $Global:SprachDBFileName=GetLanguageFileName -ActiveLanguage $Global:Language
        if ($DebugMode -eq "true") {$Text="## `t- Parameter SprachDBFileName :(" + $Global:SprachDBFileName + ")";Write-Host $Text}
        $Global:SprachDB=GetLanguageData -LanguageDBFileName  $Global:SprachDBFileName
        if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:SprachDB :(" + $Global:SprachDB + ")";Write-Host $Text}

        $global:PersonenDB=GetPersonenData
        if ($DebugMode -eq "true") {Write-Host "PersonenDB:`t";  Write-Host $global:PersonenDB}

        $global:KnotenDB=GetKnotenData
        if ($DebugMode -eq "true") {Write-Host "KnotenDB:`t";  Write-Host $global:KnotenDB}

        $global:AdressDB=GetAdressData
        if ($DebugMode -eq "true") {Write-Host "AdressDB:`t";  Write-Host $global:AdressDB}
        
        $global:KindStartNr=10
        $global:KnotenHeaderListe=GetKnotenHeaderListe
        if ($DebugMode -eq "true") {$Text= "KnotenHeaderListe:`t" + $global:KnotenHeaderListe;  Write-Host $Text}


       # $Global:TrSettingsData = TranslateSettingsData

       # if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:TrSettingsData :(" + $Global:TrSettingsData + ")";Write-Host $Text}

        if ($DebugMode -eq "true") {$text="Notbremse"; read-host $Text}
        
        if ($DebugMode -eq "true") {$text="## SetGlobalParameterTM endet ";Write-Host $text}
    }
 
    function GetAdressData {
        ##################################################
        # Version V05
        # vom 23.4.2023
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "GetAdressData startet";  Write-Host $Text}

        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {$Text= "DBOrdner:`t" +  $DBOrdner;  Write-Host $Text}
        if ( $DBOrdner[1] -ne ":") { $DBOrdner=$global:BasisPfad + "\" + $DBOrdner}
        if ($DebugMode -eq "true") {$Text= "DBOrdner:`t" +  $DBOrdner;  Write-Host $Text}

        $KnotenDBDateiName=GetParameterFromSettings ("AdresseDatei")
        if ($DebugMode -eq "true") {Write-Host "KnotenDateiName:`t";  Write-Host  $KnotenDBDateiName}
        $KnotenDBDatei=$DBOrdner + "\" + $KnotenDBDateiName
        
        $Neu=""
        if (Test-Path -Path $KnotenDBDatei) {


                $KnotenDB=Get-Content $KnotenDBDatei

                if ($KnotenDB.Length -eq 0){
                    if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei existiert nicht/oder ist leer"}

                    # Standard-Trennzeichen ist TAB ( `t )
                    $SourceData="LNr`tPersonLNrListe`tStrasse`tHausnummer`tPLZ`tStadt`tOrt`tLand`tTelefon`tmobil`tmail" + "`n"

                    $SourceData| Out-File -FilePath $KnotenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde erzeugt"}
        
                    $KnotenDB=Get-Content $KnotenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde frisch eingelesen"}

                    if ($KnotenDB.Length -eq 0){
                        if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!"}
                        #read-host “Press ENTER to continue...”
                        $erg=[System.Windows.Forms.MessageBox]::Show("Knoten-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!", "FileSystem Zugriffs-Fehler", "1", "None" )
                        $host.Exit()
                    }
                }
    

    
                # Cleanup
                $ErgText=""
                $KnotenDBSplit=$KnotenDB.split("`n")
                for($i=0; $i -lt $KnotenDBSplit.count; $i++){
                    if ($DebugMode -eq "true") {$Text="Cleanup Person " + $i + " : " + $KnotenDBSplit[$i]; Write-Host $Text}
                    if ($KnotenDBSplit[$i] -ne ""){
                        if ($ErgText -eq "") {
                                $ErgText="" + $KnotenDBSplit[$i]
                            } else {
                                $ErgText=$ErgText + "`n" + $KnotenDBSplit[$i]
                        }
                    }
                    if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}
                }
        
                if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}

                $ErgText| Out-File -FilePath $KnotenDBDatei

                $Neu=Get-Content $KnotenDBDatei
            } else {
                $text="KnotenDB-Datei: (" + $KnotenDBDatei + ") nicht gefunden! sie wird jetzt frisch angelegt";Write-Host $text

                # Standard-Trennzeichen ist TAB ( `t )
                #LNr	PersonLNrListe	Strasse	Hausnummer	PLZ	Stadt	Ort	Land	Telefon		mobil	mail
                $SourceData="LNr`tPersonLNrListe`tStrasse`tHausnummer`tPLZ`tStadt`tOrt`tLand`tTelefon`tmobil`tmail" + "`n"

                $SourceData| Out-File -FilePath $KnotenDBDatei
                if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde erzeugt"}
        
                $KnotenDB=Get-Content $KnotenDBDatei
                if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde frisch eingelesen"}

    
                # Cleanup
                $ErgText=""
                $KnotenDBSplit=$KnotenDB.split("`n")
                for($i=0; $i -lt $KnotenDBSplit.count; $i++){
                    if ($DebugMode -eq "true") {$Text="Cleanup Person " + $i + " : " + $KnotenDBSplit[$i]; Write-Host $Text}
                    if ($KnotenDBSplit[$i] -ne ""){
                        if ($ErgText -eq "") {
                                $ErgText="" + $KnotenDBSplit[$i]
                            } else {
                                $ErgText=$ErgText + "`n" + $KnotenDBSplit[$i]
                        }
                    }
                    if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}
                }
        
                if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}

                $ErgText| Out-File -FilePath $KnotenDBDatei

                $Neu=Get-Content $KnotenDBDatei

        }
        if ($DebugMode -eq "true") {$Text= "GetAdressData endet mit ÜbergabeParameter Neu:`t" + $Neu;  Write-Host $Text}
        return $Neu
    }

    function GetNextFreeAdressLnr() {
        ##################################################
        # Version V01
        # vom 1.5.2023
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "GetNextFreeAdressLnr startet ";  Write-Host $Text}

        $globalAdressDBSplit=$global:AdressDB.split("`n")

        [int]$LastLnr=0
        for($i=1; $i -lt $globalAdressDBSplit.count; $i++){
            $AdressSplit=$globalAdressDBSplit[$i].split("`t")
            if ([int]$AdressSplit[0] -gt [int]$LastLnr) {
                [int]$LastLnr = [int]$AdressSplit[0]
            }
        }

        [int]$erg = [int]$LastLnr + 1
    
        if ($DebugMode -eq "true") {$Text= "GetNextFreeAdressLnr endet mit RückgabeParameter:" + $erg;  Write-Host $Text}
        return $erg

    }

    function ReplaceAdressDaten {
        param (
            $NeueDaten=""
        )
        ##################################################
        # Version V03
        # vom 1.5.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"

        if ($DebugMode -eq "true") {$Text="## starte ReplaceAdressDaten mit Parameter --`n`t-- Neue Daten:`t" + $NeueDaten ;Write-Host $Text}

        $NeueDatenSplit=$NeueDaten.split("`t")
        [int]$ChAdressNR=[int]$NeueDatenSplit[0]

        $globalAdressDBSplit=$global:AdressDB.Split("`n")
        $LetzteAdressLnrInDB=0
        [int]$NextFreeAdressLnr=GetNextFreeAdressLnr
        if ($DebugMode -eq "true") {$Text="NextFreeAdressLnr:" +  $NextFreeAdressLnr;Write-Host $Text}

        [int]$LetzteAdressLnrInDB=($NextFreeAdressLnr - 1)
        if ($DebugMode -eq "true") {$Text="LetzteAdressLnrInDB:" +  $LetzteAdressLnrInDB;Write-Host $Text}

        # durchlaufe komplette PersonenDB 

        $ErgText=""
    
        if ($DebugMode -eq "true") {$Text="Suche Daten von Person Nr:" +  $ChAdressNR;Write-Host $Text}

        if ($DebugMode -eq "true") {$Text="LetzteAdressLnrInDB+1:" +  ($LetzteAdressLnrInDB+1);Write-Host $Text}
        if (($LetzteAdressLnrInDB+1) -eq $ChAdressNR) {
                # neue Person wird einfach hinten angehaengt
                if ($DebugMode -eq "true") {$Text="(LetzteAdressLnrInDB+1): " +  ($LetzteAdressLnrInDB+1) + " = ChAdressNR: " + $ChAdressNR + " => also hinten anhaengen";Write-Host $Text}

                $ErgText=$global:AdressDB + "`n" + $NeueDaten
            } else {
                if ($DebugMode -eq "true") {$Text="(LetzteAdressLnrInDB+1): " +  ($LetzteAdressLnrInDB+1) + " <> ChAdressNR: " + $ChAdressNR + " => also finden und ersetzen";Write-Host $Text}

                for($i=0; $i -lt $globalAdressDBSplit.count; $i++){
                    if ($DebugMode -eq "true") {$Text="Eintrag:" +  $i + " von " + $globalAdressDBSplit.count + " : " + $globalAdressDBSplit[$i];Write-Host $Text}

                        if ($globalAdressDBSplit[$i].length -ne 0)                            
                        {
                            $AdressDBSplit=$globalAdressDBSplit[$i].Split("`t")
                
                            if ($DebugMode -eq "true") {$Text="Treffer wenn :" +  $ChAdressNR + " == " + $AdressDBSplit[0];Write-Host $Text}

                            if ($ErgText -ne "") {$ErgText=$ErgText + "`n"}
                            if ($ChAdressNR -eq $AdressDBSplit[0]) {
                        
                                    if ($DebugMode -eq "true") {Write-Host "getroffen"}
                                    # neuen Wert einfuegen
                                    $ErgText=$ErgText + $NeueDaten 

                                   # $i = $globalAdressDBSplit.count
                                } else {
                                    # alten Wert uebernehmen
                                    $ErgText=$ErgText + $globalAdressDBSplit[$i] 
                            }
                        }   
                } 
        }

        # Neue Personendb speichern
        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {Write-Host "DBOrdner:`t";  Write-Host  $DBOrdner}
        if ( $DBOrdner[1] -ne ":") { $DBOrdner=$global:BasisPfad + "\" + $DBOrdner}
        if ($DebugMode -eq "true") {$Text= "DBOrdner:`t" +  $DBOrdner;  Write-Host $Text}

        $AdressDBDateiName=GetParameterFromSettings ("AdresseDatei")
        if ($DebugMode -eq "true") {Write-Host "AdressDateiName:`t";  Write-Host  $AdressDBDateiName}
        $AdressDBDatei=$DBOrdner + "\" + $AdressDBDateiName

        $ErgText| Out-File -FilePath $AdressDBDatei

        # PersonenDaten erneut einlesen
        $global:AdressDB=GetAdressData
        if ($DebugMode -eq "true") {Write-Host "AdressDB:`t";  Write-Host $global:AdressDB}
  
        if ($DebugMode -eq "true") {Write-Host "ReplaceAdressDaten endet"}
    } 

    function IstZahl(){
        param (
            $DuTZahl=""
        )
        ##################################################
        # Version V01
        # vom 1.5.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "IstZahl startet mit parameter DuTZahl:" + $DuTZahl; Write-Host $Text}

        $erg=$true
        Try {
            # [Int]$Variable = $DuTZahl
                [Int]$DuTZahl -is [Int]
            } Catch {
                $erg=$false
        }
        
        if ($DebugMode -eq "true") {$Text= "IstZahl endet mit Rückgabeparameter:" + $erg; Write-Host $Text}
        return $erg
    }

#endregion Tools

#region TestTools

    function CheckPeKn(){
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################
        # prueft ob jede Person einen Knoten hat
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        
        if ($DebugMode -eq "true"){$Text= "## CheckPeKn`t--`tstartet"; Write-Host $Text}
    
        #$KnotenListeSplit=$global:KnotenDB.split("`n")
        $PeListeSplit=$global:PersonenDB.split("`n")
        $FehlerText=""
        # gehe durch alle Personen und pruefe ob Knoten existieren
        for($i=1; $i -lt ($PeListeSplit.count); $i++){

            ProgressStatus2 -ProgressLnr 1 -MaxValue $PeListeSplit.count -ActValue $i

            if ($PeListeSplit[$i] -eq "") {
                    $FehlerText=$FehlerText + "`n" + "[Warnung]`tin Personen-DB ist Zeile (" + $i + ") leer!"
                } else {
                    $PeSplit=$PeListeSplit[$i].split("`t")

                    $PeNr=$PeSplit[0]
                    if ($PeNr -ne $i) {
                        $FehlerText=$FehlerText + "`n" + "[Warnung]`tin Personen-DB ist Zeile (" + $i + ") nicht die erwartete Person mit Lnr (" + $PeNr + ")!"
                    }

                    #$OldDebugMode=$DebugMode
                    #$DebugMode="false"
                    $PeKnotenListe=FindeAlleKnotenVonPersonNr -PersonLnr $PeNr
                    #$DebugMode=$OldDebugMode

                    if ($PeKnotenListe -eq "") {
                        $FehlerText=$FehlerText + "`n" + "[Alarm]`tin Knoten-DB existiert kein Knoten für die Person mit Lnr (" + $PeNr + ")!"
                    }
            }
        }

        $CheckPeKnFehlerFile=""
        if ($FehlerText -ne "") {

           # $OldDebugMode=$DebugMode
            #$DebugMode="false"
            $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"
            #$DebugMode=$OldDebugMode

            $CheckPeKnFehlerFile=$ExportFolder  + "\PeKnFehlerFile.log"
            $FehlerText| Out-File -FilePath $CheckPeKnFehlerFile
        }
        
        ProgressStatus2 -ProgressLnr 1 -MaxValue 100 -ActValue 100
        
        if ($DebugMode -eq "true"){$Text= "## CheckPeKn`t--`tendet"; Write-Host $Text}
        return $CheckPeKnFehlerFile
    }

    function CheckKnPe(){
        ##################################################
        # Version V02
        # vom 14.4.2023
        ##################################################
        # prueft ob alle Personen eines Knotens existieren

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
                
        if ($DebugMode -eq "true"){$Text= "## CheckKnPe`t--`tstartet"; Write-Host $Text}

        $KnotenListeSplit=$global:KnotenDB.split("`n")
        #$PeListeSplit=$global:PersonenDB.split("`n")
        $FehlerText=""

        $KnotenHeaderListeSplit=$global:KnotenHeaderListe.split("`t")
        if ($DebugMode -eq "true"){$Text= "## `t-- KnotenHeaderListeSplit.count:" + $KnotenHeaderListeSplit.count + "`tKnotenHeaderListe:" + $KnotenHeaderListe; Write-Host $Text}

        for($i=1; $i -lt ($KnotenListeSplit.count); $i++){

            ProgressStatus2 -ProgressLnr 1 -MaxValue $KnotenListeSplit.count -ActValue $i

            if ($KnotenListeSplit[$i] -eq "") {
                    $FehlerText=$FehlerText + "`n" + "[Warnung]`tin Knoten-DB ist Zeile (" + $i + ") leer!"
                } else {

                    $KnSplit=$KnotenListeSplit[$i].split("`t")

                    if ($KnSplit[1] -ne "0") {
                        $Pe=GetPersonMitNr -PersonLnr $KnSplit[$KnotenHeaderListeSplit[1]]
                        if ($Pe -eq "") {$FehlerText=$FehlerText + "`n" + "[Alarm]`tin Knoten-DB in Zeile (" + $i + "), KnotenLnr (" + $KnSplit[$KnotenHeaderListeSplit[0]] + ") ist die Person mit Lnr (" + $KnSplit[$KnotenHeaderListeSplit[1]] + ") nicht in der PersonenDB zu finden!"}
                    }

                    if ($KnSplit[4] -ne "0") {
                        $Pe=GetPersonMitNr -PersonLnr $KnSplit[$KnotenHeaderListeSplit[4]]
                        if ($Pe -eq "") {$FehlerText=$FehlerText + "`n" + "[Alarm]`tin Knoten-DB in Zeile (" + $i + "), KnotenLnr (" + $KnSplit[$KnotenHeaderListeSplit[0]] + ") ist der Partner mit Lnr (" + $KnSplit[$KnotenHeaderListeSplit[4]] + ") nicht in der PersonenDB zu finden!"}
                    }

                    if ($KnSplit[2] -ne "0") {
                        $Pe=GetPersonMitNr -PersonLnr $KnSplit[$KnotenHeaderListeSplit[2]]
                        if ($Pe -eq "") {$FehlerText=$FehlerText + "`n" + "[Alarm]`tin Knoten-DB in Zeile (" + $i + "), KnotenLnr (" + $KnSplit[$KnotenHeaderListeSplit[0]] + ") ist der Vater mit Lnr (" + $KnSplit[$KnotenHeaderListeSplit[2]] + ") nicht in der PersonenDB zu finden!"}
                    }

                    if ($KnSplit[3] -ne "0") {
                        $Pe=GetPersonMitNr -PersonLnr $KnSplit[$KnotenHeaderListeSplit[3]]
                        if ($Pe -eq "") {$FehlerText=$FehlerText + "`n" + "[Alarm]`tin Knoten-DB in Zeile (" + $i + "), KnotenLnr (" + $KnSplit[$KnotenHeaderListeSplit[0]] + ") ist die Mutter mit Lnr (" + $KnSplit[$KnotenHeaderListeSplit[3]] + ") nicht in der PersonenDB zu finden!"}
                    }

                    #$KindPos=$KnotenHeaderListeSplit[1]
                    #$global:KindStartNr
                    # Alle Kinder durchlaufen
                    for($k=$global:KindStartNr; $k -lt $KnotenHeaderListeSplit.count; $k++){
                        
                        if ($DebugMode -eq "true"){$Text= "## CheckKnPe`t-- KnotenDB-Zeile " + $i + " KindNr:" + $k + " an KnotenPos:" + $KnotenHeaderListeSplit[$k] + ":" + $KnSplit[$KnotenHeaderListeSplit[$k]]; Write-Host $Text}
                        if ($KnSplit[$KnotenHeaderListeSplit[$k]] -ne "0") {
                            $Pe=GetPersonMitNr -PersonLnr $KnSplit[$KnotenHeaderListeSplit[$k]]
                            if ($Pe -eq "") {
                                $FehlerText=$FehlerText + "`n" + "## CheckKnPe`t-- [Alarm]`tin Knoten-DB in Zeile (" + $i + "), KnotenLnr (" + $KnSplit[$KnotenHeaderListeSplit[0]] + ") ist das Kind mit Lnr (" + $KnSplit[$KnotenHeaderListeSplit[$k]] + ") nicht in der PersonenDB zu finden!"
                                if ($DebugMode -eq "true"){$Text= "## CheckKnPe`t-- [Alarm]`tin Knoten-DB in Zeile (" + $i + "), KnotenLnr (" + $KnSplit[$KnotenHeaderListeSplit[0]] + ") ist das Kind mit Lnr (" + $KnSplit[$KnotenHeaderListeSplit[$k]] + ") nicht in der PersonenDB zu finden!"; Write-Host $Text}
                            }
                        }
                    }

             
                }

        }

        $CheckKnPeFehlerFile=""
        if ($FehlerText -ne "") {

            $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"

            $CheckKnPeFehlerFile=$ExportFolder  + "\KnPeFehlerFile.log"
            $FehlerText| Out-File -FilePath $CheckKnPeFehlerFile
        }


        ProgressStatus2 -ProgressLnr 1 -MaxValue 100 -ActValue 100
                    
        if ($DebugMode -eq "true"){$Text= "## CheckKnPe`t--`tendet"; Write-Host $Text}
        return $CheckKnPeFehlerFile
    }
       
    function CheckPePa(){
        ##################################################
        # Version V02
        # vom 14.4.2023
        ##################################################
        # prueft ob alle Personen gegenseitig die passenden Partner eingetragen haben

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        $DebugMode = "true"
                
        if ($DebugMode -eq "true"){$Text= "## CheckPePa`t--`tstartet"; Write-Host $Text}

        $KnotenListeSplit=$global:KnotenDB.split("`n")
        
        $KnotenHeaderListeSplit=$global:KnotenHeaderListe.split("`t")

        $FehlerText=""

        for($i=1; $i -lt ($KnotenListeSplit.count); $i++){

            ProgressStatus2 -ProgressLnr 1 -MaxValue $KnotenListeSplit.count -ActValue $i

            if ($KnotenListeSplit[$i] -eq "") {
                    $FehlerText=$FehlerText + "`n" + "[Warnung]`tin Knoten-DB ist Zeile (" + $i + ") leer!"
                } else {

                    #$OldDebugMode=$DebugMode
                    #$DebugMode="false"

                    $Kn=$KnotenListeSplit[$i]
                    $KnSplit=$Kn.split("`t")

                    if ($KnSplit[1] -ne $KnotenHeaderListeSplit[0]) {
                        $Pe=$KnSplit[$KnotenHeaderListeSplit[1]]
                        $Pa=$KnSplit[$KnotenHeaderListeSplit[4]]

                        if ($Pa -ne "0") {
                            $PaKnListe=FindeAlleKnotenVonPersonNr -PersonLnr $Pa
                            
                            #$DebugMode="true"

                            if ($DebugMode -eq "true"){$Text= "## CheckPePa`t--`tPartnerListe:(" + $PaKnListe + ")"; Write-Host $Text}

                            $treffer = "false"
                            $PaKnListeSplit=($PaKnListe + "`t").split("`t")

                            for($o=0; $o -lt ($PaKnListeSplit.count - 1); $o++){

                                $DuTPaKnNr=$PaKnListeSplit[$o]
                                if ($DebugMode -eq "true"){$Text= "## CheckPePa`t--`tDuTPartnerKnotenNr [" + $o + "] (" + $DuTPaKnNr + ") "; Write-Host $Text}

                                $DutPaKn=$KnotenListeSplit[$DuTPaKnNr]
                                
                                $DuTPaKnSplit=$DuTPaKn.split("`t")

                                # Partner des Partners muß wieder Person sein
                                $PaKnPa=$DuTPaKnSplit[$KnotenHeaderListeSplit[4]]
                                
                                if ($DebugMode -eq "true"){$Text= "## CheckPePa`t--`tPartner (" + $PaKnPa + ") ?=? Person (" + $Pe+ ") ??"; Write-Host $Text}
                                if ($PaKnPa -eq $Pe){
                                    if ($DebugMode -eq "true"){$Text= "## CheckPePa`t--`tTreffer!"; Write-Host $Text}
                                    $treffer = "true"

                                    # Kinder von Pe und Pa vergleichen
                                    for($k=$global:KindStartNr; $k -lt $KnotenHeaderListeSplit.count; $k++){

                                   # for($Ki=1; $Ki -lt (14); $Ki++){
                                        # Kind 1: Pos [8]
                                        if ($DuTPaKnSplit[$KnotenHeaderListeSplit[$k]] -ne $KnSplit[$KnotenHeaderListeSplit[$k]]) {

                                            if ($DebugMode -eq "true"){$Text= "## CheckPePa`t--`tK:(" + $k + ") Kind (" + ($K-$global:KindStartNr) + ") in Knoten mit Lnr (" + $KnSplit[$KnotenHeaderListeSplit[0]] + ") [" + $KnSplit[$KnotenHeaderListeSplit[$k]] + "] und in Knoten mit Lnr (" + $DuTPaKnSplit[$KnotenHeaderListeSplit[0]] + ") [" + $DuTPaKnSplit[$KnotenHeaderListeSplit[$k]] + "] sind nicht gleich!"; Write-Host $Text}
                                            $FehlerText=$FehlerText + "`n" + "[Alarm]`tKind (" + ($K-$global:KindStartNr) + ") in Knoten mit Lnr (" + $KnSplit[$KnotenHeaderListeSplit[0]] + ") [" + $KnSplit[$KnotenHeaderListeSplit[$k]] + "] und in Knoten mit Lnr (" + $DuTPaKnSplit[$KnotenHeaderListeSplit[0]] + ") [" + $DuTPaKnSplit[$KnotenHeaderListeSplit[$k]] + "] sind nicht gleich!"
                                        }

                                    }

                                    $o=$PaKnListeSplit.count
                                }
                            }
                            if ($treffer -ne "true"){
                                $FehlerText=$FehlerText + "`n" + "[Alarm]`tin Knoten-DB in Zeile (" + $i + "), KnotenLnr (" + $KnSplit[$KnotenHeaderListeSplit[0]] + ") ist kein passender Partner zu finden!"
                            }
                            
                            #$DebugMode="false"
                        }
                    }  
                    $DebugMode=$OldDebugMode                 
                }

        }

        $CheckPePaFehlerFile=""
        if ($FehlerText -ne "") {

            $OldDebugMode=$DebugMode
            #$DebugMode="false"
            $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"
            $DebugMode=$OldDebugMode

            $CheckPePaFehlerFile=$ExportFolder  + "\PePaFehlerFile.log"
            $FehlerText| Out-File -FilePath $CheckPePaFehlerFile
        }


        ProgressStatus2 -ProgressLnr 1 -MaxValue 100 -ActValue 100
                    
        if ($DebugMode -eq "true"){$Text= "## CheckPePa`t--`tendet"; Write-Host $Text}
        return $CheckPePaFehlerFile
    }

    function CheckElKi(){
        ##################################################
        # Version V02
        # vom 14.4.2023
        ##################################################
        # prueft ob alle Kinder gegenseitig die passenden Eltern eingetragen haben

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
                
        if ($DebugMode -eq "true"){$Text= "## CheckElKi`t--`tstartet"; Write-Host $Text}

        $KnotenListeSplit=$global:KnotenDB.split("`n")
        
        $KnotenHeaderListeSplit=$global:KnotenHeaderListe.split("`t")

        $FehlerText=""

        for($i=1; $i -lt ($KnotenListeSplit.count); $i++){

            ProgressStatus2 -ProgressLnr 1 -MaxValue $KnotenListeSplit.count -ActValue $i

            if ($KnotenListeSplit[$i] -eq "") {
                    $FehlerText=$FehlerText + "`n" + "[Warnung]`tin Knoten-DB ist Zeile (" + $i + ") leer!"
                } else {

                    $OldDebugMode=$DebugMode
                    #$DebugMode="false"

                    $Kn=$KnotenListeSplit[$i]
                    $KnSplit=$Kn.split("`t")
                    $Pe=[int]$KnSplit[$KnotenHeaderListeSplit[1]]
                    
                    if ($DebugMode -eq "true"){$Text= "## `t-- Pe: " + $Pe + ", i: " + $i; Write-Host $Text}
                    if ($Pe -ne 0) {

                        # Eltern-Eintraege aller Kinder pruefen
                        for($k=$global:KindStartNr; $k -lt $KnotenHeaderListeSplit.count; $k++){
                            # Kind 1: Pos [8]
                            $KindNr=[int]$KnSplit[$KnotenHeaderListeSplit[$k]]
                            
                            if ($KindNr -eq 0){
                                if ($DebugMode -eq "true"){$Text= "## `t--`tKind an PosNr :(" + $KnotenHeaderListeSplit[$k] + ") existiert nicht"; Write-Host $Text}
                            } else {
                                if ($DebugMode -eq "true"){$Text= "## `t--`tKind an PosNr :(" + $KnotenHeaderListeSplit[$k] + ") wird untersucht"; Write-Host $Text}
                                $KiListe=FindeAlleKnotenVonPersonNr -PersonLnr $KindNr
                                #$DebugMode ="true"
                                if ($DebugMode -eq "true"){$Text= "## CheckElKi`t--`tKiListe:(" + $KiListe + ")"; Write-Host $Text}
                                if ($KiListe -eq "") {
                                        if ($DebugMode -eq "true"){$Text= "## `t--`tFehler in Knoten " + $i + ", Kind" + ($k - $global:KindStartNr +1) + ": - für das Kind mit Pe-Nr" + $KindNr + " existiert kein Knoten"; Write-Host $Text}
                                        $FehlerText=$FehlerText + "`n" + "[Alarm]`tin Knoten " + $i + ", Kind" + ($k - $global:KindStartNr +1) + ": - für das Kind mit Pe-Nr" + $KindNr + " existiert kein Knoten"
                                    } else {
                                    $KiListeSplit=($KiListe + "`t").split("`t")
                                    for($KiLiNr=0; $KiLiNr -lt ($KiListeSplit.count - 1); $KiLiNr++){
                                        $DuTKindKnotenLnR=[int]$KiListeSplit[$KiLiNr]
                                        if ($DebugMode -eq "true"){$Text= "## `t--`tKiLiNr:(" + $KiLiNr + ") DuTKindKnotenLnR:(" + $DuTKindKnotenLnR + ")"; Write-Host $Text}
                                        if ($DuTKindKnotenLnR -ne 0) {

                                            $DuTKindKnoten=$KnotenListeSplit[$DuTKindKnotenLnR]
                                            
                                            if ($DebugMode -eq "true"){$Text= "## `t--DuTKindKnotenLnR:(" + $DuTKindKnotenLnR + ") => DuTKindKnoten:(" + $DuTKindKnoten + ")"; Write-Host $Text}

                                            $KindKnotenSplit=$DuTKindKnoten.split("`t")

                                            $DuTE1=[int]$KindKnotenSplit[$KnotenHeaderListeSplit[2]]
                                            $DuTE2=[int]$KindKnotenSplit[$KnotenHeaderListeSplit[3]]

                                            if ($DebugMode -eq "true"){$Text= "## `t--DuTE1:(" + $DuTE1 + ") => DuTE2:(" + $DuTE2 + ")"; Write-Host $Text}

                                            if ($DuTE2 -eq 0) {
                                                    $FehlerText=$FehlerText + "`n" + "[Alarm]`tKinder mit Lnr (" + $KindKnotenSplit[$KnotenHeaderListeSplit[1]] + ") von Knoten (" + $KindKnotenSplit[$KnotenHeaderListeSplit[0]] + ") hat keine Mutter)!"
                                                } else {
                                                    if ($DuTE1 -eq 0) {
                                                            $FehlerText=$FehlerText + "`n" + "[Alarm]`tKinder mit Lnr (" + $KindKnotenSplit[$KnotenHeaderListeSplit[1]] + ") von Knoten (" + $KindKnotenSplit[$KnotenHeaderListeSplit[0]] + ") hat keinen Vater)!"
                                                        } else {
                                                            if ($DuTE1 -eq $DuTE2) {
                                                                    $FehlerText=$FehlerText + "`n" + "[Alarm]`tKinder mit Lnr (" + $KindKnotenSplit[$KnotenHeaderListeSplit[1]] + ") von Knoten (" + $KindKnotenSplit[$KnotenHeaderListeSplit[0]] + ") hat 2 gleiche Eltern (Mutter = Vater)!"
                                                                } else {
                                                                    if ($DuTE1 -ne $Pe) {
                                                                        if ($DuTE2 -ne $Pe) {
                                                                            $FehlerText=$FehlerText + "`n" + "[Alarm]`tKinder mit Lnr (" + $KindKnotenSplit[$KnotenHeaderListeSplit[1]] + ") von Knoten (" + $KindKnotenSplit[$KnotenHeaderListeSplit[0]] + ") hat fehlenden Eltern-Eintrag (" + $Pe + ")!"
                                                                        }
                                                                    }
                                                            }

                                                    }
                                            }

                                            
                                        }
                                    }


                                }


                            }
                        }
                    }  
                    #$DebugMode=$OldDebugMode                 
            }

        }

        $CheckElKiFehlerFile=""
        if ($FehlerText -ne "") {

            $OldDebugMode=$DebugMode
           # $DebugMode="false"
            $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"
            $DebugMode=$OldDebugMode

            $CheckElKiFehlerFile=$ExportFolder  + "\ElKiFehlerFile.log"
            $FehlerText| Out-File -FilePath $CheckElKiFehlerFile
        }


        ProgressStatus2 -ProgressLnr 1 -MaxValue 100 -ActValue 100
                    
        if ($DebugMode -eq "true"){$Text= "## CheckElKi`t--`tendet"; Write-Host $Text}
        return $CheckElKiFehlerFile
    } 

    function CheckPeIndex(){
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################
        # prueft ob alle Personen sortiert nach PersonenLnr in PersonenDB sind

        
        if ($DebugMode -eq "true"){$Text= "## CheckPeIndex`t--`tstartet"; Write-Host $Text}
    
        #$KnotenListeSplit=$global:KnotenDB.split("`n")
        $PeListeSplit=$global:PersonenDB.split("`n")
        $FehlerText=""
        # gehe durch alle Personen und pruefe ob Knoten existieren
        for($i=1; $i -lt ($PeListeSplit.count); $i++){

            ProgressStatus2 -ProgressLnr 1 -MaxValue $PeListeSplit.count -ActValue $i

            if ($PeListeSplit[$i] -eq "") {
                    $FehlerText=$FehlerText + "`n" + "[Warnung]`tin Personen-DB ist Zeile (" + $i + ") leer!"
                } else {
                    $PeSplit=$PeListeSplit[$i].split("`t")

                    $PeNr=$PeSplit[0]
                    if ($PeNr -ne $i) {
                        $FehlerText=$FehlerText + "`n" + "[Warnung]`tin Personen-DB ist Zeile (" + $i + ") nicht die erwartete Person mit Lnr (" + $PeNr + ")!"
                    }
            }
        }

        $CheckPeIndexFehlerFile=""
        if ($FehlerText -ne "") {

            $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"

            $CheckPeIndexFehlerFile=$ExportFolder  + "\PeIndexFehlerFile.log"
            $FehlerText| Out-File -FilePath $CheckPeIndexFehlerFile
        }
        
        ProgressStatus2 -ProgressLnr 1 -MaxValue 100 -ActValue 100
        
        if ($DebugMode -eq "true"){$Text= "## CheckPeIndex`t--`tendet"; Write-Host $Text}
        return $CheckPeIndexFehlerFile

    } 

    function PeReIndex(){
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################
        # prueft ob alle Personen sortiert nach PersonenLnr in PersonenDB sind
        if ($DebugMode -eq "true"){$Text= "## PeReIndex`t--`tstartet"; Write-Host $Text}
    
        #$KnotenListeSplit=$global:KnotenDB.split("`n")
        $PeListeSplit=$global:PersonenDB.split("`n")
        $FehlerText=""
        
        ProgressStatus2 -ProgressLnr 1 -MaxValue (2*$PeListeSplit.count) -ActValue 1

        # erstelle leere Adress-Liste
        $Rezept=@()
        for($i=0; $i -lt ($PeListeSplit.count+5); $i++){
            $Rezept=$Rezept + 0
        }

        $Fehler="false"
        # gehe durch alle Personen und setze die PeNr in die Rezept-Liste an die richtige Position
        for($i=1; $i -lt ($PeListeSplit.count); $i++){

            ProgressStatus2 -ProgressLnr 1 -MaxValue (2*$PeListeSplit.count) -ActValue ($i +1)

            if ($PeListeSplit[$i] -eq "") {
                    $Fehler="true"
                    $FehlerText=$FehlerText + "`n" + "[Warnung]`tin Personen-DB ist Zeile (" + $i + ") leer!"
                } else {
                    $PeSplit=$PeListeSplit[$i].split("`t")

                    $PeNr=$PeSplit[0]
                    if ($Rezept[$PeNr] -eq 0) {
                            $Rezept[$PeNr]=$i
                        } else {
                            $Fehler="true"
                            $FehlerText=$FehlerText + "`n" + "[Alarm]`tin Personen-DB ist LnR (" + $PeNr + ") doppelt benutzt. in Zeile (" + $i + ") und in Zeile  (" + $Rezept[$PeNr] + ") !"
                    }
            }
        }

        if ($Fehler -eq "false") {
            # PersonDB neu zusammenbauen
            $neuePeDB=$PeListeSplit[0]
            for($i=1; $i -lt ($PeListeSplit.count); $i++){

                ProgressStatus2 -ProgressLnr 1 -MaxValue (2*$PeListeSplit.count) -ActValue ($PeListeSplit.count + $i +1)
                
                if ($Rezept[$i] -ne 0) {
                    $neuePeDB=$neuePeDB + "`n" + $PeListeSplit[$Rezept[$i]]
                }
            }
           # $global:PersonenDB=$neuePeDB

            # Neue PersonenDB in Datei speichern
            WritePersonenData -NeueDaten $neuePeDB
            # und frisch einlesen
            GetPersonenData           
        }

        $PeReIndexFehlerFile=""
        if ($FehlerText -ne "") {

            $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"

            $PeReIndexFehlerFile=$ExportFolder  + "\PeReIndexFehlerFile.log"
            $FehlerText| Out-File -FilePath $PeReIndexFehlerFile
        }
        
        ProgressStatus2 -ProgressLnr 1 -MaxValue 100 -ActValue 100
        
        if ($DebugMode -eq "true"){$Text= "## PeReIndex`t--`tendet"; Write-Host $Text}
        return $PeReIndexFehlerFile
    }

    function CheckKnIndex(){
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################
        # prueft ob alle Knoten sortiert nach KnotenLnr in KnotenDB sind

        if ($DebugMode -eq "true"){$Text= "## CheckKnIndex`t--`tstartet"; Write-Host $Text}

        $KnotenListeSplit=$global:KnotenDB.split("`n")
        #$PeListeSplit=$global:PersonenDB.split("`n")
        $FehlerText=""

        for($i=1; $i -lt ($KnotenListeSplit.count); $i++){

            ProgressStatus2 -ProgressLnr 1 -MaxValue $KnotenListeSplit.count -ActValue $i

            if ($KnotenListeSplit[$i] -eq "") {
                    $FehlerText=$FehlerText + "`n" + "[Warnung]`tin Knoten-DB ist Zeile (" + $i + ") leer!"
                } else {

                    $KnSplit=$KnotenListeSplit[$i].split("`t")
                    $KnNlr=$KnSplit[0]
                    if ($KnNlr -ne $i) {
                        $FehlerText=$FehlerText + "`n" + "[Alarm]`tin Knoten-DB in Zeile (" + $i + "), KnotenLnr (" + $KnNlr + ") sollte den Knoten mit Lnr (" + $i + ") enthalten!"
                    }
            }
          }

        $CheckKnIndexFehlerFile=""
        if ($FehlerText -ne "") {

            $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"

            $CheckKnIndexFehlerFile=$ExportFolder  + "\KnIndexFehlerFile.log"
            $FehlerText| Out-File -FilePath $CheckKnIndexFehlerFile
        }


        ProgressStatus2 -ProgressLnr 1 -MaxValue 100 -ActValue 100
                    
        if ($DebugMode -eq "true"){$Text= "## CheckKnIndex`t--`tendet"; Write-Host $Text}
        return $CheckKnIndexFehlerFile
    }

    function KnReIndex(){
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################
        # prueft ob alle Personen sortiert nach PersonenLnr in PersonenDB sind
        if ($DebugMode -eq "true"){$Text= "## KnReIndex`t--`tstartet"; Write-Host $Text}
    
        #$KnotenListeSplit=$global:KnotenDB.split("`n")
        $KnListeSplit=$global:KnotenDB.split("`n")
        $FehlerText=""
        
        ProgressStatus2 -ProgressLnr 1 -MaxValue (2*$KnListeSplit.count) -ActValue 1

        # erstelle leere Adress-Liste
        $Rezept=@()
        for($i=0; $i -lt ($KnListeSplit.count+5); $i++){
            $Rezept=$Rezept + 0
        }

        $Fehler="false"
        # gehe durch alle Personen und setze die PeNr in die Rezept-Liste an die richtige Position
        for($i=1; $i -lt ($KnListeSplit.count); $i++){

            ProgressStatus2 -ProgressLnr 1 -MaxValue (2*$KnListeSplit.count) -ActValue ($i +1)

            if ($KnListeSplit[$i] -eq "") {
                    $Fehler="true"
                    $FehlerText=$FehlerText + "`n" + "[Warnung]`tin Knoten-DB ist Zeile (" + $i + ") leer!"
                } else {
                    $KnSplit=$KnListeSplit[$i].split("`t")

                    $KnNr=$KnSplit[0]
                    if ($Rezept[$KnNr] -eq 0) {
                            $Rezept[$KnNr]=$i
                        } else {
                            $Fehler="true"
                            $FehlerText=$FehlerText + "`n" + "[Alarm]`tin Knoten-DB ist LnR (" + $KnNr + ") doppelt benutzt. in Zeile (" + $i + ") und in Zeile  (" + $Rezept[$KnNr] + ") !"
                    }
            }
        }

        if ($Fehler -eq "false") {
            # PersonDB neu zusammenbauen
            $neueKnDB=$KnListeSplit[0]
            for($i=1; $i -lt ($KnListeSplit.count); $i++){

                ProgressStatus2 -ProgressLnr 1 -MaxValue (2*$KnListeSplit.count) -ActValue ($KnListeSplit.count + $i +1)
                
                if ($Rezept[$i] -ne 0) {
                    $neueKnDB=$neueKnDB + "`n" + $KnListeSplit[$Rezept[$i]]
                }
            }
           # $global:PersonenDB=$neuePeDB

            # Neue PersonenDB in Datei speichern
            WriteKnotenData -NeueDaten $neueKnDB
            # und frisch einlesen
            GetKnotenData           
        }

        $KnReIndexFehlerFile=""
        if ($FehlerText -ne "") {

            $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"

            $KnReIndexFehlerFile=$ExportFolder  + "\KnReIndexFehlerFile.log"
            $FehlerText| Out-File -FilePath $KnReIndexFehlerFile
        }
        
        ProgressStatus2 -ProgressLnr 1 -MaxValue 100 -ActValue 100
        
        if ($DebugMode -eq "true"){$Text= "## KnReIndex`t--`tendet"; Write-Host $Text}
        return $KnReIndexFehlerFile
    }

    function CheckSettingsIndex(){
        ##################################################
        # Version V01
        # vom 11.4.2023
        ##################################################
        # prueft ob alle Settings sortiert nach Lnr in SettingsDB sind

        if ($DebugMode -eq "true"){$Text= "## CheckSettingsIndex`t--`tstartet"; Write-Host $Text}

        $SettingsListeSplit=$global:SettingsData.split("`n")
        #$PeListeSplit=$global:PersonenDB.split("`n")
        $FehlerText=""

        for($i=1; $i -lt ($SettingsListeSplit.count); $i++){

            ProgressStatus2 -ProgressLnr 1 -MaxValue $SettingsListeSplit.count -ActValue $i

            if ($SettingsListeSplit[$i] -eq "") {
                    $FehlerText=$FehlerText + "`n" + "[Warnung]`tin Settings-DB ist Zeile (" + $i + ") leer!"
                } else {

                    $SeSplit=$SettingsListeSplit[$i].split("`t")
                    $SeNlr=$SeSplit[0]
                    if ($SeNlr -ne $i) {
                        $FehlerText=$FehlerText + "`n" + "[Alarm]`tin Settings-DB in Zeile (" + $i + "), Einstellungs-Lnr (" + $SeNlr + ") sollte die EInstellung mit Lnr (" + $i + ") enthalten!"
                    }
            }
          }

        $CheckSettingsIndexFehlerFile=""
        if ($FehlerText -ne "") {

            $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"

            $CheckSettingsIndexFehlerFile=$ExportFolder  + "\SettingsIndexFehlerFile.log"
            $FehlerText| Out-File -FilePath $CheckSettingsIndexFehlerFile
        }


        ProgressStatus2 -ProgressLnr 1 -MaxValue 100 -ActValue 100
                    
        if ($DebugMode -eq "true"){$Text= "## CheckSettingsIndex`t--`tendet"; Write-Host $Text}
        return $CheckSettingsIndexFehlerFile
    }

    function SettingsReIndex(){
        ##################################################
        # Version V01
        # vom 11.4.2023
        ##################################################
        # prueft ob alle Personen sortiert nach PersonenLnr in PersonenDB sind
        if ($DebugMode -eq "true"){$Text= "## SettingsReIndex`t--`tstartet"; Write-Host $Text}
    
        #$KnotenListeSplit=$global:KnotenDB.split("`n")
        $SettingsListeSplit=$global:SettingsData.split("`n")
        $FehlerText=""
        
        ProgressStatus2 -ProgressLnr 1 -MaxValue (2*$PeListeSplit.count) -ActValue 1

        # Settings werden einfach aufsteigend nummeriert - ohne Einfluß auf Inhalte
        $Fehler="false"
        # SettingsDB neu zusammenbauen
        $neueSettingsDB=$SettingsListeSplit[0]
        # gehe durch alle Personen und setze die PeNr in die Rezept-Liste an die richtige Position
        for($i=1; $i -lt ($SettingsListeSplit.count); $i++){
            if ($SettingsListeSplit[$i] -eq "") {
                    $Fehler="true"
                    $FehlerText=$FehlerText + "`n" + "[Warnung]`tin Settings-DB ist Zeile (" + $i + ") leer!"
                } else {
                     $SettingsSplit=$SettingsListeSplit[$i].split("`t")
                     $neueSettingsDB=$neueSettingsDB + "`n" + $i + "`t" + $SettingsSplit[1] + "`t" + $SettingsSplit[2] + "`t" + $SettingsSplit[3] + "`t" + $SettingsSplit[4]
            }
        }

        # Neue PersonenDB in Datei speichern
        $neueSettingsDB | Out-File -FilePath $Global:SettingsDataFile
        # und frisch einlesen
        GetSettingsData -SourceDataFile $Global:SettingsDataFile          
        

        $SettingsReIndexFehlerFile=""
        if ($FehlerText -ne "") {

            $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"

            $SettingsReIndexFehlerFile=$ExportFolder  + "\SettingsReIndexFehlerFile.log"
            $FehlerText| Out-File -FilePath $SettingsReIndexFehlerFile
        }
        
        ProgressStatus2 -ProgressLnr 1 -MaxValue 100 -ActValue 100
        
        if ($DebugMode -eq "true"){$Text= "## SettingsReIndex`t--`tendet"; Write-Host $Text}
        return $SettingsReIndexFehlerFile
    }

    function CheckLanguageIndex(){
        ##################################################
        # Version V01
        # vom 11.4.2023
        ##################################################
        # prueft ob alle Settings sortiert nach Lnr in SettingsDB sind

        if ($DebugMode -eq "true"){$Text= "## CheckLanguageIndex`t--`tstartet"; Write-Host $Text}

        $SprachListeSplit=$Global:SprachDB.split("`n")
        $FehlerText=""

        for($i=1; $i -lt ($SprachListeSplit.count); $i++){
            ProgressStatus2 -ProgressLnr 1 -MaxValue $SprachListeSplit.count -ActValue $i

            if ($SprachListeSplit[$i] -eq "") {
                    $FehlerText=$FehlerText + "`n" + "[Warnung]`tin Sprach-DB ist Zeile (" + $i + ") leer!"
                } else {

                    $SprachSplit=$SprachListeSplit[$i].split("`t")
                    $SprachNlr=$SprachSplit[0]
                    if ($SprachNlr -ne $i) {
                        $FehlerText=$FehlerText + "`n" + "[Alarm]`tin Sprach-DB in Zeile (" + $i + "), Sprach-Lnr (" + $SprachNlr + ") sollte das SprachFragment mit Lnr (" + $i + ") enthalten!"
                    }
            }
          }

        $CheckLanguageIndexFehlerFile=""
        if ($FehlerText -ne "") {

            $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"

            $CheckLanguageIndexFehlerFile=$ExportFolder  + "\LanguageIndexFehlerFile.log"
            $FehlerText| Out-File -FilePath $CheckLanguageIndexFehlerFile
        }


        ProgressStatus2 -ProgressLnr 1 -MaxValue 100 -ActValue 100
                    
        if ($DebugMode -eq "true"){$Text= "## CheckLanguageIndex`t--`tendet"; Write-Host $Text}
        return $CheckLanguageIndexFehlerFile
    }

    function LanguageReIndex(){
        ##################################################
        # Version V01
        # vom 11.4.2023
        ##################################################
        # prueft ob alle Personen sortiert nach PersonenLnr in PersonenDB sind
        if ($DebugMode -eq "true"){$Text= "## LanguageReIndex`t--`tstartet"; Write-Host $Text}
    
        #$KnotenListeSplit=$global:KnotenDB.split("`n")
        $SettingsListeSplit=$Global:SprachDB.split("`n")
        $FehlerText=""
        
        ProgressStatus2 -ProgressLnr 1 -MaxValue (2*$PeListeSplit.count) -ActValue 1

        # Settings werden einfach aufsteigend nummeriert - ohne Einfluß auf Inhalte
        $Fehler="false"
        # SettingsDB neu zusammenbauen
        $neueSettingsDB=$SettingsListeSplit[0]
        # gehe durch alle Personen und setze die PeNr in die Rezept-Liste an die richtige Position
        for($i=1; $i -lt ($SettingsListeSplit.count); $i++){
            if ($SettingsListeSplit[$i] -eq "") {
                    $Fehler="true"
                    $FehlerText=$FehlerText + "`n" + "[Warnung]`tin Settings-DB ist Zeile (" + $i + ") leer!"
                } else {
                     $SettingsSplit=$SettingsListeSplit[$i].split("`t")
                     $neueSettingsDB=$neueSettingsDB + "`n" + $i + "`t" + $SettingsSplit[1] + "`t" + $SettingsSplit[2] 
            }
        }

        # Neue PersonenDB in Datei speichern
        $neueSettingsDB | Out-File -FilePath $Global:SprachDBFileName
        # und frisch einlesen
        $Global:SprachDB=GetLanguageData -LanguageDBFileName  $Global:SprachDBFileName
        #GetSettingsData -SourceDataFile $Global:SettingsDataFile          
        

        $SprachReIndexFehlerFile=""
        if ($FehlerText -ne "") {

            $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"

            $SprachReIndexFehlerFile=$ExportFolder  + "\SprachReIndexFehlerFile.log"
            $FehlerText| Out-File -FilePath $SprachReIndexFehlerFile
        }
        
        ProgressStatus2 -ProgressLnr 1 -MaxValue 100 -ActValue 100
        
        if ($DebugMode -eq "true"){$Text= "## LanguageReIndex`t--`tendet"; Write-Host $Text}
        return $SprachReIndexFehlerFile
    }

    function GetKnotenDBVersion() {
        ##################################################
        # Version V02
        # vom 17.5.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
                
        if ($DebugMode -eq "true"){$Text= "## GetKnotenDBVersion startet"; Write-Host $Text}


        $KnotenListeSplit0=$global:KnotenDB.split("`n")[0]
        $Lnr=$KnotenListeSplit0.split("`t")[0]
        $LnrSplit=$Lnr.split("#")

        $Erg="1"
        if ($LnrSplit.count -gt 1){
            $Erg=$LnrSplit[1]
        }
        
        if ($DebugMode -eq "true"){$Text= "## GetKnotenDBVersion endet mit Rückgabe-Parameter:" + $Erg; Write-Host $Text}
        return $Erg
    }

    function GetPersonenDBVersion() {
        ##################################################
        # Version V02
        # vom 17.5.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
                
        if ($DebugMode -eq "true"){$Text= "## GetPersonenDBVersion startet"; Write-Host $Text}


        $PersonenListeSplit0=$global:PersonenDB.split("`n")[0]
        $Lnr=$PersonenListeSplit0.split("`t")[0]
        $LnrSplit=$Lnr.split("#")

        $Erg="1"
        if ($LnrSplit.count -gt 1){
            $Erg=$LnrSplit[1]
        }
        
        if ($DebugMode -eq "true"){$Text= "## GetPersonenDBVersion endet mit Rückgabe-Parameter:" + $Erg; Write-Host $Text}
        return $Erg
    }

    function GetAdressDBVersion() {
        ##################################################
        # Version V02
        # vom 17.5.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
                
        if ($DebugMode -eq "true"){$Text= "## GetAdressDBVersion startet"; Write-Host $Text}


        $AdressListeSplit0=$global:AdressDB.split("`n")[0]
        $Lnr=$AdressListeSplit0.split("`t")[0]
        if ($DebugMode -eq "true"){$Text= "## Lnr: <" + $Lnr + ">"; Write-Host $Text}
        $LnrSplit=$Lnr.split("#")

        $Erg="1"
        if ($DebugMode -eq "true"){$Text= "## LnrSplit.count: <" + $LnrSplit.count + ">"; Write-Host $Text}
        if ($LnrSplit.count -gt 1){
            $Erg=$LnrSplit[1]
        }
        
        if ($DebugMode -eq "true"){$Text= "## GetAdressDBVersion endet mit Rückgabe-Parameter:" + $Erg; Write-Host $Text}
        return $Erg
    }

    function GetLanguageDBVersion() {
        ##################################################
        # Version V02
        # vom 17.5.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
                
        if ($DebugMode -eq "true"){$Text= "## GetLanguageDBVersion startet"; Write-Host $Text}


        $LanguageListeSplit0=$global:SprachDB.split("`n")[0]
        $Lnr=$LanguageListeSplit0.split("`t")[0]
        $LnrSplit=$Lnr.split("#")

        $Erg="1"
        if ($LnrSplit.count -gt 1){
            $Erg=$LnrSplit[1]
        }
        
        if ($DebugMode -eq "true"){$Text= "## GetLanguageDBVersion endet mit Rückgabe-Parameter:" + $Erg; Write-Host $Text}
        return $Erg
    }

    function GetVersionsInfo()   {
        ##################################################
        # Version V02
        # vom 18.6.2023
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "GetVersionsInfo startet";  Write-Host $Text}

        $KnotenVersion=GetKnotenDBVersion
        $PersonenVersion=GetPersonenDBVersion
        $AdressVersion=GetAdressDBVersion
        $LanguageVersion=GetLanguageDBVersion

        
        $EingabeVersion=& .\Stammbaum_DatenEingabe.ps1 -GetVersionInfo "true"
        $EingabeVersionSplit=$EingabeVersion.split("`n")
        
        $Export2HtmlVersion=& .\Stammbaum_Export2HTML.ps1 -GetVersionInfo "true"
        $Export2HtmlVersionSplit=$Export2HtmlVersion.split("`n")

        $SettingsVersion=& .\Stammbaum_SettingsManager.ps1 -GetVersionInfo "true"
        $SettingsVersionSplit=$SettingsVersion.split("`n")

        $StartmenuVersion=& .\Stammbaum_Startmenu.ps1 -GetVersionInfo "true"
        $StartmenuVersionSplit=$StartmenuVersion.split("`n")

        $MapVersion=& .\Stammbaum_Map.ps1 -GetVersionInfo "true"
        $MapVersionSplit=$StartmenuVersion.split("`n")

        $ErgText="Datenbanken`n"
        $ErgText=$ErgText + "`tKnoten-DB-Version:`t" + $KnotenVersion + "`n"
        $ErgText=$ErgText + "`tPersonen-DB-Version:`t" + $PersonenVersion + "`n"
        $ErgText=$ErgText + "`tAdress-DB-Version:`t" + $AdressVersion + "`n"
        $ErgText=$ErgText + "`tLanguage-DB-Version:`t" + $LanguageVersion + "`n"
        $ErgText=$ErgText + "`nModule`n"
        $ErgText=$ErgText + "Modul Eingabe:`n`t" + $EingabeVersionSplit[0] + "`n`t" + $EingabeVersionSplit[1]+"`n"
        $ErgText=$ErgText + "Modul Export2Html:`n`t" + $Export2HtmlVersionSplit[0] + "`n`t" + $Export2HtmlVersionSplit[1]+"`n"
        $ErgText=$ErgText + "Modul SettingsManager:`n`t" + $SettingsVersionSplit[0] + "`n`t" + $SettingsVersionSplit[1]+"`n"
        $ErgText=$ErgText + "Modul Tools:`n`tVersion:`t" + $Version + "`n`tStand:`t" + $Stand+"`n"
        $ErgText=$ErgText + "Modul Map:`n`tVersion:`t" + $MapVersionSplit[0] + "`n`tStand:`t" + $MapVersionSplit[1]+"`n"
        $ErgText=$ErgText + "Modul Startmenu:`n`t" + $StartmenuVersionSplit[0] + "`n`t" + $StartmenuVersionSplit[1]+"`n"
        

        $BrowserInfo=GetBrowserVersioninfo
        $ErgText=$ErgText + "`n" + $BrowserInfo


        $GetVersionsInfoFile=""
        if ($ErgText -ne "") {

            $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"
            if ($ExportFolder -eq "") {$ExportFolder="."}

            $GetVersionsInfoFile=$ExportFolder  + "\GetVersionsInfoFile.log"
            $ErgText| Out-File -FilePath $GetVersionsInfoFile
        }
        
        ProgressStatus2 -ProgressLnr 1 -MaxValue 100 -ActValue 100
        
        if ($DebugMode -eq "true"){$Text= "## GetVersionsInfo endet mit Rückgabe-Parameter:" + $GetVersionsInfoFile; Write-Host $Text}
        return $GetVersionsInfoFile
    }

    function MigrateKnotenUndPersonenDbFromV1ToV2(){
        ##################################################
        # Version V01
        # vom 17.5.2023
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "MigrateDbFromV1ToV2 startet";  Write-Host $Text}

        $ErgText=""

        $KnotenVersion=GetKnotenDBVersion
        if ($DebugMode -eq "true") {$Text= "KnotenVersion: <" +  $KnotenVersion + ">";  Write-Host $Text}
        $PersonenVersion=GetPersonenDBVersion
        if ($DebugMode -eq "true") {$Text= "PersonenVersion: <" +  $PersonenVersion + ">";  Write-Host $Text}
        $AdressVersion=GetAdressDBVersion
        if ($DebugMode -eq "true") {$Text= "AdressVersion: <" +  $AdressVersion + ">";  Write-Host $Text}

        $VerStat=$true
        if ($KnotenVersion -ne "1") {
            if ($DebugMode -eq "true") {Write-Host "KnotenVersion ist nicht 1"}
            if ($KnotenVersion -ne "") {
                if ($DebugMode -eq "true") {Write-Host "KnotenVersion ist nicht """""}
                $VerStat=$false
            }
        }
        if ($PersonenVersion -ne "1") {
            if ($DebugMode -eq "true") {Write-Host "PersonenVersion ist nicht 1"}
            if ($PersonenVersion -ne "") {
                if ($DebugMode -eq "true") {Write-Host "PersonenVersion ist nicht """""}
                $VerStat=$false
            }
        }
        if ($AdressVersion -ne "1") {
            if ($DebugMode -eq "true") {Write-Host "AdressVersion ist nicht 1"}
            if ($AdressVersion -ne "") {
                if ($DebugMode -eq "true") {Write-Host "AdressVersion ist nicht """""}
                $VerStat=$false
            }
        }


        if ($DebugMode -eq "true") {$Text= "VerStat:" +  $VerStat;  Write-Host $Text}

        if ($VerStat -eq $true) {
                # hier wird migriert!
                                
                
                ######################### starte mit Personendb ################################
                if ($DebugMode -eq "true") {$Text= "Starte mit Personendb";  Write-Host $Text}

                $PersonenSplit=$Global:PersonenDB.split("`n")
                $FehlerText=""

                # Header anpassen (VersionsInfo eliminieren)
                $Header=$PersonenSplit[0]
                $HeaderSplit=$Header.split("#")

                $Erg="1"
                if ($HeaderSplit.count -gt 1){
                        $PureHeader=$HeaderSplit[2]
                    } else {
                        $PureHeader=$Header
                }

                $NeuePersonenDB="#2#" + $PureHeader
                for($i=1; $i -lt ($PersonenSplit.count); $i++){
                    ProgressStatus2 -ProgressLnr 1 -MaxValue $PersonenSplit.count -ActValue $i
                    $Person=$PersonenSplit[$i]
                    $PersonSplit=$Person.split("`t")
                    $GebOrt=$PersonSplit[10]
                    $SterbeOrt=$PersonSplit[11]

                    $NeuerGebOrt=""
                    if ($GebOrt.length -gt 0){
                        if ((IstZahl -DuTZahl $GebOrt) -eq $true) {
                                $NeuerGebOrt=$GebOrt
                            } else {
                                $NewAddressLnr=GetNextFreeAdressLnr
                                $NewAddress="" + $NewAddressLnr + "`t`t`t`t`t" + $GebOrt + "`t`t`t`t`t`t`t"
                                $GebErg=ReplaceAdressDaten -NeueDaten $NewAddress
                                if ($DebugMode -eq "true") {$Text= "GeburtsOrt in Adressdb eingefügt. GebErg:" +  $GebErg;  Write-Host $Text}
                                $NeuerGebOrt=$NewAddressLnr
                                # Person wird erst am ende angepasst
                        }
                    }

                    $NeuerSterbeOrt=""
                    if ($SterbeOrt.length -gt 0){
                        if ((IstZahl -DuTZahl $SterbeOrt) -eq $true) {
                                $NeuerSterbeOrt=$SterbeOrt
                            } else {
                                $NewAddressLnr=GetNextFreeAdressLnr
                                $NewAddress="" + $NewAddressLnr + "`t`t`t`t`t" + $SterbeOrt + "`t`t`t`t`t`t`t"
                                $SterbeErg=ReplaceAdressDaten -NeueDaten $NewAddress
                                if ($DebugMode -eq "true") {$Text= "SterbeOrt in Adressdb eingefügt. SterbeErg:" +  $SterbeErg;  Write-Host $Text}
                                $NeuerSterbeOrt=$NewAddressLnr
                                # Person wird erst am ende angepasst
                        }
                    }
                    
                    if ($DebugMode -eq "true") {$Text= "Person " + $i + ": " + $Person;  Write-Host $Text}
                    $NeuePerson="" + $PersonSplit[0]
                    for($p=1; $p -lt ($PersonSplit.count); $p++){
                        if ($p -eq 10) {
                                $NeuePerson=$NeuePerson + "`t" + $NeuerGebOrt
                            }
                            elseif ($p -eq 11) {
                                $NeuePerson=$NeuePerson + "`t" + $NeuerSterbeOrt
                            } 
                            else {
                                $NeuePerson=$NeuePerson + "`t" + $PersonSplit[$p]
                        }
                    }
                    
                    if ($DebugMode -eq "true") {$Text= "`tPerson alt:`t" +  $Person + "`n" + "`tPerson neu:`t" +  $NeuePerson;  Write-Host $Text}
                    $NeuePersonenDB=$NeuePersonenDB + "`n" + $NeuePerson
                }
                # neue personendb schreiben
                WritePersonenData -NeueDaten $NeuePersonenDB 
                
                # neue personendb frisch einlesen
                $global:PersonenDB=GetPersonenData
                if ($DebugMode -eq "true") {Write-Host "PersonenDB:`t";  Write-Host $global:PersonenDB}


                ######################### Personendb fertig ################################

                
                ######################### starte mit Knotendb ################################
                if ($DebugMode -eq "true") {$Text= "Starte mit Knotendb";  Write-Host $Text}

                $KnotenSplit=$Global:Knotendb.split("`n")
                $FehlerText=""
                
                # Header anpassen (VersionsInfo eliminieren)
                $Header=$KnotenSplit[0]
                $HeaderSplit=$Header.split("#")

                $Erg="1"
                if ($HeaderSplit.count -gt 1){
                        $PureHeader=$HeaderSplit[2]
                    } else {
                        $PureHeader=$Header
                }
                
                $NeueKnotenDB="#2#" + $PureHeader
                for($i=1; $i -lt ($KnotenSplit.count); $i++){
                    ProgressStatus2 -ProgressLnr 1 -MaxValue $KnotenSplit.count -ActValue $i
                    $EinzelKnoten=$KnotenSplit[$i]
                    $EinzelKnotenSplit=$EinzelKnoten.split("`t")
                    $TrauOrt=$EinzelKnotenSplit[24]

                    $NeuerTrauOrt=""
                    if ($TrauOrt.length -gt 0){
                        if ((IstZahl -DuTZahl $TrauOrt) -eq $true) {
                                $NeuerTrauOrt=$TrauOrt
                            } else {
                                $NewAddressLnr=GetNextFreeAdressLnr
                                $NewAddress="" + $NewAddressLnr + "`t`t`t`t`t" + $TrauOrt + "`t`t`t`t`t`t`t"
                                $GebErg=ReplaceAdressDaten -NeueDaten $NewAddress
                                if ($DebugMode -eq "true") {$Text= "TrauOrt in Adressdb eingefügt. GebErg:" +  $GebErg;  Write-Host $Text}
                                $NeuerTrauOrt=$NewAddressLnr
                                # EinzelKnoten wird erst am ende angepasst
                        }
                    }
                    
                    if ($DebugMode -eq "true") {$Text= "EinzelKnoten " + $i + ": " + $EinzelKnoten;  Write-Host $Text}
                    $NeueEinzelKnoten="" + $EinzelKnotenSplit[0]
                    for($p=1; $p -lt ($EinzelKnotenSplit.count); $p++){
                        if ($p -eq 24) {
                                $NeueEinzelKnoten=$NeueEinzelKnoten + "`t" + $NeuerTrauOrt
                            }
                            else {
                                $NeueEinzelKnoten=$NeueEinzelKnoten + "`t" + $EinzelKnotenSplit[$p]
                        }
                    }
                    
                    if ($DebugMode -eq "true") {$Text= "`tEinzelKnoten alt:`t" +  $EinzelKnoten + "`n" + "`tEinzelKnoten neu:`t" +  $NeueEinzelKnoten;  Write-Host $Text}
                    $NeueKnotenDB=$NeueKnotenDB + "`n" + $NeueEinzelKnoten
                }
                # neue Knotendb schreiben
                WriteKnotenData -NeueDaten $NeueKnotenDB 
                
                # neue Knotendb frisch einlesen
                $global:KnotenDB=GetKnotenData
                if ($DebugMode -eq "true") {Write-Host "KnotenDB:`t";  Write-Host $global:KnotenDB}



                ######################### Knotendb fertig ################################


        
            } else {
                $ErgText = GetTextFromLanguageDB -ID  ("3_M_RES_26") # "Datanbanken liegen nicht in der erforderliche Version vor. Es wird lieber mal nix gemacht!"
        }

        $MigrateDbFile=""
        if ($ErgText -ne "") {

            $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"
            if ($ExportFolder -eq "") {$ExportFolder="."}

            $MigrateDbFile=$ExportFolder  + "\MigrateDbV1ToV2File.log"
            $ErgText| Out-File -FilePath $MigrateDbFile
        }
        
        ProgressStatus2 -ProgressLnr 1 -MaxValue 100 -ActValue 100
        
        if ($DebugMode -eq "true"){$Text= "## MigrateDbFromV1ToV2 endet mit Rückgabe-Parameter:" + $MigrateDbFile; Write-Host $Text}
        return $MigrateDbFile
    }

    function MigrateAdressDbFromV1ToV2(){
        ##################################################
        # Version V01
        # vom 17.5.2023
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "MigrateAdressDbFromV1ToV2 startet";  Write-Host $Text}

        $ErgText=""

        $AdressVersion=GetAdressDBVersion
        if ($DebugMode -eq "true") {$Text= "AdressVersion: <" +  $AdressVersion + ">";  Write-Host $Text}

        $VerStat=$true
        if ($AdressVersion -ne "1") {
            if ($DebugMode -eq "true") {Write-Host "AdressVersion ist nicht 1"}
            if ($AdressVersion -ne "") {
                if ($DebugMode -eq "true") {Write-Host "AdressVersion ist nicht """""}
                $VerStat=$false
            }
        }


        if ($DebugMode -eq "true") {$Text= "VerStat:" +  $VerStat;  Write-Host $Text}

        if ($VerStat -eq $true) {
                # hier wird migriert!

                if ($DebugMode -eq "true") {$Text= "Starte mit AdressDBdb";  Write-Host $Text}

                $AdressDBSplit=$Global:AdressDB.split("`n")
                $FehlerText=""

                # Header anpassen (VersionsInfo eliminieren)
                $Header=$AdressDBSplit[0]
                $HeaderSplit=$Header.split("#")

                $Erg="1"
                if ($HeaderSplit.count -gt 1){
                        $PureHeader=$HeaderSplit[2]
                    } else {
                        $PureHeader=$Header
                }

                $NeueAdressDB="#2#" + $PureHeader + "`tX`tY" 
                for($i=1; $i -lt ($AdressDBSplit.count); $i++){
                    ProgressStatus2 -ProgressLnr 1 -MaxValue $AdressDBSplit.count -ActValue $i
                    $Adresse=$AdressDBSplit[$i]
                    if ($DebugMode -eq "true") {$text = "Adresse:`t" +  $Adresse;  Write-Host $text} 
                    $NeueAdressDB=$NeueAdressDB + "`n" + $Adresse + "`t`t" 
                }
                
                if ($DebugMode -eq "true") {$text = "NeueAdressDB:`t" +  $NeueAdressDB;  Write-Host $text} 

                # neue personendb schreiben
                WriteAdressData -NeueDaten $NeueAdressDB 

                
                # PersonenDaten erneut einlesen
                $global:AdressDB=GetAdressData
                if ($DebugMode -eq "true") {Write-Host "AdressDB:`t";  Write-Host $global:AdressDB} 

            } else {
                $ErgText = GetTextFromLanguageDB -ID  ("3_M_RES_26") # "Datanbanken liegen nicht in der erforderliche Version vor. Es wird lieber mal nix gemacht!"
        }
                
        $MigrateDbFile=""
        if ($ErgText -ne "") {

            $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"
            if ($ExportFolder -eq "") {$ExportFolder="."}

            $MigrateDbFile=$ExportFolder  + "\MigrateAdressDbV1ToV2File.log"
            $ErgText| Out-File -FilePath $MigrateDbFile
        }
        
        ProgressStatus2 -ProgressLnr 1 -MaxValue 100 -ActValue 100
        
        if ($DebugMode -eq "true"){$Text= "## MigrateAdressDbFromV1ToV2 endet mit Rückgabe-Parameter:" + $MigrateDbFile; Write-Host $Text}
        return $MigrateDbFile
    }


#endregion TestTools

#region BrowserVersionsInfo

    function GetChromeDriverVersion() {
        param (
            $chromeDriverPath=""
        )
        ##################################################
        # Version V01
        # vom 2.6.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"

        if ($DebugMode -eq "true") {$DebugText="GetChromeDriverVersion startet";Write-Host $DebugText}

        $Erg= ""
        $Version=""
        
        $PrgPfad=$chromeDriverPath + "\chromedriver.exe"
        if ($DebugMode -eq "true") {$DebugText="PrgPfad:" + $PrgPfad;Write-Host $DebugText}

        # Überprüfen, ob die Chrome-Executable-Datei vorhanden ist
        if (Test-Path $PrgPfad) {
            
                if ($DebugMode -eq "true") {$DebugText="chromeDriverPath " + $chromeDriverPath + " existiert";Write-Host $DebugText}

                # Starten Sie den ChromeDriver und erfassen Sie die Ausgabe
                $chromeDriverOutput = & $PrgPfad --version

                # Extrahieren Sie die Version aus der Ausgabe
                $chromeDriverVersion = $chromeDriverOutput -replace '^.*ChromeDriver\s+(\d+\.\d+\.\d+\.\d+).*$','$1'

                $Erg=$chromeDriverVersion
                
                if ($DebugMode -eq "true") {$DebugText= "Die installierte Chrome-Driver-version ist:`t" + $Erg;Write-Host $DebugText}
            }
            else {
                if ($DebugMode -eq "true") {$DebugText= "Chrome-Driver ist nicht installiert.";Write-Host $DebugText}
        }

        if ($DebugMode -eq "true") {$DebugText= "GetChromeDriverVersion endet mit Rückgabe:`t" + $Erg;Write-Host $DebugText}

        return $Erg
    }

    function GetOpera64Version() {
        ##################################################
        # Version V01
        # vom 2.6.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$DebugText="GetChrome64Version startet";Write-Host $DebugText}

        $Erg= ""
        $Version=""

        # Pfad zur Chrome-Executable-Datei
        $ChromeExecutablePath = "$env:ProgramFiles\Opera\launcher.exe"

        $FileVersionInfo=@()

        # Überprüfen, ob die Chrome-Executable-Datei vorhanden ist
        if (Test-Path $ChromeExecutablePath) {

                # Abrufen der Dateiinformationen
                [string]$FileVersionInfo = Get-Item $ChromeExecutablePath | Get-ItemProperty -Name VersionInfo
                if ($DebugMode -eq "true") {$DebugText= "FileVersionInfo:`n" + $FileVersionInfo;Write-Host $DebugText}

            
                $FileVersionInfoHeaderSplit=$FileVersionInfo.split("=") # eliminiert "@{VersionInfo="
                $FileVersionInfoSplit=$FileVersionInfoHeaderSplit[1].split("`n")
                if ($DebugMode -eq "true") {$DebugText= "SplitAnz:`t" + $FileVersionInfoSplit.count;Write-Host $DebugText}


                for($f=0; $f -lt $FileVersionInfoSplit.count; $f++){
                    $Zeile=$FileVersionInfoSplit[$f]
                
                    if ($DebugMode -eq "true") {$DebugText= "Zeile:`t" + $Zeile;Write-Host $DebugText}
                    $ZeileSplit=$Zeile.split(":")
               
                    if ($DebugMode -eq "true") {$DebugText= "ZeileSplit[0]:`t" + $ZeileSplit[0] + ", ZeileSplit[1]:`t" + $ZeileSplit[1];Write-Host $DebugText}

                    if ($ZeileSplit[0].Trim() -eq "ProductVersion") {
                        $Version=$ZeileSplit[1]
                        
                        if ($DebugMode -eq "true") {$DebugText= "Treffer";Write-Host $DebugText}
                    }
                }
                if ($DebugMode -eq "true") {$DebugText= "Version:`t" + $Version;Write-Host $DebugText}


                $Erg= $Version
        
                if ($DebugMode -eq "true") {$DebugText= "Die installierte Chrome-Browserversion ist:`t" + $Version;Write-Host $DebugText}
            }
            else {
                if ($DebugMode -eq "true") {$DebugText= "Chrome-Browser ist nicht installiert.";Write-Host $DebugText}
        }


        if ($DebugMode -eq "true") {$DebugText= "GetChrome64Version endet mit Rückgabe:`t" + $Erg;Write-Host $DebugText}

        return $Erg
    }

    function GetOperaProfileVersion() {
        ##################################################
        # Version V01
        # vom 2.6.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") {$DebugText="GetOperaProfileVersion startet";Write-Host $DebugText}

        $Erg= ""
        $Version=""

        # Pfad zur Chrome-Executable-Datei
        $ChromeExecutablePath = "$env:LOCALAPPDATA\Programs\Opera\launcher.exe"

        $FileVersionInfo=@()

        # Überprüfen, ob die Chrome-Executable-Datei vorhanden ist
        if (Test-Path $ChromeExecutablePath) {

                # Abrufen der Dateiinformationen
                [string]$FileVersionInfo = Get-Item $ChromeExecutablePath | Get-ItemProperty -Name VersionInfo
                if ($DebugMode -eq "true") {$DebugText= "FileVersionInfo:`n" + $FileVersionInfo;Write-Host $DebugText}

            
                $FileVersionInfoHeaderSplit=$FileVersionInfo.split("=") # eliminiert "@{VersionInfo="
                $FileVersionInfoSplit=$FileVersionInfoHeaderSplit[1].split("`n")
                if ($DebugMode -eq "true") {$DebugText= "SplitAnz:`t" + $FileVersionInfoSplit.count;Write-Host $DebugText}


                for($f=0; $f -lt $FileVersionInfoSplit.count; $f++){
                    $Zeile=$FileVersionInfoSplit[$f]
                
                    if ($DebugMode -eq "true") {$DebugText= "Zeile:`t" + $Zeile;Write-Host $DebugText}
                    $ZeileSplit=$Zeile.split(":")
               
                    if ($DebugMode -eq "true") {$DebugText= "ZeileSplit[0]:`t" + $ZeileSplit[0] + ", ZeileSplit[1]:`t" + $ZeileSplit[1];Write-Host $DebugText}

                    if ($ZeileSplit[0].Trim() -eq "ProductVersion") {
                        $Version=$ZeileSplit[1]
                        
                        if ($DebugMode -eq "true") {$DebugText= "Treffer";Write-Host $DebugText}
                    }
                }
                if ($DebugMode -eq "true") {$DebugText= "Version:`t" + $Version;Write-Host $DebugText}


                $Erg= $Version
        
                if ($DebugMode -eq "true") {$DebugText= "Die installierte Opera-Browserversion ist:`t" + $Version;Write-Host $DebugText}
            }
            else {
                if ($DebugMode -eq "true") {$DebugText= "Opera im User-Profile ist nicht installiert.";Write-Host $DebugText}
        }


        if ($DebugMode -eq "true") {$DebugText= "GetOperaProfileVersion endet mit Rückgabe:`t" + $Erg;Write-Host $DebugText}

        return $Erg
    }

    function GetOpera32Version() {
        ##################################################
        # Version V01
        # vom 2.6.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$DebugText="GetChrome64Version startet";Write-Host $DebugText}

        $Erg= ""
        $Version=""

        # Pfad zur Chrome-Executable-Datei
        $ChromeExecutablePath = "$env:ProgramFiles (x86)\Opera\launcher.exe"

        $FileVersionInfo=@()

        # Überprüfen, ob die Chrome-Executable-Datei vorhanden ist
        if (Test-Path $ChromeExecutablePath) {

                # Abrufen der Dateiinformationen
                [string]$FileVersionInfo = Get-Item $ChromeExecutablePath | Get-ItemProperty -Name VersionInfo
                if ($DebugMode -eq "true") {$DebugText= "FileVersionInfo:`n" + $FileVersionInfo;Write-Host $DebugText}

            
                $FileVersionInfoHeaderSplit=$FileVersionInfo.split("=") # eliminiert "@{VersionInfo="
                $FileVersionInfoSplit=$FileVersionInfoHeaderSplit[1].split("`n")
                if ($DebugMode -eq "true") {$DebugText= "SplitAnz:`t" + $FileVersionInfoSplit.count;Write-Host $DebugText}


                for($f=0; $f -lt $FileVersionInfoSplit.count; $f++){
                    $Zeile=$FileVersionInfoSplit[$f]
                
                    if ($DebugMode -eq "true") {$DebugText= "Zeile:`t" + $Zeile;Write-Host $DebugText}
                    $ZeileSplit=$Zeile.split(":")
               
                    if ($DebugMode -eq "true") {$DebugText= "ZeileSplit[0]:`t" + $ZeileSplit[0] + ", ZeileSplit[1]:`t" + $ZeileSplit[1];Write-Host $DebugText}

                    if ($ZeileSplit[0].Trim() -eq "ProductVersion") {
                        $Version=$ZeileSplit[1]
                        
                        if ($DebugMode -eq "true") {$DebugText= "Treffer";Write-Host $DebugText}
                    }
                }
                if ($DebugMode -eq "true") {$DebugText= "Version:`t" + $Version;Write-Host $DebugText}


                $Erg= $Version
        
                if ($DebugMode -eq "true") {$DebugText= "Die installierte Chrome-Browserversion ist:`t" + $Version;Write-Host $DebugText}
            }
            else {
                if ($DebugMode -eq "true") {$DebugText= "Chrome-Browser ist nicht installiert.";Write-Host $DebugText}
        }


        if ($DebugMode -eq "true") {$DebugText= "GetChrome64Version endet mit Rückgabe:`t" + $Erg;Write-Host $DebugText}

        return $Erg
    }

    function GetAvast64Version() {
        ##################################################
        # Version V01
        # vom 2.6.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$DebugText="GetChrome64Version startet";Write-Host $DebugText}

        $Erg= ""
        $Version=""

        # Pfad zur Chrome-Executable-Datei
        $ChromeExecutablePath = "$env:ProgramFiles\AVAST Software\Browser\Application\AvastBrowser.exe"

        $FileVersionInfo=@()

        # Überprüfen, ob die Chrome-Executable-Datei vorhanden ist
        if (Test-Path $ChromeExecutablePath) {

                # Abrufen der Dateiinformationen
                [string]$FileVersionInfo = Get-Item $ChromeExecutablePath | Get-ItemProperty -Name VersionInfo
                if ($DebugMode -eq "true") {$DebugText= "FileVersionInfo:`n" + $FileVersionInfo;Write-Host $DebugText}

            
                $FileVersionInfoHeaderSplit=$FileVersionInfo.split("=") # eliminiert "@{VersionInfo="
                $FileVersionInfoSplit=$FileVersionInfoHeaderSplit[1].split("`n")
                if ($DebugMode -eq "true") {$DebugText= "SplitAnz:`t" + $FileVersionInfoSplit.count;Write-Host $DebugText}


                for($f=0; $f -lt $FileVersionInfoSplit.count; $f++){
                    $Zeile=$FileVersionInfoSplit[$f]
                
                    if ($DebugMode -eq "true") {$DebugText= "Zeile:`t" + $Zeile;Write-Host $DebugText}
                    $ZeileSplit=$Zeile.split(":")
               
                    if ($DebugMode -eq "true") {$DebugText= "ZeileSplit[0]:`t" + $ZeileSplit[0] + ", ZeileSplit[1]:`t" + $ZeileSplit[1];Write-Host $DebugText}

                    if ($ZeileSplit[0].Trim() -eq "ProductVersion") {
                        $Version=$ZeileSplit[1]
                        
                        if ($DebugMode -eq "true") {$DebugText= "Treffer";Write-Host $DebugText}
                    }
                }
                if ($DebugMode -eq "true") {$DebugText= "Version:`t" + $Version;Write-Host $DebugText}


                $Erg= $Version
        
                if ($DebugMode -eq "true") {$DebugText= "Die installierte Chrome-Browserversion ist:`t" + $Version;Write-Host $DebugText}
            }
            else {
                if ($DebugMode -eq "true") {$DebugText= "Chrome-Browser ist nicht installiert.";Write-Host $DebugText}
        }


        if ($DebugMode -eq "true") {$DebugText= "GetChrome64Version endet mit Rückgabe:`t" + $Erg;Write-Host $DebugText}

        return $Erg
    }

    function GetAvast32Version() {
        ##################################################
        # Version V01
        # vom 2.6.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$DebugText="GetChrome64Version startet";Write-Host $DebugText}

        $Erg= ""
        $Version=""

        # Pfad zur Chrome-Executable-Datei
        $ChromeExecutablePath = "$env:ProgramFiles (x86)\AVAST Software\Browser\Application\AvastBrowser.exe"

        $FileVersionInfo=@()

        # Überprüfen, ob die Chrome-Executable-Datei vorhanden ist
        if (Test-Path $ChromeExecutablePath) {

                # Abrufen der Dateiinformationen
                [string]$FileVersionInfo = Get-Item $ChromeExecutablePath | Get-ItemProperty -Name VersionInfo
                if ($DebugMode -eq "true") {$DebugText= "FileVersionInfo:`n" + $FileVersionInfo;Write-Host $DebugText}

            
                $FileVersionInfoHeaderSplit=$FileVersionInfo.split("=") # eliminiert "@{VersionInfo="
                $FileVersionInfoSplit=$FileVersionInfoHeaderSplit[1].split("`n")
                if ($DebugMode -eq "true") {$DebugText= "SplitAnz:`t" + $FileVersionInfoSplit.count;Write-Host $DebugText}


                for($f=0; $f -lt $FileVersionInfoSplit.count; $f++){
                    $Zeile=$FileVersionInfoSplit[$f]
                
                    if ($DebugMode -eq "true") {$DebugText= "Zeile:`t" + $Zeile;Write-Host $DebugText}
                    $ZeileSplit=$Zeile.split(":")
               
                    if ($DebugMode -eq "true") {$DebugText= "ZeileSplit[0]:`t" + $ZeileSplit[0] + ", ZeileSplit[1]:`t" + $ZeileSplit[1];Write-Host $DebugText}

                    if ($ZeileSplit[0].Trim() -eq "ProductVersion") {
                        $Version=$ZeileSplit[1]
                        
                        if ($DebugMode -eq "true") {$DebugText= "Treffer";Write-Host $DebugText}
                    }
                }
                if ($DebugMode -eq "true") {$DebugText= "Version:`t" + $Version;Write-Host $DebugText}


                $Erg= $Version
        
                if ($DebugMode -eq "true") {$DebugText= "Die installierte Chrome-Browserversion ist:`t" + $Version;Write-Host $DebugText}
            }
            else {
                if ($DebugMode -eq "true") {$DebugText= "Chrome-Browser ist nicht installiert.";Write-Host $DebugText}
        }


        if ($DebugMode -eq "true") {$DebugText= "GetChrome64Version endet mit Rückgabe:`t" + $Erg;Write-Host $DebugText}

        return $Erg
    }

    function GetChrome64Version() {
        ##################################################
        # Version V01
        # vom 2.6.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$DebugText="GetChrome64Version startet";Write-Host $DebugText}

        $Erg= ""
        $Version=""

        # Pfad zur Chrome-Executable-Datei
        $ChromeExecutablePath = "$env:ProgramFiles\Google\Chrome\Application\chrome.exe"

        $FileVersionInfo=@()

        # Überprüfen, ob die Chrome-Executable-Datei vorhanden ist
        if (Test-Path $ChromeExecutablePath) {

                # Abrufen der Dateiinformationen
                [string]$FileVersionInfo = Get-Item $ChromeExecutablePath | Get-ItemProperty -Name VersionInfo
                if ($DebugMode -eq "true") {$DebugText= "FileVersionInfo:`n" + $FileVersionInfo;Write-Host $DebugText}

            
                $FileVersionInfoHeaderSplit=$FileVersionInfo.split("=") # eliminiert "@{VersionInfo="
                $FileVersionInfoSplit=$FileVersionInfoHeaderSplit[1].split("`n")
                if ($DebugMode -eq "true") {$DebugText= "SplitAnz:`t" + $FileVersionInfoSplit.count;Write-Host $DebugText}


                for($f=0; $f -lt $FileVersionInfoSplit.count; $f++){
                    $Zeile=$FileVersionInfoSplit[$f]
                
                    if ($DebugMode -eq "true") {$DebugText= "Zeile:`t" + $Zeile;Write-Host $DebugText}
                    $ZeileSplit=$Zeile.split(":")
               
                    if ($DebugMode -eq "true") {$DebugText= "ZeileSplit[0]:`t" + $ZeileSplit[0] + ", ZeileSplit[1]:`t" + $ZeileSplit[1];Write-Host $DebugText}

                    if ($ZeileSplit[0].Trim() -eq "ProductVersion") {
                        $Version=$ZeileSplit[1]
                        
                        if ($DebugMode -eq "true") {$DebugText= "Treffer";Write-Host $DebugText}
                    }
                }
                if ($DebugMode -eq "true") {$DebugText= "Version:`t" + $Version;Write-Host $DebugText}


                $Erg= $Version
        
                if ($DebugMode -eq "true") {$DebugText= "Die installierte Chrome-Browserversion ist:`t" + $Version;Write-Host $DebugText}
            }
            else {
                if ($DebugMode -eq "true") {$DebugText= "Chrome-Browser ist nicht installiert.";Write-Host $DebugText}
        }


        if ($DebugMode -eq "true") {$DebugText= "GetChrome64Version endet mit Rückgabe:`t" + $Erg;Write-Host $DebugText}

        return $Erg
    }

    function GetChrome32Version() {
        ##################################################
        # Version V01
        # vom 2.6.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"

        if ($DebugMode -eq "true") {$DebugText="GetChrome32Version startet";Write-Host $DebugText}

        $Erg= ""
        $Version=""

        # Pfad zur Chrome-Executable-Datei
        $ChromeExecutablePath = "$env:ProgramFiles(x86)\Google\Chrome\Application\chrome.exe"

        $FileVersionInfo=@()

        # Überprüfen, ob die Chrome-Executable-Datei vorhanden ist
        if (Test-Path $ChromeExecutablePath) {

                # Abrufen der Dateiinformationen
                [string]$FileVersionInfo = Get-Item $ChromeExecutablePath | Get-ItemProperty -Name VersionInfo
                if ($DebugMode -eq "true") {$DebugText= "FileVersionInfo:`n" + $FileVersionInfo;Write-Host $DebugText}

            
                $FileVersionInfoHeaderSplit=$FileVersionInfo.split("=") # eliminiert "@{VersionInfo="
                $FileVersionInfoSplit=$FileVersionInfoHeaderSplit[1].split("`n")
                if ($DebugMode -eq "true") {$DebugText= "SplitAnz:`t" + $FileVersionInfoSplit.count;Write-Host $DebugText}


                for($f=0; $f -lt $FileVersionInfoSplit.count; $f++){
                    $Zeile=$FileVersionInfoSplit[$f]
                
                    if ($DebugMode -eq "true") {$DebugText= "Zeile:`t" + $Zeile;Write-Host $DebugText}
                    $ZeileSplit=$Zeile.split(":")
               
                    if ($DebugMode -eq "true") {$DebugText= "ZeileSplit[0]:`t" + $ZeileSplit[0] + ", ZeileSplit[1]:`t" + $ZeileSplit[1];Write-Host $DebugText}

                    if ($ZeileSplit[0].Trim() -eq "ProductVersion") {
                        $Version=$ZeileSplit[1]
                        
                        if ($DebugMode -eq "true") {$DebugText= "Treffer";Write-Host $DebugText}
                    }
                }
                if ($DebugMode -eq "true") {$DebugText= "Version:`t" + $Version;Write-Host $DebugText}


                $Erg= $Version
        
                if ($DebugMode -eq "true") {$DebugText= "Die installierte Chrome-Browserversion ist:`t" + $Version;Write-Host $DebugText}
            }
            else {
                if ($DebugMode -eq "true") {$DebugText= "Chrome-Browser ist nicht installiert.";Write-Host $DebugText}
        }


        if ($DebugMode -eq "true") {$DebugText= "GetChrome32Version endet mit Rückgabe:`t" + $Erg;Write-Host $DebugText}

        return $Erg
    }

    function GetFirefox64Version() {
        ##################################################
        # Version V01
        # vom 2.6.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"

        if ($DebugMode -eq "true") {$DebugText="GetFirefox64Version startet";Write-Host $DebugText}

        $Erg= ""
        $Version=""

        # Pfad zur Firefox-Executable-Datei
        $firefoxExecutablePath = "$env:ProgramFiles\Mozilla Firefox\firefox.exe"


        # Überprüfen, ob die Chrome-Executable-Datei vorhanden ist
        if (Test-Path $firefoxExecutablePath) {

                # Abrufen der Dateiinformationen
                [string]$FileVersionInfo = Get-Item $firefoxExecutablePath | Get-ItemProperty -Name VersionInfo
                if ($DebugMode -eq "true") {$DebugText= "FileVersionInfo:`n" + $FileVersionInfo;Write-Host $DebugText}

            
                $FileVersionInfoHeaderSplit=$FileVersionInfo.split("=") # eliminiert "@{VersionInfo="
                $FileVersionInfoSplit=$FileVersionInfoHeaderSplit[1].split("`n")
                if ($DebugMode -eq "true") {$DebugText= "SplitAnz:`t" + $FileVersionInfoSplit.count;Write-Host $DebugText}


                for($f=0; $f -lt $FileVersionInfoSplit.count; $f++){
                    $Zeile=$FileVersionInfoSplit[$f]
                
                    if ($DebugMode -eq "true") {$DebugText= "Zeile:`t" + $Zeile;Write-Host $DebugText}
                    $ZeileSplit=$Zeile.split(":")
               
                    if ($DebugMode -eq "true") {$DebugText= "ZeileSplit[0]:`t" + $ZeileSplit[0] + ", ZeileSplit[1]:`t" + $ZeileSplit[1];Write-Host $DebugText}

                    if ($ZeileSplit[0].Trim() -eq "ProductVersion") {
                        $Version=$ZeileSplit[1]
                        
                        if ($DebugMode -eq "true") {$DebugText= "Treffer";Write-Host $DebugText}
                    }
                }
                if ($DebugMode -eq "true") {$DebugText= "Version:`t" + $Version;Write-Host $DebugText}


                $Erg= $Version
        
                if ($DebugMode -eq "true") {$DebugText= "Die installierte Firefox-Browserversion ist:`t" + $Version;Write-Host $DebugText}
            }
            else {
                if ($DebugMode -eq "true") {$DebugText= "Firefox-Browser ist nicht installiert.";Write-Host $DebugText}
        }


        if ($DebugMode -eq "true") {$DebugText= "GetFirefox64Version endet mit Rückgabe:`t" + $Erg;Write-Host $DebugText}

        return $Erg
    }

    function GetFirefox32Version() {
        ##################################################
        # Version V01
        # vom 2.6.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"

        if ($DebugMode -eq "true") {$DebugText="GetFirefox32Version startet";Write-Host $DebugText}

        $Erg= ""
        $Version=""

        # Pfad zur Firefox-Executable-Datei
        $firefoxExecutablePath = "$env:ProgramFiles(x86)\Mozilla Firefox\firefox.exe"


        # Überprüfen, ob die Chrome-Executable-Datei vorhanden ist
        if (Test-Path $firefoxExecutablePath) {

                # Abrufen der Dateiinformationen
                [string]$FileVersionInfo = Get-Item $firefoxExecutablePath | Get-ItemProperty -Name VersionInfo
                if ($DebugMode -eq "true") {$DebugText= "FileVersionInfo:`n" + $FileVersionInfo;Write-Host $DebugText}

            
                $FileVersionInfoHeaderSplit=$FileVersionInfo.split("=") # eliminiert "@{VersionInfo="
                $FileVersionInfoSplit=$FileVersionInfoHeaderSplit[1].split("`n")
                if ($DebugMode -eq "true") {$DebugText= "SplitAnz:`t" + $FileVersionInfoSplit.count;Write-Host $DebugText}


                for($f=0; $f -lt $FileVersionInfoSplit.count; $f++){
                    $Zeile=$FileVersionInfoSplit[$f]
                
                    if ($DebugMode -eq "true") {$DebugText= "Zeile:`t" + $Zeile;Write-Host $DebugText}
                    $ZeileSplit=$Zeile.split(":")
               
                    if ($DebugMode -eq "true") {$DebugText= "ZeileSplit[0]:`t" + $ZeileSplit[0] + ", ZeileSplit[1]:`t" + $ZeileSplit[1];Write-Host $DebugText}

                    if ($ZeileSplit[0].Trim() -eq "ProductVersion") {
                        $Version=$ZeileSplit[1]
                        
                        if ($DebugMode -eq "true") {$DebugText= "Treffer";Write-Host $DebugText}
                    }
                }
                if ($DebugMode -eq "true") {$DebugText= "Version:`t" + $Version;Write-Host $DebugText}


                $Erg= $Version
        
                if ($DebugMode -eq "true") {$DebugText= "Die installierte Firefox-Browserversion ist:`t" + $Version;Write-Host $DebugText}
            }
            else {
                if ($DebugMode -eq "true") {$DebugText= "Firefox-Browser ist nicht installiert.";Write-Host $DebugText}
        }


        if ($DebugMode -eq "true") {$DebugText= "GetFirefox32Version endet mit Rückgabe:`t" + $Erg;Write-Host $DebugText}

        return $Erg
    }

    function GetEdgeVersion() {
        ##################################################
        # Version V01
        # vom 2.6.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"

        if ($DebugMode -eq "true") {$DebugText="GetEdgeVersion startet";Write-Host $DebugText}

        $Erg= ""
        $Version=(Get-AppxPackage -Name Microsoft.MicrosoftEdge).Version

        $Erg= $Version
     
        if ($DebugMode -eq "true") {$DebugText= "GetEdgeVersion endet mit Rückgabe:`t" + $Erg;Write-Host $DebugText}

        return $Erg
    }

    function GetIEVersion() {
        ##################################################
        # Version V01
        # vom 2.6.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"

        if ($DebugMode -eq "true") {$DebugText="GetEdgeVersion startet";Write-Host $DebugText}

        $Erg= ""
        $Version= (Get-ItemProperty "HKLM:\Software\Microsoft\Internet Explorer").Version

        $Erg= $Version
     
        if ($DebugMode -eq "true") {$DebugText= "GetEdgeVersion endet mit Rückgabe:`t" + $Erg;Write-Host $DebugText}

        return $Erg
    }

    function FindBrowserDriverPfad() {
        param(
            $BrowserDriverPfad=""
        )
        ##################################################
        # Version V01
        # vom 2.6.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"

        if ($DebugMode -eq "true") {$DebugText="FindBrowserDriverPfad startet";Write-Host $DebugText}

       # $BrowserDriverPfad="E:\_Stammbaum_Zeugs\NeuMitPowershell\Selenium\chromedriver\win32\113"
        if ($BrowserDriverPfad -eq "") {
            $Chrome64Version=GetChrome64Version
            $Chrome64VersionMajor=$Chrome64Version.split(".")[0].trim() 
            if ($Chrome64Version -ne "") {
                    $BrowserDriverPfad=$global:BasisPfad + "\selenium\chromedriver\win32\" + $Chrome64VersionMajor
                } else {
                    $Chrome32Version=GetChrome32Version
                    $Chrome32VersionMajor=$Chrome32Version.split(".")[0].trim() 
                    if ($Chrome32Version -ne "") {
                        $BrowserDriverPfad=$global:BasisPfad + "\selenium\chromedriver\win32\" + $Chrome32VersionMajor
                    }
            }
        }
        
        if ($DebugMode -eq "true") {$DebugText= "FindBrowserDriverPfad endet mit Rückgabe:" + $BrowserDriverPfad ;Write-Host $DebugText}
        return $BrowserDriverPfad
    }

    function FindSeleniumPfad() {
        param(
            $SeleniumPfad=""
        )
        ##################################################
        # Version V01
        # vom 2.6.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") {$DebugText="FindSeleniumPfad startet mit Parameter:`n`tSeleniumPfad:`t" + $SeleniumPfad;Write-Host $DebugText}
        
        $SeleniumPfad=(" " + $SeleniumPfad).trim()
        if ($SeleniumPfad -eq "") {
            $SeleniumPfad=$global:BasisPfad + "\Selenium\selenium-powershell-master"
        }

        if ($DebugMode -eq "true") {$DebugText= "FindSeleniumPfad endet mit Rückgabe:" + $SeleniumPfad ;Write-Host $DebugText}
        return $SeleniumPfad
    }

    function GetBrowserVersioninfo() {
        ##################################################
        # Version V01
        # vom 27.5.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$DebugText= "GetBrowserVersioninfo startet";Write-Host $DebugText}


        $Chrome64Version=GetChrome64Version
        $Chrome32Version=GetChrome32Version
        $Firefox64Version=GetFirefox64Version
        $Firefox32Version=GetFirefox32Version
        $EdgeVersion=GetEdgeVersion
        $IEVersion=GetIEVersion
        $Opera64Version=GetOpera64Version
        $Opera32Version=GetOpera32Version
        $OperaProfileVersion=GetOperaProfileVersion
        $Avast64Version=GetAvast64Version
        $Avast32Version=GetAvast32Version

        $BrowserDriverPfad=FindBrowserDriverPfad -BrowserDriverPfad $BrowserDriverPfad
        $SeleniumPfad=FindSeleniumPfad -SeleniumPfad $SeleniumPfad
    
        $SummaryText=""
        $SummaryText= $SummaryText + "Chrome-Browser 64-Bit`t" + $Chrome64Version + "`n"
        $SummaryText= $SummaryText + "Chrome-Browser 32-Bit`t" + $Chrome32Version + "`n"
        $SummaryText= $SummaryText + "Firefox-Browser 64-Bit`t" + $Firefox64Version + "`n"
        $SummaryText= $SummaryText + "Firefox-Browser 32-Bit`t" + $Firefox32Version + "`n"
        $SummaryText= $SummaryText + "Edge-Browser`t" + $EdgeVersion + "`n"
        $SummaryText= $SummaryText + "IE-Browser`t" + $IEVersion + "`n"
        $SummaryText= $SummaryText + "Opera-Browser Profile`t" + $OperaProfileVersion + "`n"
        $SummaryText= $SummaryText + "Opera-Browser 64-Bit`t" + $Opera64Version + "`n"
        $SummaryText= $SummaryText + "Opera-Browser 32-Bit`t" + $Opera32Version + "`n"
        $SummaryText= $SummaryText + "Avast-Browser 64-Bit`t" + $Avast64Version + "`n"
        $SummaryText= $SummaryText + "Avast-Browser 32-Bit`t" + $Avast32Version + "`n`n"
        $SummaryText= $SummaryText + "BrowserDriverPfad`t" + $BrowserDriverPfad + "`n"
        $SummaryText= $SummaryText + "SeleniumPfad`t" + $SeleniumPfad + "`n"

    
        if ($DebugMode -eq "true") {$DebugText= $SummaryText;Write-Host $DebugText}

        if ($DebugMode -eq "true") {$DebugText= "GetBrowserVersioninfo endet mit Rückgabe:" + $SummaryText ;Write-Host $DebugText}
        return $SummaryText
    }

#endregion BrowserVersionsInfo


#region MainMenuTM  

    function ProgressStatus2() {
        param (
            $ProgressLnr=0,
            $MaxValue=0,
            $ActValue=0
        )
        ##################################################
        # Version V02
        # vom 10.4.2023
        # == Version V03 von Stammbaum_Export2HTML_V24.ps1 aber nur mit 2 Fortschritts-Balken
        ##################################################
                
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode="true"

        if ($DebugMode -eq "true"){$Text= "## ProgressStatus2 startet`t--`tParameter:`n`t`t`tProgressLnr:`t" + $ProgressLnr + "`n`t`t`tMaxValue:`t" + $MaxValue + "`n`t`t`tActValue:`t" + $ActValue; Write-Host $Text}

        # Notbremse gegen Fehlermeldung
        if ($MaxValue -lt $ActValue ) {$ActValue = $MaxValue}


        if ($ProgressLnr -eq 1) {
        
            #$ProgressBar1.show()
            $ProgressBar1.Maximum=$MaxValue
            $ProgressBar1.value=$ActValue
        }
        if ($ProgressLnr -eq 2) {
        
            #$ProgressBar2.show()
            $ProgressBar2.Maximum=$MaxValue
            $ProgressBar2.value=$ActValue
        }

        $DebugMode=$OldDebugMode

    }

    function prepareTgGui2() {
        ##################################################
        # Version V01
        # vom 7.4.2023
        # == Version V01 von Stammbaum_Export2HTML_V24.ps1 aber ohne Handling von $DATComboBox, die hier nicht existiert
        ##################################################
        if ($DebugMode -eq "true"){$Text= "## prepareTgGui2 startet"; Write-Host $Text}
        
        $TGSelected = $TGComboBox.SelectedIndex
        if ($DebugMode -eq "true"){$Text= "## prepareTgGui2`t--`tAuswahl:`t" + $TGSelected + " (" + $TGComboBox.selecteditem + ")"; Write-Host $Text}
        
        if ($TGSelected -eq 0) {
                $DAGComboBox.hide()
                $DAGComboBox.SelectedIndex=-1
            } elseif ($TGSelected -eq 1) {
                $DAGComboBox.show()
        }
    }
      
    $ZielOeffnenButton_OnClick={
        $File=$erglabel.Text
        Invoke-Item $File

    }

    $StartButton_OnClick={
        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick startet"; Write-Host $Text}
        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DATComboBox.SelectedIndex + " (" + $DATComboBox.selecteditem + ")`n`t--`tDAG-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}

        
    
        $OldDebugMode=$DebugMode
       # $DebugMode="true"

        if ($TGComboBox.SelectedIndex -eq 0) {
                # alles automatisch machen lassen
                if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")"; Write-Host $Text}

                $ZielOeffnenButton.hide()         
                $erglabel.hide()

                $PB1Label.show()
                $ProgressBar1.show()  
                $ProgressBar2.show()  
                $PB2Label.Text=GetTextFromLanguageDB -ID  ("3_M_RES_4") #" Gesamt-Status "   
                $PB2Label.show()  

                $MainMenuTMForm.Refresh()  
                   
                $AnzTeilProzesse = 9

                ProgressStatus2 -ProgressLnr 2 -MaxValue $AnzTeilProzesse -ActValue 1
                # PE <==> Kn 
                $PB1Label.Text=GetTextFromLanguageDB -ID  ("3_M_RES_5") #" PE <==> Kn "  
                $MainMenuTMForm.Refresh()  
                $PeKnSourceDataFile=CheckPeKn
                
                ProgressStatus2 -ProgressLnr 2 -MaxValue $AnzTeilProzesse -ActValue 2
                # Kn <==> Pe   
                $PB1Label.Text=GetTextFromLanguageDB -ID  ("3_M_RES_6") #" Kn <==> Pe " 
                $MainMenuTMForm.Refresh()    
                $KnPeSourceDataFile=CheckKnPe

                
                ProgressStatus2 -ProgressLnr 2 -MaxValue $AnzTeilProzesse -ActValue 3
                # Pe <==> Pa
                $PB1Label.Text=GetTextFromLanguageDB -ID  ("3_M_RES_7") #" Pe <==> Pa " 
                $MainMenuTMForm.Refresh()   
                $PePaSourceDataFile=CheckPePa

                
                ProgressStatus2 -ProgressLnr 2 -MaxValue $AnzTeilProzesse -ActValue 4
                # El <==> Ki
                $PB1Label.Text=GetTextFromLanguageDB -ID  ("3_M_RES_8") #" El <==> Ki "  
                $MainMenuTMForm.Refresh()  
                $ElKiSourceDataFile=CheckElKi
                
                ProgressStatus2 -ProgressLnr 2 -MaxValue $AnzTeilProzesse -ActValue 5
                # Check Pe-Index
                $PB1Label.Text =GetTextFromLanguageDB -ID  ("3_M_RES_9") # "Test ""Personen-DB Index""" 
                $MainMenuTMForm.Refresh()  
                $CheckPeIndexSourceDataFile=CheckPeIndex                

                ProgressStatus2 -ProgressLnr 2 -MaxValue $AnzTeilProzesse -ActValue 6
                # Check Kn-Index
                $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_10") #"Test ""Knoten-DB Index""" 
                $MainMenuTMForm.Refresh()  
                $CheckKnIndexSourceDataFile=CheckKnIndex   
                               
                ProgressStatus2 -ProgressLnr 2 -MaxValue $AnzTeilProzesse -ActValue 7
                # Pe-DB Re-Index
                $PB1Label.Text =GetTextFromLanguageDB -ID  ("3_M_RES_11") # "Erneuere Personen-DB Index"
                $MainMenuTMForm.Refresh()  
                $PeReIndexSourceDataFile=PeReIndex  
                              
                ProgressStatus2 -ProgressLnr 2 -MaxValue $AnzTeilProzesse -ActValue 8
                # Kn-DB Re-Index
                $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_12") #"Erneuere Knoten-DB Index" 
                $MainMenuTMForm.Refresh()  
                $KnReIndexSourceDataFile=KnReIndex 

                ProgressStatus2 -ProgressLnr 2 -MaxValue $AnzTeilProzesse -ActValue 9
                # Check Settingsn-Index
                $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_20") #"Test ""Settings-DB Index""" 
                $MainMenuTMForm.Refresh()  
                $CheckSettingsIndexSourceDataFile=CheckSettingsIndex    

                ProgressStatus2 -ProgressLnr 2 -MaxValue $AnzTeilProzesse -ActValue 10
                #  Settingsn-Re-Index
                $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_21") #"Test ""Settings-DB Re-Index""" 
                $MainMenuTMForm.Refresh()  
                $SettingsReIndexSourceDataFile=SettingsReIndex    

                ProgressStatus2 -ProgressLnr 2 -MaxValue $AnzTeilProzesse -ActValue 11
                # Check Settingsn-Index
                $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_22") #"Test ""Settings-DB Index""" 
                $MainMenuTMForm.Refresh()  
                $CheckLanguageIndexSourceDataFile=CheckLanguageIndex   

                ProgressStatus2 -ProgressLnr 2 -MaxValue $AnzTeilProzesse -ActValue 12
                # Check Settingsn-Index
                $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_23") #"Test ""Settings-DB Index""" 
                $MainMenuTMForm.Refresh()  
                $LanguageReIndexSourceDataFile=LanguageReIndex   
                
                              
                 
                
                ProgressStatus2 -ProgressLnr 2 -MaxValue $AnzTeilProzesse -ActValue 13
                $PB1Label.Text= GetTextFromLanguageDB -ID  ("3_M_RES_13") #" Ergebnisse aufbereiten " 
                $MainMenuTMForm.Refresh()           


                $Erg=""
                if ($PeKnSourceDataFile -ne ""){$Erg1=Get-Content $PeKnSourceDataFile;$Erg=$Erg + "check Person <==> Knoten" + "`n" + $Erg1 + "`n`n"}
                if ($KnPeSourceDataFile -ne ""){$Erg2=Get-Content $KnPeSourceDataFile;$Erg=$Erg + "check Knoten <==> Person" + "`n" + $Erg2 + "`n`n"}
                if ($PePaSourceDataFile -ne ""){$Erg3=Get-Content $PePaSourceDataFile;$Erg=$Erg + "check Person <==> Partner" + "`n" + $Erg3 + "`n`n"}
                if ($ElKiSourceDataFile -ne ""){$Erg4=Get-Content $ElKiSourceDataFile;$Erg=$Erg + "check Eltern <==> Kinder" + "`n" + $Erg4 + "`n`n"}
                if ($CheckPeIndexSourceDataFile -ne ""){$Erg5=Get-Content $CheckPeIndexSourceDataFile;$Erg=$Erg + "check Personen-Index" + "`n" + $Erg5 + "`n`n"}
                if ($CheckKnIndexSourceDataFile -ne ""){$Erg6=Get-Content $CheckKnIndexSourceDataFile;$Erg=$Erg + "check Knoten-Index" + "`n" + $Erg6 + "`n`n"}
                if ($PeReIndexSourceDataFile -ne ""){$Erg7=Get-Content $PeReIndexSourceDataFile;$Erg=$Erg + "Erneuere Personen-DB Index" + "`n" + $Erg7 + "`n`n"}
                if ($KnReIndexSourceDataFile -ne ""){$Erg8=Get-Content $KnReIndexSourceDataFile;$Erg=$Erg + "Erneuere Knoten-DB Index" + "`n" + $Erg8 + "`n`n"}
                if ($CheckSettingsIndexSourceDataFile -ne ""){$Erg9=Get-Content $CheckSettingsIndexSourceDataFile;$Erg=$Erg + "check Settings-DB Index" + "`n" + $Erg9 + "`n`n"}
                if ($SettingsReIndexSourceDataFile -ne ""){$Erg10=Get-Content $SettingsReIndexSourceDataFile;$Erg=$Erg + "Erneuere Settings-DB Index" + "`n" + $Erg10 + "`n`n"}
                if ($CheckLanguageIndexSourceDataFile -ne ""){$Erg11=Get-Content $CheckLanguageIndexSourceDataFile;$Erg=$Erg + "check Language-DB Index" + "`n" + $Erg11 + "`n`n"}
                if ($LanguageReIndexSourceDataFile -ne ""){$Erg12=Get-Content $LanguageReIndexSourceDataFile;$Erg=$Erg + "Erneuere Language-DB Index" + "`n" + $Erg12 + "`n`n"}
                 

                $SourceDataFile=""
                if ($Erg -ne "") {
                    $ExportFolder=GetParameterFromSettings -Parametername "ExportZielPfad"
                    $SourceDataFile=$ExportFolder + "\TestErgebnisse.Log"
                    $Erg| Out-File -FilePath $SourceDataFile
                }
                
                ProgressStatus2 -ProgressLnr 2 -MaxValue $AnzTeilProzesse -ActValue $AnzTeilProzesse

                if ($SourceDataFile -eq ""){
                        $erglabel.Text=GetTextFromLanguageDB -ID  ("3_M_RES_1")
                        $erglabel.show()
                    } else {                           
                        $erglabel.Text=$SourceDataFile           
                        $erglabel.show()
                        $ZielOeffnenButton.show() 
                }
                $MainMenuTMForm.Refresh()

            } elseif ($TGComboBox.SelectedIndex -eq 1) {
                # manuelle Tool-Auswahl
                if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")"; Write-Host $Text}

                $ProgressBar2.hide()    
                $PB2Label.hide()                  
                
                $ZielOeffnenButton.hide()         
                $erglabel.hide()

                $PB1Label.show()
                $ProgressBar1.show()
                #$ZielOeffnenButton.show()                        
                #$erglabel.show() 
                $MainMenuTMForm.Refresh()   


                if ($DAGComboBox.SelectedIndex -eq 0) {
                        # PE <==> Kn 
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}

                        $PB1Label.Text =  GetTextFromLanguageDB -ID  ("3_M_RES_14") #"Test ""Person <==> Knoten"""
                        $MainMenuTMForm.Refresh()
 
                        $SourceDataFile=CheckPeKn
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        if ($SourceDataFile -eq ""){
                                $erglabel.Text=GetTextFromLanguageDB -ID  ("3_M_RES_1")
                                $erglabel.show()
                            } else {
                                $erglabel.Text=$SourceDataFile
                                $erglabel.show()
                                $ZielOeffnenButton.show() 
                                $MainMenuTMForm.Refresh()
                        }
                    } elseif ($DAGComboBox.SelectedIndex -eq 1) {
                        # Kn <==> Pe
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_15") # "Test ""Knoten <==> Person"""
                        $MainMenuTMForm.Refresh()

                        $SourceDataFile=CheckKnPe
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        if ($SourceDataFile -eq ""){
                                $erglabel.Text=GetTextFromLanguageDB -ID  ("3_M_RES_1")
                                $erglabel.show()
                            } else {
                                $erglabel.Text=$SourceDataFile
                                $erglabel.show()
                                $ZielOeffnenButton.show() 
                                $MainMenuTMForm.Refresh()
                        }
                    } elseif ($DAGComboBox.SelectedIndex -eq 2) {
                        # Pe <==> Pa    
                                  
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_16") #"Test ""Person <==> Partner"""
                        $MainMenuTMForm.Refresh()

                        $SourceDataFile=CheckPePa
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        if ($SourceDataFile -eq ""){
                                $erglabel.Text=GetTextFromLanguageDB -ID  ("3_M_RES_1")
                                $erglabel.show()
                            } else {
                                $erglabel.Text=$SourceDataFile
                                $erglabel.show()
                                $ZielOeffnenButton.show() 
                                $MainMenuTMForm.Refresh()
                        }
                    } elseif ($DAGComboBox.SelectedIndex -eq 3) {
                        # El <==> Ki   
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_17") #"Test ""Eltern <==> Kind"""
                        $MainMenuTMForm.Refresh()

                        $SourceDataFile=CheckElKi
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        if ($SourceDataFile -eq ""){
                                $erglabel.Text=GetTextFromLanguageDB -ID  ("3_M_RES_1")
                                $erglabel.show()
                            } else {
                                $erglabel.Text=$SourceDataFile
                                $erglabel.show()
                                $ZielOeffnenButton.show() 
                                $MainMenuTMForm.Refresh()
                        }

                    } elseif ($DAGComboBox.SelectedIndex -eq 4) {
                         # Check Pe-Index
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_18") #"Test ""Pe-DB Index"""
                        $MainMenuTMForm.Refresh()

                        $SourceDataFile=CheckPeIndex
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        if ($SourceDataFile -eq ""){
                                $erglabel.Text=GetTextFromLanguageDB -ID  ("3_M_RES_1")
                                $erglabel.show()
                            } else {
                                $erglabel.Text=$SourceDataFile
                                $erglabel.show()
                                $ZielOeffnenButton.show() 
                                $MainMenuTMForm.Refresh()
                        }

                    } elseif ($DAGComboBox.SelectedIndex -eq 5) {
                         # Check Kn-Index
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        $PB1Label.Text =GetTextFromLanguageDB -ID  ("3_M_RES_19") # "Test ""Kn-DB Index"""
                        $MainMenuTMForm.Refresh()
                                                
                        $SourceDataFile=CheckKnIndex
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        if ($SourceDataFile -eq ""){
                                $erglabel.Text=GetTextFromLanguageDB -ID  ("3_M_RES_1")
                                $erglabel.show()
                            } else {
                                $erglabel.Text=$SourceDataFile
                                $erglabel.show()
                                $ZielOeffnenButton.show() 
                                $MainMenuTMForm.Refresh()
                        }
                        
                    } elseif ($DAGComboBox.SelectedIndex -eq 6) {
                         # Pe-DB Re-Index
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_2") #"Erneuere Personen-DB Index"
                        $MainMenuTMForm.Refresh()
                                               
                        $SourceDataFile=PeReIndex
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        if ($SourceDataFile -eq ""){
                                $erglabel.Text=GetTextFromLanguageDB -ID  ("3_M_RES_1")
                                $erglabel.show()
                            } else {
                                $erglabel.Text=$SourceDataFile
                                $erglabel.show()
                                $ZielOeffnenButton.show()
                        } 
                        $MainMenuTMForm.Refresh()
                        
                        
                    } elseif ($DAGComboBox.SelectedIndex -eq 7) {
                         # Kn-DB Re-Index
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_3") #"Erneuere Knoten-DB Index"
                        $MainMenuTMForm.Refresh()
                                               
                        $SourceDataFile=KnReIndex
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        $erglabel.Text=$SourceDataFile
                        $erglabel.show()
                        $ZielOeffnenButton.show() 
                        $MainMenuTMForm.Refresh()

                } elseif ($DAGComboBox.SelectedIndex -eq 8) {
                         # CheckSettingsIndex
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_20") # "Test ""Settings-DB Index""" 
                        $MainMenuTMForm.Refresh()
                                               
                        $SourceDataFile=CheckSettingsIndex
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        $erglabel.Text=$SourceDataFile
                        $erglabel.show()
                        $ZielOeffnenButton.show() 
                        $MainMenuTMForm.Refresh()

                } elseif ($DAGComboBox.SelectedIndex -eq 9) {
                         # CheckSettingsIndex
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_21") # "Test ""Settings-DB Index""" 
                        $MainMenuTMForm.Refresh()
                                               
                        $SourceDataFile=SettingsReIndex
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        $erglabel.Text=$SourceDataFile
                        $erglabel.show()
                        $ZielOeffnenButton.show() 
                        $MainMenuTMForm.Refresh()

                } elseif ($DAGComboBox.SelectedIndex -eq 10) {
                         # CheckSettingsIndex
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_22") # "Test ""Language-DB Index""" 
                        $MainMenuTMForm.Refresh()
                                               
                        $SourceDataFile=CheckLanguageIndex
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        $erglabel.Text=$SourceDataFile
                        $erglabel.show()
                        $ZielOeffnenButton.show() 
                        $MainMenuTMForm.Refresh()


                } elseif ($DAGComboBox.SelectedIndex -eq 11) {
                         # CheckSettingsIndex
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_23") # "Test ""Settings-DB Index""" 
                        $MainMenuTMForm.Refresh()
                                               
                        $SourceDataFile=LanguageReIndex
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        $erglabel.Text=$SourceDataFile
                        $erglabel.show()
                        $ZielOeffnenButton.show() 
                        $MainMenuTMForm.Refresh()

                } elseif ($DAGComboBox.SelectedIndex -eq 12) {
                         # CheckSettingsIndex
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_24") # "Test ""Versions-INfo""" 
                        $MainMenuTMForm.Refresh()

                       # $DebugMode="true"
                       # if ($DebugMode -eq "true"){$Text= "`n`t`t--`tGlobal:SettingsData:`t(" + $Global:SettingsData + ")`n"; Write-Host $Text}
                       ## $DebugMode="false"
                       # read-host “Press ENTER to continue...”
                          
                                               
                        $SourceDataFile=GetVersionsInfo
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        $erglabel.Text=$SourceDataFile
                        $erglabel.show()
                        $ZielOeffnenButton.show() 
                        $MainMenuTMForm.Refresh()                        


                    } elseif ($DAGComboBox.SelectedIndex -eq 13) {
                         # ?? 
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_25") # "Test ""DBs werden angepasst""" 
                        $MainMenuTMForm.Refresh()

                        $SourceDataFile=MigrateKnotenUndPersonenDbFromV1ToV2
                        Write-Host $SourceDataFile
                        if ($SourceDataFile -ne "") {
                            if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                            $erglabel.Text=$SourceDataFile
                            $ZielOeffnenButton.show() 
                        } else {
                            $erglabel.Text = GetTextFromLanguageDB -ID  ("3_M_RES_1") # "Test ""erfolgreich ... ohne Fehler""" 
                        }
                        $erglabel.show()
                        $MainMenuTMForm.Refresh() 


                        
                    } elseif ($DAGComboBox.SelectedIndex -eq 14) {
                         # ?? 
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        $PB1Label.Text = GetTextFromLanguageDB -ID  ("3_M_RES_25") # "Test ""DBs werden angepasst""" 
                        $MainMenuTMForm.Refresh()

                        $SourceDataFile=MigrateAdressDbFromV1ToV2
                        Write-Host $SourceDataFile
                        if ($SourceDataFile -ne "") {
                            if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                            $erglabel.Text=$SourceDataFile
                            $ZielOeffnenButton.show() 
                        } else {
                            $erglabel.Text = GetTextFromLanguageDB -ID  ("3_M_RES_1") # "Test ""erfolgreich ... ohne Fehler""" 
                        }
                        $erglabel.show()
                        $MainMenuTMForm.Refresh() 



                    } elseif ($DAGComboBox.SelectedIndex -eq 15) {
                         # ?? 
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        # kommt vielleicht noch was ...

                                     

                }
        }
        
        $DebugMode=$OldDebugMode
    }

    function MainMenuTM() {
        ##################################################
        # Version V03
        # vom 17.5.2023
        ##################################################
        #$DebugMode="true"

        $LinkerRand=20
        $RechterRand=35
        $ObererRand=20
        $UntererRand=50

        $SpaltenAbstand=0
        $ZeienAbstand=5

        $ListenHeight=20
        $ListenWidth=400

        $LabelHeight=20
        $LabelWidth=400
        
        $PBHeight=20
        $PBWidth=400

        $OKButtonTop=420

        $TGSelected=0

        # GUI erzeugen
        $MainMenuTMForm = New-Object System.Windows.Forms.Form
        $MainMenuTMForm.StartPosition = "CenterScreen"
        $MainMenuTMForm.Text = GetTextFromLanguageDB -ID "3_1" #"Stammbaum Tools-Manager"

        ### Text/Grafik ###
        $AktLeft=$LinkerRand
        $AktTop=$ObererRand

        # Label Settings-Werte LNR
        $TGLabel = New-Object System.Windows.Forms.Label
        $TGLabel.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $TGLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $TGLabel.Text = GetTextFromLanguageDB -ID  ("3_M_6") #"Selektion"
        $MainMenuTMForm.Controls.Add($TGLabel)
        

        $AktLeft=$LinkerRand 
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        # Liste Settings-Werte LNR
        $TGComboBox = New-Object system.Windows.Forms.ComboBox
        $TGComboBox.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $TGComboBox.Size = New-Object System.Drawing.Size($ListenWidth,$ListenHeight)
        #$TGListbox.Add_DoubleClick($LNR_OnDblClick)
        #$TGListbox.Add_Click($LNR_OnClick)
        $TGComboBox.Font = ‘Microsoft Sans Serif,10’
        $TGComboBox.Items.Clear()
        [void] $TGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_TG_1"))
        [void] $TGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_TG_2"))
       # [void] $TGComboBox.Items.Add("als automatisch")
       # [void] $TGComboBox.Items.Add("Einzeltest auswählen")
        $TGComboBox.SelectedIndex=-1
        $TGComboBox.add_SelectedIndexChanged({
            prepareTgGui2
        })
        $MainMenuTMForm.Controls.Add($TGComboBox)


        $AktLeft=$LinkerRand 
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand


        # ComboBox Design-Art Grafisch
        $DAGComboBox = New-Object system.Windows.Forms.ComboBox
        $DAGComboBox.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $DAGComboBox.Size = New-Object System.Drawing.Size($ListenWidth,$ListenHeight)
        #$DAGComboBox.Add_DoubleClick($LNR_OnDblClick)
        #$DAGComboBox.Add_Click($LNR_OnClick)
        $DAGComboBox.Font = ‘Microsoft Sans Serif,10’
        $DAGComboBox.Items.Clear()
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_DAG_1"))
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_DAG_2"))
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_DAG_3"))
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_DAG_4"))
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_DAG_5"))
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_DAG_6"))
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_DAG_7"))
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_DAG_8"))
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_DAG_9"))
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_DAG_10"))
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_DAG_11"))
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_DAG_12")) 
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_DAG_13")) 
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_DAG_14")) 
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID "3_M_DAG_15")) 
        $DAGComboBox.SelectedIndex=-1
        $DAGComboBox.Hide()
        $MainMenuTMForm.Controls.Add($DAGComboBox)


        $AktLeft=$LinkerRand
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        # Label Settings-Werte LNR
        $PB1Label = New-Object System.Windows.Forms.Label
        $PB1Label.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $PB1Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PB1Label.Text =  GetTextFromLanguageDB -ID  ("3_M_L1_0")  #"erster Schritt"
        $PB1Label.Hide()
        $MainMenuTMForm.Controls.Add($PB1Label)
        
        $AktLeft=$LinkerRand 
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        $ProgressBar1 = New-Object System.Windows.Forms.ProgressBar
        $ProgressBar1.Location = New-Object System.Drawing.Point($AktLeft,$AktTop)
        $ProgressBar1.Size = New-Object System.Drawing.Size($PBWidth, $LabelHeight)
        $ProgressBar1.Style="Continuous"
        $ProgressBar1.value=0
        $ProgressBar1.Maximum=100
        $ProgressBar1.Hide()
        $MainMenuTMForm.Controls.Add($ProgressBar1);

        
        $AktLeft=$LinkerRand
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        # Label Settings-Werte LNR
        $PB2Label = New-Object System.Windows.Forms.Label
        $PB2Label.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $PB2Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PB2Label.Text =  GetTextFromLanguageDB -ID  ("3_M_L2_0") #"zweiter Schritt"
        $PB2Label.Hide()
        $MainMenuTMForm.Controls.Add($PB2Label)
        
        $AktLeft=$LinkerRand
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        $ProgressBar2 = New-Object System.Windows.Forms.ProgressBar
        $ProgressBar2.Location = New-Object System.Drawing.Point($AktLeft,$AktTop)
        $ProgressBar2.Size = New-Object System.Drawing.Size($PBWidth, $LabelHeight)
        $ProgressBar2.Style="Continuous"
        $ProgressBar2.value=0
        $ProgressBar2.Maximum=100
        $ProgressBar2.Hide()
        $MainMenuTMForm.Controls.Add($ProgressBar2);  

        $AktLeft=$LinkerRand
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        # Label Settings-Werte LNR
        $ErgLabel = New-Object System.Windows.Forms.Label
        $ErgLabel.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $ErgLabel.Size = New-Object System.Drawing.Size($PBWidth,$LabelHeight)
        $ErgLabel.Text =  GetTextFromLanguageDB -ID  ("3_M_4")
        $ErgLabel.Hide()
        $MainMenuTMForm.Controls.Add($ErgLabel)
        
        $AktLeft=$LinkerRand
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        # Button "Zieldatei öffnen"                            
        $ZielOeffnenButton = New-Object System.Windows.Forms.Button
        # Die nächsten beiden Zeilen legen die Position und die Größe des Buttons fest
        $ZielOeffnenButton.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $ZielOeffnenButton.Size = New-Object System.Drawing.Size($PBWidth,$LabelHeight)
        $ZielOeffnenButton.Text =  GetTextFromLanguageDB -ID  ("3_M_5")
        $ZielOeffnenButton.Name = "OpenGoal"
        $ZielOeffnenButton.Hide()
        #Die folgende Zeile ordnet dem Click-Event die Schließen-Funktion für das Formular zu
        $ZielOeffnenButton.add_Click($ZielOeffnenButton_OnClick)
        $MainMenuTMForm.Controls.Add($ZielOeffnenButton)

        
        $AktLeft=$LinkerRand
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        # Button "Speichern"                            
        $StartButton = New-Object System.Windows.Forms.Button
        # Die nächsten beiden Zeilen legen die Position und die Größe des Buttons fest
        $StartButton.Location = New-Object System.Drawing.Size(100,$AktTop)
        $StartButton.Size = New-Object System.Drawing.Size(100,23)
        $StartButton.Text =  GetTextFromLanguageDB -ID  ("3_M_2")
        $StartButton.Name = "Start"
        #Die folgende Zeile ordnet dem Click-Event die Schließen-Funktion für das Formular zu
        $StartButton.add_Click($StartButton_OnClick)
        $MainMenuTMForm.Controls.Add($StartButton)

        # Button "Abbruch"                            
        $CancelButton = New-Object System.Windows.Forms.Button
        # Die nächsten beiden Zeilen legen die Position und die Größe des Buttons fest
        $CancelButton.Location = New-Object System.Drawing.Size(300,$AktTop)
        $CancelButton.Size = New-Object System.Drawing.Size(100,23)
        #$CancelButton.Text = "Beenden"
        $CancelButton.Text =  GetTextFromLanguageDB -ID  ("3_M_3")
        $CancelButton.Name = "Beenden"
        $CancelButton.DialogResult = "Cancel"
        #Die folgende Zeile ordnet dem Click-Event die Schließen-Funktion für das Formular zu
        $CancelButton.Add_Click({$MainMenuTMForm.Close()})
        $MainMenuTMForm.Controls.Add($CancelButton)

        
        #$MainMenuTMForm.Size = New-Object System.Drawing.Size(750,500)
        $MainMenuTMBreite=$ListenWidth + $RechterRand + $LinkerRand
        $MainMenuTMHoehe=$CancelButton.Top + $CancelButton.Height + $UntererRand
        $MainMenuTMForm.Size = New-Object System.Drawing.Size($MainMenuTMBreite,$MainMenuTMHoehe)
        
        $StartButton.Width=$MainMenuTMBreite/5
        $CancelButton.Width=$MainMenuTMBreite/5
        
        $StartButton.Left=$MainMenuTMBreite/5
        $CancelButton.Left=$MainMenuTMBreite/5*3

        [void] $MainMenuTMForm.ShowDialog()
    }

#endregion MainMenuTM


#region Main

    $DebugMode = "false"
    if ($Global:DebugMode -eq "true"){$DebugMode="true"}
    #$DebugMode="true"


    if ($GetVersionInfo -eq "true") {            
            $ErgText=$ErgText + "Version:`t" + $Version + "`n"
            $ErgText=$ErgText + "Stand:`t" + $Stand + "`n"
            $ErgText=$ErgText + "Developper:`t" + $Developper + "`n"
            return  $ErgText

        } else {


            $global:BasisPfad=""
            $Global:SettingsDataFile=""
            $Global:SettingsData=""
            $global:AktPersonNr=0
            $global:PersonenDB=""
            $global:KnotenDB=""
            $Global:SprachDBFileName=""
            $Global:SprachDB=""
            $global:AdressDB=""

            $global:KindStartNr=0
            $global:KnotenHeaderListe=@()

            SetGlobalParameterTM


                [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
                [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")


            MainMenuTM
    }
#endregion Main