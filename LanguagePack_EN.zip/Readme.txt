this is a new translated language-DB for support of english language.

simply overwrite the older, existing file in your database folder (default \DBDaten\SprachPaket_EN.sdb)
