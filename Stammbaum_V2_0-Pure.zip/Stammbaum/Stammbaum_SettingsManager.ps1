param (
    $DebugMode="false",
    $LogMode="false",
    $GetVersionInfo="false"
)

cls

##################################################
$Version="0.7"
$Stand="03.05.2023"
$Developper="na ich"
##################################################


#region Tools

    function DetectScriptPath {
        Param(
            $PowershellVersion
        )
        ##################################################
        # Version V02
        # vom 8.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        if ($DebugMode -eq "true") {
            $text="DetectScriptPath Startet mit Parameter`nPowershellVersion:`t" + $PowershellVersion + "`nDebugMode:`t" + $DebugMode + "`n"
            Write-Host  $Text
        }

        # gezielte Versuch anhand der installierten PS-Version den Script-Pfad zu ermitteln
        if ($PowershellVersion -gt 2){
            $BasisPfad=$PSScriptRoot
        }
        if ($PowershellVersion -gt 1){
            $BasisPfad=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath('.\')
        }

        # falls nichts funktioniert, dann wird stumpf versucht
        if ($BasisPfad -eq ""){
            $BasisPfad=$PSScriptRoot
        }
        if ($BasisPfad -eq ""){
            $BasisPfad=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath('.\')
        }
        if ($BasisPfad -eq ""){
            $BasisPfad=split-path -parent $MyInvocation.MyCommand.Definition
        }

        if ($DebugMode -eq "true") {
            $a=$PSScriptRoot
            $b=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath('.\')
            $c=split-path -parent $MyInvocation.MyCommand.Definition

            $Text="Ermitteln des ScriptPfades`n Methode 1: " + $a + "`n" + "Methode 2: " + $b + "`n" + "Methode 3: " + $c + "`n"
            $text=$Text + "DetectScriptPath endet mit Rueckgabe-Parameter`nBasisPfad:`t" + $BasisPfad + "`n"
            Write-Host  $Text
        }
        return $BasisPfad
}

    function DetectPSVersion() {
        
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        $PSVersion=""
        $PSVersion=$PSVersionTable.PSVersion.Major

        return $PSVersion
    }   

    function GetSettingsData {
        Param(
            $SourceDataFile
        )

        ##################################################
        # Version V04
        # vom 11.6.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        if ($DebugMode -eq "true") {$Text="## GetSettingsData startet `t- mit Parameter SourceDataFile: (" + $SourceDataFile + ")";Write-Host $text}
        $SourceData=Get-Content $SourceDataFile

        if ($SourceData.Length -eq 0){
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei existiert nicht/oder ist leer"}


            # Standard-Trennzeichen ist TAB ( `t )
            $SourceData="Lnr	Kategorie	Namen	Wert	Beschreibung" + "`n"
            $SourceData=$SourceData + "1`tallgemein`tDatenquelle`t1`tSpeicherort der Daten, 1=interne ExcelSheets (noch nicht verf�gber: , 2=SQL-DB, 3=Spreadsheet-Datei)" + "`n"
            $SourceData=$SourceData + "2`tallgemein`tFeldTrenner`tTAB`tSpalten-Trennzeichen aller interner Datens�tze" + "`n"

            $SourceData=$SourceData + "3`tallgemein`tSprache`t`tSprache des Tools (DE-DE, EN-EN, ...). bleibt der Parameter leer, so wird die aktive Sprach-Einstellung des Systems benutzt" + "`n"
            $SourceData=$SourceData + "4`tFileSystem`tExportZielPfad`t" +  $BasisPfad + "\ZielDateien`tZielordner f�r DatenExporte" + "`n"
            $SourceData=$SourceData + "5`tFileSystem`tDatenZielPfad`t" +  $BasisPfad + "\DBDaten`tOrdner der DB-Daten" + "`n"
            $SourceData=$SourceData + "6`tFileSystem`tPersonenDatei`tPersonen.sdb`tDB-Datei f�r Personendaten" + "`n"
            $SourceData=$SourceData + "7`tFileSystem`tAdresseDatei`tAdressen.sdb`tDB-Datei f�r Adressdaten" + "`n"
            $SourceData=$SourceData + "8`tFileSystem`tKnotenDatei`tKnoten.sdb`tDB-Datei f�r Knotendaten" + "`n"
            $SourceData=$SourceData + "9`tDarstellung`tGeborenZeichen`t*`tZeichen f�r ""geboren""" + "`n"
            $SourceData=$SourceData + "10`tDarstellung`tGestorbenZeichen`t[char]0x2020`tZeichen f�r ""gestorben""" + "`n"
            $SourceData=$SourceData + "11`tDarstellung`tHochzeitZeichen`t[char]0x26AD`tZeichen f�r ""Hochzeit""" + "`n"
            $SourceData=$SourceData + "12`tDarstellung`tScheidungsZeichen`t[char]0x26AE`tZeichen f�r ""Trennung""" + "`n"
            $SourceData=$SourceData + "13`tDarstellung`tNodeBreite`t120`tBreite der Person bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "14`tDarstellung`tNodeHoehe`t100`tH�he der Person bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "15`tDarstellung`tPersonBreite`t100`tBreite der Verbindungsk�sten bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "16`tDarstellung`tPersonHoehe`t130`tH�he der Verbindungsk�sten bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "17`tDarstellung`tZeilenabstand`t50`tZeilenabstand zwischen den K�sten bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "18`tDarstellung`tSpaltenAbstand`t50`tHorrizontaler Abstand zwischen den K�sten bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "19`tDarstellung`tHintergrundFarbe`tgreen`tFarbe des Seiten-Hintergrunds bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "20`tDarstellung`tPersonenFarbe`tgrey`tFarbe der Personenkaestchen bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "21`tDarstellung`tWdhPersonenFarbe`tgreen`tFarbe der Personenkaestchen bei Wiederholungen (weiterer Partner) bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "22`tDarstellung`tKnotenFarbe`tblue`tFarbe der Personenkaestchen bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "23`tDarstellung`tPersonenSchriftFarbe`t#ada`tFarbe der Personenkaestchen bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "24`tDarstellung`tWdhPersonenSchriftFarbe`t#ada`tFarbe der Personenkaestchen bei Wiederholungen (weiterer Partner) bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "25`tDarstellung`tKnotenSchriftFarbe`t#dad`tFarbe der Personenkaestchen bei Objektbasierter Darstellung (grey, green, blue, #dad, ...)" + "`n"
            $SourceData=$SourceData + "26`tDarstellung`tPersonenSchriftGroesse`t12`tGroesse der Schrift (in px) in den Personenkaestchen bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "27`tDarstellung`tWdhPersonenSchriftGroesse`t12`tGroesse der Schrift (in px) in den Personenkaestchen bei Wiederholungen (weiterer Partner) bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "28`tDarstellung`tKnotenSchriftGroesse`t12`tGroesse der Schrift (in px) in den Personenkaestchen bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "29`tDarstellung`tPersonInhalt`t+,+,-,+,+,+,-,-,-,-,-,-,-`tInhalt der Personenkaestchen bei Objektbasierter Darstellung (Lnr,Vorname,ZusatzVorname,Nachname,GebName,GebDatum,GeburtsOrt,Sterbedatum,SterbeOrt_Friedhof,Bemerkung,religion,geschl,nationalit�t)" + "`n"
            $SourceData=$SourceData + "30`tDarstellung`tKnotenInhalt`t+,+,-,-`tInhalt der Knotenkaestchen bei Objektbasierter Darstellung (Lnr,TrauDatum,TrauOrt,ScheidungsDatum)" + "`n"
            $SourceData=$SourceData + "31`tDebugging`tDebugMode`tWAHR`tDebug-Log-Datei wird erzeugt" + "`n"
            $SourceData=$SourceData + "32`tDebugging`tLogMode`t1`t(an = 1, aus = 0) Log-Datei(en) werden erzeugt" + "`n"
            $SourceData=$SourceData + "33`tDebugging`tLogFileZielPfad`t" +  $BasisPfad + "\ZielDateien`tSpeicherPfad der Debug-Log-Datei" + "`n"
            $SourceData=$SourceData + "34`tDebugging`tLogFileDateiname`tDebugLog.log`tDateiname der Debug-Log-Datei" + "`n"
            $SourceData=$SourceData + "35`tFileSystem`tSeleniumPfad	`t`tPfad zum Selenium-Verzeichnis (""...\selenium-powershell-master"")" + "`n"
            $SourceData=$SourceData + "36`tFileSystem`tChromeDriverPfad`t`tPfad zum ChromeDriver (""...\chromedriver\win32\113"")" + "`n"
            $SourceData=$SourceData + "37`tFileSystem`tGoogleMapsUsername`t`tUsername (mail adresse) zum Anmelden bei Google Maps" + "`n"
            $SourceData=$SourceData + "38`tFileSystem`tGoogleMapsPassword`t`tPasswort (passend zur mail adresse) zum Anmelden bei Google Maps" + "`n"
            $SourceData=$SourceData + "39`tDarstellung`tGoogleMapsImportDetails`t+,+,+,+,-,+`tInhalt, der bei Google Maps dargestellt werden soll (GebOrt,WohnOrt, SterbeOrt,HochzeitsOrt,ScheidungsOrt,Verbinder)" + "`n"
            $SourceData=$SourceData + "40`tDarstellung`tGoogleMapsPosIconGebOrt`t1844`tIcon-Nummer, das bei Google Maps als Geburtsort dargestellt werden soll" + "`n"
            $SourceData=$SourceData + "41`tDarstellung`tGoogleMapsPosFarbeGebOrt`t1`tFarb-Nummer, in der bei Google Maps der Geburtsort dargestellt werden soll (0=schwarz, 1=dunkelgr�n, 2=lila, 3=rot, 4=gelb)" + "`n"
            $SourceData=$SourceData + "42`tDarstellung`tGoogleMapsPosIconWohnOrt`t1603`tIcon-Nummer, das bei Google Maps als Wohnort dargestellt werden soll" + "`n"
            $SourceData=$SourceData + "43`tDarstellung`tGoogleMapsPosFarbeWohnOrt`t2`tFarb-Nummer, in der bei Google Maps der Wohnort dargestellt werden soll (0=schwarz, 1=dunkelgr�n, 2=lila, 3=rot, 4=gelb)" + "`n"
            $SourceData=$SourceData + "44`tDarstellung`tGoogleMapsPosIconSterbeOrt`t1670`tIcon-Nummer, das bei Google Maps als Sterbeort dargestellt werden soll" + "`n"
            $SourceData=$SourceData + "45`tDarstellung`tGoogleMapsPosFarbeSterbeOrt`t0`tFarb-Nummer, in der bei Google Maps der Sterbeort dargestellt werden soll (0=schwarz, 1=dunkelgr�n, 2=lila, 3=rot, 4=gelb)" + "`n"
            $SourceData=$SourceData + "46`tDarstellung`tGoogleMapsPosIconHochzeitsOrt`t1592`tIcon-Nummer, das bei Google Maps als Hochzeitsort dargestellt werden soll" + "`n"
            $SourceData=$SourceData + "47`tDarstellung`tGoogleMapsPosFarbeHochzeitsOrt`t3`tFarb-Nummer, in der bei Google Maps der Hochzeitsort dargestellt werden soll (0=schwarz, 1=dunkelgr�n, 2=lila, 3=rot, 4=gelb)" + "`n"
            $SourceData=$SourceData + "48`tDarstellung`tGoogleMapsPosIconScheidungsOrt`t1516`tIcon-Nummer, das bei Google Maps als Scheidungsort dargestellt werden soll" + "`n"
            $SourceData=$SourceData + "49`tDarstellung`tGoogleMapsPosFarbeScheidungsOrt`t4`tFarb-Nummer, in der bei Google Maps der Scheidungsort dargestellt werden soll (0=schwarz, 1=dunkelgr�n, 2=lila, 3=rot, 4=gelb)" + "`n"
            $SourceData=$SourceData + "50`tDarstellung`tGoogleMapsFarbPalette`tVIpgJd-nEeMgc-eEDwDf12,VIpgJd-nEeMgc-eEDwDf20,VIpgJd-nEeMgc-eEDwDf11,VIpgJd-nEeMgc-eEDwDf14,VIpgJd-nEeMgc-eEDwDf4`tFarb-Namen-Liste - Liste der benutztenm Farben bei Google Maps (standard: schwarz, 1=dunkelgr�n, lila, rot, gelb)" + "`n"



            $SourceData| Out-File -FilePath $SourceDataFile
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei wurde erzeugt"}
        
            $SourceData=Get-Content $SourceDataFile
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei wurde frisch eingelesen"}

            if ($SourceData.Length -eq 0){
                if ($DebugMode -eq "true") {Write-Host "Settings-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!"}
                #read-host �Press ENTER to continue...�
                $erg=[System.Windows.Forms.MessageBox]::Show("Settings-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!", "FileSystem Zugriffs-Fehler", "1", "None" )
                $host.Exit()
            }
        }
        
        if ($DebugMode -eq "true") {$text= "## GetSettingsData endet `t- mit R�ckgabe-Parameter SourceData: (" + $SourceData + ")";Write-Host $text}
        return $SourceData
    }

    function GetParameterFromSettings {
        param (
            $Parametername=""
        )
        ##################################################
        # Version V02
        # vom 7.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
            
        if ($DebugMode -eq "true") {$text= "## GetParameterFromSettings startet `t- mit Parameter Parametername: (" + $Parametername + ")";Write-Host $text}

        $DummyText=""
        # Achtung Namensaenderung!
        $SourceDataZeilenSpit=$global:SettingsData.Split("`n")

        for($i=0; $i -lt $SourceDataZeilenSpit.count; $i++){

                if ($SourceDataZeilenSpit[$i].length -ne 0)                            
                {
                    $SourceDataSplit=$SourceDataZeilenSpit[$i].Split("`t")

                    if ($DebugMode -eq "true") { $text="Parmeter " + $SourceDataSplit[2];Write-Host $text}
                    if ($Parametername -eq $SourceDataSplit[2]){
                        
                        $DummyText=$SourceDataSplit[3]

                        if ($Parametername -eq "LogMode"){
                            if ($SourceDataSplit[3] -eq "wahr"){
                                    $DummyText="true"
                                } elseif ($SourceDataSplit[3] -eq "true"){
                                    $DummyText="true"
                                }elseif ($SourceDataSplit[3] -eq "falsch"){
                                    $DummyText="false"
                                } elseif ($SourceDataSplit[3] -eq "false"){
                                    $DummyText="false"
                            }
                        } 
                        if ($Parametername -eq "DebugMode"){
                            if ($SourceDataSplit[3] -eq "wahr"){
                                    $DummyText="true"
                                } elseif ($SourceDataSplit[3] -eq "true"){
                                    $DummyText="true"
                                } elseif ($SourceDataSplit[3] -eq "falsch"){
                                    $DummyText="false"
                                } elseif ($SourceDataSplit[3] -eq "false"){
                                    $DummyText="false"
                            }
                        } 
                    }
                }   
        } 
    
        if ($DebugMode -eq "true") {$text="## GetParameterFromSettings endet `t- mit R�ckgabe-Parameter DummyText: (" + $DummyText + ")";Write-Host $text}
        return $DummyText
    }

    function GetLanguageFileName() {
        Param(
            $ActiveLanguage
        )
        ##################################################
        # Version V03
        # vom 20.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") {$text="## GetLanguageFileName startet `t- mit Parameter ActiveLanguage: (" + $ActiveLanguage + ")";Write-Host $text}

        $DBPfad=""

        $DBPfad=GetParameterFromSettings -Parametername "DatenZielPfad"
        if ($DebugMode -eq "true") {$text="## `t`t-- DBPfad aus Settings: (" + $DBPfad + ")";Write-Host $text}

        if (Test-Path -Path $DBPfad) {
            } else {
                $DBPfad = $global:BasisPfad + "\DBDaten"
                if ($DebugMode -eq "true") {$text="## `t`t-- DBPfad aus Settings nicht gefunden. teste jetzt: (" + $DBPfad + ")";Write-Host $text}
                if (Test-Path -Path $DBPfad) {
                    } else {
                        $DBPfad = $global:BasisPfad
                        if ($DebugMode -eq "true") {$text="## `t`t-- Standard-DBPfad als Kombination Basispfad\DBDaten nicht gefunden. teste jetzt: (" + $DBPfad + ")";Write-Host $text}
                        if (Test-Path -Path $DBPfad) {
                            } else {
                                $DBPfad = ""
                                if ($DebugMode -eq "true") {$text="## `t`t-- Auch nicht gefunden. ich gebe auf - das wird nix mehr!";Write-Host $text}
                        }
                }
        }

        $LanguageFileName=""

        if ($DBPfad -eq "") {
                #$Abbbruch=$true
            } else {
                
             #   if ($ActiveLanguage -eq "DE-DE") {$LanguageFileName=$DBPfad + "\SprachPaket_DE.sdb"}
              #  if ($ActiveLanguage -eq "EN-DE") {$LanguageFileName=$DBPfad + "\SprachPaket_DE.sdb"}
              #  if ($ActiveLanguage -eq "EN-EN") {$LanguageFileName=$DBPfad + "\SprachPaket_EN.sdb"}
                if ($ActiveLanguage -like "*-DE") {$LanguageFileName=$DBPfad + "\SprachPaket_DE.sdb";if ($DebugMode -eq "true") {$text="DE erkannt";Write-Host $text}}
                if ($ActiveLanguage -like "*-EN") {$LanguageFileName=$DBPfad + "\SprachPaket_EN.sdb";if ($DebugMode -eq "true") {$text="EN erkannt";Write-Host $text}}

                if ($LanguageFileName -eq "") {$LanguageFileName=$DBPfad + "\SprachPaket_EN.sdb";if ($DebugMode -eq "true") {$text="NIX erkannt - EN gestzt";Write-Host $text}}

                if (Test-Path -Path $LanguageFileName) {
                    } else {
                        $text="LanguageFile: (" + $LanguageFileName + ") nicht gefunden!";Write-Host $text
                }
        }
                        
        if ($DebugMode -eq "true") {$text="## GetLanguageFileName endet `t- mit R�ckgabe-Parameter LanguageFileName: (" + $LanguageFileName + ")";Write-Host $text}
        
        if ($DebugMode -eq "true") {$text="Notbremse"; read-host $Text}
        return $LanguageFileName
    }

    function GetLanguageData {
        Param(
            $LanguageDBFileName
        )
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$text="## GetLanguageData startet `t- mit Parameter LanguageDBFileName: (" + $LanguageDBFileName + ")";Write-Host $text}

        $SourceData=""
        if ($LanguageDBFileName -ne "") {
            $SourceData=Get-Content $LanguageDBFileName
        }

        if ($SourceData.Length -eq 0){
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei existiert nicht/oder ist leer"}
        }
        
        if ($DebugMode -eq "true") {$text="## GetLanguageData endet `t- mit R�ckgabe-Parameter SourceData: (" + $SourceData + ")";Write-Host $text}
        return $SourceData
    }

    function GetTextFromLanguageDB {
        param (
            $ID=""
        )
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        if ($DebugMode -eq "true") { $text="## GetTextFromLanguageDB startet zum Auslesen von ID:`t" + $ID;Write-Host $text}

        $DummyText=""
        # Achtung Namensaenderung!
        $SourceDataZeilenSpit=$Global:SprachDB.Split("`n")

        for($i=0; $i -lt $SourceDataZeilenSpit.count; $i++){

                if ($SourceDataZeilenSpit[$i].length -ne 0)                            
                {
                    $SourceDataSplit=$SourceDataZeilenSpit[$i].Split("`t")

                    if ($DebugMode -eq "true") { $text="Pr�fe Parmeter (`t" + $SourceDataSplit[1] + ") hat Wert:(`t" + $SourceDataSplit[2] + ")";Write-Host $text}
                    if ($ID -eq $SourceDataSplit[1]){
                        $DummyText=$SourceDataSplit[2]
                        $i = $SourceDataZeilenSpit.count
                    }
                }   
        } 
    
        if ($DebugMode -eq "true") {Write-Host "## GetTextFromLanguageDB endet `t- mit R�ckgabe-Parameter DummyText: (" + $DummyText + ")"}
        return $DummyText
    }

    function TranslateSettingsData() {
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
        
        if ($DebugMode -eq "true") { $text="## TranslateSettingsData startet";Write-Host $text}

        $MenuData=@()
        $MenuData=$MenuData + $Global:SettingsData
        if ($DebugMode -eq "true") { $text="## `t- MenuData:`t(" + $MenuData + ")";Write-Host $text}

        if ($DebugMode -eq "true") {$text="## `t- ZeilenAnzahl: (" + $MenuData.count + ")";Write-Host $text}

        $NeuesMenu=""
        foreach ($MenuZeile in $MenuData) {
            $ZeilenSplit= $MenuZeile.split("`t")

            $Lnr=$ZeilenSplit[0]
            $Kategorie=$ZeilenSplit[1]
            $Namen=$ZeilenSplit[2]
            $Wert=$ZeilenSplit[3]
            $Beschreibung=$ZeilenSplit[4]

            if ($DebugMode -eq "true") {$text="## `t- Lnr: (" + $Lnr + ")`t- Kategorie: (" + $Kategorie + ")`t- Namen: (" + $Namen + ")`t- Wert: (" + $Wert + ")`t- Beschreingung: (" + $Beschreingung + ")";Write-Host $text}

            $TrKategorie=""
            $TrName=""
            $TrBeschreibung=""

            if ($Lnr -ne "") {
                $TrKategorie=GetTextFromLanguageDB -ID ("2_S_" + $Lnr + "_1")
                $TrNamen=GetTextFromLanguageDB -ID ("2_S_" + $Lnr + "_2")
                $TrBeschreibung=GetTextFromLanguageDB -ID  ("2_S_" + $Lnr + "_3")

                if ($DebugMode -eq "true") {$text="## `t- TrKategorie: (" + $TrKategorie + ")`t- TrName: (" + $TrName + ")`t- TrBeschreingung: (" + $TrBeschreingung + ")";Write-Host $text}
                if ($TrKategorie -ne "") {$Kategorie=$TrKategorie}
                if ($TrNamen -ne "") {$Namen=$TrNamen}
                if ($TrBeschreibung -ne "") {$Beschreibung=$TrBeschreibung}

                $NeuesMenu=$NeuesMenu + $Lnr.Trim() + "`t" + $Kategorie.Trim()
                $NeuesMenu=$NeuesMenu + "`t" + $Namen.Trim() + "`t " + $Wert.Trim()
                $NeuesMenu=$NeuesMenu + "`t" + $Beschreibung.Trim() + "`n" 
            }

        }
        
        if ($DebugMode -eq "true") {$text="## `t- NeuesMenu: (`n" + $NeuesMenu + "`n)";Write-Host $text}
        if ($DebugMode -eq "true") {$text="Notbremse"; read-host $Text}
        
        if ($NeuesMenu -ne "") {$MenuData = $NeuesMenu}
        
        if ($DebugMode -eq "true") {$text="## TranslateSettingsData endet `t- mit R�ckgabe-Parameter MenuData: (" + $MenuData + ")";Write-Host $text}
        return $MenuData
    }

    function DetectOsUserLanguage() {
        
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        $UserLanguageList=Get-WinUserLanguageList
        $MainLanguage=$UserLanguageList[0].languagetag.ToUpper()

        return $MainLanguage
    }

    function SetGlobalParameterSM(){
        
        ##################################################
        # Version V02
        # vom 20.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"


        $Fehler=$false

        $global:BasisPfad=""
        $global:BasisPfad=DetectScriptPath -PowershellVersion  DetectPSVersion
        if ($global:BasisPfad -eq "") {$Fehler=$true}


        $Global:SettingsDataFile = $global:BasisPfad + "\Settings.def"

        if ($DebugMode -eq "true") {
            $Text="## SetGlobalParameter`t- gesetzte globale Parameter" + "`n"
            $text=$Text + "`t`t- global:BasisPfad:`t" + $global:BasisPfad + "`n"
            $text=$Text + "`t`t- Global:SettingsDataFile:`t" + $Global:SettingsDataFile + "`n"
            $text=$Text +  "`n"
            Write-Host  $Text
        }


        $Global:SettingsData=GetSettingsData -SourceDataFile $Global:SettingsDataFile
        if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:SettingsData :(" + $Global:SettingsData + ")";Write-Host $Text}
        if ($global:SettingsData -eq "") {$Fehler=$true}

        $DebugDummy=GetParameterFromSettings -Parametername "DebugMode"
        if ($DebugDummy -eq "1") {$Global:DebugMode= "true"}
        $LogDummy=GetParameterFromSettings -Parametername "LogMode"
        if ($LogDummy -eq "1") {$Global:LogMode= "true"}

        $Language=GetParameterFromSettings -Parametername "Sprache"
        if ($Language -eq "") {
                $Global:Language=DetectOsUserLanguage 
                if ($DebugMode -eq "true") { $text="## `t- Sprach-Feld in den Settings ist leer => erkannte User-Profil-Haupt-Sprache:`t" + $Global:Language + " wird benutzt"; Write-Host $text}
            } else {
                $Global:Language=$Language.ToUpper()
                if ($DebugMode -eq "true") { $text="## `t- Sprach-Feld in den Settings ist definiert:`t" + $Global:Language + " wird benutzt"; Write-Host $text}
        }

        $SprachDBFileName=GetLanguageFileName -ActiveLanguage $Global:Language
        if ($DebugMode -eq "true") {$Text="## `t- Parameter SprachDBFileName :(" + $SprachDBFileName + ")";Write-Host $Text}
        if ($SprachDBFileName -eq "") {$Fehler=$true}
        $Global:SprachDB=GetLanguageData -LanguageDBFileName  $SprachDBFileName
        if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:SprachDB :(" + $Global:SprachDB + ")";Write-Host $Text}
        if ($global:SprachDB -eq "") {$Fehler=$true}

        
        $Global:TrSettingsData = TranslateSettingsData
        if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:TrSettingsData :(" + $Global:TrSettingsData + ")";Write-Host $Text}
        if ($global:TrSettingsData -eq "") {$Fehler=$true}


        if ($Fehler -eq $true) { $Ausgabe=""} else { $Ausgabe="Ok"}
        
        if ($DebugMode -eq "true") {$text="Notbremse"; read-host $Text}
        
        if ($DebugMode -eq "true") {$text="## SetGlobalParameterSM endet ";Write-Host $text}
        return $Ausgabe
    }

    function GetGuiltyLanguage(){
        Param(
            $TestBezeichnung
        )
        ##################################################
        # Version V01
        # vom 10.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
        
        if ($DebugMode -eq "true") { $text="## GetGuiltyLanguage startet";Write-Host $text}
        
        $OkSprache=""
        $DuTLanguage=$TestBezeichnung.ToUpper()

        # deutsch
        IF ($DuTLanguage -eq "DE-DE") {$OkSprache="DE-DE"}
        IF ($DuTLanguage -eq "DE_DE") {$OkSprache="DE-DE"}
        IF ($DuTLanguage -eq "DE") {$OkSprache="DE-DE"}
        IF ($DuTLanguage -eq "DEUTSCH") {$OkSprache="DE-DE"}
        IF ($DuTLanguage -eq "GERMAN") {$OkSprache="DE-DE"}
        #englisch
        IF ($DuTLanguage -eq "EN-EN") {$OkSprache="EN-EN"}
        IF ($DuTLanguage -eq "EN_EN") {$OkSprache="EN-EN"}
        IF ($DuTLanguage -eq "EN") {$OkSprache="EN-EN"}
        IF ($DuTLanguage -eq "ENGLISH") {$OkSprache="EN-EN"}
        IF ($DuTLanguage -eq "ENGLISCH") {$OkSprache="EN-EN"}

        if ($DebugMode -eq "true") {$text="## GetGuiltyLanguage endet `t- mit R�ckgabe-Parameter OkSprache: (" + $OkSprache + ")";Write-Host $text}
        return $OkSprache
    }
     
     
#endregion Tools


#region EventHandler



    function SaveAllSettings() {
        ##################################################
        # Version V01
        # vom 9.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
        
        if ($DebugMode -eq "true") { $text="## SaveAllSettings startet";Write-Host $text}
    

        if ($DebugMode -eq "true") {Write-Host "Settings-Datei wird erzeugt"}

        # Tabelle nach Lnr absteigend sortieren
        $DGVdata.Sort($DGVdata.Columns[0],'Descending')

        $AnzahlZeilen=$DGVdata.RowCount
        #$AnzahlZeilen=$DGVdata.Items.count
        if ($DebugMode -eq "true") {$Text="Anzahl Tabellen-Zeilen :`t" + $AnzahlZeilen; Write-Host $Text}
    
        
        # PositionsListe erstellen
        $PosListe=@()
        for($i=1; $i -lt $AnzahlZeilen+5; $i++){
            $PosListe=$PosListe + "0"
        }
        
        if ($DebugMode -eq "true") {$Text="## `t-- leere PosListe :`t" + $PosListe; Write-Host $Text}

        # PositionsListe mit Werten fuellen
        for($i=1; $i -lt ($AnzahlZeilen); $i++){

            $Pos = $DGVdata.Rows[$i].Cells[0].Value

            if ($DebugMode -eq "true") {$Text="## `t-- Position`t(" + $Pos + ")"; Write-Host $Text}
            $PosListe[$Pos]=$DGVdata.Rows[$i].Cells[3].Value
            if ($DebugMode -eq "true") {$Text="## `t-- Neuer Wert`t" + $DGVdata.Rows[$i].Cells[3].Value  + "`tf�r Position`t" + $Pos + "`t=> Neue PosListe :`t" + $PosListe; Write-Host $Text}
            # Schleife beenden wenn naechste Zeile leer ist
           # if ($DGVdata.Rows[($i+1)].Cells[0].Value -eq "") {$i = ($AnzahlZeilen + 5)}
        }
        
        if ($DebugMode -eq "true") {$Text="## `t-- Neue PosListe :`t" + $PosListe; Write-Host $Text}

        # Neue Settings-Liste aus Original Plus neue Werte zusammenstellen
        $NeueSettings=""
        $SettingsSplit=$global:SettingsData.Split("`n")
        # Ueberschrift bleibt gleich
        $NeueSettings="" + $SettingsSplit[0]
        for($i=1; $i -lt $SettingsSplit.count; $i++){
            if ($SettingsSplit[$i] -ne "") {
                $ZeilenSplit=$SettingsSplit[$i].split("`t")

                $NeueSettings=$NeueSettings + "`n" + $ZeilenSplit[0] + "`t" + $ZeilenSplit[1] + "`t" + $ZeilenSplit[2] + "`t" + $PosListe[$i] + "`t" + $ZeilenSplit[4] 
            }
        }
        
        if ($DebugMode -eq "true") {$Text="## `t-- Neue Settings-Liste :`n" + $NeueSettings; Write-Host $Text}

        $NeueSettings| Out-File -FilePath $Global:SettingsDataFile
        if ($DebugMode -eq "true") {Write-Host "Settings-Datei wurde erzeugt"}

        
        if ($DebugMode -eq "true") {$text="## SaveAllSettings endet und beendet das Men�";Write-Host $text}

        $objForm.Close()
    }

#endregion EventHandler


#region Submenue WerteChange
    #region SubmenueEventhandler

        function EditValuesFormSaveClick() {
            ##################################################
            # Version V01
            # vom 9.4.2023
            ##################################################

            $DebugMode = "false"
            if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
            #$DebugMode = "true"
        
            if ($DebugMode -eq "true") { $text="## EditValuesFormSaveClick startet";Write-Host $text}

            if ($DebugMode -eq "true") {Write-Host "Settings-Wert uebernehmen"}

            # test ob Parameter Sprache editiert wird
            $SettingsSplit=$global:SettingsData.split("`n")
            $Zeile=$DGVdata.SelectedCells[0].Value
            $Parameter=$SettingsSplit[$Zeile].split("`t")[2]
            if ($Parameter -eq "Sprache") {
                $textBox4.Text = GetGuiltyLanguage -TestBezeichnung $textBox4.Text
            } 
            $DGVdata.SelectedCells[3].Value = $textBox4.Text

            if ($DebugMode -eq "true") {Write-Host "Beende Untermenue EditValuesForm"}
            $EditValuesForm.Close()

            if ($DebugMode -eq "true") { $text="## EditValuesFormSaveClick endet";Write-Host $text}
        }

        function FormResizeEV() {
            ##################################################
            # Version V01
            # vom 9.4.2023
            ##################################################

            $DebugMode = "false"
            if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
           # $DebugMode = "true"
        
            if ($DebugMode -eq "true") { $text="## FormResizeEV startet";Write-Host $text}

            if ($DebugMode -eq "true") { $text="## `t-- FensterBreite:`t" + $EditValuesForm.width + "`t, FensterH�he:`t" + $EditValuesForm.height;Write-Host $text}

            $FormRandRechts=35
            $textBox1.width=($EditValuesForm.width-$textBox1.left - $FormRandRechts)
            $textBox2.width=$textBox1.width
            $textBox3.width=$textBox1.width
            $textBox4.width=$textBox1.width
            $textBox5.width=$textBox1.width

            $Teil=($EditValuesForm.width - $SaveButton.width - $CancelButton.width) / 3
            $OKButton.left = $Teil
            $CancelButton.left = $EditValuesForm.width - $FormRandRechts - $CancelButton.width - $Teil

            $EditValuesForm.height=300

            if ($DebugMode -eq "true") { $text="## FormResizeEV endet";Write-Host $text}
        }

    #endregion SubmenueEventhandler

    function EditValues {
        param ($SelectionZeile=0)
        ##################################################
        # Version V02
        # vom 9.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") { $text="## EditValues startet";Write-Host $text}
    
        $LabelWidth=90
        $Labelleft=20
        $textBoxleft=$Labelleft + $LabelWidth + 2
        $TextBoxWidth=650

        # GUI erzeugen
        $EditValuesForm = New-Object System.Windows.Forms.Form
        $EditValuesForm.StartPosition = "CenterScreen"
       # $EditValuesForm.Text = "Stammbaum Settings-Editor"
        $EditValuesForm.Text = GetTextFromLanguageDB -ID  ("2_2")
        $EditValuesForm.Size = New-Object System.Drawing.Size(800,300)
        $EditValuesForm.Add_Resize({FormResizeEV})

        $ZeileTop=20
        $label1 = New-Object System.Windows.Forms.Label
        $label1.Location = New-Object System.Drawing.Point($Labelleft, $ZeileTop)
        $label1.Size = New-Object System.Drawing.Size($LabelWidth,20)
        $label1.Text =  GetTextFromLanguageDB -ID  ("2_M_1_1") + ":"
        $label1.Enabled=$false
        $EditValuesForm.Controls.Add($label1)

        $textBox1 = New-Object System.Windows.Forms.TextBox
        $textBox1.Location = New-Object System.Drawing.Point($textBoxleft, $ZeileTop)
        $textBox1.Size = New-Object System.Drawing.Size($TextBoxWidth,20)
        $textBox1.Enabled=$false
        $EditValuesForm.Controls.Add($textBox1)

        $ZeileTop=60
        $label2 = New-Object System.Windows.Forms.Label
        $label2.Location = New-Object System.Drawing.Point($Labelleft, $ZeileTop)
        $label2.Size = New-Object System.Drawing.Size($LabelWidth,20)
        $label2.Text =  GetTextFromLanguageDB -ID  ("2_M_1_2") + ":"
        $label2.Enabled=$false
        $EditValuesForm.Controls.Add($label2)

        $textBox2 = New-Object System.Windows.Forms.TextBox
        $textBox2.Location = New-Object System.Drawing.Point($textBoxleft, $ZeileTop)
        $textBox2.Size = New-Object System.Drawing.Size($TextBoxWidth,20)
        $textBox2.Enabled=$false
        $EditValuesForm.Controls.Add($textBox2)
    
        $ZeileTop=100
        $label3 = New-Object System.Windows.Forms.Label
        $label3.Location = New-Object System.Drawing.Point($Labelleft, $ZeileTop)
        $label3.Size = New-Object System.Drawing.Size($LabelWidth,20)
        $label3.Text =  GetTextFromLanguageDB -ID  ("2_M_1_3") + ":"
        $label3.Enabled=$false
        $EditValuesForm.Controls.Add($label3)

        $textBox3 = New-Object System.Windows.Forms.TextBox
        $textBox3.Location = New-Object System.Drawing.Point($textBoxleft, $ZeileTop)
        $textBox3.Size = New-Object System.Drawing.Size($TextBoxWidth,20)
        $textBox3.Enabled=$false
        $EditValuesForm.Controls.Add($textBox3)
    
        $ZeileTop=140
        $label4 = New-Object System.Windows.Forms.Label
        $label4.Location = New-Object System.Drawing.Point($Labelleft, $ZeileTop)
        $label4.Size = New-Object System.Drawing.Size($LabelWidth,20)
        $label4.Text =  GetTextFromLanguageDB -ID  ("2_M_1_4") + ":"
        $label4.Enabled=$false
        $EditValuesForm.Controls.Add($label4)

        $textBox4 = New-Object System.Windows.Forms.TextBox
        $textBox4.Location = New-Object System.Drawing.Point($textBoxleft, $ZeileTop)
        $textBox4.Size = New-Object System.Drawing.Size($TextBoxWidth,20)
        $EditValuesForm.Controls.Add($textBox4)
    
        $ZeileTop=180
        $label5 = New-Object System.Windows.Forms.Label
        $label5.Location = New-Object System.Drawing.Point($Labelleft, $ZeileTop)
        $label5.Size = New-Object System.Drawing.Size($LabelWidth,20)
        $label5.Text =  GetTextFromLanguageDB -ID  ("2_M_1_5") + ":"
        $label5.Enabled=$false
        $EditValuesForm.Controls.Add($label5)

        $textBox5 = New-Object System.Windows.Forms.TextBox
        $textBox5.Location = New-Object System.Drawing.Point($textBoxleft, $ZeileTop)
        $textBox5.Size = New-Object System.Drawing.Size($TextBoxWidth,20)
        $textBox5.Enabled=$false
        $EditValuesForm.Controls.Add($textBox5)

        
        $ZeileTop=220
        # Button "OK"                            
        $OKButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $OKButton.Location = New-Object System.Drawing.Size(100,$ZeileTop)
        $OKButton.Size = New-Object System.Drawing.Size(100,23)
        $OKButton.Text =  GetTextFromLanguageDB -ID  ("2_M_2")
        $OKButton.Name = "OK"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $OKButton.add_Click({EditValuesFormSaveClick})
        $EditValuesForm.Controls.Add($OKButton)

        # Button "Abbruch"                            
        $CancelButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $CancelButton.Location = New-Object System.Drawing.Size(300,$ZeileTop)
        $CancelButton.Size = New-Object System.Drawing.Size(100,23)
        $CancelButton.Text =GetTextFromLanguageDB -ID  ("2_M_3")
        $CancelButton.Name = "Abbrechen"
        $CancelButton.DialogResult = "Cancel"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $CancelButton.Add_Click({$EditValuesForm.Close()})
        $EditValuesForm.Controls.Add($CancelButton)


        $EditValuesForm.Height=300
        $EditValuesForm.Width= $textBoxleft + $TextBoxWidth + 40
        $OKButton.left=$EditValuesForm.Width/5*1 - ($OKButton.Width/2)
        $CancelButton.left=$EditValuesForm.Width/5*4  - ($CancelButton.Width/2)


        $textBox1.Text=$DGVdata.SelectedCells[0].Value
        $textBox2.Text=$DGVdata.SelectedCells[1].Value
        $textBox3.Text=$DGVdata.SelectedCells[2].Value
        $textBox4.Text=$DGVdata.SelectedCells[3].Value
        $textBox5.Text=$DGVdata.SelectedCells[4].Value

        [void] $EditValuesForm.ShowDialog()
        
        if ($DebugMode -eq "true") { $text="## EditValues endet";Write-Host $text}
    }


#endregion Submenue WerteChange


#region GUI

    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")


    function EmptyDGV() {
        Write-Host "clear"
        $DGVdata.Rows.Clear()
    }

    function DGVHeader() {
        ##################################################
        # Version V01
        # vom 9.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") { $text="## DGVHeader startet";Write-Host $text}
        $SourceData = $global:SettingsData
        $SourceDataHeaderZeile=$SourceData.Split("`n")[0]
        $SourceDataHeaderZeileSplit= $SourceDataHeaderZeile.Split("`t")
        $DGVdata.ColumnCount = $SourceDataHeaderZeileSplit.count
        
        for($i=0; $i -lt $SourceDataHeaderZeileSplit.count; $i++){
            #$Wert= $SourceDataHeaderZeileSplit[$i]
            $Wert= "2_M_1_" + ($i+1)
            $TrWert=GetTextFromLanguageDB -ID  ($Wert)
            #$TrWert=GetLanguageData -LanguageDBFileName $Wert
            if ($DebugMode -eq "true") { $text="## `t-- Wert:(" + $Wert + ") TrWert:(" + $TrWert + ")";Write-Host $text}
            $DGVdata.Columns[$i].Name = $TrWert
        }

        if ($DebugMode -eq "true") { $text="## DGVHeader endet";Write-Host $text}
    }

    function FillDGV() {
        ##################################################
        # Version V01
        # vom 9.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") { $text="## FillDGV startet";Write-Host $text}

        
        if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:TrSettingsData :(" + $Global:TrSettingsData + ")";Write-Host $Text}

        if ($DGVdata.Items.count -gt 0) {
            EmptyDGV
        }

        $SourceDataZeilenSplit=$Global:TrSettingsData.Split("`n")
        for($z=1; $z -lt $SourceDataZeilenSplit.count; $z++){
            if ($SourceDataZeilenSplit[$z] -ne "") {
                $SourceDataSpaltenSplit=$SourceDataZeilenSplit[$z].Split("`t")
                    
                $Tabellenzeile=@()
                if ($DebugMode -eq "true") { $text="##`t--  Zeile: "+$SourceDataZeilenSplit[$z];Write-Host $text}

                for($i=0; $i -lt $SourceDataSpaltenSplit.count; $i++){
                    $Tabellenzeile =  $Tabellenzeile + $SourceDataSpaltenSplit[$i].trim()
                }
                if ($DebugMode -eq "true") { $text="##`t--  neu zusammengestellte Zeile: "+$Tabellenzeile;Write-Host $text}
                [void]$DGVdata.Rows.Add($Tabellenzeile)
            }   
        } 
    
        $objForm.Refresh

        if ($DebugMode -eq "true") { $text="## FillDGV endet";Write-Host $text}
    }

    function DGVdblclick() {
        ##################################################
        # Version V01
        # vom 9.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") { $text="## DGVdblclick startet";Write-Host $text}

        if ($DebugMode -eq "true") { $text="## `t-- SelectedCells[0].Value:`t" + $DGVdata.SelectedCells[0].Value + "`tSelectedRows.index:`t" + $DGVdata.SelectedRows.index;Write-Host $text}

        $Nummer=$DGVdata.SelectedCells[0].Value
        if ($DebugMode -eq "true") {Write-Host $Nummer}
        EditValues $Nummer

        if ($DebugMode -eq "true") { $text="## DGVdblclick endet";Write-Host $text}
    }

    function FormResizeSM() {
        ##################################################
        # Version V01
        # vom 9.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
        
        if ($DebugMode -eq "true") { $text="## FormResizeSM startet";Write-Host $text}

        if ($DebugMode -eq "true") { $text="## `t-- FensterBreite:`t" + $objForm.width + "`t, FensterH�he:`t" + $objForm.height;Write-Host $text}

        $FormRandTop=20
        $FormRandLeft=20
        $FormRandUnten=35
        $FormRandRechts=35
        $ZeilenAbstand=10
        $TabellenHeaderHoehe=20


        # horrizontal
        $DGVdata.width = ($objForm.width - $FormRandRechts - $FormRandLeft)
        $Teil=($DGVdata.width - $SaveButton.width - $CancelButton.width) / 3
        $SaveButton.left = $DGVdata.left + $Teil
        $CancelButton.left = $objForm.width - $FormRandRechts - $CancelButton.width - $Teil
        
        # vertikal
        $DGVdata.height = ($objForm.height - $DGVdata.top - $CancelButton.height - $FormRandUnten - $ZeilenAbstand -$TabellenHeaderHoehe)
        $SaveButton.top = ($DGVdata.top + $DGVdata.height + $ZeilenAbstand)
        $CancelButton.top = $SaveButton.top

        if ($DebugMode -eq "true") { $text="## FormResizeSM endet";Write-Host $text}
    }

    function MainMenuSM() {
        ##################################################
        # Version V01
        # vom 9.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
        
        if ($DebugMode -eq "true") { $text="## MainMenuSM startet";Write-Host $text}

        $FormRandTop=20
        $FormRandLeft=20

        $FormBreite=750
        $FormHoehe=500

        $LabelTop=$FormRandTop
        $LabelHight=20
        $LabelLeft=$FormRandLeft
        $LabelBreite=100
        
        $TabellenHeaderHoehe=20
        $TabellenTop=$LabelTop + $ZeilenAbstand + $TabellenHeaderHoehe
        $TabellenLeft=$FormRandLeft

        $ButtonHight=20
        $ButtonBreite=100

        # Form erzeugen
        $objForm = New-Object System.Windows.Forms.Form
        $objForm.StartPosition = "CenterScreen"
        #$TrText=GetTextFromLanguageDB -ID  ("2_1")
        #$objForm.Text = "Stammbaum Settings-Manager"
        $objForm.Text = GetTextFromLanguageDB -ID  ("2_1")
        $objForm.Size = New-Object System.Drawing.Size($FormBreite,$FormHoehe)
        $objForm.Add_Resize({FormResizeSM})

        # Label Tabelle
        $TabelleLabel = New-Object System.Windows.Forms.Label
        $TabelleLabel.Location = New-Object System.Drawing.Size($LabelLeft,$LabelTop)
        $TabelleLabel.Size = New-Object System.Drawing.Size($LabelBreite,$LabelHight)
        #$TabelleLabel.Text="Einstellungen"
        $TabelleLabel.Text= GetTextFromLanguageDB -ID  ("2_M_1")
        $objForm.Controls.Add($TabelleLabel)

        
        # DataGridView Werte-Tabelle
        $DGVdata = [System.Windows.Forms.DataGridView]::new()
        $DGVdata.ColumnHeadersHeightSizeMode = [System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode]::AutoSize
        $DGVdata.Location = New-Object System.Drawing.Point($TabellenLeft, $TabellenTop)
        $DGVdata.Name = "Einstellungen"
        $DGVdata.TabIndex = 3
 
        $DGVdata.ColumnHeadersVisible = $true
        $DGVdata.RowHeadersVisible = $false
        $DGVdata.AutoSizeColumnsMode = 'Fill'
        $DGVdata.AllowUserToResizeRows = $true
        $DGVdata.selectionmode = 'FullRowSelect'
        $DGVdata.MultiSelect = $false 
        $DGVdata.AllowUserToAddRows = $false
        $DGVdata.ReadOnly = $true
        $DGVdata.add_doubleclick({DGVdblclick})
        $objForm.Controls.Add($DGVdata)


        # Button "Speichern"                            
        $SaveButton = New-Object System.Windows.Forms.Button
        $SaveButton.Size = New-Object System.Drawing.Size($ButtonBreite,$ButtonHight)
        $SaveButton.Text = GetTextFromLanguageDB -ID  "2_M_2"
        $SaveButton.Name = "Speichern"
        $SaveButton.add_Click({SaveAllSettings})
        $SaveButton.TabIndex = 1
        $objForm.Controls.Add($SaveButton)

        # Button "Abbruch"                            
        $CancelButton = New-Object System.Windows.Forms.Button
        $CancelButton.Size = New-Object System.Drawing.Size($ButtonBreite,$ButtonHight)
        $CancelButton.Text = GetTextFromLanguageDB -ID "2_M_3"
        $CancelButton.Name = "Abbrechen"
        $CancelButton.DialogResult = "Cancel"
        $CancelButton.Add_Click({$objForm.Close()})
        $CancelButton.TabIndex = 2
        $objForm.Controls.Add($CancelButton)

        FormResizeSM

        DGVHeader
        FillDGV

        #FillListboxes

        [void] $objForm.ShowDialog()
    }


#endregion GUI

#region Main

    $DebugMode = "false"
    if ($Global:DebugMode -eq "true"){$DebugMode="true"}
    #$DebugMode="true"


    if ($GetVersionInfo -eq "true") {            
            $ErgText=$ErgText + "Version:`t" + $Version + "`n"
            $ErgText=$ErgText + "Stand:`t" + $Stand + "`n"
            $ErgText=$ErgText + "Developper:`t" + $Developper + "`n"
            return  $ErgText

        } else {


            if ($DebugMode -eq "true"){$Global:Debugmode="true"} else {$Global:Debugmode="false"}
            if ($LogMode -eq "true"){$Global:LogMode="true"} else {$Global:LogMode="false"}


            if ($DebugMode -eq "true") { $text="#######################################################################################`n## Stammbaum_SettingsManager.ps1 startet im Debugmode`n dr�ck [enter], dann geht`s los`n"; Write-Host $text; read-host $Text}

            $Global:Language=""         # installierte User-Profil-SPrache
            $global:BasisPfad=""        # FS-Pfad des Stammbaum-Tools
            $Global:SprachDB=""         # Inhalt der aktuellen SprachDB-Datei

            $Global:SettingsDataFile=""
            $global:SettingsData=""
            $global:TrSettingsData=""


            if ($DebugMode -eq "true") { $text="Debugmode:`t" + $DebugMode; Write-Host $text; read-host �Press ENTER to continue...�}

            $Vorbereitung=SetGlobalParameterSM

            if ($Vorbereitung -eq "OK") {
                    MainMenuSM
                } else {
                    Write-Host "Fehler in der Vorbereitung - bitte Verzeichnisse pr�fen!"
            }
    }
#endregion Main