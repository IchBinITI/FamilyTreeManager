param (
    $DebugMode="false",
    $GetVersionInfo="false"
)

cls

##################################################
$Version="0.27"
$Stand="20.05.2023"
$Developper="na ich"
##################################################


if ($DebugMode -eq "true") { $text="Debugmode:`t" + $DebugMode; Write-Host $text; read-host �Press ENTER to continue...�}


#region Tools

    function DetectScriptPath {
        Param(
            $PowershellVersion
        )
        ##################################################
        # Version V02
        # vom 8.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        if ($DebugMode -eq "true") {
            $text="DetectScriptPath Startet mit Parameter`nPowershellVersion:`t" + $PowershellVersion + "`nDebugMode:`t" + $DebugMode + "`n"
            Write-Host  $Text
        }

        # gezielte Versuch anhand der installierten PS-Version den Script-Pfad zu ermitteln
        if ($PowershellVersion -gt 2){
            $BasisPfad=$PSScriptRoot
        }
        if ($PowershellVersion -gt 1){
            $BasisPfad=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath('.\')
        }

        # falls nichts funktioniert, dann wird stumpf versucht
        if ($BasisPfad -eq ""){
            $BasisPfad=$PSScriptRoot
        }
        if ($BasisPfad -eq ""){
            $BasisPfad=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath('.\')
        }
        if ($BasisPfad -eq ""){
            $BasisPfad=split-path -parent $MyInvocation.MyCommand.Definition
        }

        if ($DebugMode -eq "true") {
            $a=$PSScriptRoot
            $b=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath('.\')
            $c=split-path -parent $MyInvocation.MyCommand.Definition

            $Text="Ermitteln des ScriptPfades`n Methode 1: " + $a + "`n" + "Methode 2: " + $b + "`n" + "Methode 3: " + $c + "`n"
            $text=$Text + "DetectScriptPath endet mit Rueckgabe-Parameter`nBasisPfad:`t" + $BasisPfad + "`n"
            Write-Host  $Text
        }
        return $BasisPfad
}

    function DetectPSVersion() {
        
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        $PSVersion=""
        $PSVersion=$PSVersionTable.PSVersion.Major

        return $PSVersion
    }   

    function GetSettingsData {
        Param(
            $SourceDataFile
        )

        ##################################################
        # Version V03
        # vom 8.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        if ($DebugMode -eq "true") {$Text="## GetSettingsData startet `t- mit Parameter SourceDataFile: (" + $SourceDataFile + ")";Write-Host $text}
        $SourceData=Get-Content $SourceDataFile

        if ($SourceData.Length -eq 0){
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei existiert nicht/oder ist leer"}

            # Standard-Trennzeichen ist TAB ( `t )
            $SourceData="Lnr	Kategorie	Namen	Wert	Beschreibung" + "`n"
            $SourceData=$SourceData + "1`tallgemein`tDatenquelle`t1`tSpeicherort der Daten, 1=interne ExcelSheets (noch nicht verf�gber: , 2=SQL-DB, 3=Spreadsheet-Datei)" + "`n"
            $SourceData=$SourceData + "2`tallgemein`tFeldTrenner`tTAB`tSpalten-Trennzeichen aller interner Datens�tze" + "`n"
            $SourceData=$SourceData + "3`tFileSystem`tExportZielPfad`t" +  $BasisPfad + "`tZielordner f�r DatenExporte" + "`n"
            $SourceData=$SourceData + "4`tDarstellung`tNodeBreite`t120`tBreite der Person bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "5`tDarstellung`tNodeHoehe`t100`tH�he der Person bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "6`tDarstellung`tPersonBreite`t100`tBreite der Verbindungsk�sten bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "7`tDarstellung`tPersonHoehe`t130`tH�he der Verbindungsk�sten bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "8`tDebugging`tDebugMode`tWAHR`tDebug-Log-Datei wird erzeugt" + "`n"
            $SourceData=$SourceData + "9`tDebugging`tDebugZielPfad`t" +  $BasisPfad + "`tSpeicherPfad der Debug-Log-Datei" + "`n"
            $SourceData=$SourceData + "10`tDebugging`tDebugZielDateiname`tDebugLog.log`tDateiname der Debug-Log-Datei" + "`n"
            $SourceData=$SourceData + "11`tFileSystem`tDatenZielPfad`t" +  $BasisPfad + "\DBDaten`tOrdner der DB-Daten" + "`n"
            $SourceData=$SourceData + "12`tFileSystem`tPersonenDatei`tPersonen.sdb`tDB-Datei f�r Personendaten" + "`n"
            $SourceData=$SourceData + "13`tFileSystem`tKnotenDatei`tKnoten.sdb`tDB-Datei f�r Knotendaten" + "`n"
            $SourceData=$SourceData + "14`tFileSystem`tAdresseDatei`tAdressen.sdb`tDB-Datei f�r Adressdaten" + "`n"


            $SourceData| Out-File -FilePath $SourceDataFile
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei wurde erzeugt"}
        
            $SourceData=Get-Content $SourceDataFile
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei wurde frisch eingelesen"}

            if ($SourceData.Length -eq 0){
                if ($DebugMode -eq "true") {Write-Host "Settings-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!"}
                #read-host �Press ENTER to continue...�
                $erg=[System.Windows.Forms.MessageBox]::Show("Settings-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!", "FileSystem Zugriffs-Fehler", "1", "None" )
                $host.Exit()
            }
        }
        
        if ($DebugMode -eq "true") {$text= "## GetSettingsData endet `t- mit R�ckgabe-Parameter SourceData: (" + $SourceData + ")";Write-Host $text}
        return $SourceData
    }

    function GetParameterFromSettings {
        param (
            $Parametername=""
        )
        ##################################################
        # Version V02
        # vom 7.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
            
        if ($DebugMode -eq "true") {$text= "## GetParameterFromSettings startet `t- mit Parameter Parametername: (" + $Parametername + ")";Write-Host $text}

        $DummyText=""
        # Achtung Namensaenderung!
        $SourceDataZeilenSpit=$global:SettingsData.Split("`n")

        for($i=0; $i -lt $SourceDataZeilenSpit.count; $i++){

                if ($SourceDataZeilenSpit[$i].length -ne 0)                            
                {
                    $SourceDataSplit=$SourceDataZeilenSpit[$i].Split("`t")

                    if ($DebugMode -eq "true") { $text="Parmeter " + $SourceDataSplit[2];Write-Host $text}
                    if ($Parametername -eq $SourceDataSplit[2]){
                        
                        $DummyText=$SourceDataSplit[3]

                        if ($Parametername -eq "LogMode"){
                            if ($SourceDataSplit[3] -eq "wahr"){
                                    $DummyText="true"
                                } elseif ($SourceDataSplit[3] -eq "true"){
                                    $DummyText="true"
                                }elseif ($SourceDataSplit[3] -eq "falsch"){
                                    $DummyText="false"
                                } elseif ($SourceDataSplit[3] -eq "false"){
                                    $DummyText="false"
                            }
                        } 
                        if ($Parametername -eq "DebugMode"){
                            if ($SourceDataSplit[3] -eq "wahr"){
                                    $DummyText="true"
                                } elseif ($SourceDataSplit[3] -eq "true"){
                                    $DummyText="true"
                                } elseif ($SourceDataSplit[3] -eq "falsch"){
                                    $DummyText="false"
                                } elseif ($SourceDataSplit[3] -eq "false"){
                                    $DummyText="false"
                            }
                        } 
                    }
                }   
        } 
    
        if ($DebugMode -eq "true") {$text="## GetParameterFromSettings endet `t- mit R�ckgabe-Parameter DummyText: (" + $DummyText + ")";Write-Host $text}
        return $DummyText
    }
        
    function DetectOsUserLanguage() {
        
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        $UserLanguageList=Get-WinUserLanguageList
        $MainLanguage=$UserLanguageList[0].languagetag.ToUpper()

        return $MainLanguage
    }
    
    function GetLanguageFileName() {
        Param(
            $ActiveLanguage
        )
        ##################################################
        # Version V02
        # vom 11.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        
        if ($DebugMode -eq "true") {$text="## GetLanguageFileName startet `t- mit Parameter ActiveLanguage: (" + $ActiveLanguage + ")";Write-Host $text}

        $DBPfad=GetParameterFromSettings -Parametername "DatenZielPfad"

        if (Test-Path -Path $DBPfad) {
            } else {
                $DBPfad = $global:BasisPfad + "\DBDaten"
                if (Test-Path -Path $DBPfad) {
                    } else {
                        $DBPfad = $global:BasisPfad
                }
        }

        if ($ActiveLanguage -eq "DE-DE") {$LanguageFileName=$DBPfad + "\SprachPaket_DE.sdb"}
        if ($ActiveLanguage -eq "EN-EN") {$LanguageFileName=$DBPfad + "\SprachPaket_EN.sdb"}

        if ($LanguageFileName -eq "") {$LanguageFileName=$DBPfad + "\SprachPaket_EN.sdb"}

        if (Test-Path -Path $LanguageFileName) {
            } else {
                $text="LanguageFile: (" + $LanguageFileName + ") nicht gefunden!";Write-Host $text
        }
                        
        if ($DebugMode -eq "true") {$text="## GetLanguageFileName endet `t- mit R�ckgabe-Parameter LanguageFileName: (" + $LanguageFileName + ")";Write-Host $text}
        return $LanguageFileName
    }

    function GetLanguageData {
        Param(
            $LanguageDBFileName
        )
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$text="## GetLanguageData startet `t- mit Parameter LanguageDBFileName: (" + $LanguageDBFileName + ")";Write-Host $text}

        $SourceData=""
        if ($LanguageDBFileName -ne "") {
            $SourceData=Get-Content $LanguageDBFileName
        }

        if ($SourceData.Length -eq 0){
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei existiert nicht/oder ist leer"}
        }
        
        if ($DebugMode -eq "true") {$text="## GetLanguageData endet `t- mit R�ckgabe-Parameter SourceData: (" + $SourceData + ")";Write-Host $text}
        return $SourceData
    }

    function GetTextFromLanguageDB {
        param (
            $ID=""
        )
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") { $text="## GetTextFromLanguageDB startet zum Auslesen von ID:`t" + $ID;Write-Host $text}

        $DummyText=""
        # Achtung Namensaenderung!
        $SourceDataZeilenSpit=$Global:SprachDB.Split("`n")

        for($i=0; $i -lt $SourceDataZeilenSpit.count; $i++){

                if ($SourceDataZeilenSpit[$i].length -ne 0)                            
                {
                    $SourceDataSplit=$SourceDataZeilenSpit[$i].Split("`t")

                    if ($DebugMode -eq "true") { $text="Pr�fe Parmeter (`t" + $SourceDataSplit[1] + ") hat Wert:(`t" + $SourceDataSplit[2] + ")";Write-Host $text}
                    if ($ID -eq $SourceDataSplit[1]){
                        $DummyText=$SourceDataSplit[2]
                        $i = $SourceDataZeilenSpit.count
                    }
                }   
        } 
    
        if ($DebugMode -eq "true") {Write-Host "## GetTextFromLanguageDB endet `t- mit R�ckgabe-Parameter DummyText: (" + $DummyText + ")"}
        return $DummyText
    }

    function GetPersonenData {
        ##################################################
        # Version V04
        # vom 23.4.2023
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "GetPersonenData startet";  Write-Host $Text}

        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {$Text= "DBOrdner:`t" +  $DBOrdner;  Write-Host $Text}
        if ( $DBOrdner[1] -ne ":") { $DBOrdner=$global:BasisPfad + "\" + $DBOrdner}
        if ($DebugMode -eq "true") {$Text= "DBOrdner:`t" +  $DBOrdner;  Write-Host $Text}

        $PersonenDBDateiName=GetParameterFromSettings ("PersonenDatei")
        if ($DebugMode -eq "true") {Write-Host "PersonenDBDateiName:`t";  Write-Host  $PersonenDBDateiName}
        $PersonenDBDatei=$DBOrdner + "\" + $PersonenDBDateiName

        $Neu=""
        if (Test-Path -Path $PersonenDBDatei) {


                $PersonenDB=Get-Content $PersonenDBDatei

                if ($PersonenDB.Length -eq 0){
                    if ($DebugMode -eq "true") {Write-Host "Personen-DB-Datei existiert nicht/oder ist leer"}

                    # Standard-Trennzeichen ist TAB ( `t )
                    $SourceData="#2#LNr`tVorname`tName`tGeburtsname`tGeburtsdatum`tSterbedatum`tBemerkung`tZusatzVornamen`tmobil`tmail`tGeburtsOrt`tSterbeOrt/Friedhof`treligion`tgeschl`tnationalit�t`tWohnOrtNr" + "`n"


                    $SourceData| Out-File -FilePath $PersonenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Personen-DB-Datei wurde erzeugt"}
        
                    $PersonenDB=Get-Content $PersonenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Personen-DB-Datei wurde frisch eingelesen"}

                    if ($PersonenDB.Length -eq 0){
                        if ($DebugMode -eq "true") {Write-Host "Personen-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!"}
                        #read-host �Press ENTER to continue...�
                        $erg=[System.Windows.Forms.MessageBox]::Show("Personen-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!", "FileSystem Zugriffs-Fehler", "1", "None" )
                        $host.Exit()
                    }
                }

                # Cleanup
                $ErgText=""
                $PersonenDBSplit=$PersonenDB.split("`n")
                for($i=0; $i -lt $PersonenDBSplit.count; $i++){
                    if ($DebugMode -eq "true") {$Text="Cleanup Person " + $i + " : " + $PersonenDBSplit[$i]; Write-Host $Text}
                    if ($PersonenDBSplit[$i] -ne ""){
                        if ($ErgText -eq "") {
                                $ErgText="" + $PersonenDBSplit[$i]
                            } else {
                                $ErgText=$ErgText + "`n" + $PersonenDBSplit[$i]
                        }
                    }
                    if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}
                }
        
                if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}

                $ErgText| Out-File -FilePath $PersonenDBDatei

                $Neu=Get-Content $PersonenDBDatei
            } else {
                $text="PersonenDB-Datei: (" + $PersonenDBDatei + ") nicht gefunden!";Write-Host $text

                
                # Standard-Trennzeichen ist TAB ( `t )
                $SourceData="#2#LNr`tVorname`tName`tGeburtsname`tGeburtsdatum`tSterbedatum`tBemerkung`tZusatzVornamen`tmobil`tmail`tGeburtsOrt`tSterbeOrt/Friedhof`treligion`tgeschl`tnationalit�t`tWohnOrtNr" + "`n"


                $SourceData| Out-File -FilePath $PersonenDBDatei
                if ($DebugMode -eq "true") {Write-Host "Personen-DB-Datei wurde erzeugt"}
        
                $PersonenDB=Get-Content $PersonenDBDatei
                if ($DebugMode -eq "true") {Write-Host "Personen-DB-Datei wurde frisch eingelesen"}

                # Cleanup
                $ErgText=""
                $PersonenDBSplit=$PersonenDB.split("`n")
                for($i=0; $i -lt $PersonenDBSplit.count; $i++){
                    if ($DebugMode -eq "true") {$Text="Cleanup Person " + $i + " : " + $PersonenDBSplit[$i]; Write-Host $Text}
                    if ($PersonenDBSplit[$i] -ne ""){
                        if ($ErgText -eq "") {
                                $ErgText="" + $PersonenDBSplit[$i]
                            } else {
                                $ErgText=$ErgText + "`n" + $PersonenDBSplit[$i]
                        }
                    }
                    if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}
                }
        
                if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}

                $ErgText| Out-File -FilePath $PersonenDBDatei

                $Neu=Get-Content $PersonenDBDatei

        }
        
        if ($DebugMode -eq "true") {$Text= "GetPersonenData endet mit �bergabeParameter Neu:`t" + $Neu;  Write-Host $Text}
        return $Neu
    }

    function GetKnotenData {
        ##################################################
        # Version V05
        # vom 23.4.2023
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "GetKnotenData startet";  Write-Host $Text}

        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {$Text= "DBOrdner:`t" +  $DBOrdner;  Write-Host $Text}
        if ( $DBOrdner[1] -ne ":") { $DBOrdner=$global:BasisPfad + "\" + $DBOrdner}
        if ($DebugMode -eq "true") {$Text= "DBOrdner:`t" +  $DBOrdner;  Write-Host $Text}

        $KnotenDBDateiName=GetParameterFromSettings ("KnotenDatei")
        if ($DebugMode -eq "true") {Write-Host "KnotenDateiName:`t";  Write-Host  $KnotenDBDateiName}
        $KnotenDBDatei=$DBOrdner + "\" + $KnotenDBDateiName
        
        $Neu=""
        if (Test-Path -Path $KnotenDBDatei) {


                $KnotenDB=Get-Content $KnotenDBDatei

                if ($KnotenDB.Length -eq 0){
                    if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei existiert nicht/oder ist leer"}

                    # Standard-Trennzeichen ist TAB ( `t )
                    $SourceData="#2#LNr`tPersonLNr`tVaterLNr`tMutterLNr`tPartnerLNr`tKnoten2LNr`tKnoten3LNr`tKnoten4LNr`tKind1LNr`tKind2LNr`tKind3LNr`tKind4LNr`tKind5LNr`tKind6LNr`tKind7LNr`tKind8LNr`tKind9LNr`tKind10LNr`tKind11LNr`tKind12LNr`tKind13LNr`tKind14LNr`tStartDatum`tEndDatum`tTrau-Ort" + "`n"

                    $SourceData| Out-File -FilePath $KnotenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde erzeugt"}
        
                    $KnotenDB=Get-Content $KnotenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde frisch eingelesen"}

                    if ($KnotenDB.Length -eq 0){
                        if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!"}
                        #read-host �Press ENTER to continue...�
                        $erg=[System.Windows.Forms.MessageBox]::Show("Knoten-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!", "FileSystem Zugriffs-Fehler", "1", "None" )
                        $host.Exit()
                    }
                }
    

    
                # Cleanup
                $ErgText=""
                $KnotenDBSplit=$KnotenDB.split("`n")
                for($i=0; $i -lt $KnotenDBSplit.count; $i++){
                    if ($DebugMode -eq "true") {$Text="Cleanup Person " + $i + " : " + $KnotenDBSplit[$i]; Write-Host $Text}
                    if ($KnotenDBSplit[$i] -ne ""){
                        if ($ErgText -eq "") {
                                $ErgText="" + $KnotenDBSplit[$i]
                            } else {
                                $ErgText=$ErgText + "`n" + $KnotenDBSplit[$i]
                        }
                    }
                    if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}
                }
        
                if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}

                $ErgText| Out-File -FilePath $KnotenDBDatei

                $Neu=Get-Content $KnotenDBDatei
            } else {
                $text="KnotenDB-Datei: (" + $KnotenDBDatei + ") nicht gefunden! sie wird jetzt frisch angelegt";Write-Host $text

                # Standard-Trennzeichen ist TAB ( `t )
                $SourceData="#2#LNr`tPersonLNr`tVaterLNr`tMutterLNr`tPartnerLNr`tKnoten2LNr`tKnoten3LNr`tKnoten4LNr`tKind1LNr`tKind2LNr`tKind3LNr`tKind4LNr`tKind5LNr`tKind6LNr`tKind7LNr`tKind8LNr`tKind9LNr`tKind10LNr`tKind11LNr`tKind12LNr`tKind13LNr`tKind14LNr`tStartDatum`tEndDatum`tTrau-Ort" + "`n"

                $SourceData| Out-File -FilePath $KnotenDBDatei
                if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde erzeugt"}
        
                $KnotenDB=Get-Content $KnotenDBDatei
                if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde frisch eingelesen"}

    
                # Cleanup
                $ErgText=""
                $KnotenDBSplit=$KnotenDB.split("`n")
                for($i=0; $i -lt $KnotenDBSplit.count; $i++){
                    if ($DebugMode -eq "true") {$Text="Cleanup Person " + $i + " : " + $KnotenDBSplit[$i]; Write-Host $Text}
                    if ($KnotenDBSplit[$i] -ne ""){
                        if ($ErgText -eq "") {
                                $ErgText="" + $KnotenDBSplit[$i]
                            } else {
                                $ErgText=$ErgText + "`n" + $KnotenDBSplit[$i]
                        }
                    }
                    if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}
                }
        
                if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}

                $ErgText| Out-File -FilePath $KnotenDBDatei

                $Neu=Get-Content $KnotenDBDatei

        }
        if ($DebugMode -eq "true") {$Text= "GetKnotenData endet mit �bergabeParameter Neu:`t" + $Neu;  Write-Host $Text}
        return $Neu
    }

    function GetAdressData {
        ##################################################
        # Version V05
        # vom 23.4.2023
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "GetWohnOrtData startet";  Write-Host $Text}

        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {$Text= "DBOrdner:`t" +  $DBOrdner;  Write-Host $Text}
        if ( $DBOrdner[1] -ne ":") { $DBOrdner=$global:BasisPfad + "\" + $DBOrdner}
        if ($DebugMode -eq "true") {$Text= "DBOrdner:`t" +  $DBOrdner;  Write-Host $Text}

        $KnotenDBDateiName=GetParameterFromSettings ("AdresseDatei")
        if ($DebugMode -eq "true") {Write-Host "KnotenDateiName:`t";  Write-Host  $KnotenDBDateiName}
        $KnotenDBDatei=$DBOrdner + "\" + $KnotenDBDateiName
        
        $Neu=""
        if (Test-Path -Path $KnotenDBDatei) {


                $KnotenDB=Get-Content $KnotenDBDatei

                if ($KnotenDB.Length -eq 0){
                    if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei existiert nicht/oder ist leer"}

                    # Standard-Trennzeichen ist TAB ( `t )
                    $SourceData="#2#LNr`tPersonLNrListe`tStrasse`tHausnummer`tPLZ`tStadt`tOrt`tLand`tTelefon`tmobil`tmail`tLat`tLon" + "`n"

                    $SourceData| Out-File -FilePath $KnotenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde erzeugt"}
        
                    $KnotenDB=Get-Content $KnotenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde frisch eingelesen"}

                    if ($KnotenDB.Length -eq 0){
                        if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!"}
                        #read-host �Press ENTER to continue...�
                        $erg=[System.Windows.Forms.MessageBox]::Show("Knoten-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!", "FileSystem Zugriffs-Fehler", "1", "None" )
                        $host.Exit()
                    }
                }
    

    
                # Cleanup
                $ErgText=""
                $KnotenDBSplit=$KnotenDB.split("`n")
                for($i=0; $i -lt $KnotenDBSplit.count; $i++){
                    if ($DebugMode -eq "true") {$Text="Cleanup Person " + $i + " : " + $KnotenDBSplit[$i]; Write-Host $Text}
                    if ($KnotenDBSplit[$i] -ne ""){
                        if ($ErgText -eq "") {
                                $ErgText="" + $KnotenDBSplit[$i]
                            } else {
                                $ErgText=$ErgText + "`n" + $KnotenDBSplit[$i]
                        }
                    }
                    if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}
                }
        
                if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}

                $ErgText| Out-File -FilePath $KnotenDBDatei

                $Neu=Get-Content $KnotenDBDatei
            } else {
                $text="KnotenDB-Datei: (" + $KnotenDBDatei + ") nicht gefunden! sie wird jetzt frisch angelegt";Write-Host $text

                # Standard-Trennzeichen ist TAB ( `t )
                #LNr	PersonLNrListe	Strasse	Hausnummer	PLZ	Stadt	Ort	Land	Telefon		mobil	mail
                $SourceData="#2#LNr`tPersonLNrListe`tStrasse`tHausnummer`tPLZ`tStadt`tOrt`tLand`tTelefon`tmobil`tmail`tLat`tLon" + "`n"

                $SourceData| Out-File -FilePath $KnotenDBDatei
                if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde erzeugt"}
        
                $KnotenDB=Get-Content $KnotenDBDatei
                if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde frisch eingelesen"}

    
                # Cleanup
                $ErgText=""
                $KnotenDBSplit=$KnotenDB.split("`n")
                for($i=0; $i -lt $KnotenDBSplit.count; $i++){
                    if ($DebugMode -eq "true") {$Text="Cleanup Person " + $i + " : " + $KnotenDBSplit[$i]; Write-Host $Text}
                    if ($KnotenDBSplit[$i] -ne ""){
                        if ($ErgText -eq "") {
                                $ErgText="" + $KnotenDBSplit[$i]
                            } else {
                                $ErgText=$ErgText + "`n" + $KnotenDBSplit[$i]
                        }
                    }
                    if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}
                }
        
                if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}

                $ErgText| Out-File -FilePath $KnotenDBDatei

                $Neu=Get-Content $KnotenDBDatei

        }
        if ($DebugMode -eq "true") {$Text= "GetWohnOrtData endet mit �bergabeParameter Neu:`t" + $Neu;  Write-Host $Text}
        return $Neu
    }

    function GetPersonMitNr {
        param (
            $PersonLnr="0"
        )
        ##################################################
        # Version V03
        # vom 15.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") { Write-Host "PersonenDB:";Write-Host $global:PersonenDB}
    
        $PersonenDBZeilenSplit=$global:PersonenDB.Split("`n")

        #$PersonenDB
        $ErgText=""
    
        if ($DebugMode -eq "true") {$Text="Suche Daten von Person Nr:" +  $PersonLnr;Write-Host $Text}
        if ($PersonenDBZeilenSplit.count -gt 1) {
            for($i=1; $i -lt $PersonenDBZeilenSplit.count; $i++){
                if ($DebugMode -eq "true") {$Text="Eintrag:" +  $i + " von " + $PersonenDBZeilenSplit.count + " : " + $PersonenDBZeilenSplit[$i];Write-Host $Text}

                if ($PersonenDBZeilenSplit[$i] -ne "")                            
                {
                    $PersonenDBSplit=$PersonenDBZeilenSplit[$i].Split("`t")
                
                    if ($DebugMode -eq "true") {$Text="Treffer wenn :" +  $PersonLnr + " == " + $PersonenDBSplit[0];Write-Host $Text}
                    if ($PersonLnr -eq $PersonenDBSplit[0]) {
                        if ($DebugMode -eq "true") {Write-Host "getroffen"}
                        $ErgText=$PersonenDBZeilenSplit[$i]
                    }
                }   
            } 
        }

        if ($DebugMode -eq "true") {$Text="ErgText:" +  $ErgText;Write-Host $Text}
        return $ErgText
    }

    function GetKnotenDBZeileMitKnotenLNr {
        param (
            $KnotenLnr="0"
        )
        ##################################################
        # Version V01
        # vom 22.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") { Write-Host "## GetKnotenDBZeileMitKnotenLNr `t- startet"}

    
        $KnotenDBZeilenSplit=$Global:KnotenDB.Split("`n")

        #$PersonenDB
        $ErgText=""
    
        if ($DebugMode -eq "true") {$Text="Suche Daten von Knoten Nr:" +  $KnotenLnr;Write-Host $Text}
        if ($KnotenDBZeilenSplit.count -gt 1) {
            for($i=1; $i -lt $KnotenDBZeilenSplit.count; $i++){
                if ($DebugMode -eq "true") {$Text="Eintrag:" +  $i + " von " + $KnotenDBZeilenSplit.count + " : " + $KnotenDBZeilenSplit[$i];Write-Host $Text}

                if ($KnotenDBZeilenSplit[$i] -ne "")                            
                {
                    $KnotenDBSplit=$KnotenDBZeilenSplit[$i].Split("`t")
                
                    if ($DebugMode -eq "true") {$Text="Treffer wenn :" +  $KnotenLnr + " == " + $KnotenDBSplit[0];Write-Host $Text}
                    if ($KnotenLnr -eq $KnotenDBSplit[0]) {
                        if ($DebugMode -eq "true") {Write-Host "getroffen"}
                        $ErgText=$i
                    }
                }   
            } 
        }
        
        if ($DebugMode -eq "true") {$Text="## GetKnotenDBZeileMitKnotenLNr `t- endet mit R�ckgabe ErgText:" +  $ErgText;Write-Host $Text}
        return $ErgText
    }

    function GetKnotenHeaderListe(){
        ##################################################
        # Version V02
        # vom 14.4.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") { $text="## GetKnotenHeaderListe startet ";Write-Host $text}

        $KnotenHeaderListe=@()
        $KnotenDBSplit=$Global:KnotenDB.Split("`n")
        $KnotenheaderSplit=$KnotenDBSplit[0].Split("`t")
        # leere Liste erzeugen
        for($i=0; $i -lt $KnotenheaderSplit.count+$global:KindStartNr; $i++){
            $KnotenHeaderListe=$KnotenHeaderListe + 0
        }

        if ($DebugMode -eq "true") { $text="## GetKnotenHeaderListe `t-- leere KnotenHeaderListe: [" +  $KnotenHeaderListe + "]";Write-Host $text}
        
        # Liste fuellen
        $MaxKindNr=0
        for($i=0; $i -lt $KnotenheaderSplit.count; $i++){
            if ($DebugMode -eq "true") { $text=" `t-- Element [" + $i + "] : [" +  $KnotenheaderSplit[$i] + "]";Write-Host $text}
            switch ( $KnotenheaderSplit[$i].ToUpper() ) {
                "LNR".ToUpper() {       $KnotenHeaderListe[0] = $i}
                "PersonLNr".ToUpper() { $KnotenHeaderListe[1] = $i}
                "VaterLNr".ToUpper() {  $KnotenHeaderListe[2] = $i}
                "MutterLNr".ToUpper() { $KnotenHeaderListe[3] = $i}
                "PartnerLNr".ToUpper() {$KnotenHeaderListe[4] = $i}
                "StartDatum".ToUpper() {$KnotenHeaderListe[5] = $i}
                "EndDatum".ToUpper() {  $KnotenHeaderListe[6] = $i}
                "Trau-Ort".ToUpper() {  $KnotenHeaderListe[7] = $i}
            }
            $Dummy2=""
            $dummy=$KnotenheaderSplit[$i].ToUpper() + "D"
            if ($DebugMode -eq "true") { $text=" `t-- Kind : [" +  $KnotenheaderSplit[$i] + "]";Write-Host $text}
            $KindSplit=$dummy.split("D")
            if ($KindSplit.count -gt 1) {
                if ($DebugMode -eq "true") { $text=" `t-- KindSplit[1] : [" +  $KindSplit[1] + "]";Write-Host $text}
                $Dummy2=$KindSplit[1] + "L"
                $KindNrSplit=$Dummy2.split("L")
                if ($DebugMode -eq "true") { $text=" `t-- KindNrSplit[1] : [" +  $KindNrSplit[1] + "]";Write-Host $text}
                if ($DebugMode -eq "true") { $text=" `t-- KindNrSplit.count : [" +  $KindNrSplit.count + "]";Write-Host $text}
                if ($KindNrSplit.count -eq 3) { 
                    if ($KindNrSplit[1] -eq "NR") {
                        if ($DebugMode -eq "true") { $text=" `t-- KindNr : [" +  $KindNrSplit[0] + "] - MaxKindNr:" + $MaxKindNr;Write-Host $text}
                        [int]$KindNr=$KindNrSplit[0]
                        $KnotenHeaderListe[$global:KindStartNr + $KindNr-1]=$i
                        if ($DebugMode -eq "true") { $text=" `t-- KindNr : [" +  $KindNr + "] - MaxKindNr:[" + $MaxKindNr + "]";Write-Host $text}
                        if ($MaxKindNr -lt $KindNr) {
                                $MaxKindNr = $KindNr
                                if ($DebugMode -eq "true") { $text=" `t-- Ja! MaxKindNr:[" + $MaxKindNr + "]";Write-Host $text}
                            } else {
                                if ($DebugMode -eq "true") { $text=" `t-- N�! KindNr : [" +  $KindNr + "] - MaxKindNr:[" + $MaxKindNr + "]";Write-Host $text}
                        }
                    }
                }
            }
        }

        if ($DebugMode -eq "true") { $text="## GetKnotenHeaderListe `t-- bef�llte KnotenHeaderListe: [" +  $KnotenHeaderListe + "]";Write-Host $text}

        if ($DebugMode -eq "true") { $text="## GetKnotenHeaderListe `t-- Anzahl Stellen: [" +  ($global:KindStartNr + $MaxKindNr) + "]";Write-Host $text}

        $NeueListe="" + $KnotenHeaderListe[0]
        for($i=1; $i -lt ($global:KindStartNr + $MaxKindNr); $i++){

            $NeueListe=$NeueListe + "`t" + $KnotenHeaderListe[$i]
           # $NeueListe=$NeueListe  + $KnotenHeaderListe[$i]
        }

        if ($DebugMode -eq "true") { $text="## GetKnotenHeaderListe endet mit R�ckgabe der KnotenHeaderListe: [" + $NeueListe + "]";Write-Host $text}
        return $NeueListe
    }

    function FindeAlleKnotenVonPersonNr {
        param (
            $PersonLnr="0"
        )
        ##################################################
        # Version V02
        # vom 14.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") {$Text= Write-Host "starte FindeAlleKnotenVonPersonNr mit Person Nr.:" + $PersonLnr;Write-Host $Text}


        #$global:KindStartNr=0
        #$global:KnotenHeaderListe=@()
        
        if ($DebugMode -eq "true") {$Text="global:KnotenHeaderListe:" +  $global:KnotenHeaderListe;Write-Host $Text}
        $KnotenHeaderListeSplit=$global:KnotenHeaderListe.split("`t")

        $ErgText=""
    
        if ($DebugMode -eq "true") {$Text="Suche Knoten von Person Nr:" +  $PersonLnr;Write-Host $Text}
        for($i=1; $i -lt $global:KnotenDB.count; $i++){
            if ($DebugMode -eq "true") {$Text="Eintrag:" +  $i + " von " + $global:KnotenDB.count + " : " + $global:KnotenDB[$i];Write-Host $Text}

                if ($global:KnotenDB[$i] -ne "")   
                {
                   # Write-Host $i; Write-Host $global:KnotenDB[$i]
                    $KnotenDBSplit=$global:KnotenDB[$i].Split("`t")
                
                    if ($DebugMode -eq "true") {$Text="Treffer wenn :" +  $PersonLnr + " == " + $KnotenDBSplit[0];Write-Host $Text}
                    $KnotenDBPersonPos=$KnotenHeaderListeSplit[1]
                    if ($PersonLnr -eq $KnotenDBSplit[$KnotenDBPersonPos]) {

                        if ($DebugMode -eq "true") {Write-Host "getroffen"}
                        if ($ErgText -eq "") {
                                $ErgText = "" + $i
                            } else{
                                $ErgText=$ErgText + "`t" + $i
                        }
                    }
                }   
        } 
    
        if ($DebugMode -eq "true") {$Text="ErgText:" +  $ErgText;Write-Host $Text}
        return $ErgText
    }

    function FindeLetztePersonLnrInDB() {
        ##################################################
        # Version V01
        # vom 15.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$Text="## FindeLetztePersonLnrInDB startet ";Write-Host $text}

        [int]$LetzteNr=0
        $globalPersonenDBSplit=$global:PersonenDB.Split("`n")
        
        for($i=1; $i -lt $globalPersonenDBSplit.count; $i++){
            $ZeilenSplit=$globalPersonenDBSplit[$i].Split("`t")
            if ($DebugMode -eq "true") {$Text="## `t--  LetzteNr " + $LetzteNr+ ", ZeilenSplit[0]:" + $ZeilenSplit[0];Write-Host $text}
            if ([int]$ZeilenSplit[0] -gt [int]$LetzteNr) {[int]$LetzteNr=[int]$ZeilenSplit[0]}
        }

        if ($DebugMode -eq "true") {$Text="## FindeLetztePersonLnrInDB endet mit R�ckgabe Nr" + $LetzteNr;Write-Host $text}
        return $LetzteNr
    }

    function ReplacePersonenDaten {
        param (
            $NeueDaten=""
        )
        ##################################################
        # Version V02
        # vom 15.4.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$Text="ReplacePersonenDaten startet mit Parameter:`n`tNeueDaten:`t(" + $NeueDaten + ")";Write-Host $Text}

        if ($NeueDaten -ne "") {

            $NeueDatenSplit=$NeueDaten.split("`t")
            [int]$ChPersonNR=[int]$NeueDatenSplit[0]


            # durchlaufe komplette PersonenDB 

            $ErgText=""
    
            $globalPersonenDBSplit=$global:PersonenDB.split("`n")
        
            if ($DebugMode -eq "true") {$Text="Suche Daten von Person Nr:" +  $ChPersonNR;Write-Host $Text}
            [int]$LetztePeNrInDB=FindeLetztePersonLnrInDB
            if (($LetztePeNrInDB + 1) -eq $ChPersonNR) {
                    # neue Person wird einfach hinten angehaengt
                    if ($DebugMode -eq "true") {$Text="(LetztePeNrInDB + 1): " +  ($LetztePeNrInDB + 1) + " = ChPersonNR: " + $ChPersonNR + " => also hinten anhaengen";Write-Host $Text}
                    $ErgText=$global:PersonenDB + "`n" + $NeueDaten
                } else {
                    if ($DebugMode -eq "true") {$Text="(LetztePeNrInDB + 1): " +  ($LetztePeNrInDB + 1) + " <> ChPersonNR: " + $ChPersonNR + " => also suchen und aendern";Write-Host $Text}

                    for($i=0; $i -lt $globalPersonenDBSplit.count; $i++){
                        if ($DebugMode -eq "true") {$Text="Eintrag:" +  $i + " von " + $globalPersonenDBSplit.count + " : " + $globalPersonenDBSplit[$i];Write-Host $Text}

                            if ($globalPersonenDBSplit[$i].length -ne 0)                            
                            {
                                $PersonenDBSplit=$globalPersonenDBSplit[$i].Split("`t")
                
                                if ($DebugMode -eq "true") {$Text="Treffer wenn :" +  $PersonLnr + " == " + $PersonenDBSplit[0];Write-Host $Text}
                                if ($ErgText -ne "") {$ErgText=$ErgText + "`n"}
                                if ($ChPersonNR -eq $PersonenDBSplit[0]) {
                        
                                        if ($DebugMode -eq "true") {Write-Host "getroffen"}
                                        # neuen Wert einfuegen
                                        $ErgText=$ErgText + $NeueDaten
                                    } else {
                                        # alten Wert uebernehmen
                                        $ErgText=$ErgText + $globalPersonenDBSplit[$i]
                                }
                            }   
                    } 
            }

            # Neue Personendb speichern
            $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
            if ($DebugMode -eq "true") {$Text= "DBOrdner:`t" +  $DBOrdner;  Write-Host $Text}
            if ( $DBOrdner[1] -ne ":") { $DBOrdner=$global:BasisPfad + "\" + $DBOrdner}
            if ($DebugMode -eq "true") {$Text= "DBOrdner:`t" +  $DBOrdner;  Write-Host $Text}

            $PersonenDBDateiName=GetParameterFromSettings ("PersonenDatei")
            if ($DebugMode -eq "true") {$Text=  "PersonenDBDateiName:`t" + $PersonenDBDateiName;  Write-Host  $Text}

            $PersonenDBDatei=$DBOrdner + "\" + $PersonenDBDateiName
            if ($DebugMode -eq "true") {$Text=  "PersonenDBDatei:`t" + $PersonenDBDatei;  Write-Host  $Text}
        
            if ($DebugMode -eq "true") {$Text=  "ErgText:`n" + $ErgText;  Write-Host  $Text}
            $ErgText| Out-File -FilePath $PersonenDBDatei

            # PersonenDaten erneut einlesen
            $global:PersonenDB = GetPersonenData
        }

        if ($DebugMode -eq "true") {Write-Host "ReplacePersonenDaten endet"}
    }
    
    function FindeLetztenKnotenLnrInDB() {
        ##################################################
        # Version V02
        # vom 23.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$Text="## FindeLetztenKnotenLnrInDB startet ";Write-Host $text}

        [int]$LetzteNr=0
        $globalKnotenDBSplit=$global:KnotenDB.Split("`n")
        
        for($i=1; $i -lt $globalKnotenDBSplit.count; $i++){
            $ZeilenSplit=$globalKnotenDBSplit[$i].Split("`t")
            if ($DebugMode -eq "true") {$Text="## `t--  LetzteNr " + $LetzteNr+ ", ZeilenSplit[0]:" + $ZeilenSplit[0];Write-Host $text}
            if ([int]$ZeilenSplit[0] -gt [int]$LetzteNr) {[int]$LetzteNr=[int]$ZeilenSplit[0]}
        }

        if ($DebugMode -eq "true") {$Text="## FindeLetztenKnotenLnrInDB endet mit R�ckgabe Nr" + $LetzteNr;Write-Host $text}
        return $LetzteNr
    }

    function ReplaceKnotenDaten {
        param (
            $NeueDaten=""
        )
        ##################################################
        # Version V02
        # vom 15.4.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$Text="## starte ReplaceKnotenDaten mit Parameter --`n`t-- Neue Daten:`t" + $NeueDaten ;Write-Host $Text}

        $NeueDatenSplit=$NeueDaten.split("`t")
        [int]$ChKnotenNR=[int]$NeueDatenSplit[0]

        $globalKnotenDBSplit=$global:KnotenDB.Split("`n")
        $LetzteKnotenLnrInDB=0
        $LetzteKnotenLnrInDB=FindeLetztenKnotenLnrInDB

        # durchlaufe komplette PersonenDB 

        $ErgText=""
    
        if ($DebugMode -eq "true") {$Text="Suche Daten von Person Nr:" +  $ChKnotenNR;Write-Host $Text}

        if ($DebugMode -eq "true") {$Text="LetzteKnotenLnrInDB+1:" +  ($LetzteKnotenLnrInDB+1);Write-Host $Text}
        if (($LetzteKnotenLnrInDB+1) -eq $ChKnotenNR) {
                # neue Person wird einfach hinten angehaengt
                if ($DebugMode -eq "true") {$Text="global:KnotenDB.count: " +  $globalKnotenDBSplit.count + " = ChKnotenNR: " + $ChKnotenNR + " => also hinten anhaengen";Write-Host $Text}

                $ErgText=$global:KnotenDB + "`n" + $NeueDaten
            } else {
                if ($DebugMode -eq "true") {$Text="global:KnotenDB.count: " +  $globalKnotenDBSplit.count + " <> ChKnotenNR: " + $ChKnotenNR + " => also finden und ersetzen";Write-Host $Text}

                for($i=0; $i -lt $globalKnotenDBSplit.count; $i++){
                    if ($DebugMode -eq "true") {$Text="Eintrag:" +  $i + " von " + $globalKnotenDBSplit.count + " : " + $globalKnotenDBSplit[$i];Write-Host $Text}

                        if ($globalKnotenDBSplit[$i].length -ne 0)                            
                        {
                            $KnotenDBSplit=$globalKnotenDBSplit[$i].Split("`t")
                
                            if ($DebugMode -eq "true") {$Text="Treffer wenn :" +  $ChKnotenNR + " == " + $KnotenDBSplit[0];Write-Host $Text}

                            if ($ErgText -ne "") {$ErgText=$ErgText + "`n"}
                            if ($ChKnotenNR -eq $KnotenDBSplit[0]) {
                        
                                    if ($DebugMode -eq "true") {Write-Host "getroffen"}
                                    # neuen Wert einfuegen
                                    $ErgText=$ErgText + $NeueDaten 

                                   # $i = $globalKnotenDBSplit.count
                                } else {
                                    # alten Wert uebernehmen
                                    $ErgText=$ErgText + $globalKnotenDBSplit[$i] 
                            }
                        }   
                } 
        }

        # Neue Personendb speichern
        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {Write-Host "DBOrdner:`t";  Write-Host  $DBOrdner}
        if ( $DBOrdner[1] -ne ":") { $DBOrdner=$global:BasisPfad + "\" + $DBOrdner}
        if ($DebugMode -eq "true") {$Text= "DBOrdner:`t" +  $DBOrdner;  Write-Host $Text}

        $KnotenDBDateiName=GetParameterFromSettings ("KnotenDatei")
        if ($DebugMode -eq "true") {Write-Host "KnotenDateiName:`t";  Write-Host  $KnotenDBDateiName}
        $KnotenDBDatei=$DBOrdner + "\" + $KnotenDBDateiName

        $ErgText| Out-File -FilePath $KnotenDBDatei

        # PersonenDaten erneut einlesen
        $global:KnotenDB= GetKnotenData
    
        if ($DebugMode -eq "true") {Write-Host "beende ReplaceKnotenDaten"}
    }

    function SetGlobalParameterDE(){
        
        ##################################################
        # Version V02
        # vom 01.05.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        $global:BasisPfad=DetectScriptPath -PowershellVersion  DetectPSVersion

        $Global:SettingsDataFile = $global:BasisPfad + "\Settings.def"

        if ($DebugMode -eq "true") {
            $Text="## SetGlobalParameter`t- gesetzte globale Parameter" + "`n"
            $text=$Text + "`t`t- global:BasisPfad:`t" + $global:BasisPfad + "`n"
            $text=$Text + "`t`t- Global:SettingsDataFile:`t" + $Global:SettingsDataFile + "`n"
            $text=$Text +  "`n"
            Write-Host  $Text
        }

        $Global:SettingsData=GetSettingsData -SourceDataFile $Global:SettingsDataFile
        if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:SettingsData :(" + $Global:SettingsData + ")";Write-Host $Text}

        $DebugDummy=GetParameterFromSettings -Parametername "DebugMode"
        if ($DebugDummy -eq "1") {$Global:DebugMode= "true"}
        if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:DebugMode ist aktiv wegen Settings.def";Write-Host $Text}
        $LogDummy=GetParameterFromSettings -Parametername "LogMode"
        if ($LogDummy -eq "1") {$Global:LogMode= "true"}

        $Language=GetParameterFromSettings -Parametername "Sprache"
        if ($Language -eq "") {
                $Global:Language=DetectOsUserLanguage 
                if ($DebugMode -eq "true") { $text="## `t- Sprach-Feld in den Settings ist leer => erkannte User-Profil-Haupt-Sprache:`t" + $Global:Language + " wird benutzt"; Write-Host $text}
            } else {
                $Global:Language=$Language.ToUpper()
                if ($DebugMode -eq "true") { $text="## `t- Sprach-Feld in den Settings ist definiert:`t" + $Global:Language + " wird benutzt"; Write-Host $text}
        }

        $SprachDBFileName=GetLanguageFileName -ActiveLanguage $Global:Language
        if ($DebugMode -eq "true") {$Text="## `t- Parameter SprachDBFileName :(" + $SprachDBFileName + ")";Write-Host $Text}
        $Global:SprachDB=GetLanguageData -LanguageDBFileName  $SprachDBFileName
        if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:SprachDB :(" + $Global:SprachDB + ")";Write-Host $Text}

        #$global:SettingsData=GetSettingsData
       # if ($DebugMode -eq "true") {Write-Host "SettingsData:`t";  Write-Host $SettingsData}

        #$global:PersonenDB=
        $global:PersonenDB=GetPersonenData
        if ($DebugMode -eq "true") {Write-Host "PersonenDB:`t";  Write-Host $global:PersonenDB}

        $global:KnotenDB=GetKnotenData
        if ($DebugMode -eq "true") {Write-Host "KnotenDB:`t";  Write-Host $global:KnotenDB}

        $global:AdressDB=GetAdressData
        if ($DebugMode -eq "true") {Write-Host "AdressDB:`t";  Write-Host $global:AdressDB}

        
        $global:KindStartNr=10
        $global:KnotenHeaderListe=GetKnotenHeaderListe
        if ($DebugMode -eq "true") {$Text= "KnotenHeaderListe:`t" + $global:KnotenHeaderListe;  Write-Host $Text}


        $Dummy=GetParameterFromSettings -Parametername "GestorbenZeichen"
        if ($Dummy.StartsWith("[char]0x") -eq $true) {
                $global:GestorbenZeichen=([char][int]$dummy.SubString(6))
            } else {
                $global:GestorbenZeichen=$Dummy
        }
        $Dummy=GetParameterFromSettings -Parametername "GeborenZeichen"
        if ($Dummy.StartsWith("[char]0x") -eq $true) {
                $global:GeborenZeichen=([char][int]$dummy.SubString(6))
            } else {
                $global:GeborenZeichen=$Dummy
        }
        $Dummy=GetParameterFromSettings -Parametername "HochzeitZeichen"
        if ($Dummy.StartsWith("[char]0x") -eq $true) {
                $global:HochzeitZeichen=([char][int]$dummy.SubString(6))
            } else {
                $global:HochzeitZeichen=$Dummy
        }
        $Dummy=GetParameterFromSettings -Parametername "ScheidungsZeichen"
        if ($Dummy.StartsWith("[char]0x") -eq $true) {
                $global:ScheidungsZeichen=([char][int]$dummy.SubString(6))
            } else {
                $global:ScheidungsZeichen=$Dummy
        }


       # $Global:TrSettingsData = TranslateSettingsData

       # if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:TrSettingsData :(" + $Global:TrSettingsData + ")";Write-Host $Text}

        if ($DebugMode -eq "true") {$text="Notbremse"; read-host $Text}
        
        if ($DebugMode -eq "true") {$text="## SetGlobalParameterTM endet ";Write-Host $text}
    }
 
    function GetWohnort() {
        param (
            $WohnOrtNr=0
        )
        ##################################################
        # Version V01
        # vom 29.4.2023
        ##################################################
        #
        # sucht in der $global:AdressDB nach dem $WohnOrtNr in der Spalte LNR
        # gibt die komplette ADresse zur�ck (oder "" wenn nix gefunden wurde)
        #
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "GetWohnort startet mit Start-Parameter WohnOrtNr:" + $WohnOrtNr;  Write-Host $Text}

        $globalAdressDBSplit=$global:AdressDB.split("`n")

        $Treffer=0
        for($i=1; $i -lt $globalAdressDBSplit.count; $i++){
            $AdressSplit=$globalAdressDBSplit[$i].split("`t")
            if ($AdressSplit[0] -eq $WohnOrtNr) {
                $Treffer=$i
                $i=$globalAdressDBSplit.count
            }
        }
        $erg=""
        if ($Treffer -gt 0) {$erg=$globalAdressDBSplit[$Treffer]}
    
        if ($DebugMode -eq "true") {$Text= "GetWohnort endet mit R�ckgabe-Parameter: " + $erg;  Write-Host $Text}
        return $erg
    }

    function GetNextFreeAdressLnr() {
        ##################################################
        # Version V01
        # vom 1.5.2023
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "GetNextFreeAdressLnr startet ";  Write-Host $Text}

        $globalAdressDBSplit=$global:AdressDB.split("`n")

        [int]$LastLnr=0
        for($i=1; $i -lt $globalAdressDBSplit.count; $i++){
            $AdressSplit=$globalAdressDBSplit[$i].split("`t")
            if ([int]$AdressSplit[0] -gt [int]$LastLnr) {
                [int]$LastLnr = [int]$AdressSplit[0]
            }
        }

        [int]$erg = [int]$LastLnr + 1
    
        if ($DebugMode -eq "true") {$Text= "GetNextFreeAdressLnr endet mit R�ckgabeParameter:" + $erg;  Write-Host $Text}
        return $erg

    }

     function ReplaceAdressDaten {
        param (
            $NeueDaten=""
        )
        ##################################################
        # Version V03
        # vom 1.5.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"

        if ($DebugMode -eq "true") {$Text="## starte ReplaceAdressDaten mit Parameter --`n`t-- Neue Daten:`t" + $NeueDaten ;Write-Host $Text}

        $NeueDatenSplit=$NeueDaten.split("`t")
        [int]$ChAdressNR=[int]$NeueDatenSplit[0]

        $globalAdressDBSplit=$global:AdressDB.Split("`n")
        $LetzteAdressLnrInDB=0
        [int]$NextFreeAdressLnr=GetNextFreeAdressLnr
        if ($DebugMode -eq "true") {$Text="NextFreeAdressLnr:" +  $NextFreeAdressLnr;Write-Host $Text}

        [int]$LetzteAdressLnrInDB=($NextFreeAdressLnr - 1)
        if ($DebugMode -eq "true") {$Text="LetzteAdressLnrInDB:" +  $LetzteAdressLnrInDB;Write-Host $Text}

        # durchlaufe komplette PersonenDB 

        $ErgText=""
    
        if ($DebugMode -eq "true") {$Text="Suche Daten von Person Nr:" +  $ChAdressNR;Write-Host $Text}

        if ($DebugMode -eq "true") {$Text="LetzteAdressLnrInDB+1:" +  ($LetzteAdressLnrInDB+1);Write-Host $Text}
        if (($LetzteAdressLnrInDB+1) -eq $ChAdressNR) {
                # neue Person wird einfach hinten angehaengt
                if ($DebugMode -eq "true") {$Text="(LetzteAdressLnrInDB+1): " +  ($LetzteAdressLnrInDB+1) + " = ChAdressNR: " + $ChAdressNR + " => also hinten anhaengen";Write-Host $Text}

                $ErgText=$global:AdressDB + "`n" + $NeueDaten
            } else {
                if ($DebugMode -eq "true") {$Text="(LetzteAdressLnrInDB+1): " +  ($LetzteAdressLnrInDB+1) + " <> ChAdressNR: " + $ChAdressNR + " => also finden und ersetzen";Write-Host $Text}

                for($i=0; $i -lt $globalAdressDBSplit.count; $i++){
                    if ($DebugMode -eq "true") {$Text="Eintrag:" +  $i + " von " + $globalAdressDBSplit.count + " : " + $globalAdressDBSplit[$i];Write-Host $Text}

                        if ($globalAdressDBSplit[$i].length -ne 0)                            
                        {
                            $AdressDBSplit=$globalAdressDBSplit[$i].Split("`t")
                
                            if ($DebugMode -eq "true") {$Text="Treffer wenn :" +  $ChAdressNR + " == " + $AdressDBSplit[0];Write-Host $Text}

                            if ($ErgText -ne "") {$ErgText=$ErgText + "`n"}
                            if ($ChAdressNR -eq $AdressDBSplit[0]) {
                        
                                    if ($DebugMode -eq "true") {Write-Host "getroffen"}
                                    # neuen Wert einfuegen
                                    $ErgText=$ErgText + $NeueDaten 

                                   # $i = $globalAdressDBSplit.count
                                } else {
                                    # alten Wert uebernehmen
                                    $ErgText=$ErgText + $globalAdressDBSplit[$i] 
                            }
                        }   
                } 
        }

        # Neue Personendb speichern
        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {Write-Host "DBOrdner:`t";  Write-Host  $DBOrdner}
        if ( $DBOrdner[1] -ne ":") { $DBOrdner=$global:BasisPfad + "\" + $DBOrdner}
        if ($DebugMode -eq "true") {$Text= "DBOrdner:`t" +  $DBOrdner;  Write-Host $Text}

        $AdressDBDateiName=GetParameterFromSettings ("AdresseDatei")
        if ($DebugMode -eq "true") {Write-Host "AdressDateiName:`t";  Write-Host  $AdressDBDateiName}
        $AdressDBDatei=$DBOrdner + "\" + $AdressDBDateiName

        $ErgText| Out-File -FilePath $AdressDBDatei

        # PersonenDaten erneut einlesen
        $global:AdressDB=GetAdressData
        if ($DebugMode -eq "true") {Write-Host "AdressDB:`t";  Write-Host $global:AdressDB}
  
        if ($DebugMode -eq "true") {Write-Host "ReplaceAdressDaten endet"}
    } 

    function GetAdressGUISummary() {
        param (
            $WohnOrtNr=0
        )
        ##################################################
        # Version V01
        # vom 01.05.2023
        ##################################################
        #
        # holt mit GetWohnort die Zeilen-Nr in der $global:AdressDB von AdresseLnr $WohnOrtNr in der Spalte LNR
        # gibt die Zusammenstellung der ADresse Kommagetrennt zur�ck (oder "" wenn nix gefunden wurde)
        #
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "GetAdressGUISummary startet mit Start-Parameter WohnOrtNr:" + $WohnOrtNr;  Write-Host $Text}

        $TrefferAdresse=GetWohnort -WohnOrtNr $WohnOrtNr

        $erg=""
        if ($TrefferAdresse -ne "") {

            $Adresse=$TrefferAdresse.Split("`t")

            if ($Adresse[2] -ne "") {
                $erg=$erg + $Adresse[2]
            }
            if ($Adresse[3] -ne "") {
                $erg=$erg  + " " + $Adresse[3]
            }
            if ($Adresse[4] -ne "") {
                if ($erg -ne ""){
                    $erg=$erg  + ", " 
                }
                $erg=$erg + $Adresse[4]
            }
            if ($Adresse[5] -ne "") {
                if ($erg -ne ""){
                    $erg=$erg  + " " 
                }
                $erg=$erg + $Adresse[5]
            }
            if ($Adresse[6] -ne "") {
                if ($erg -ne ""){
                    $erg=$erg  + ", " 
                }
                $erg=$erg + $Adresse[6]
            }
            if ($Adresse[7] -ne "") {
                if ($erg -ne ""){
                    $erg=$erg  + ", " 
                }
                $erg=$erg + $Adresse[7]
            }


        }

        
        if ($DebugMode -eq "true") {$Text= "GetAdressGUISummary endet mit R�ckgabe-Parameter: " + $erg;  Write-Host $Text}
        return $erg
    }
    
    function GetAdressMainGUISummary() {
        param (
            $WohnOrtNr=0
        )
        ##################################################
        # Version V01
        # vom 01.05.2023
        ##################################################
        #
        # holt mit GetWohnort die Zeilen-Nr in der $global:AdressDB von AdresseLnr $WohnOrtNr in der Spalte LNR
        # gibt die Zusammenstellung der ADresse Kommagetrennt zur�ck (oder "" wenn nix gefunden wurde)
        #
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "GetAdressGUISummary startet mit Start-Parameter WohnOrtNr:" + $WohnOrtNr;  Write-Host $Text}

        $TrefferAdresse=GetWohnort -WohnOrtNr $WohnOrtNr

        $erg=""
        if ($TrefferAdresse -ne "") {

            $Adresse=$TrefferAdresse.Split("`t")

            if ($Adresse[4] -ne "") {
                if ($erg -ne ""){
                    $erg=$erg  + ", " 
                }
                $erg=$erg + $Adresse[4]
            }
            if ($Adresse[5] -ne "") {
                if ($erg -ne ""){
                    $erg=$erg  + " " 
                }
                $erg=$erg + $Adresse[5]
            }

        }

        
        if ($DebugMode -eq "true") {$Text= "GetAdressGUISummary endet mit R�ckgabe-Parameter: " + $erg;  Write-Host $Text}
        return $erg
    }

#endregion Tools


#region Sub Menue SelectPerson
    ##############################################################
    ### Sub Menue SelectPerson
    $SelectPersonForm_ErsterButton_OnClick={
        $SelectDBZeiletextBox.Text=1
        SelectPersonFelderFuellen
    }

    $SelectPersonForm_LetzterButton_OnClick={
        $globalPersonenDBSplit=$global:PersonenDB.Split("`n")
        $SelectDBZeiletextBox.Text=($globalPersonenDBSplit.count-1)
        SelectPersonFelderFuellen
    }   

    $SelectPersonForm_RueckButton_OnClick={
        [int]$dummy=$SelectDBZeiletextBox.Text
        if ($dummy -gt 1) { $SelectDBZeiletextBox.Text=$dummy - 1}
        SelectPersonFelderFuellen
    }  

    $SelectPersonForm_VorButton_OnClick={
        [int]$dummy=$SelectDBZeiletextBox.Text
        if ($dummy -lt $global:PersonenDB.Split("`n").count - 1){$SelectDBZeiletextBox.Text=$dummy + 1}
        SelectPersonFelderFuellen
    }   

    function SelectPersonFelderFuellen {
        ##################################################
        # Version V02
        # vom 16.4.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") {Write-Host "starte SelectPersonFelderFuellen"}

        $PersonDBZeileLnr = $SelectDBZeiletextBox.Text

    
        if ($DebugMode -eq "true") {$Text="hole Daten von Person in DB-Zeile:" +  $PersonDBZeileLnr + " mit Lnr:" + $SelectPersonLNRtextBox.Text;Write-Host $Text}
        $PersonenDaten=$global:PersonenDB.Split("`n")[$PersonDBZeileLnr]
        #$PersonenDaten=GetPersonMitNr($PersonLnr)
        if ($DebugMode -eq "true") {Write-Host "PersonenDaten:";Write-Host $PersonenDaten}

        if ($PersonenDaten -ne "") {
            $PersonenDatenSplit=$PersonenDaten.Split("`t")

            $SelectDBZeiletextBox.Text           = $PersonDBZeileLnr
            $SelectPersonLNRtextBox.Text         = $PersonenDatenSplit[0]
            $SelectPersonVornametextBox.Text     = $PersonenDatenSplit[1]
            $SelectPersonNachnametextBox.Text    = $PersonenDatenSplit[2]
            $SelectPersonGebNametextBox.Text     = $PersonenDatenSplit[3]
            $SelectPersonGebDatumtextBox.Text    = $PersonenDatenSplit[4]
            $SelectPersonSterbeDatumtextBox.Text = $PersonenDatenSplit[5]
            $SelectPersonBemerkungtextBox.Text   = $PersonenDatenSplit[6]
        }
    }

    function SelectPerson {
        ##################################################
        # Version V02
        # vom 16.4.2023
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") {Write-Host "starte Sub Men� SelectPerson"}

        $global:AktPersonNr=1

        $HorrAbstand=5
        $ZeilenAbstand=10

        $LabelWidth=100
        $LabelHeight=20
        $LabelLeft=20
        $TextBoxLeft=$LabelLeft + $LabelWidth + $HorrAbstand
        $TextBoxWidth=200
    
        # GUI erzeugen
        $SelectPersonForm = New-Object System.Windows.Forms.Form
        $SelectPersonForm.StartPosition = "CenterScreen"
        $SelectPersonForm.Text = GetTextFromLanguageDB -ID "5_2" # "Stammbaum Settings-Manager"
        $SelectPersonForm.width = ($LabelWidth+$TextBoxWidth+$HorrAbstand+$LabelLeft+30)

        $ZeilenTop=20
        # Label LNR
        $SelectDBZeileLabel = New-Object System.Windows.Forms.Label
        $SelectDBZeileLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $SelectDBZeileLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $SelectDBZeileLabel.Text=  GetTextFromLanguageDB -ID "5_M_100" #"DB-Zeile" 
        $SelectPersonForm.Controls.Add($SelectDBZeileLabel)

        $SelectDBZeiletextBox = New-Object System.Windows.Forms.TextBox
        $SelectDBZeiletextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $SelectDBZeiletextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $SelectDBZeiletextBox.TabIndex = 0
        $SelectPersonForm.Controls.Add($SelectDBZeiletextBox)
        
        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label LNR
        $SelectPersonLNRLabel = New-Object System.Windows.Forms.Label
        $SelectPersonLNRLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $SelectPersonLNRLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $SelectPersonLNRLabel.Text= GetTextFromLanguageDB -ID "5_M_101" #"LNr"
        $SelectPersonForm.Controls.Add($SelectPersonLNRLabel)

        $SelectPersonLNRtextBox = New-Object System.Windows.Forms.TextBox
        $SelectPersonLNRtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $SelectPersonLNRtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $SelectPersonLNRtextBox.TabIndex = 1
        $SelectPersonForm.Controls.Add($SelectPersonLNRtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Vorname
        $SelectPersonVornameLabel = New-Object System.Windows.Forms.Label
        $SelectPersonVornameLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $SelectPersonVornameLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $SelectPersonVornameLabel.Text=GetTextFromLanguageDB -ID "5_M_102" #"Vorname"
        $SelectPersonForm.Controls.Add($SelectPersonVornameLabel)

        $SelectPersonVornametextBox = New-Object System.Windows.Forms.TextBox
        $SelectPersonVornametextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $SelectPersonVornametextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $SelectPersonVornametextBox.TabIndex = 2
        $SelectPersonForm.Controls.Add($SelectPersonVornametextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Nachname
        $SelectPersonNachnameLabel = New-Object System.Windows.Forms.Label
        $SelectPersonNachnameLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $SelectPersonNachnameLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $SelectPersonNachnameLabel.Text=GetTextFromLanguageDB -ID "5_M_103" #"Nachname"
        $SelectPersonForm.Controls.Add($SelectPersonNachnameLabel)

        $SelectPersonNachnametextBox = New-Object System.Windows.Forms.TextBox
        $SelectPersonNachnametextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $SelectPersonNachnametextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $SelectPersonNachnametextBox.TabIndex = 3
        $SelectPersonForm.Controls.Add($SelectPersonNachnametextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label GebName
        $SelectPersonGebNameLabel = New-Object System.Windows.Forms.Label
        $SelectPersonGebNameLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $SelectPersonGebNameLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $SelectPersonGebNameLabel.Text=GetTextFromLanguageDB -ID "5_M_104" #"Geburts-name"
        $SelectPersonForm.Controls.Add($SelectPersonGebNameLabel)

        $SelectPersonGebNametextBox = New-Object System.Windows.Forms.TextBox
        $SelectPersonGebNametextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $SelectPersonGebNametextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $SelectPersonGebNametextBox.TabIndex = 4
        $SelectPersonForm.Controls.Add($SelectPersonGebNametextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label GebDatum
        $SelectPersonGebDatumLabel = New-Object System.Windows.Forms.Label
        $SelectPersonGebDatumLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $SelectPersonGebDatumLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $SelectPersonGebDatumLabel.Text=GetTextFromLanguageDB -ID "5_M_105" #"Geburts-Datum"
        $SelectPersonForm.Controls.Add($SelectPersonGebDatumLabel)

        $SelectPersonGebDatumtextBox = New-Object System.Windows.Forms.TextBox
        $SelectPersonGebDatumtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $SelectPersonGebDatumtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $SelectPersonGebDatumtextBox.TabIndex = 5
        $SelectPersonForm.Controls.Add($SelectPersonGebDatumtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label SterbeDatum
        $SelectPersonSterbeDatumLabel = New-Object System.Windows.Forms.Label
        $SelectPersonSterbeDatumLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $SelectPersonSterbeDatumLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $SelectPersonSterbeDatumLabel.Text=GetTextFromLanguageDB -ID "5_M_106" #"Sterbe-Datum"
        $SelectPersonForm.Controls.Add($SelectPersonSterbeDatumLabel)

        $SelectPersonSterbeDatumtextBox = New-Object System.Windows.Forms.TextBox
        $SelectPersonSterbeDatumtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $SelectPersonSterbeDatumtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $SelectPersonSterbeDatumtextBox.TabIndex = 6
        $SelectPersonForm.Controls.Add($SelectPersonSterbeDatumtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Bemerkung
        $SelectPersonBemerkungLabel = New-Object System.Windows.Forms.Label
        $SelectPersonBemerkungLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $SelectPersonBemerkungLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $SelectPersonBemerkungLabel.Text=GetTextFromLanguageDB -ID "5_M_107" #"Bemerkung"
        $SelectPersonForm.Controls.Add($SelectPersonBemerkungLabel)

        $SelectPersonBemerkungtextBox = New-Object System.Windows.Forms.TextBox
        $SelectPersonBemerkungtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $SelectPersonBemerkungtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $SelectPersonBemerkungtextBox.TabIndex = 7
        $SelectPersonForm.Controls.Add($SelectPersonBemerkungtextBox)
    
    
        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        $Tab=($SelectPersonBemerkungtextBox.left + $SelectPersonBemerkungtextBox.width-$LabelLeft-(3*$HorrAbstand))/4
        # Button "Erster"                            
        $ErsterButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $ErsterButton.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $ErsterButton.Size = New-Object System.Drawing.Size($Tab,$LabelHeight)
        $ErsterButton.TabIndex = 8
        $ErsterButton.Text = GetTextFromLanguageDB -ID "5_M_108" #"|<-"
        $ErsterButton.Name = "Erster"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $ErsterButton.add_Click($SelectPersonForm_ErsterButton_OnClick)
        $SelectPersonForm.Controls.Add($ErsterButton)

        # Button "Rueck"                            
        $RueckButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $RueckButton.Location = New-Object System.Drawing.Size(($LabelLeft+$HorrAbstand+$Tab),$ZeilenTop)
        $RueckButton.Size = New-Object System.Drawing.Size($Tab,$LabelHeight)
        $RueckButton.TabIndex = 9
        $RueckButton.Text = GetTextFromLanguageDB -ID "5_M_109" #"<-"
        $RueckButton.Name = "Rueck"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $RueckButton.add_Click($SelectPersonForm_RueckButton_OnClick)
        $SelectPersonForm.Controls.Add($RueckButton)

        # Button "Vor"                            
        $VorButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $VorButton.Location = New-Object System.Drawing.Size(($LabelLeft+2*($HorrAbstand+$Tab)),$ZeilenTop)
        $VorButton.Size = New-Object System.Drawing.Size($Tab,$LabelHeight)
        $VorButton.TabIndex = 10
        $VorButton.Text = GetTextFromLanguageDB -ID "5_M_110" #"->"
        $VorButton.Name = "vor"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $VorButton.add_Click($SelectPersonForm_VorButton_OnClick)
        $SelectPersonForm.Controls.Add($VorButton)

        # Button "Erster"                            
        $LetzterButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $LetzterButton.Location = New-Object System.Drawing.Size(($LabelLeft+3*($HorrAbstand+$Tab)),$ZeilenTop)
        $LetzterButton.Size = New-Object System.Drawing.Size($Tab,$LabelHeight)
        $LetzterButton.TabIndex = 11
        $LetzterButton.Text =  GetTextFromLanguageDB -ID "5_M_111" #"->|"
        $LetzterButton.Name = "Letzter"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $LetzterButton.add_Click($SelectPersonForm_LetzterButton_OnClick)
        $SelectPersonForm.Controls.Add($LetzterButton)

    
        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        $OKButtonBreite=($SelectPersonBemerkungtextBox.left + $SelectPersonBemerkungtextBox.width-$LabelLeft - $HorrAbstand)/2
        # Button "OK"                            
        $OKButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $OKButton.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $OKButton.Size = New-Object System.Drawing.Size($OKButtonBreite,$LabelHeight)
        $OKButton.TabIndex = 12
        $OKButton.Text =  GetTextFromLanguageDB -ID "5_M_112" #"OK"
        $OKButton.Name = "OK"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $OKButton.add_Click({$SelectPersonForm.Close()})
        $SelectPersonForm.Controls.Add($OKButton)

        # Button "Abbruch"       
        $Tab=($SelectPersonBemerkungtextBox.left + $SelectPersonBemerkungtextBox.width-$LabelLeft)/2 +($HorrAbstand/2) +$LabelLeft                    
        $CancelButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $CancelButton.Location = New-Object System.Drawing.Size($Tab,$ZeilenTop)
        $CancelButton.Size = New-Object System.Drawing.Size($OKButtonBreite,$LabelHeight)
        $CancelButton.TabIndex = 13
        $CancelButton.Text = GetTextFromLanguageDB -ID "5_M_113" # "Abbrechen"
        $CancelButton.Name = "Abbrechen"
        $CancelButton.DialogResult = "Cancel"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $CancelButton.Add_Click({$SelectPersonLNRtextBox.Text=0;$SelectPersonForm.Close()})
        $SelectPersonForm.Controls.Add($CancelButton)
    
        $SelectPersonForm.height = ($ZeilenTop + $LabelHeight + $ZeilenAbstand + 40)

        $SelectDBZeiletextBox.Text=1
       # $SelectPersonLNRtextBox.Text=$global:PersonenDB.Split("`n")[$SelectDBZeiletextBox.Text].Split("`t")[0]
        SelectPersonFelderFuellen

        $Erfolg =  $SelectPersonForm.ShowDialog()

        $global:AktPersonNr=$SelectPersonLNRtextBox.Text
      
        if ($DebugMode -eq "true") {$text="beende Sub Men� SelectPerson. gefundene Person:" + $global:AktPersonNr;Write-Host $Text}

    }

    ### Sub Menue SelectPerson
    ##############################################################
#endregion Sub Menue SelectPerson

#region Sub Menue PersonenSucheAusBestand

    function GetPersonenTrefferListe {
        ##################################################
        # Version V02
        # vom 16.4.2023
        ##################################################
        
        $globalPersonenDBSplit=$global:PersonenDB.Split("`n")

        for($i=1; $i -lt $globalPersonenDBSplit.count; $i++){

            $PersonenDBSplit=$globalPersonenDBSplit[$i].Split("`t")

            $Treffer="true"
            if ($PersonenSucheAusBestandVornametextBox.text -ne "") {
                if ($PersonenDBSplit[1] -like ("*" + $PersonenSucheAusBestandVornametextBox.text + "*")) {
                    }  else {
                        $Treffer="false"
                }
            }
            if ($PersonenSucheAusBestandNachnametextBox.text -ne "") {
                if ($PersonenDBSplit[2] -like ("*" + $PersonenSucheAusBestandNachnametextBox.text + "*")) {
                    }  else {
                        $Treffer="false"
                }
            }
            if ($PersonenSucheAusBestandGebNametextBox.text -ne "") {
                if ($PersonenDBSplit[3] -like ("*" + $PersonenSucheAusBestandGebNametextBox.text + "*")) {
                    }  else {
                        $Treffer="false"
                }
            }
            if ($PersonenSucheAusBestandSterbeDatumtextBox.text -ne "") {
                if ($PersonenDBSplit[4] -like ("*" + $PersonenSucheAusBestandSterbeDatumtextBox.text + "*")) {
                    }  else {
                        $Treffer="false"
                }
            }
            if ($PersonenSucheAusBestandBemerkungtextBox.text -ne "") {
                if ($PersonenDBSplit[5] -like ("*" + $PersonenSucheAusBestandBemerkungtextBox.text + "*")) {
                    }  else {
                        $Treffer="false"
                }
            }
            if ($PersonenSucheAusBestandZusatzVornamentextBox.text -ne "") {
                if ($PersonenDBSplit[6] -like ("*" + $PersonenSucheAusBestandZusatzVornamentextBox.text + "*")) {
                    }  else {
                        $Treffer="false"
                }
            }
            if ($PersonenSucheAusBestandGeburtsOrttextBox.text -ne "") {
                if ($PersonenDBSplit[7] -like ("*" + $PersonenSucheAusBestandGeburtsOrttextBox.text + "*")) {
                    }  else {
                        $Treffer="false"
                }
            }
            if ($PersonenSucheAusBestandSterbeOrttextBox.text -ne "") {
                if ($PersonenDBSplit[8] -like ("*" + $PersonenSucheAusBestandSterbeOrttextBox.text + "*")) {
                    }  else {
                        $Treffer="false"
                }
            }
            if ($PersonenSucheAusBestandReligiontextBox.text -ne "") {
                if ($PersonenDBSplit[9] -like ("*" + $PersonenSucheAusBestandReligiontextBox.text + "*")) {
                    }  else {
                        $Treffer="false"
                }
            }
            if ($PersonenSucheAusBestandGeschltextBox.text -ne "") {
                if ($PersonenDBSplit[10] -like ("*" + $PersonenSucheAusBestandGeschltextBox.text + "*")) {
                    }  else {
                        $Treffer="false"
                }
            }
            if ($PersonenSucheAusBestandNationalitaettextBox.text -ne "") {
                if ($PersonenDBSplit[11] -like ("*" + $PersonenSucheAusBestandNationalitaettextBox.text + "*")) {
                    }  else {
                        $Treffer="false"
                }
            }


            if ($Treffer -eq "true") {
                if ($TrefferListe -eq "") {
                        $TrefferListe = "Start" + $globalPersonenDBSplit[$i] 
                    } else {
                        $TrefferListe = $TrefferListe + "`n" +  $globalPersonenDBSplit[$i] 
                }
            }
        }

        $TrefferListe="`n" + $TrefferListe
        $PersonenSucheAusBestandSuchErgebnisListbox.Items.Clear()
        $TrefferListeSplit=$TrefferListe.split("`n")
        for($i=1; $i -lt $TrefferListeSplit.count; $i++){
            if ($TrefferListeSplit[$i] -ne "") {
                [void] $PersonenSucheAusBestandSuchErgebnisListbox.Items.Add(($TrefferListeSplit[$i]))
            }
        }
    }

    function PersonenSucheAusBestand {
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################


        if ($DebugMode -eq "true") {Write-Host "starte Sub Men� PersonenSucheAusBestand"}

        #$global:AktPersonNr=1

        $HorrAbstand=5
        $ZeilenAbstand=10

        $LabelWidth=100
        $LabelHeight=20
        $LabelLeft=20
        $TextBoxLeft=$LabelLeft + $LabelWidth + $HorrAbstand
        $TextBoxWidth=200

        $ErgBreite=500
    
        # GUI erzeugen
        $PersonenSucheAusBestandForm = New-Object System.Windows.Forms.Form
        $PersonenSucheAusBestandForm.StartPosition = "CenterScreen"
        $PersonenSucheAusBestandForm.Text =  GetTextFromLanguageDB -ID "5_3" #"Stammbaum PersonenSucheAusBestand"
        $PersonenSucheAusBestandForm.width = ($LabelWidth+$TextBoxWidth+$HorrAbstand+$LabelLeft+30 + $ErgBreite + $HorrAbstand)

        $ZeilenTop=20
        # Label LNR
        $PersonenSucheAusBestandLNRLabel = New-Object System.Windows.Forms.Label
        $PersonenSucheAusBestandLNRLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenSucheAusBestandLNRLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenSucheAusBestandLNRLabel.Text= GetTextFromLanguageDB -ID "5_M_201" #"LNr"
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandLNRLabel)

        $PersonenSucheAusBestandLNRtextBox = New-Object System.Windows.Forms.TextBox
        $PersonenSucheAusBestandLNRtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenSucheAusBestandLNRtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenSucheAusBestandLNRtextBox.ReadOnly = 'true'
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandLNRtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Vorname
        $PersonenSucheAusBestandVornameLabel = New-Object System.Windows.Forms.Label
        $PersonenSucheAusBestandVornameLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenSucheAusBestandVornameLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenSucheAusBestandVornameLabel.Text= GetTextFromLanguageDB -ID "5_M_202" #"Vorname"
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandVornameLabel)

        $PersonenSucheAusBestandVornametextBox = New-Object System.Windows.Forms.TextBox
        $PersonenSucheAusBestandVornametextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenSucheAusBestandVornametextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenSucheAusBestandVornametextBox.Add_TextChanged({GetPersonenTrefferListe})
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandVornametextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Nachname
        $PersonenSucheAusBestandNachnameLabel = New-Object System.Windows.Forms.Label
        $PersonenSucheAusBestandNachnameLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenSucheAusBestandNachnameLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenSucheAusBestandNachnameLabel.Text= GetTextFromLanguageDB -ID "5_M_203" #"Nachname"
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandNachnameLabel)

        $PersonenSucheAusBestandNachnametextBox = New-Object System.Windows.Forms.TextBox
        $PersonenSucheAusBestandNachnametextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenSucheAusBestandNachnametextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenSucheAusBestandNachnametextBox.Add_TextChanged({GetPersonenTrefferListe})
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandNachnametextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label GebName
        $PersonenSucheAusBestandGebNameLabel = New-Object System.Windows.Forms.Label
        $PersonenSucheAusBestandGebNameLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenSucheAusBestandGebNameLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenSucheAusBestandGebNameLabel.Text= GetTextFromLanguageDB -ID "5_M_204" #"Geburts-name"
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandGebNameLabel)

        $PersonenSucheAusBestandGebNametextBox = New-Object System.Windows.Forms.TextBox
        $PersonenSucheAusBestandGebNametextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenSucheAusBestandGebNametextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenSucheAusBestandGebNametextBox.Add_TextChanged({GetPersonenTrefferListe})
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandGebNametextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label GebDatum
        $PersonenSucheAusBestandGebDatumLabel = New-Object System.Windows.Forms.Label
        $PersonenSucheAusBestandGebDatumLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenSucheAusBestandGebDatumLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenSucheAusBestandGebDatumLabel.Text= GetTextFromLanguageDB -ID "5_M_205" #"Geburts-Datum"
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandGebDatumLabel)

        $PersonenSucheAusBestandGebDatumtextBox = New-Object System.Windows.Forms.TextBox
        $PersonenSucheAusBestandGebDatumtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenSucheAusBestandGebDatumtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenSucheAusBestandGebDatumtextBox.Add_TextChanged({GetPersonenTrefferListe})
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandGebDatumtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label SterbeDatum
        $PersonenSucheAusBestandSterbeDatumLabel = New-Object System.Windows.Forms.Label
        $PersonenSucheAusBestandSterbeDatumLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenSucheAusBestandSterbeDatumLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenSucheAusBestandSterbeDatumLabel.Text= GetTextFromLanguageDB -ID "5_M_206" #"Sterbe-Datum"
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandSterbeDatumLabel)

        $PersonenSucheAusBestandSterbeDatumtextBox = New-Object System.Windows.Forms.TextBox
        $PersonenSucheAusBestandSterbeDatumtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenSucheAusBestandSterbeDatumtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenSucheAusBestandSterbeDatumtextBox.Add_TextChanged({GetPersonenTrefferListe})
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandSterbeDatumtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Bemerkung
        $PersonenSucheAusBestandBemerkungLabel = New-Object System.Windows.Forms.Label
        $PersonenSucheAusBestandBemerkungLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenSucheAusBestandBemerkungLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenSucheAusBestandBemerkungLabel.Text= GetTextFromLanguageDB -ID "5_M_207" #"Bemerkung"
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandBemerkungLabel)

        $PersonenSucheAusBestandBemerkungtextBox = New-Object System.Windows.Forms.TextBox
        $PersonenSucheAusBestandBemerkungtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenSucheAusBestandBemerkungtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenSucheAusBestandBemerkungtextBox.Add_TextChanged({GetPersonenTrefferListe})
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandBemerkungtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label ZusatzVornamen
        $PersonenSucheAusBestandZusatzVornamenLabel = New-Object System.Windows.Forms.Label
        $PersonenSucheAusBestandZusatzVornamenLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenSucheAusBestandZusatzVornamenLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenSucheAusBestandZusatzVornamenLabel.Text= GetTextFromLanguageDB -ID "5_M_208" #"Zusatz-Vornamen"
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandZusatzVornamenLabel)

        $PersonenSucheAusBestandZusatzVornamentextBox = New-Object System.Windows.Forms.TextBox
        $PersonenSucheAusBestandZusatzVornamentextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenSucheAusBestandZusatzVornamentextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenSucheAusBestandBemerkungtextBox.Add_TextChanged({GetPersonenTrefferListe})
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandZusatzVornamentextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label GeburtsOrt
        $PersonenSucheAusBestandGeburtsOrtLabel = New-Object System.Windows.Forms.Label
        $PersonenSucheAusBestandGeburtsOrtLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenSucheAusBestandGeburtsOrtLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenSucheAusBestandGeburtsOrtLabel.Text= GetTextFromLanguageDB -ID "5_M_209" #"GeburtsOrt"
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandGeburtsOrtLabel)

        $PersonenSucheAusBestandGeburtsOrttextBox = New-Object System.Windows.Forms.TextBox
        $PersonenSucheAusBestandGeburtsOrttextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenSucheAusBestandGeburtsOrttextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenSucheAusBestandGeburtsOrttextBox.Add_TextChanged({GetPersonenTrefferListe})
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandGeburtsOrttextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label SterbeOrt
        $PersonenSucheAusBestandSterbeOrtLabel = New-Object System.Windows.Forms.Label
        $PersonenSucheAusBestandSterbeOrtLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenSucheAusBestandSterbeOrtLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenSucheAusBestandSterbeOrtLabel.Text= GetTextFromLanguageDB -ID "5_M_210" #"Sterbe-Ort"
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandSterbeOrtLabel)

        $PersonenSucheAusBestandSterbeOrttextBox = New-Object System.Windows.Forms.TextBox
        $PersonenSucheAusBestandSterbeOrttextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenSucheAusBestandSterbeOrttextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenSucheAusBestandSterbeOrttextBox.Add_TextChanged({GetPersonenTrefferListe})
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandSterbeOrttextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Religion
        $PersonenSucheAusBestandReligionLabel = New-Object System.Windows.Forms.Label
        $PersonenSucheAusBestandReligionLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenSucheAusBestandReligionLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenSucheAusBestandReligionLabel.Text=GetTextFromLanguageDB -ID "5_M_211" #"Religion"
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandReligionLabel)

        $PersonenSucheAusBestandReligiontextBox = New-Object System.Windows.Forms.TextBox
        $PersonenSucheAusBestandReligiontextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenSucheAusBestandReligiontextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenSucheAusBestandReligiontextBox.Add_TextChanged({GetPersonenTrefferListe})
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandReligiontextBox)
        
        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Geschlecht
        $PersonenSucheAusBestandGeschlLabel = New-Object System.Windows.Forms.Label
        $PersonenSucheAusBestandGeschlLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenSucheAusBestandGeschlLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenSucheAusBestandGeschlLabel.Text=GetTextFromLanguageDB -ID "5_M_212" #"Geschlecht"
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandGeschlLabel)

        $PersonenSucheAusBestandGeschltextBox = New-Object System.Windows.Forms.TextBox
        $PersonenSucheAusBestandGeschltextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenSucheAusBestandGeschltextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenSucheAusBestandGeschltextBox.Add_TextChanged({GetPersonenTrefferListe})
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandGeschltextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Nationalitaet
        $PersonenSucheAusBestandNationalitaetLabel = New-Object System.Windows.Forms.Label
        $PersonenSucheAusBestandNationalitaetLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenSucheAusBestandNationalitaetLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenSucheAusBestandNationalitaetLabel.Text=GetTextFromLanguageDB -ID "5_M_213" #"Nationalit�t"
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandNationalitaetLabel)

        $PersonenSucheAusBestandNationalitaettextBox = New-Object System.Windows.Forms.TextBox
        $PersonenSucheAusBestandNationalitaettextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenSucheAusBestandNationalitaettextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenSucheAusBestandNationalitaettextBox.Add_TextChanged({GetPersonenTrefferListe})
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandNationalitaettextBox)

    
        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        $Tab=($PersonenSucheAusBestandBemerkungtextBox.left + $PersonenSucheAusBestandBemerkungtextBox.width-$LabelLeft-(3*$HorrAbstand))/4
        $OKButtonBreite=($PersonenSucheAusBestandBemerkungtextBox.left + $PersonenSucheAusBestandBemerkungtextBox.width-$LabelLeft - $HorrAbstand)/2
        # Button "OK"                            
        $PersonenSucheAusBestandOKButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $PersonenSucheAusBestandOKButton.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenSucheAusBestandOKButton.Size = New-Object System.Drawing.Size($OKButtonBreite,$LabelHeight)
        $PersonenSucheAusBestandOKButton.Text = GetTextFromLanguageDB -ID "5_M_214" #"OK"
        $PersonenSucheAusBestandOKButton.Name = "OK"
        $PersonenSucheAusBestandOKButton.DialogResult = "OK"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $PersonenSucheAusBestandOKButton.add_Click({$PersonenSucheAusBestandForm.Close()})
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandOKButton)

        # Button "Abbruch"       
        $Tab=($PersonenSucheAusBestandBemerkungtextBox.left + $PersonenSucheAusBestandBemerkungtextBox.width-$LabelLeft)/2 +($HorrAbstand/2) +$LabelLeft                    
        $PersonenSucheAusBestandCancelButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $PersonenSucheAusBestandCancelButton.Location = New-Object System.Drawing.Size($Tab,$ZeilenTop)
        $PersonenSucheAusBestandCancelButton.Size = New-Object System.Drawing.Size($OKButtonBreite,$LabelHeight)
        $PersonenSucheAusBestandCancelButton.Text =GetTextFromLanguageDB -ID "5_M_215" # "Abbrechen"
        $PersonenSucheAusBestandCancelButton.Name = "Abbrechen"
        $PersonenSucheAusBestandCancelButton.DialogResult = "Cancel"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $PersonenSucheAusBestandCancelButton.Add_Click({$PersonenSucheAusBestandForm.Close()})
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandCancelButton)
    

        $ErgLeft=$PersonenSucheAusBestandGeschltextBox.left + $PersonenSucheAusBestandGeschltextBox.width + $HorrAbstand
        


        # Label PersonenSucheAusBestand SuchErgebnis
        $PersonenSucheAusBestandSuchErgebnisLabel = New-Object System.Windows.Forms.Label
        $PersonenSucheAusBestandSuchErgebnisLabel.Location = New-Object System.Drawing.Size( $ErgLeft,$PersonenSucheAusBestandLNRLabel.top)
        $PersonenSucheAusBestandSuchErgebnisLabel.Size = New-Object System.Drawing.Size($ErgBreite,$LabelHeight)
        $PersonenSucheAusBestandSuchErgebnisLabel.Text =GetTextFromLanguageDB -ID "5_M_216" # "Such-Ergebnis"
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandSuchErgebnisLabel)

        # Liste PersonenSucheAusBestandSuchErgebnis
        $PersonenSucheAusBestandSuchErgebnisListbox = New-Object System.Windows.Forms.Listbox
        $PersonenSucheAusBestandSuchErgebnisListbox.Location = New-Object System.Drawing.Size( $ErgLeft,$PersonenSucheAusBestandVornameLabel.top)
        $PersonenSucheAusBestandSuchErgebnisListbox.Size = New-Object System.Drawing.Size($ErgBreite,($PersonenSucheAusBestandCancelButton.top - $ZeilenAbstand - $PersonenSucheAusBestandVornametextBox.top)) #($ZeilenTop  - $ZeilenAbstand - $PersonenSucheAusBestandVornameLabel.top))
        $PersonenSucheAusBestandSuchErgebnisListbox.Add_DoubleClick({
           # $DebugMode = "true"
            if ($DebugMode -eq "true") { $text="# PersonenSucheAusBestand - Auswahl:`t" + $PersonenSucheAusBestandSuchErgebnisListbox.text.Split("`t")[0]; Write-Host $text}
            #$DebugMode = "false"
            if ($PersonenSucheAusBestandSuchErgebnisListbox.text.Split("`t")[0] -ne "") {
                $PersonenSucheAusBestandLNRtextBox.text=$PersonenSucheAusBestandSuchErgebnisListbox.text.Split("`t")[0];
            }
        })
        $PersonenSucheAusBestandForm.Controls.Add($PersonenSucheAusBestandSuchErgebnisListbox) 


        GetPersonenTrefferListe

        $PersonenSucheAusBestandForm.height = ($ZeilenTop + $LabelHeight + $ZeilenAbstand + 40)

        $PersonenSucheAusBestandLNRtextBox.Text="0"
        #PersonenSucheAusBestandFelderFuellen

        $Erfolg =  $PersonenSucheAusBestandForm.ShowDialog() 
        if ( $Erfolg -eq "Cancel") {
            $PersonenSucheAusBestandLNRtextBox.Text="0"
        }

        return $PersonenSucheAusBestandLNRtextBox.Text

    }
#endregion Sub Menue PersonenSucheAusBestand

#region Sub Menue MainForm

    #region Eltern

    function NeuePeEltern() {
    
        ##################################################
        # Version V02
        # vom 16.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") { $text="# NeuePeEltern - startet"; Write-Host $text}

        [int]$NextPersonNr=FindeLetztePersonLnrInDB
        $NextPersonNr=$NextPersonNr + 1

        # neuen Vater erzeugen
        $NeueVaterDaten="" + $NextPersonNr + "`t`t`t`t`t`t`t`t`t`t`t`t`t"
        # neuen Mutter erzeugen
        $NeueMutterDaten="" + ($NextPersonNr+1) + "`t`t`t`t`t`t`t`t`t`t`t`t`t"
        ReplacePersonenDaten -NeueDaten $NeueVaterDaten
        ReplacePersonenDaten -NeueDaten $NeueMutterDaten
        if ($DebugMode -eq "true") { $text="# NeuePeEltern - Vater und Mutter wurden angelegt. jetzt noch Knoten anpassen"; Write-Host $text}

        $KnotenDBZeilenSplit=$global:KnotenDB.Split("`n")
        $globalKnotenHeaderListeSplit=$global:KnotenHeaderListe.Split("`t")

        # Person-Knoten anpassen...
        # es kann mehrere Verbindungen geben! Alle m�ssen angepasst werden
        # erst mal Liste aller Knoten dieser Person
        $AktPersonKnotenListe=FindeAlleKnotenVonPersonNr($global:AktPersonNr)
        if ($DebugMode -eq "true") { $text="# NeuePeEltern - Alle Knoten der AktPerson " + $global:AktPersonNr + " :`t" + $AktPersonKnotenListe; Write-Host $text}

        # Sicherstellen dass ein Tab im String drin ist
        $AktKnotenListe=$AktPersonKnotenListe + "`t"
        $AktKnotenListeSplit=$AktKnotenListe.Split("`t") 

        # jetzt die Liste aller Knoten dieser Person durchgehen und jeweils die Eltern anpassen
        for($i=0; $i -lt $AktKnotenListeSplit.count-1; $i++){
        #foreach  ( $Akn in $AktKnotenListe) {
            if ($DebugMode -eq "true") { $text="# NeuePeEltern - Element " + $i + ":`t" + $AktKnotenListeSplit[$i]; Write-Host $text}
            $AknKnoten=$KnotenDBZeilenSplit[$AktKnotenListeSplit[$i]]
            if ($DebugMode -eq "true") { $text="# NeuePeEltern - AknKnoten:`t" + $AknKnoten; Write-Host $text}
            $AktKnotenSplit=$AknKnoten.Split("`t")

            $NeuerPeKnoten=""
            for($t=0; $t -lt $AktKnotenSplit.count; $t++){
                $Wert=$AktKnotenSplit[$t]
                if ($t -eq [int]($globalKnotenHeaderListeSplit[2])) {$Wert=$NextPersonNr}
                if ($t -eq [int]($globalKnotenHeaderListeSplit[3])) {$Wert=($NextPersonNr+1)}

                if ($NeuerPeKnoten -eq "") {
                        $NeuerPeKnoten=$NeuerPeKnoten + $Wert
                    } else {
                        $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $Wert
                }
            }

            if ($DebugMode -eq "true") { $text="# NeuePeEltern - Aufruf " + $AktKnotenListeSplit[$i] + " ReplaceKnotenDaten(`t" + $NeuerPeKnoten + ")."; Write-Host $text}
            ReplaceKnotenDaten($NeuerPeKnoten)                
        } 

        # Jetzt noch beiden Eltern einen Knoten bauen mit Person als Kind und gegenseitig als Partner
        # $NextKnotenNr=$global:KnotenDB.count
        $LetzteKnotenNr=FindeLetztenKnotenLnrInDB
        $NextKnotenNr=$LetzteKnotenNr+1

        $KnotenHeaderSpaltenSplit=$KnotenDBZeilenSplit[0].split("`t")

        $NeuerVaKnoten=""
        for($t=0; $t -lt $KnotenHeaderSpaltenSplit.count; $t++){
            $Wert="0"
            if ($t -eq [int]($globalKnotenHeaderListeSplit[0])) {$Wert=$NextKnotenNr}
            if ($t -eq [int]($globalKnotenHeaderListeSplit[1])) {$Wert=$NextPersonNr}
            if ($t -eq [int]($globalKnotenHeaderListeSplit[4])) {$Wert=($NextPersonNr+1)}
            if ($t -eq [int]($globalKnotenHeaderListeSplit[10])) {$Wert=$global:AktPersonNr} # erstes Kind

            if ($NeuerVaKnoten -eq "") {
                    $NeuerVaKnoten=$NeuerVaKnoten + $Wert
                } else {
                    $NeuerVaKnoten=$NeuerVaKnoten + "`t" + $Wert
            }
        }

        #$NeueVaterKnotenDaten= "" + $NextKnotenNr + "`t" + $NextPersonNr + "`t0`t0`t" + ($NextPersonNr+1) + "`t0`t0`t0`t" + $global:AktPersonNr + "`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0"
        #if ($DebugMode -eq "true") { $text="#`t -- `tNeueVaterKnotenDaten: (" + $NeueVaterKnotenDaten + "). `n `t -- `tNeuerVaKnoten     : (" + $NeuerVaKnoten + ")."; Write-Host $text}
        $NeueVaterKnotenDaten=$NeuerVaKnoten
        
        $NeuerMuKnoten=""
        for($t=0; $t -lt $KnotenHeaderSpaltenSplit.count; $t++){
            $Wert="0"
            if ($t -eq [int]($globalKnotenHeaderListeSplit[0])) {$Wert=($NextKnotenNr+1)}
            if ($t -eq [int]($globalKnotenHeaderListeSplit[1])) {$Wert= ($NextPersonNr+1)}
            if ($t -eq [int]($globalKnotenHeaderListeSplit[4])) {$Wert=$NextPersonNr}
            if ($t -eq [int]($globalKnotenHeaderListeSplit[10])) {$Wert=$global:AktPersonNr} # erstes Kind

            if ($NeuerMuKnoten -eq "") {
                    $NeuerMuKnoten=$NeuerMuKnoten + $Wert
                } else {
                    $NeuerMuKnoten=$NeuerMuKnoten + "`t" + $Wert
            }
        }
       # $NeueMutterKnotenDaten="" + ($NextKnotenNr+1) + "`t" + ($NextPersonNr+1) + "`t0`t0`t" + $NextPersonNr + "`t0`t0`t0`t" + $global:AktPersonNr + "`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0"
       # if ($DebugMode -eq "true") { $text="#`t -- `tNeueMutterKnotenDaten: (" + $NeueMutterKnotenDaten + "). `n `t -- `tNeuerMuKnoten       : (" + $NeuerMuKnoten + ")."; Write-Host $text}
        $NeueMutterKnotenDaten=$NeuerMuKnoten
                    
        if ($DebugMode -eq "true") { $text="# NeuePeEltern - Aufruf Vaterdaten: ReplaceKnotenDaten(" + $NeueVaterKnotenDaten + ")."; Write-Host $text}
        ReplaceKnotenDaten($NeueVaterKnotenDaten)
                    
        if ($DebugMode -eq "true") { $text="# NeuePeEltern - Aufruf Mutterdaten: ReplaceKnotenDaten(" + $NeueMutterKnotenDaten + ")."; Write-Host $text}
        ReplaceKnotenDaten($NeueMutterKnotenDaten)

        $global:GuiErstesKindNr=1
        MainFormFelderFuellen
        
        if ($DebugMode -eq "true") { $text="# NeuePeEltern - endet"; Write-Host $text}
    }

    $MainFormE1_OnClick={

        ##################################################
        # Version V01
        # vom 16.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($global:KnotenPersonen[0] -ne 0) {
                if ($DebugMode -eq "true") { $text="# MainFormE1_OnClick - AktPerson wechselt von:`t" + $global:AktPersonNr +" zu " + $global:KnotenPersonen[0]; Write-Host $text}
                $global:AktPersonNr=$global:KnotenPersonen[0]
                if ($DebugMode -eq "true") { $text="# MainFormE1_OnClick - neue AktPerson:`t" + $global:AktPersonNr; Write-Host $text}
                $global:GuiErstesKindNr=0
                MainFormFelderFuellen
            } else {
                if ($DebugMode -eq "true") { $text="# MainFormE1_OnClick - KnotenPersonen[0]:`t" + $global:KnotenPersonen[0]; Write-Host $text}
                if ($DebugMode -eq "true") { $text="# MainFormE1_OnClick - Also werden beide Eltern-Teile jetzt angelegt - leer, ohne Daten ... "; Write-Host $text}
                
                NeuePeEltern
        }
        
    }
   
    $MainFormE2_OnClick={
        if ($global:KnotenPersonen[1] -ne 0) {
                if ($DebugMode -eq "true") { $text="# MainFormE2_OnClick - AktPerson wechselt von:`t" + $global:AktPersonNr +" zu " + $global:KnotenPersonen[1]; Write-Host $text}
                $global:AktPersonNr=$global:KnotenPersonen[1]
                if ($DebugMode -eq "true") { $text="# MainFormE2_OnClick - neue AktPerson:`t" + $global:AktPersonNr; Write-Host $text}
                $global:GuiErstesKindNr=0
                MainFormFelderFuellen
            } else {
                if ($DebugMode -eq "true") { $text="# MainFormE2_OnClick - KnotenPersonen[1]:`t" + $global:KnotenPersonen[1]; Write-Host $text}
                if ($DebugMode -eq "true") { $text="# MainFormE2_OnClick - Also werden beide Eltern-Teile jetzt angelegt - leer, ohne Daten"; Write-Host $text}
                
                NeuePeEltern          
        }
    }
   
    $MainFormE3_OnClick={
        if ($global:KnotenPersonen[2] -ne 0) {
                if ($DebugMode -eq "true") { $text="# MainFormE3_OnClick - AktPerson wechselt von:`t" + $global:AktPersonNr +" zu " + $global:KnotenPersonen[2]; Write-Host $text}
                $global:AktPersonNr=$global:KnotenPersonen[2]
                if ($DebugMode -eq "true") { $text="# MainFormE3_OnClick - neue AktPerson:`t" + $global:AktPersonNr; Write-Host $text}
                $global:GuiErstesKindNr=0
                MainFormFelderFuellen
            } else {
                if ($DebugMode -eq "true") { $text="# MainFormE3_OnClick - KnotenPersonen[2]:`t" + $global:KnotenPersonen[2] + " also passiert gar nix"; Write-Host $text}
        }
    }
   
    $MainFormE4_OnClick={
        if ($global:KnotenPersonen[3] -ne 0) {
            if ($DebugMode -eq "true") { $text="# MainFormE4_OnClick - AktPerson wechselt von:`t" + $global:AktPersonNr +" zu " + $global:KnotenPersonen[3]; Write-Host $text}
            $global:AktPersonNr=$global:KnotenPersonen[3]
            if ($DebugMode -eq "true") { $text="# MainFormE4_OnClick - neue AktPerson:`t" + $global:AktPersonNr; Write-Host $text}
                $global:GuiErstesKindNr=0
            MainFormFelderFuellen
        } else {if ($DebugMode -eq "true") { $text="# MainFormE4_OnClick - KnotenPersonen[3]:`t" + $global:KnotenPersonen[3] + " also passiert gar nix"; Write-Host $text}}
    }

    #endregion Eltern   

    #region Person und Partner
        ##########################
        ### Person
        $MainFormPe_OnClick={
            if ($global:KnotenPersonen[4] -ne 0) {
                if ($DebugMode -eq "true") { $text="# MainFormPe_OnClick - PersonenDaten von AktPerson`t" + $global:AktPersonNr +" �ndern"; Write-Host $text}
                $NeueDaten=PersonenDatenEditor ($global:AktPersonNr)
                if ($NeueDaten -ne "") {
                        ReplacePersonenDaten -NeueDaten $NeueDaten
                        if ($DebugMode -eq "true") { $text="# MainFormPe_OnClick - PersonenDaten von AktPerson`t" + $global:AktPersonNr + " wurden ver�ndert. Mainform neu aufbauen"; Write-Host $text}
                        MainFormFelderFuellen
            
                    } else {
                       if ($DebugMode -eq "true") { $text="# MainFormPe_OnClick - PersonenDaten von AktPerson`t" + $global:AktPersonNr + " wurden nicht ver�ndert."; Write-Host $text}
                }
            } else {if ($DebugMode -eq "true") { $text="# MainFormPe_OnClick - KnotenPersonen[4]:`t" + $global:KnotenPersonen[4] + " FEHLER - das kann es nie passieren an der Stelle!"; Write-Host $text}}

        }
   

        ### Knoten
        $MainFormKn_OnClick={
            if ($DebugMode -eq "true") { $text="# MainFormKn_OnClick - global:KnotenPersonen`t" + $global:KnotenPersonen; Write-Host $text}
            # darf nur laufen wenn Partner existiert
            #$KnotenPersonenSplit=$global:KnotenPersonen.Split("`t")
            $PartnerNr=$global:KnotenPersonen[5]
            if ($PartnerNr -ne 0 -and $PartnerNr -ne "") {
                PartnerSettingsChange
            }
        }
   
        ### Partner
        $MainFormPa_OnClick={

            if ($global:KnotenPersonen[5] -ne 0) {
                    if ($DebugMode -eq "true") { $text="# MainFormPa_OnClick - AktPerson wechselt von:`t" + $global:AktPersonNr +" zu " + $global:KnotenPersonen[5]; Write-Host $text}
                    $global:AktPersonNr=$global:KnotenPersonen[5]
                    if ($DebugMode -eq "true") { $text="# MainFormPa_OnClick - neue AktPerson:`t" + $global:AktPersonNr; Write-Host $text}
                    MainFormFelderFuellen
                } else {
                    if ($DebugMode -eq "true") { $text="# MainFormPa_OnClick - KnotenPersonen[5]:`t" + $global:KnotenPersonen[5] + " also passiert gar nix"; Write-Host $text}
                    # neuer Partner erzeugen
                    NeuerPartner
            }
        
        }
   
    #endregion Person und Partner

    #region KinderOnClick
        ##########################
        ### Kinder
        function MainFormKind_OnClick() {
            Param(
                $KindButtonNr = 0
            )
            ##################################################
            # Version V02
            # vom 28.4.2023
            ##################################################

            $DebugMode = "false"
            if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
           # $DebugMode = "true"
            
            if ($DebugMode -eq "true") { $Text= "MainFormKind_OnClick statet mit Parameter KindButtonNr:" + $KindButtonNr; Write-Host $Text}

            if ($KindButtonNr -gt 0) {
                # Kinder (14x)
                $KindPosInKnotenPersonen=(6+$global:GuiErstesKindNr + $KindButtonNr - 1)
                if ($DebugMode -eq "true") { $Text= "KindPosInKnotenPersonen:" + $KindPosInKnotenPersonen; Write-Host $Text}

                if ($KindPosInKnotenPersonen -gt 19) {$KnotenPersonenPos=$KindPosInKnotenPersonen + 6 } else {$KnotenPersonenPos=$KindPosInKnotenPersonen}
                if ($DebugMode -eq "true") { $Text= "`t-- KnotenPersonenPos:" + $KnotenPersonenPos; Write-Host $Text}
                if ($DebugMode -eq "true") { $Text= "`t-- global:KnotenPersonen[KnotenPersonenPos]=0?:(" + $global:KnotenPersonen[$KnotenPersonenPos] + ")"; Write-Host $Text}
                $KindExistiert=$false
                if ([int]$global:KnotenPersonen[$KnotenPersonenPos] -ne 0) {
                    if ($DebugMode -eq "true") { $Text= "`t-- Ist nicht 0:" ; Write-Host $Text}
                    if ($global:KnotenPersonen[$KnotenPersonenPos] -ne "") {
                        if ($DebugMode -eq "true") { $Text= "`t-- Ist nicht leer" ; Write-Host $Text}
                        $KindExistiert=$true

                        $global:GuiErstesKindNr=0

                        if ($DebugMode -eq "true") { $text="`t-- AktPerson wechselt von:`t" + $global:AktPersonNr +" zu " + $global:KnotenPersonen[6]; Write-Host $text}
                        $global:AktPersonNr=$global:KnotenPersonen[$KnotenPersonenPos]
                        if ($DebugMode -eq "true") { $text="`t-- neue AktPerson:`t" + $global:AktPersonNr; Write-Host $text}
                        MainFormFelderFuellen
                    }
                }
                if ($KindExistiert -eq $false) {

                    # pruefen ob vorheriges Kind existiert
                    $LetzteKindPosInKnotenPersonen=(6+$global:GuiErstesKindNr + $KindButtonNr - 2)
                    if ($LetzteKindPosInKnotenPersonen -gt 19) {$LetzteKnotenPersonenPos=$LetzteKindPosInKnotenPersonen + 6 } else {$LetzteKnotenPersonenPos=$LetzteKindPosInKnotenPersonen}


                    if ([int]$global:KnotenPersonen[$LetzteKnotenPersonenPos] -gt 0) {
                        if ($DebugMode -eq "true") { $text="`t-- KnotenPersonen[LetzteKnotenPersonenPos]:`t" + $global:KnotenPersonen[$LetzteKnotenPersonenPos] + " also wird neues Kind angelegt"; Write-Host $text}
                        NeuesKind
                    }
                }

            }
            if ($DebugMode -eq "true") { $Text= "MainFormKind_OnClick endet"; Write-Host $Text}
 
        }

    #endregion KinderOnClick

    function ErstePerson {
        ##################################################
        # Version V02
        # vom 16.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") { $text="# ErstePerson - startet"; Write-Host $text}
        
        $global:AktPersonNr=1
        $PeNummer=1

        # erst mal eine Person in die DB schreiben - sonst gehen keine Adressen zum eingeben
        $NeuePerson="1`t`t`t`t`t`t`t`t`t`t`t`t`t`t`t" 
        ReplacePersonenDaten -NeueDaten $NeuePerson
        
        $NeueDaten=PersonenDatenEditor($PeNummer)    
        if ($DebugMode -eq "true") { $text="# ErstePerson - Neue Personendaten:" + $NeueDaten; Write-Host $text}

        if ($NeueDaten -ne "") {
            ReplacePersonenDaten -NeueDaten $NeueDaten
            
            $KnotenDBZeilenSplit=$global:KnotenDB.Split("`n")
            $KnotenDBZeilenSplit0Split=$KnotenDBZeilenSplit[0].Split("`t")
            $globalKnotenHeaderListeSplit=$global:KnotenHeaderListe.Split("`t")
            
            if ($DebugMode -eq "true") { $text="# ErstePerson - global:KnotenHeaderListe:" + $global:KnotenHeaderListe; Write-Host $text}

            if ($DebugMode -eq "true") { $text="# ErstePerson - Knoten erzeugen"; Write-Host $text}
            $KnNummer=1

            $NeuerPeKnoten=""
            for($t=0; $t -lt $KnotenDBZeilenSplit0Split.count; $t++){
                $Wert="0"
                if ($t -eq [int]($globalKnotenHeaderListeSplit[0])) {$Wert=$KnNummer}
                if ($t -eq [int]($globalKnotenHeaderListeSplit[1])) {$Wert=$PeNummer}

                if ($NeuerPeKnoten -eq "") {
                        $NeuerPeKnoten=$NeuerPeKnoten + $Wert
                    } else {
                        $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $Wert
                }
            }
       #     $NeuerPeKnoten2=$NeuerPeKnoten


          #  $NeuerPeKnoten="" + $KnNummer + "`t" + $PeNummer  + "`t" + "0" + "`t" + "0" + "`t" + "0"
           ## $NeuerPeKnoten=$NeuerPeKnoten + "`t" + "0" + "`t" + "0" + "`t" + "0" + "`t" + "0" + "`t" + "0"
          #  $NeuerPeKnoten=$NeuerPeKnoten + "`t" + "0" + "`t" + "0" + "`t" + "0" + "`t" + "0" + "`t" + "0"
          #  $NeuerPeKnoten=$NeuerPeKnoten + "`t" + "0" + "`t" + "0" + "`t" + "0" + "`t" + "0" + "`t" + "0"
          #  $NeuerPeKnoten=$NeuerPeKnoten + "`t" + "0" + "`t" + "0" + "`t" + "0" + "`t" + "0" + "`t" + "0"
          #  if ($DebugMode -eq "true") { $text="#`t -- `tNeuerPeKnoten : (" + $NeuerPeKnoten + ") `n `t -- `tNeuerPeKnoten2: (" + $NeuerPeKnoten2 + ")"; Write-Host $text}
                  
                  
                    
            if ($DebugMode -eq "true") { $text="# ErstePerson - Neue Knotendaten:" + $NeuerPeKnoten; Write-Host $text}
            ReplaceKnotenDaten($NeuerPeKnoten)
        }
        if ($DebugMode -eq "true") { $text="# ErstePerson - endet"; Write-Host $text}
    }

    function NeuerPartner {
        ##################################################
        # Version V03
        # vom 22.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") {$Text="## NeuerPartner startet ";Write-Host $text}

        $KnotenDBZeilenSplit=$global:KnotenDB.Split("`n")
        $globalKnotenHeaderListeSplit=$global:KnotenHeaderListe.Split("`t")

            # neuer Partner erzeugen
            $LetztePeNrInDB=FindeLetztePersonLnrInDB
            if ($DebugMode -eq "true") { $text="# NeuerPartner - starte PersonenDatenEditor(" + ($LetztePeNrInDB + 1) + ")"; Write-Host $text}
            $NeueDaten=PersonenDatenEditor($LetztePeNrInDB + 1)
            if ($DebugMode -eq "true") { $text="# NeuerPartner - Ergebnis aus PersonenDatenEditor:" + $NeueDaten; Write-Host $text}

       #     if ($NeueDaten -ne "") {
                    [int]$PartnerNr=[int]$NeueDaten.split("`t")[0]
                    if ($DebugMode -eq "true") { $text="# NeuerPartner - Lnr des gefundenen Partners:" + $PartnerNr; Write-Host $text}

                    if ($PartnerNr -eq ($LetztePeNrInDB + 1)) {

                        # Partner besteht noch nicht
                        if ($DebugMode -eq "true") { $text="# NeuerPartner - Partner existiert noch nicht - wird mit Lnr:" + $PartnerNr + "angelegt"; Write-Host $text}
                        
                        ReplacePersonenDaten -NeueDaten $NeueDaten
                        if ($DebugMode -eq "true") { $text="# NeuerPartner - PersonenDaten von Partner`t" + $PartnerNr + " wurden angelegt. jetzt noch Knoten anpassen"; Write-Host $text}


                        # beide Knoten anpassen...
                        # Da hier auf leeren Partner geklickt wurde, existiert nur der aktive Knoten. bei zus�tzlichen Verbindungen mu� der passende gesuchtwerden
                        # $AktPersonKnotenListe=FindeAlleKnotenVonPersonNr($global:AktPersonNr)
                        # if ($DebugMode -eq "true") { $text="# MainFormPa_OnClick - Alle Knoten der AktPerson " + $global:AktPersonNr + " :`t" + $AktPersonKnotenListe; Write-Host $text}

                        if ($DebugMode -eq "true") { $text="# NeuerPartner - global:KnotenPersonen.count:`t" + $global:KnotenPersonen.count; Write-Host $text}
                        if ($DebugMode -eq "true") { $text="# NeuerPartner - global:Knotendb.count:`t" + $KnotenDBZeilenSplit.count; Write-Host $text}
                        if ($DebugMode -eq "true") { $text="# NeuerPartner - global:KnotenPersonen:`t" + $global:KnotenPersonen; Write-Host $text}
                        $PeKnotenNr=$global:KnotenPersonen[24]
                        if ($DebugMode -eq "true") { $text="# NeuerPartner - PeKnotenNr:`t" + $PeKnotenNr; Write-Host $text}
##########################################################

                       # $KnotenDBZeilenNr=GetKnotenDBZeileMitKnotenLNr -KnotenLnr $PeKnotenNr
                       # $PeKnoten=$KnotenDBZeilenSplit[$KnotenDBZeilenNr]
                        
                        $PeKnoten=$KnotenDBZeilenSplit[$PeKnotenNr]

                        if ($DebugMode -eq "true") { $text="# NeuerPartner - PeKnoten:`t" + $PeKnoten; Write-Host $text}

                        $PeKnotenSpaltenSplit=$PeKnoten.Split("`t")


                        $NeuerPeKnoten=""
                        for($t=0; $t -lt $PeKnotenSpaltenSplit.count; $t++){
                            $Wert=$PeKnotenSpaltenSplit[$t]
                            if ($t -eq [int]($globalKnotenHeaderListeSplit[4])) {$Wert=$PartnerNr}
                            #if ($t -eq [int]($globalKnotenHeaderListeSplit[3])) {$Wert=($NextPersonNr+1)}

                            if ($NeuerPeKnoten -eq "") {
                                    $NeuerPeKnoten=$NeuerPeKnoten + $Wert
                                } else {
                                    $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $Wert
                            }
                        }
                     #   $NeuerPeKnoten2= $NeuerPeKnoten


                      #  $NeuerPeKnoten=$PeKnotenSpaltenSplit[0] + "`t" + $PeKnotenSpaltenSplit[1] + "`t" + $PeKnotenSpaltenSplit[2] + "`t" + $PeKnotenSpaltenSplit[3]
                      ##  $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $PartnerNr + "`t" + $PeKnotenSpaltenSplit[5] + "`t" + $PeKnotenSpaltenSplit[6]
                      #  $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $PeKnotenSpaltenSplit[7] + "`t" + $PeKnotenSpaltenSplit[8] + "`t" + $PeKnotenSpaltenSplit[9]
                      #  $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $PeKnotenSpaltenSplit[10] + "`t" + $PeKnotenSpaltenSplit[11] + "`t" + $PeKnotenSpaltenSplit[12]
                      #  $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $PeKnotenSpaltenSplit[13] + "`t" + $PeKnotenSpaltenSplit[14] + "`t" + $PeKnotenSpaltenSplit[15]
                      #  $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $PeKnotenSpaltenSplit[16] + "`t" + $PeKnotenSpaltenSplit[17] + "`t" + $PeKnotenSpaltenSplit[18]
                      #  $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $PeKnotenSpaltenSplit[19] + "`t" + $PeKnotenSpaltenSplit[20] + "`t" + $PeKnotenSpaltenSplit[21]
                      #  $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $PeKnotenSpaltenSplit[22] + "`t" + $PeKnotenSpaltenSplit[23] + "`t" + $PeKnotenSpaltenSplit[24]

                     #   if ($DebugMode -eq "true") { $text="#`t -- `tNeuerPeKnoten: (" + $NeuerPeKnoten + "). `n `t -- `tNeuerPeKnoten2: (" + $NeuerPeKnoten2 + ")."; Write-Host $text}

                    
                        if ($DebugMode -eq "true") { $text="# NeuerPartner - Aufruf ReplaceKnotenDaten(`t" + $NeuerPeKnoten + ")."; Write-Host $text}
                        ReplaceKnotenDaten($NeuerPeKnoten)

                        if ($DebugMode -eq "true") {read-host �Press ENTER to continue...�}

                        #Knoten: LNr,PersonLNr,VaterLNr,MutterLNr,PartnerLNr,Knoten2LNr,Knoten3LNr,Knoten4LNr,Kind1LNr,Kind2LNr,Kind3LNr,Kind4LNr,Kind5LNr,Kind6LNr,Kind7LNr,Kind8LNr,Kind9LNr,Kind10LNr,Kind11LNr,Kind12LNr,Kind13LNr,Kind14LNr,StartDatum,EndDatum,Trau-Ort
                        #LeerKnoten: LNr,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
                        $LetztenKnotenLnrInDB=FindeLetztenKnotenLnrInDB

                        $NeuerPaKnotenLnr=($LetztenKnotenLnrInDB + 1)
                        $NeuerPaKnotenPe=$PartnerNr

                        if (($LetztePeNrInDB+1) -eq $PartnerNr) {
                                # Partner ist neue Person
                                if ($DebugMode -eq "true") { $text="## NeuerPartner`t-- Partner ist neue Person - keine Eltern-Daten."; Write-Host $text}
                                $NeuerPaKnotenVa="0"
                                $NeuerPaKnotenMu="0"
                            } else {
                                # Partner ist bestehende Person hat also eventuell schon eltern
                                if ($DebugMode -eq "true") { $text="## NeuerPartner `t-- Partner ist bestehende Person - eventuell Eltern-Daten vorhanden."; Write-Host $text}
                                $PartnerKnotenListe=FindeAlleKnotenVonPersonNr($PartnerNr)
                                $PartnerKnotenListe=$PartnerKnotenListe + "`t"
                                $PartnerKnoten=$PartnerKnotenListe.Split("`t")[0]

                                $NeuerPaKnotenVa=$KnotenDBZeilenSplit[2]
                                $NeuerPaKnotenMu=$KnotenDBZeilenSplit[3]
                        }

                        $NeuerPaKnoten=""
                        for($t=0; $t -lt $PeKnotenSpaltenSplit.count; $t++){
                            $Wert="0"
                            if ($t -eq [int]($globalKnotenHeaderListeSplit[0])) {$Wert=$NeuerPaKnotenLnr}
                            if ($t -eq [int]($globalKnotenHeaderListeSplit[1])) {$Wert=$NeuerPaKnotenPe}
                            if ($t -eq [int]($globalKnotenHeaderListeSplit[2])) {$Wert=$NeuerPaKnotenVa}
                            if ($t -eq [int]($globalKnotenHeaderListeSplit[3])) {$Wert=$NeuerPaKnotenMu}
                            if ($t -eq [int]($globalKnotenHeaderListeSplit[4])) {$Wert=$global:AktPersonNr}

                            if ($NeuerPaKnoten -eq "") {
                                    $NeuerPaKnoten=$NeuerPaKnoten + $Wert
                                } else {
                                    $NeuerPaKnoten=$NeuerPaKnoten + "`t" + $Wert
                            }
                        }
                     #    $NeuerPeKnoten2= $NeuerPeKnoten


                      #  $NeuerPaKnoten="" + ($LetztenKnotenLnrInDB + 1) + "`t" + $PartnerNr 
                      #  if ($DebugMode -eq "true") { $text="## `t-- NeuerPaKnoten:" + $NeuerPaKnoten; Write-Host $text}

                      #  if (($LetztePeNrInDB+1) -eq $PartnerNr) {
                      #          # Partner ist neue Person
                      #          if ($DebugMode -eq "true") { $text="## NeuerPartner`t-- Partner ist neue Person - keine Eltern-Daten."; Write-Host $text}
                      #          $NeuerPaKnoten=$NeuerPaKnoten  + "`t" + "0" + "`t" + "0"
                      #      } else {
                      #          # Partner ist bestehende Person hat also eventuell schon eltern
                      #          if ($DebugMode -eq "true") { $text="## NeuerPartner `t-- Partner ist bestehende Person - eventuell Eltern-Daten vorhanden."; Write-Host $text}
                      #          $PartnerKnotenListe=FindeAlleKnotenVonPersonNr($PartnerNr)
                      #          $PartnerKnotenListe=$PartnerKnotenListe + "`t"
                      #          $PartnerKnoten=$PartnerKnotenListe.Split("`t")[0]


                      #          $NeuerPaKnoten=$NeuerPaKnoten  + "`t" + $KnotenDBZeilenSplit[2] + "`t" + $KnotenDBZeilenSplit[3]
                       # }
                      #  $NeuerPaKnoten=$NeuerPaKnoten + "`t" + $global:AktPersonNr + "`t" + "0" + "`t" + "0" + "`t" + "0"
                      #  $NeuerPaKnoten=$NeuerPaKnoten + "`t" + "0" + "`t" + "0" + "`t" + "0" + "`t" + "0" + "`t" + "0"
                     # #  $NeuerPaKnoten=$NeuerPaKnoten + "`t" + "0" + "`t" + "0" + "`t" + "0" + "`t" + "0" + "`t" + "0"
                      #  $NeuerPaKnoten=$NeuerPaKnoten + "`t" + "0" + "`t" + "0" + "`t" + "0" + "`t" + "0" + "`t" + "0"
                     #   $NeuerPaKnoten=$NeuerPaKnoten + "`t" + "0" + "`t" + "0"
                    
                      #  if ($DebugMode -eq "true") { $text="#`t -- `tNeuerPeKnoten: (" + $NeuerPeKnoten + "). `n `t -- `tNeuerPeKnoten2: (" + $NeuerPeKnoten2 + ")."; Write-Host $text}

                        if ($DebugMode -eq "true") { $text="# NeuerPartner - Aufruf ReplaceKnotenDaten(`t" + $NeuerPaKnoten + ")."; Write-Host $text}
                        ReplaceKnotenDaten($NeuerPaKnoten)
                        
                        if ($DebugMode -eq "true") {read-host �Press ENTER to continue...�}

                        MainFormFelderFuellen
                    } else {
                        # Partner besteht schon
                        if ($DebugMode -eq "true") { $text="# NeuerPartner - Partner existiert schon mit Lnr:" + $PartnerNr ; Write-Host $text}

                        # beide Knoten anpassen...
                        # Da hier auf leeren Partner geklickt wurde, existiert nur der aktive Knoten. bei zus�tzlichen Verbindungen mu� der passende gesuchtwerden
                        # $AktPersonKnotenListe=FindeAlleKnotenVonPersonNr($global:AktPersonNr)
                        # if ($DebugMode -eq "true") { $text="# MainFormPa_OnClick - Alle Knoten der AktPerson " + $global:AktPersonNr + " :`t" + $AktPersonKnotenListe; Write-Host $text}

                        if ($DebugMode -eq "true") { $text="# NeuerPartner - global:KnotenPersonen.count:`t" + $global:KnotenPersonen.count; Write-Host $text}
                        if ($DebugMode -eq "true") { $text="# NeuerPartner - global:Knotendb.count:`t" + $KnotenDBZeilenSplit.count; Write-Host $text}
                        if ($DebugMode -eq "true") { $text="# NeuerPartner - global:KnotenPersonen:`t" + $global:KnotenPersonen; Write-Host $text}
                        $PeKnotenNr=$global:KnotenPersonen[24]
                        if ($DebugMode -eq "true") { $text="# NeuerPartner - PeKnotenNr:`t" + $PeKnotenNr; Write-Host $text}

                        $PeKnoten=$KnotenDBZeilenSplit[$PeKnotenNr]
                        if ($DebugMode -eq "true") { $text="# NeuerPartner - PeKnoten:`t" + $PeKnoten; Write-Host $text}

                        $PeKnotenSpaltenSplit=$PeKnoten.Split("`t")

                        $NeuerPeKnoten=""
                        for($t=0; $t -lt $PeKnotenSpaltenSplit.count; $t++){
                            $Wert=$PeKnotenSpaltenSplit[$t]
                            if ($t -eq [int]($globalKnotenHeaderListeSplit[4])) {$Wert=$PartnerNr}
                            #if ($t -eq [int]($globalKnotenHeaderListeSplit[3])) {$Wert=($NextPersonNr+1)}

                            if ($NeuerPeKnoten -eq "") {
                                    $NeuerPeKnoten=$NeuerPeKnoten + $Wert
                                } else {
                                    $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $Wert
                            }
                        }
                     #   $NeuerPeKnoten2= $NeuerPeKnoten

                     #   $NeuerPeKnoten=$PeKnotenSpaltenSplit[0] + "`t" + $PeKnotenSpaltenSplit[1] + "`t" + $PeKnotenSpaltenSplit[2] + "`t" + $PeKnotenSpaltenSplit[3]
                     #   $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $PartnerNr + "`t" + $PeKnotenSpaltenSplit[5] + "`t" + $PeKnotenSpaltenSplit[6]
                     #   $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $PeKnotenSpaltenSplit[7] + "`t" + $PeKnotenSpaltenSplit[8] + "`t" + $PeKnotenSpaltenSplit[9]
                     #   $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $PeKnotenSpaltenSplit[10] + "`t" + $PeKnotenSpaltenSplit[11] + "`t" + $PeKnotenSpaltenSplit[12]
                     #   $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $PeKnotenSpaltenSplit[13] + "`t" + $PeKnotenSpaltenSplit[14] + "`t" + $PeKnotenSpaltenSplit[15]
                     #   $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $PeKnotenSpaltenSplit[16] + "`t" + $PeKnotenSpaltenSplit[17] + "`t" + $PeKnotenSpaltenSplit[18]
                     #   $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $PeKnotenSpaltenSplit[19] + "`t" + $PeKnotenSpaltenSplit[20] + "`t" + $PeKnotenSpaltenSplit[21]
                    #    $NeuerPeKnoten=$NeuerPeKnoten + "`t" + $PeKnotenSpaltenSplit[22] + "`t" + $PeKnotenSpaltenSplit[23] + "`t" + $PeKnotenSpaltenSplit[24]
                    
                     #   if ($DebugMode -eq "true") { $text="#`t -- `tNeuerPeKnoten: (" + $NeuerPeKnoten + "). `n `t -- `tNeuerPeKnoten2: (" + $NeuerPeKnoten2 + ")."; Write-Host $text}


                        if ($DebugMode -eq "true") { $text="# NeuerPartner - Aufruf ReplaceKnotenDaten(`t" + $NeuerPeKnoten + ")."; Write-Host $text}
                        ReplaceKnotenDaten($NeuerPeKnoten)
                        
                      #  if ($DebugMode -eq "true") {read-host �Person ist ge�ndert...weiter?�}

                        #Knoten: LNr,PersonLNr,VaterLNr,MutterLNr,PartnerLNr,Knoten2LNr,Knoten3LNr,Knoten4LNr,Kind1LNr,Kind2LNr,Kind3LNr,Kind4LNr,Kind5LNr,Kind6LNr,Kind7LNr,Kind8LNr,Kind9LNr,Kind10LNr,Kind11LNr,Kind12LNr,Kind13LNr,Kind14LNr,StartDatum,EndDatum,Trau-Ort
                        #LeerKnoten: LNr,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0

                        #####################################
                        # Partner ist bestehende Person
                        # ==> passenden Partner-Knoten finden!
                        $PartnerKnotenListe=FindeAlleKnotenVonPersonNr($PartnerNr)
                        $PartnerKnotenListe=$PartnerKnotenListe + "`t"
                        $PartnerKnotenSplit=$PartnerKnotenListe.Split("`t")
                        $TrefferKnoten=0
                        
                        if ($DebugMode -eq "true") { $text="# NeuerPartner -PartnerKnotenSplit.count:" + $PartnerKnotenSplit.count ; Write-Host $text}
                        if ($PartnerKnotenSplit.count -eq 1) {
                                if ($DebugMode -eq "true") { $text="# `t -- Partner hat noch keinen Knoten => nix mehr frei => mu� neuer erst-Knoten gebaut werden"; Write-Host $text}

                                $NeuerPaKnotenLNR=([int]$KnotenDBZeilenSplit[$KnotenDBZeilenSplit.count-1].Split("`t")[$globalKnotenHeaderListeSplit[0]] + 1)
                                $NeuerPaKnotenPe=$PartnerNr 

                                $AlterPartnerKnoten=$KnotenDBZeilenSplit[$PartnerKnotenSplit[$globalKnotenHeaderListeSplit[0]]]
                                if ($DebugMode -eq "true") { $text="# NeuerPartner - erster alter Knoten: " + $AlterPartnerKnoten; Write-Host $text}
                                $AlterPartnerKnotenSplit=$AlterPartnerKnoten.Split("`t")

                                $NeuerPaKnotenVa=$AlterPartnerKnotenSplit[$globalKnotenHeaderListeSplit[2]]
                                $NeuerPaKnotenMu=$AlterPartnerKnotenSplit[$globalKnotenHeaderListeSplit[3]]

                            } elseif ($PartnerKnotenSplit.count -eq 2) {
                                if ($DebugMode -eq "true") { $text="# `t -- Partner hat einen Knoten => pr�fen ob Partner vom Partner noch 0 ist - dann nutzen - sonst neuer Knoten n�tig"; Write-Host $text}

                                $TrefferKnoten=$KnotenDBZeilenSplit[$PartnerKnotenSplit[$globalKnotenHeaderListeSplit[0]]]
                                if ([int]$TrefferKnoten.split("`t")[$globalKnotenHeaderListeSplit[4]] -eq 0) {
                                        if ($DebugMode -eq "true") { $text="# `t -- Partner vom Partner ist noch 0 ==> diesen Knoten nutzen" ; Write-Host $text}


                                        $NeuerPaKnotenLNR=$TrefferKnoten.Split("`t")[$globalKnotenHeaderListeSplit[0]]
                                        $NeuerPaKnotenPe=$PartnerNr 
                                
                                        $NeuerPaKnotenVa=$TrefferKnoten.Split("`t")[$globalKnotenHeaderListeSplit[2]]
                                        $NeuerPaKnotenMu=$TrefferKnoten.Split("`t")[$globalKnotenHeaderListeSplit[3]]

                                                                    
                                    } else {
                                        if ($DebugMode -eq "true") { $text="# `t -- Partner vom Partner ist schon besetzt ==> neuen Knoten bauen" ; Write-Host $text}

                                        $NeuerPaKnotenLNR=([int]$KnotenDBZeilenSplit[$KnotenDBZeilenSplit.count-1].Split("`t")[$globalKnotenHeaderListeSplit[0]] + 1)
                                        $NeuerPaKnotenPe=$PartnerNr 

                                        $AlterPartnerKnoten=$KnotenDBZeilenSplit[$PartnerKnotenSplit[$globalKnotenHeaderListeSplit[0]]]
                                        if ($DebugMode -eq "true") { $text="# NeuerPartner - erster alter Knoten: " + $AlterPartnerKnoten; Write-Host $text}
                                        $AlterPartnerKnotenSplit=$AlterPartnerKnoten.Split("`t")

                                        $NeuerPaKnotenVa=$AlterPartnerKnotenSplit[$globalKnotenHeaderListeSplit[2]]
                                        $NeuerPaKnotenMu=$AlterPartnerKnotenSplit[$globalKnotenHeaderListeSplit[3]]

                                }
                            } else {
                                if ($DebugMode -eq "true") { $text="# `t -- Partner hat mehrere Knoten => nix mehr frei => mu� neuer Knoten gebaut werden"; Write-Host $text}

                                $NeuerPaKnotenLNR=([int]$KnotenDBZeilenSplit[$KnotenDBZeilenSplit.count-1].Split("`t")[$globalKnotenHeaderListeSplit[0]] + 1)
                                $NeuerPaKnotenPe=$PartnerNr 

                                $AlterPartnerKnoten=$KnotenDBZeilenSplit[$PartnerKnotenSplit[$globalKnotenHeaderListeSplit[0]]]
                                if ($DebugMode -eq "true") { $text="# NeuerPartner - erster alter Knoten: " + $AlterPartnerKnoten; Write-Host $text}
                                $AlterPartnerKnotenSplit=$AlterPartnerKnoten.Split("`t")

                                $NeuerPaKnotenVa=$AlterPartnerKnotenSplit[$globalKnotenHeaderListeSplit[2]]
                                $NeuerPaKnotenMu=$AlterPartnerKnotenSplit[$globalKnotenHeaderListeSplit[3]]

                        }

                        
                        $NeuerPaKnoten=""
                        for($t=0; $t -lt $PeKnotenSpaltenSplit.count; $t++){
                            $Wert="0"
                            if ($t -eq [int]($globalKnotenHeaderListeSplit[0])) {$Wert=$NeuerPaKnotenLnr}
                            if ($t -eq [int]($globalKnotenHeaderListeSplit[1])) {$Wert=$NeuerPaKnotenPe}
                            if ($t -eq [int]($globalKnotenHeaderListeSplit[2])) {$Wert=$NeuerPaKnotenVa}
                            if ($t -eq [int]($globalKnotenHeaderListeSplit[3])) {$Wert=$NeuerPaKnotenMu}
                            if ($t -eq [int]($globalKnotenHeaderListeSplit[4])) {$Wert=$global:AktPersonNr}

                            if ($NeuerPaKnoten -eq "") {
                                    $NeuerPaKnoten=$NeuerPaKnoten + $Wert
                                } else {
                                    $NeuerPaKnoten=$NeuerPaKnoten + "`t" + $Wert
                            }
                        }
                        
                        if ($DebugMode -eq "true") { $text="# NeuerPartner - Aufruf ReplaceKnotenDaten(`t" + $NeuerPaKnoten + ")."; Write-Host $text}
                        ReplaceKnotenDaten($NeuerPaKnoten)

                        
                      #  if ($DebugMode -eq "true") {read-host �Partner ist ge�ndert...�}

                        MainFormFelderFuellen



                    }
         #       } else {
         #          if ($DebugMode -eq "true") { $text="# NeuerPartner - PersonenDaten von AktPerson`t" + $global:AktPersonNr + " wurden nicht ver�ndert."; Write-Host $text}
         #   }

    }
    
    #region Neuer 2t-Partner
        $MainFormNewKn1_OnClick={
            ##################################################
            # Version V02
            # vom 22.4.2023
            ##################################################

            $DebugMode = "false"
            if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
         #   $DebugMode = "true"

            if ($DebugMode -eq "true") { $text="# MainFormNewKn1_OnClick - startet"; Write-Host $text}

            
            $globalKnotenHeaderListeSplit=$global:KnotenHeaderListe.Split("`t")

            $globalKnotenDBSplit = $global:KnotenDB.Split("`n")
           # $FreieKnotenNr=$globalKnotenDBSplit.count

            $LetztenKnotenLnrInDB=FindeLetztenKnotenLnrInDB
            $FreieKnotenNr=($LetztenKnotenLnrInDB + 1)

            $PersonKnotenNr=$global:KnotenPersonen[24]

            #$KnotenDBZeilenSplit=$globalKnotenDBSplit.Split("`n")
            $PersonKnoten=$globalKnotenDBSplit[$PersonKnotenNr]
        
            $PersonKnotenSplit=$PersonKnoten.Split("`t")

            # aktuellen Knoten kopieren als neuen 

         #   $NeuePersonKnotenDaten=""
         #   for($i=0; $i -lt 4; $i++){
         #       if ($NeuePersonKnotenDaten -eq "") {
         #               $NeuePersonKnotenDaten="" + $FreieKnotenNr
         #           } else {
         #               $NeuePersonKnotenDaten=$NeuePersonKnotenDaten + "`t" + $PersonKnotenSplit[$i]
         #       }
         #   }
            #LNR
            $NeuePersonKnotenDaten="" + $FreieKnotenNr
            #Pe
            $NeuePersonKnotenDaten=$NeuePersonKnotenDaten + "`t" + $PersonKnotenSplit[$globalKnotenHeaderListeSplit[1]]
            #Va
            $NeuePersonKnotenDaten=$NeuePersonKnotenDaten + "`t" + $PersonKnotenSplit[$globalKnotenHeaderListeSplit[2]]
            #Mu
            $NeuePersonKnotenDaten=$NeuePersonKnotenDaten + "`t" + $PersonKnotenSplit[$globalKnotenHeaderListeSplit[3]]
            #Pa
            $NeuePersonKnotenDaten=$NeuePersonKnotenDaten + "`t" + $PersonKnotenSplit[$globalKnotenHeaderListeSplit[4]]

            $NeuePersonKnotenDaten=$NeuePersonKnotenDaten + "`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0"
            
            
            if ($DebugMode -eq "true") { $text="# `t-- speichere zusammengebautern neuen PE-Knoten:" + $NeuePersonKnotenDaten; Write-Host $text}
            ReplaceKnotenDaten($NeuePersonKnotenDaten)
        
            $NeueKnotenPersonen=($global:KnotenPersonen[0],$global:KnotenPersonen[1],0,0,$global:KnotenPersonen[4],0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,$globalKnotenDBSplit.count,0)
            if ($DebugMode -eq "true") { $text="# `t-- speichere global:KnotenPersonen:" + $global:KnotenPersonen; Write-Host $text}
            $global:KnotenPersonen=$NeueKnotenPersonen

            if ($DebugMode -eq "true") { $text="# `t-- Starte NeuerPartner"; Write-Host $text}
            NeuerPartner

            if ($DebugMode -eq "true") { $text="# MainFormNewKn1_OnClick - endet"; Write-Host $text}

        }

        function SubMenuePartnerWahl {
            param (
                $PartnerListe="" # enthaelt alle Daten schon fertig - muss nur noch dargestellt werden
            )
            ##################################################
            # Version V01
            # vom 7.4.2023
            ##################################################


            $RandLinks=20
            $RandOben=20
            $RandRechts=30
            $RandUnten=30


            $FormBreite=750
            $FormHoehe=500

            $LabelHoehe=20
            $ZeilenAbstand=5

            $ListBoxBreite=$FormBreite-$RandLinks-$RandRechts
            $ListboxHoehe=100

            # GUI erzeugen
            $PartnerWahlForm = New-Object System.Windows.Forms.Form
            $PartnerWahlForm.StartPosition = "CenterScreen"
            $PartnerWahlForm.Text =GetTextFromLanguageDB -ID "5_4" # "Stammbaum PartnerWahl"
            $PartnerWahlForm.Size = New-Object System.Drawing.Size($FormBreite,$FormHoehe)

            #$FormMinBreite=2*$TabellenLeft + 4*$SpaltenAbstand + $Spaltenbreite1 + $Spaltenbreite2 + $Spaltenbreite3 + $Spaltenbreite4 + $Spaltenbreite5 + $RechterFormRand
            #if ($objForm.width -lt $FormMinBreite) {$objForm.width = $FormMinBreite}

            ### LNR ###
            $Zeile1=$RandOben

            # Label Settings-Werte LNR
            $PartnerWahlLabel = New-Object System.Windows.Forms.Label
            $PartnerWahlLabel.Location = New-Object System.Drawing.Size($RandLinks,$Zeile1)
            $PartnerWahlLabel.Size = New-Object System.Drawing.Size($ListBoxBreite,$LabelHoehe)
            $PartnerWahlForm.Controls.Add($PartnerWahlLabel)

            
            $Zeile2=$Zeile1 + $LabelHoehe+$ZeilenAbstand
            # Liste Settings-Werte LNR
            $PartnerWahlListbox = New-Object System.Windows.Forms.Listbox
            $PartnerWahlListbox.Location = New-Object System.Drawing.Size($RandLinks,$Zeile2)
            $PartnerWahlListbox.Size = New-Object System.Drawing.Size($ListBoxBreite,$ListboxHoehe)
            $PartnerWahlListbox.Add_DoubleClick($LNR_OnDblClick)
            $PartnerWahlListbox.Add_Click($LNR_OnClick)
            $PartnerWahlForm.Controls.Add($PartnerWahlListbox)

            
            $PartnerWahlListbox.Items.Clear()
            $PartnerListeSplit=$PartnerListe.split("`n")
            for($i=0; $i -lt $PartnerListeSplit.count; $i++){
                [void] $PartnerWahlListbox.Items.Add(($PartnerListeSplit[$i]))
            }

            
            $Zeile3=$Zeile2 + $ListboxHoehe+$ZeilenAbstand
            # Button "Speichern"                            
            $PartnerWahlSaveButton = New-Object System.Windows.Forms.Button
            # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
            $PartnerWahlSaveButton.Location = New-Object System.Drawing.Size(100,$Zeile3)
            $PartnerWahlSaveButton.Size = New-Object System.Drawing.Size(100,23)
            $PartnerWahlSaveButton.Text = GetTextFromLanguageDB -ID "5_M_301" #"OK"
            $PartnerWahlSaveButton.Name = "Speichern"
            #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
            $PartnerWahlSaveButton.add_Click({$AuswahlNr=$PartnerWahlListbox.SelectedIndex;$PartnerWahlForm.Close()})
            $PartnerWahlForm.Controls.Add($PartnerWahlSaveButton)

            # Button "Abbruch"                            
            $PartnerWahlCancelButton = New-Object System.Windows.Forms.Button
            # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
            $PartnerWahlCancelButton.Location = New-Object System.Drawing.Size(300,$Zeile3)
            $PartnerWahlCancelButton.Size = New-Object System.Drawing.Size(100,23)
            $PartnerWahlCancelButton.Text = GetTextFromLanguageDB -ID "5_M_302" #"Abbrechen"
            $PartnerWahlCancelButton.Name = "Abbrechen"
            $PartnerWahlCancelButton.DialogResult = "Cancel"
            #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
            $PartnerWahlCancelButton.Add_Click({$AuswahlNr=0;$PartnerWahlForm.Close()})
            $PartnerWahlForm.Controls.Add($PartnerWahlCancelButton)

            
            [void] $PartnerWahlForm.ShowDialog()


            $AuswahlNr=$PartnerWahlListbox.SelectedIndex
            return $AuswahlNr 
        }


        function KnotenSelect {
            ##################################################
            # Version V02
            # vom 16.4.2023
            ##################################################

            $DebugMode = "false"
            if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
           # $DebugMode = "true"

            if ($DebugMode -eq "true") { $text="# KnotenSelect - startet"; Write-Host $text}

            if ($DebugMode -eq "true") { $text="# KnotenSelect - erzeuge Liste aller Knoten"; Write-Host $text}
            $KnotenListe=FindeAlleKnotenVonPersonNr($global:AktPersonNr)
            $KnotenListeSplit=$KnotenListe.Split("`t")
            if ($KnotenListeSplit.count -gt 1) {
            
                if ($DebugMode -eq "true") { $text="# KnotenSelect - erzeuge PartnerListe"; Write-Host $text}
                
                $PartnerListe=""

                for($i=0; $i -lt $KnotenListeSplit.count; $i++){


                    if ($DebugMode -eq "true") { $text="# KnotenSelect - Partner " + $i; Write-Host $text}

                    # hole knotendaten aus knotenDB
                    $DuTKnoten=$global:KnotenDB[$KnotenListeSplit[$i]]
                    if ($DebugMode -eq "true") { $text="# KnotenSelect - Person-Knoten " + $DuTKnoten; Write-Host $text}

                    $DuTKnotenSplit=$DuTKnoten.split("`t")

                    # hole Partner aus Knoten
                    $PartnerNr=$DuTKnotenSplit[4]
                    if ($DebugMode -eq "true") { $text="# KnotenSelect - PartnerNr aus Knoten " + $PartnerNr; Write-Host $text}
                    # hole PersonDaten von Partner
                    if ($PartnerListe -eq "") {
                            $PartnerListe="" + (GetPersonMitNr -PersonLnr $PartnerNr) #$global:PersonenDB[$PartnerNr]
                        } else {
                            $PartnerListe=$PartnerListe + "`n" + (GetPersonMitNr -PersonLnr $PartnerNr) #$global:PersonenDB[$PartnerNr]
                    }
                }

                

                if ($DebugMode -eq "true") { $text="# KnotenSelect - fertige PartnerListe: "; Write-Host $text;Write-Host $PartnerListe}
                $Auswahl=SubMenuePartnerWahl($PartnerListe) # Index der $PartnerListe

                if ($DebugMode -eq "true") { $text="# KnotenSelect - ausgew�hltes Element Nr: " + $Auswahl; Write-Host $text}


                $PersonKnotenAuswahlNr=$global:KnotenDB[$KnotenListeSplit[$Auswahl]].split("`t")[0]
                #$PersonKnotenAuswahlNr=$KnotenListeSplit[$Auswahl]
                if ($DebugMode -eq "true") { $text="# KnotenSelect - ausgew�hlter Knoten Nr: " + $PersonKnotenAuswahlNr; Write-Host $text}
                
                # Finde AuswahlKnotenLnr in Knoten DB
                $NeuerAktKnoten=0
                $globalKnotenDBsplit=$global:KnotenDB.split("`n")
                for($i=1; $i -lt $globalKnotenDBsplit.count; $i++){
                    
                    if ($DebugMode -eq "true") { $text="# `t-- Vergleiche PersonKnotenAuswahlNr:" + $PersonKnotenAuswahlNr + " mit DB-Zeile " + $i + "[0]:" + [int]$globalKnotenDBsplit[$i].split("`t")[0]; Write-Host $text} 
                    if ([int]$globalKnotenDBsplit[$i].split("`t")[0] -eq [int]$PersonKnotenAuswahlNr) {
                        $NeuerAktKnoten=$i
                        $i = $globalKnotenDBsplit.count
                    }
                }

                if ($DebugMode -eq "true") { $text="# KnotenSelect - NeuerAktKnoten gefunden:" + $NeuerAktKnoten; Write-Host $text} 

                $global:AktKnoten=$NeuerAktKnoten      
                if ($DebugMode -eq "true") { $text="# KnotenSelect - setze global:AktKnoten auf " + $global:AktKnoten; Write-Host $text}          

            } else {
                if ($DebugMode -eq "true") { $text="# KnotenSelect - nur 1 Knoten => nix zu tun"; Write-Host $text}
            }
            
            if ($DebugMode -eq "true") { $text="# KnotenSelect - endet"; Write-Host $text}
        }


        $MainFormChKn1_OnClick={
            MainFormFelderFuellen
        }
    
    #endregion Neuer 2t-Partner

    function FindKindAnz() {
        param (
            $PeKnotenLnr="" # ZeilenNr in Global:KnotenDB - nicht LNR
        )

        ##################################################
        # Version V01
        # vom 23.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"

        if ($DebugMode -eq "true") {$Text="## FindKindAnz startet ";Write-Host $text}


        $KnotenDBZeilenSplit=$global:KnotenDB.Split("`n")
        $globalKnotenHeaderListeSplit=$global:KnotenHeaderListe.Split("`t")
        
        $AktKnotenDaten=$KnotenDBZeilenSplit[$PeKnotenLnr]
        if ($DebugMode -eq "true") { $text="## FindKindAnz`t-- global:KnotenHeaderListe:`t" + $global:KnotenHeaderListe + "`n        `t-- KnotenDBZeilenSplit(0):`t" + $KnotenDBZeilenSplit[0] + "`n            `t-- AktKnotenDaten:`t" + $AktKnotenDaten; Write-Host $text}
        $AktKnotenDatenSplit=$AktKnotenDaten.Split("`t") 


        # finde letztes Kind
        $KinderAnz=0
        for($i=$global:KindStartNr; $i -lt $globalKnotenHeaderListeSplit.count; $i++){
            if ($DebugMode -eq "true") {$Text="## `t-- i:" + $i + ", Kind:" + $AktKnotenDatenSplit[$globalKnotenHeaderListeSplit[$i]];Write-Host $text}
            if ([int]($AktKnotenDatenSplit[$globalKnotenHeaderListeSplit[$i]]) -ne 0) {
                    $KinderAnz=$KinderAnz+1
                } else {
                    #$i = $globalKnotenHeaderListeSplit.count
            }
            if ($DebugMode -eq "true") {$Text="KinderAnz" + $KinderAnz;Write-Host $text}
        }

        if ($DebugMode -eq "true") {$Text="## FindKindAnz endet mit �bergabeParameter KinderAnz:" + $KinderAnz;Write-Host $text}
        return $KinderAnz
    }

    function MehrKinderZuKnoten() {
        ##################################################
        # Version V01
        # vom 26.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$Text="## MehrKinderZuKnoten startet ";Write-Host $text}

        $KnotenDBZeilenSplit=$global:KnotenDB.Split("`n")

        # �berschriften erweitern
        $Header=$KnotenDBZeilenSplit[0]
        $HeaderSplit=$Header.split("`t")
        $LetzteSpaltenName=$HeaderSplit[($HeaderSplit.count - 1)]
        
        if ($DebugMode -eq "true") {$Text="## MehrKinderZuKnoten `t-- letzteSpaltenName:`t" + $LetzteSpaltenName;Write-Host $text}
        [int]$StartNr=0
        if ($LetzteSpaltenName.ToUpper() -eq "Trau-Ort".ToUpper()){
                $StartNr=15 
            } else {
                $StartNr=([int]($LetzteSpaltenName.substring(4,($LetzteSpaltenName.length-7)))+1)
        }
        if ($DebugMode -eq "true") {$Text="## MehrKinderZuKnoten `t-- StartNr:`t" + $StartNr;Write-Host $text}
        # �berschrift Erweiterung zusammenbauen
        for($i=($StartNr); $i -lt ($StartNr+7); $i++){
            $MehrHeader=$MehrHeader + "`tKind" + ($i) + "Lnr"
        }

        $NeuerHeader=$Header + $MehrHeader
        if ($DebugMode -eq "true") {$Text="## MehrKinderZuKnoten `t-- NeuerHeader:`t" + $NeuerHeader;Write-Host $text}

        $NeueDB="" + $NeuerHeader
        for($i=1; $i -lt $KnotenDBZeilenSplit.count; $i++){
            $Zeile=$KnotenDBZeilenSplit[$i]
            $NeueDB=$NeueDB + "`n" + $Zeile + "`t0`t0`t0`t0`t0`t0`t0"
        }
        if ($DebugMode -eq "true") {$Text="## MehrKinderZuKnoten `t-- NeueDB:`t" + $NeueDB;Write-Host $text}

        # Knoten DB speichern
        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {$Text= "DBOrdner:`t" +  $DBOrdner;  Write-Host $Text}
        if ( $DBOrdner[1] -ne ":") { $DBOrdner=$global:BasisPfad + "\" + $DBOrdner}
        if ($DebugMode -eq "true") {$Text= "DBOrdner:`t" +  $DBOrdner;  Write-Host $Text}

        $KnotenDBDateiName=GetParameterFromSettings ("KnotenDatei")
        if ($DebugMode -eq "true") {Write-Host "KnotenDateiName:`t";  Write-Host  $KnotenDBDateiName}
        $KnotenDBDatei=$DBOrdner + "\" + $KnotenDBDateiName

        $NeueDB| Out-File -FilePath $KnotenDBDatei
        if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde gespeichert"}
        

        # alles wieder frisch einlesen
        $Frisch=GetKnotenData
        $global:KnotenDB=$frisch
        if ($DebugMode -eq "true") {$Text="neue Knoten-DB-Datei:" + $global:KnotenDB;Write-Host $text}
        $Frisch2=GetKnotenHeaderListe
        $global:KnotenHeaderListe=$Frisch2
        if ($DebugMode -eq "true") {$Text="neue KnotenHeaderListei:" + $global:KnotenHeaderListe;Write-Host $text}
        if ($DebugMode -eq "true") {$Text="## MehrKinderZuKnoten endet ";Write-Host $text}
    }

    function NeuesKind {
        ##################################################
        # Version V04
        # vom 26.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"

        if ($DebugMode -eq "true") {$Text="## NeuesKind startet ";Write-Host $text}

        
        $KnotenDBZeilenSplit=$global:KnotenDB.Split("`n")
        $globalKnotenHeaderListeSplit=$global:KnotenHeaderListe.Split("`t")


        # Kind geht nur mit Partner!
        if ($global:KnotenPersonen[5] -gt 0) {

            if ($DebugMode -eq "true") { $text="# NeuesKind - leer, ohne Daten"; Write-Host $text}
                
            [int]$NextPersonNr=FindeLetztePersonLnrInDB
            $NextPersonNr=$NextPersonNr + 1
            if ($DebugMode -eq "true") { $text="## NeuesKind `t-- NextPersonNr:" + $NextPersonNr; Write-Host $text}
            # neues Kind erzeugen
            $NeueKindDaten="" + $NextPersonNr + "`t`t`t`t`t`t`t`t`t`t`t`t`t"
            ReplacePersonenDaten -NeueDaten $NeueKindDaten
            if ($DebugMode -eq "true") { $text="# NeuesKind - Kind wurden angelegt. jetzt noch Knoten anpassen"; Write-Host $text}



            # Person-Knoten anpassen...
            # nur der aktive Knoten muss angepasst werden!

            $KnotenNr=$global:KnotenPersonen[24]
            if ($DebugMode -eq "true") { $text="# NeuesKind - KnotenNr:`t" + $KnotenNr; Write-Host $text}

            
            $AktKnotenDaten=$KnotenDBZeilenSplit[$KnotenNr]
            if ($DebugMode -eq "true") { $text="# NeuesKind - AktKnotenDaten:`t" + $AktKnotenDaten; Write-Host $text}
            $AktKnotenDatenSplit=$AktKnotenDaten.Split("`t") 

            $KinderAnz=FindKindAnz -PeKnotenLnr $KnotenNr
            if ($DebugMode -eq "true") { $text="# `t-- FindKindAnz findet " + $KinderAnz + " Kinder bei Knoten " + $KnotenNr; Write-Host $text}


            $NeuerPeKnoten=""+$AktKnotenDatenSplit[0]
            if ($DebugMode -eq "true") { $text="# `t-- global:KindStartNr " + $global:KindStartNr + ", KinderAnz: " + $KinderAnz+ ", globalKnotenHeaderListeSplit.count: " + $globalKnotenHeaderListeSplit.count; Write-Host $text}
            if (($global:KindStartNr + $KinderAnz) -lt $globalKnotenHeaderListeSplit.count) {
                    for($i=1; $i -lt $AktKnotenDatenSplit.count; $i++){
                        $Wert=$AktKnotenDatenSplit[$i]
                        if ($i -eq [int]($globalKnotenHeaderListeSplit[($global:KindStartNr + $KinderAnz)])) {$Wert=$NextPersonNr}

                        $NeuerPeKnoten=$NeuerPeKnoten  + "`t" + $Wert

                    }
                } else {
                    # globalKnotenHeaderListe und alle Knoten m�ssen um 1 Kind erweitert werden
                    MehrKinderZuKnoten

                    # Quell-Daten aktualisieren
                    $KnotenDBZeilenSplit=$global:KnotenDB.Split("`n")
                    $globalKnotenHeaderListeSplit=$global:KnotenHeaderListe.Split("`t")

                    $AktKnotenDaten=$KnotenDBZeilenSplit[$KnotenNr]
                    if ($DebugMode -eq "true") { $text="# NeuesKind - AktKnotenDaten  erneut eingelesen:`t" + $AktKnotenDaten; Write-Host $text}
                    $AktKnotenDatenSplit=$AktKnotenDaten.Split("`t") 


                    for($i=1; $i -lt $AktKnotenDatenSplit.count; $i++){
                        $Wert=$AktKnotenDatenSplit[$i]
                        if ($i -eq [int]($globalKnotenHeaderListeSplit[($global:KindStartNr + $KinderAnz)])) {$Wert=$NextPersonNr}

                        $NeuerPeKnoten=$NeuerPeKnoten  + "`t" + $Wert

                    }

            }

            ReplaceKnotenDaten($NeuerPeKnoten) 
            if ($DebugMode -eq "true") { $text="# NeuesKind - Kind bei Person eingetragen:`t" + $NeuerPeKnoten; Write-Host $text}


            # jetzt noch beim Partner
            # $global:KnotenPersonen:	E1	E2	E3	E4	Pe	Pa	K1	k2	...	k14	Hochzeit	HochzeitsOrt	Trennung	PEKnotenNr	PaKnotenNr
            if ($DebugMode -eq "true") { $text="# NeuesKind - global:KnotenPersonen:`t" + $global:KnotenPersonen; Write-Host $text}
            $PartnerKnoten=$global:KnotenPersonen[25]
            if ($DebugMode -eq "true") { $text="# NeuesKind - PartnerKnoten:`t" + $PartnerKnoten; Write-Host $text}
    
            $AktKnotenDaten=$KnotenDBZeilenSplit[$PartnerKnoten]
            $AktKnotenDatenSplit=$AktKnotenDaten.Split("`t") 


            $PaKinderAnz=FindKindAnz -PeKnotenLnr $PartnerKnoten
            if ($DebugMode -eq "true") { $text="# `t-- FindKindAnz findet " + $PaKinderAnz + " Partner-Kinder bei Knoten " + $PartnerKnoten; Write-Host $text}


            $NeuerPaKnoten=""+$AktKnotenDatenSplit[0]
            if (($global:KindStartNr + $PaKinderAnz) -lt $globalKnotenHeaderListeSplit.count) {
                    for($i=1; $i -lt $AktKnotenDatenSplit.count; $i++){
                        $Wert=$AktKnotenDatenSplit[$i]
                        if ($i -eq [int]($globalKnotenHeaderListeSplit[($global:KindStartNr + $PaKinderAnz)])) {$Wert=$NextPersonNr}

                        $NeuerPaKnoten=$NeuerPaKnoten  + "`t" + $Wert

                    }
                } else {
                    # globalKnotenHeaderListe und alle Knoten m�ssen um 1 Kind erweitert werden
            }

       #     $NeuerPaKnoten2=$NeuerPaKnoten


            # finde letztes Kind
        #    $LetztesKind=7
        #    for($i=8; $i -lt $AktKnotenDatenSplit.count-3; $i++){
        #        if ($AktKnotenDatenSplit[$i] -ne 0) {
        #            $LetztesKind=$i
        #        }
        #    }

         #   $NeuerPaKnoten=""
         #   if ($LetztesKind -lt $AktKnotenDatenSplit.count-2) {
         #       for($i=0; $i -lt $LetztesKind+1; $i++){
                    
         #           if ($DebugMode -eq "true") { $text="# NeuesKind - Daten vor Kind:`t" + $i; Write-Host $text}
         #           if ($i -eq 0) {
         #                   $NeuerPaKnoten=$NeuerPaKnoten + $AktKnotenDatenSplit[$i]
         #               } else {
         #                   $NeuerPaKnoten=$NeuerPaKnoten  + "`t" + $AktKnotenDatenSplit[$i]
         #           }
         #       }
         #       if ($DebugMode -eq "true") { $text="# NeuesKind - Kind" ; Write-Host $text}
         #       $NeuerPaKnoten=$NeuerPaKnoten  + "`t" + $NextPersonNr
         #       for($i=$LetztesKind+2; $i -lt $AktKnotenDatenSplit.count; $i++){
         #           if ($DebugMode -eq "true") { $text="# NeuesKind - Daten nach Kind:`t" + $i; Write-Host $text}
         #           $NeuerPaKnoten=$NeuerPaKnoten  + "`t" + $AktKnotenDatenSplit[$i]
         #       }   
         #   }

          
           # if ($DebugMode -eq "true") { $text="## NeuesKind `t-- NeuerPaKnoten:`t" + $NeuerPaKnoten + "`n             `t-- NeuerPaKnoten2:`t" + $NeuerPaKnoten2; Write-Host $text}


            ReplaceKnotenDaten($NeuerPaKnoten) 
            if ($DebugMode -eq "true") { $text="# NeuesKind - Kind bei Patner eingetragen:`t" + $NeuerPaKnoten; Write-Host $text}


            # KindKnoten
            $LetztenKnotenLnrInDB=FindeLetztenKnotenLnrInDB
            $NextKnotenNr=($LetztenKnotenLnrInDB + 1)

            $NeueKindKnotenDaten="" + $NextKnotenNr
            for($i=1; $i -lt $AktKnotenDatenSplit.count; $i++){
                $Wert="0"
                if ($i -eq [int]($globalKnotenHeaderListeSplit[1])) {$Wert=$NextPersonNr}
                if ($i -eq [int]($globalKnotenHeaderListeSplit[2])) {$Wert=$global:KnotenPersonen[4]}
                if ($i -eq [int]($globalKnotenHeaderListeSplit[3])) {$Wert=$global:KnotenPersonen[5]}
                if ($i -eq [int]($globalKnotenHeaderListeSplit[5])) {$Wert=""}
                if ($i -eq [int]($globalKnotenHeaderListeSplit[6])) {$Wert=""}
                if ($i -eq [int]($globalKnotenHeaderListeSplit[7])) {$Wert=""}

                $NeueKindKnotenDaten=$NeueKindKnotenDaten  + "`t" + $Wert
            }
                
         #   $NeueKindKnotenDaten2=$NeueKindKnotenDaten


          #  $NextKnotenNr=($LetztenKnotenLnrInDB + 1)
          #  $NeueKindKnotenDaten="" + $NextKnotenNr + "`t" + $NextPersonNr + "`t" + $global:KnotenPersonen[4] + "`t"  + $global:KnotenPersonen[5] + "`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0`t0"
        
          #  if ($DebugMode -eq "true") { $text="## NeuesKind `t-- NeueKindKnotenDaten: `t" + $NeueKindKnotenDaten + "`n             `t-- NeueKindKnotenDaten2:`t" + $NeueKindKnotenDaten2; Write-Host $text}

            if ($DebugMode -eq "true") { $text="## `t-- Neuer Kind Knoten:" + $NeueKindKnotenDaten; Write-Host $text}
            ReplaceKnotenDaten($NeueKindKnotenDaten) 
            if ($DebugMode -eq "true") { $text="# NeuesKind - KindKnoten eingetragen"; Write-Host $text}

            MainFormFelderFuellen
        }

      #  $DebugMode=$OldDebugMode    
    }

    #region PartnerschaftsSettings

        $PartnerschaftsOKButton_OnClick={
            ##################################################
            # Version V02
            # vom 23.4.2023
            ##################################################
        
            $DebugMode = "false"
            if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
           # $DebugMode = "true"

            if ($DebugMode -eq "true") {$Text="## PartnerschaftsOKButton_OnClick startet ";Write-Host $text}


            $PersonKnotenNr=$global:KnotenPersonen[24]
            $PartnerKnotenNr=$global:KnotenPersonen[25]

            
            $globalKnotenHeaderListeSplit=$global:KnotenHeaderListe.Split("`t")

            
            $KnotenDBZeilenSplit=$global:KnotenDB.Split("`n")

            $PersonKnoten=$KnotenDBZeilenSplit[$PersonKnotenNr]
            $PersonKnotenSplit=$PersonKnoten.Split("`t")
            $PersonKnotenAnz=$PersonKnotenSplit.count


            $NeuePersonKnotenDaten="" + $PersonKnotenSplit[0]
            for($i=1; $i -lt $PersonKnotenSplit.count; $i++){

                    $wert=$PersonKnotenSplit[$i]

                    if ($globalKnotenHeaderListeSplit[5] -eq $i) {$wert=$PartnerschaftsHochzeitsDatumtextBox.Text} # $PersonKnotenSplit[$PersonKnotenSplit[5]]}
                    if ($globalKnotenHeaderListeSplit[6] -eq $i) {$wert=$PartnerschaftsTrennungsDatumtextBox.Text} # $PersonKnotenSplit[$PersonKnotenSplit[6]]}
                    if ($globalKnotenHeaderListeSplit[7] -eq $i) {$wert=$PartnerschaftsHochzeitsOrttextBox.Name} # $PersonKnotenSplit[$PersonKnotenSplit[7]]}

                    $NeuePersonKnotenDaten=$NeuePersonKnotenDaten + "`t" + $Wert
            }

            
       #     $NeuePersonKnotenDaten2=$NeuePersonKnotenDaten


          #  $NeuePersonKnotenDaten=""
         #   for($i=0; $i -lt 22; $i++){
          #      if ($NeuePersonKnotenDaten -eq "") {
          #              $NeuePersonKnotenDaten=$PersonKnotenSplit[$i]
          #          } else {
          #              $NeuePersonKnotenDaten=$NeuePersonKnotenDaten + "`t" + $PersonKnotenSplit[$i]
         #       }
         #   }
          #  $NeuePersonKnotenDaten=$NeuePersonKnotenDaten + "`t" + $PartnerschaftsHochzeitsDatumtextBox.Text + "`t" + $PartnerschaftsTrennungsDatumtextBox.Text + "`t" + $PartnerschaftsHochzeitsOrttextBox.Text
            

          #  if ($DebugMode -eq "true") { $text="# `t-- NeuePersonKnotenDaten(" + $NeuePersonKnotenDaten + ")`n`t - NeuePersonKnotenDaten2(" + $NeuePersonKnotenDaten2 + ")"; Write-Host $text}
          #  if ($DebugMode -eq "true") {$text="Notbremse"; read-host $Text}

            if ($DebugMode -eq "true") { $text="# PartnerschaftsOKButton_OnClick - Aufruf PersonKnotenDaten: ReplaceKnotenDaten(" + $NeuePersonKnotenDaten + ")."; Write-Host $text}
            ReplaceKnotenDaten($NeuePersonKnotenDaten)

            $PartnerKnoten=$KnotenDBZeilenSplit[$PartnerKnotenNr]
            $PartnerKnotenSplit=$PartnerKnoten.Split("`t")
            $PartnerKnotenAnz=$PartnerKnotenSplit.count

            $NeuePartnerKnotenDaten="" + $PartnerKnotenSplit[0]
            for($i=1; $i -lt $PartnerKnotenSplit.count; $i++){

                    $wert=$PartnerKnotenSplit[$i]

                    if ($globalKnotenHeaderListeSplit[5] -eq $i) {$wert=$PartnerschaftsHochzeitsDatumtextBox.Text} # $PersonKnotenSplit[$PersonKnotenSplit[5]]}
                    if ($globalKnotenHeaderListeSplit[6] -eq $i) {$wert=$PartnerschaftsTrennungsDatumtextBox.Text} # $PersonKnotenSplit[$PersonKnotenSplit[6]]}
                    if ($globalKnotenHeaderListeSplit[7] -eq $i) {$wert=$PartnerschaftsHochzeitsOrttextBox.Name} # $PersonKnotenSplit[$PersonKnotenSplit[7]]}

                    $NeuePartnerKnotenDaten=$NeuePartnerKnotenDaten + "`t" + $Wert
            }
         #    $NeuePersonKnotenDaten2=$NeuePersonKnotenDaten

         #   $NeuePartnerKnotenDaten=""
          #  for($i=0; $i -lt 22; $i++){
          #      if ($NeuePartnerKnotenDaten -eq "") {
          #              $NeuePartnerKnotenDaten=$PartnerKnotenSplit[$i]
          #          } else {
          #              $NeuePartnerKnotenDaten=$NeuePartnerKnotenDaten + "`t" + $PartnerKnotenSplit[$i]
          #      }
          #  }
          #  $NeuePartnerKnotenDaten=$NeuePartnerKnotenDaten + "`t" + $PartnerschaftsHochzeitsDatumtextBox.Text + "`t" + $PartnerschaftsTrennungsDatumtextBox.Text + "`t" + $PartnerschaftsHochzeitsOrttextBox.Text
            
         #   if ($DebugMode -eq "true") { $text="# `t-- NeuePersonKnotenDaten(" + $NeuePersonKnotenDaten + ")`n`t - NeuePersonKnotenDaten2(" + $NeuePersonKnotenDaten2 + ")"; Write-Host $text}
         #   if ($DebugMode -eq "true") {$text="Notbremse"; read-host $Text}


            if ($DebugMode -eq "true") { $text="# PartnerschaftsOKButton_OnClick - Aufruf PartnerKnotenDaten: ReplaceKnotenDaten(" + $NeuePartnerKnotenDaten + ")."; Write-Host $text}
            ReplaceKnotenDaten($NeuePartnerKnotenDaten)

            
            if ($DebugMode -eq "true") {$Text="## PartnerschaftsOKButton_OnClick endet  ";Write-Host $text}

            $PartnerschaftsForm.Close()
        }

        function PartnerschaftsFelderFuellen {
            ##################################################
            # Version V02
            # vom 16.4.2023
            ##################################################
        
            $DebugMode = "false"
            if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
           # $DebugMode = "true"

            if ($DebugMode -eq "true") {$Text="## PartnerschaftsFelderFuellen startet ";Write-Host $text}
    
            #$KnotenLnr = $PartnerschaftsLNRtextBox.Text

    
            if ($DebugMode -eq "true") {$Text="## global:KnotenPersonen:" + $global:KnotenPersonen;Write-Host $text}
            #if ($DebugMode -eq "true") {$Text="hole Daten von Knoten Nr:" +  $KnotenLnr;Write-Host $Text}
                
                $KnotenDBZeilenSplit=$global:KnotenDB.Split("`n")
                $PartnerschaftsLNRtextBox.Text=$KnotenDBZeilenSplit[$global:KnotenPersonen[24]].Split("`t")[0]
                if ($global:KnotenPersonen[20] -ne 0) {
                    $PartnerschaftsHochzeitsDatumtextBox.Text    = $global:KnotenPersonen[20]
                }

                $Wert=$global:KnotenPersonen[22].Trim()
                if ($DebugMode -eq "true") {$Text="## HochzeitsOrt-Wert:" + $Wert;Write-Host $text}
                if ($Wert -ne "") {
                    if ((IstZahl -DuTZahl $Wert) -eq $true) {
                            if ($DebugMode -eq "true") {$Text="## HochzeitsOrt-Wert als Zahl erkannt";Write-Host $text}
                            $PartnerschaftsHochzeitsOrttextBox.Text=GetAdressGUISummary -WohnOrtNr $Wert
                            $PartnerschaftsHochzeitsOrttextBox.Name=$Wert
                        } else {
                            if ($DebugMode -eq "true") {$Text="## HochzeitsOrt-Wert ist keine Zahl";Write-Host $text}
                            $PartnerschaftsHochzeitsOrttextBox.Text=$Wert
                            $PartnerschaftsHochzeitsOrttextBox.Name=""
                    }
                }

                if ($global:KnotenPersonen[21] -ne 0) {
                    $PartnerschaftsTrennungsDatumtextBox.Text    = $global:KnotenPersonen[21]
                }
            if ($DebugMode -eq "true") {$Text="## PartnerschaftsFelderFuellen endet ";Write-Host $text}

        }

        $PartnerschaftsHochzeitsOrttextBox_onClick={
            ##################################################
            # Version V02
            # vom 23.4.2023
            ##################################################
        
            $DebugMode = "false"
            if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
           # $DebugMode = "true"

            if ($DebugMode -eq "true") {$Text="## PartnerschaftsHochzeitsOrttextBox_onClick startet ";Write-Host $text}

            #AdressDatenEditor -DuTAdressNr $PersonenDatenEditorSterbeOrttextBox.Text
            if ($PartnerschaftsHochzeitsOrttextBox.Name -eq "") {$Wert=$PartnerschaftsHochzeitsOrttextBox.Text} else {$Wert=$PartnerschaftsHochzeitsOrttextBox.Name}
            $ErgWert=AdressDatenEditor -DuTAdressNr  $Wert
            if ($DebugMode -eq "true") {$Text="## ErgWert: " + $ErgWert;Write-Host $text}
            # bei Hochzeitsort fehlt ein Tab f�r Spalte 2
            
            
            $ErgWertSplit=$ErgWert.Split("`t")
            #$NeuerErgWert="" + $ErgWertSplit[0] + "`t" + $ErgWertSplit[1]
            #$NeuerErgWert=$NeuerErgWert + "`t" + $ErgWertSplit[1]
            #$NeuerErgWert=$NeuerErgWert + "`t" + $ErgWertSplit[2]
            #$NeuerErgWert=$NeuerErgWert + "`t" + $ErgWertSplit[3]
            #$NeuerErgWert=$NeuerErgWert + "`t" + $ErgWertSplit[4]
            #$NeuerErgWert=$NeuerErgWert + "`t" + $ErgWertSplit[5]
            #$NeuerErgWert=$NeuerErgWert + "`t" + $ErgWertSplit[6]
            #$NeuerErgWert=$NeuerErgWert + "`t" + $ErgWertSplit[7]
            #$NeuerErgWert=$NeuerErgWert + "`t" + $ErgWertSplit[8]
            #$NeuerErgWert=$NeuerErgWert + "`t" + $ErgWertSplit[9]
            #$NeuerErgWert=$NeuerErgWert + "`t" + $ErgWertSplit[10]
            #$NeuerErgWert=$NeuerErgWert + "`t" + $ErgWertSplit[11]
            #$NeuerErgWert=$NeuerErgWert + "`t" + $ErgWertSplit[12]

            #ReplaceAdressDaten -NeueDaten $NeuerErgWert
            
            ReplaceAdressDaten -NeueDaten $ErgWert
            $PartnerschaftsHochzeitsOrttextBox.Name=$ErgWertSplit[0]
            #PersonenDatenSpeichern
            # $global:KnotenPersonen anpassen ([22])
            #PartnerschaftsFelderFuellen

            if ($DebugMode -eq "true") {$Text="## PartnerschaftsHochzeitsOrttextBox_onClick endet  ";Write-Host $text}
        }


        function PartnerSettingsChange {
            ##################################################
            # Version V01
            # vom 7.4.2023
            ##################################################

            if ($DebugMode -eq "true") {Write-Host "starte Sub Men� SelectPerson"}

            #$global:AktPersonNr=1

            $HorrAbstand=5
            $ZeilenAbstand=10

            $LabelWidth=100
            $LabelHeight=20
            $LabelLeft=20
            $TextBoxLeft=$LabelLeft + $LabelWidth + $HorrAbstand
            $TextBoxWidth=200
    
            # PartnerschaftsGUI erzeugen
            $PartnerschaftsForm = New-Object System.Windows.Forms.Form
            $PartnerschaftsForm.StartPosition = "CenterScreen"
            $PartnerschaftsForm.Text =  GetTextFromLanguageDB -ID "5_5" #"Stammbaum Verbindungs-Daten Editor"
            $PartnerschaftsForm.width = ($LabelWidth+$TextBoxWidth+$HorrAbstand+$LabelLeft+30)


            $ZeilenTop=20
            # Label LNR
            $PartnerschaftsLNRLabel = New-Object System.Windows.Forms.Label
            $PartnerschaftsLNRLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
            $PartnerschaftsLNRLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
            $PartnerschaftsLNRLabel.Text=GetTextFromLanguageDB -ID "5_M_401" #"Knoten-LNr"
            $PartnerschaftsForm.Controls.Add($PartnerschaftsLNRLabel)

            $PartnerschaftsLNRtextBox = New-Object System.Windows.Forms.TextBox
            $PartnerschaftsLNRtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
            $PartnerschaftsLNRtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
            $PartnerschaftsLNRtextBox.ReadOnly = 'true'
            $PartnerschaftsLNRtextBox.TabIndex = 10
            $PartnerschaftsForm.Controls.Add($PartnerschaftsLNRtextBox)

            
            $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
            # Label HochzeitsDatum
            $PartnerschaftsHochzeitsDatumLabel = New-Object System.Windows.Forms.Label
            $PartnerschaftsHochzeitsDatumLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
            $PartnerschaftsHochzeitsDatumLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
            $PartnerschaftsHochzeitsDatumLabel.Text=GetTextFromLanguageDB -ID "5_M_402" #"Hochzeits-Datum"
            $PartnerschaftsForm.Controls.Add($PartnerschaftsHochzeitsDatumLabel)

            $PartnerschaftsHochzeitsDatumtextBox = New-Object System.Windows.Forms.TextBox
            $PartnerschaftsHochzeitsDatumtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
            $PartnerschaftsHochzeitsDatumtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
            $PartnerschaftsHochzeitsDatumtextBox.TabIndex = 0
            $PartnerschaftsForm.Controls.Add($PartnerschaftsHochzeitsDatumtextBox)

            $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
            # Label HochzeitsOrt
            $PartnerschaftsHochzeitsOrtLabel = New-Object System.Windows.Forms.Label
            $PartnerschaftsHochzeitsOrtLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
            $PartnerschaftsHochzeitsOrtLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
            $PartnerschaftsHochzeitsOrtLabel.Text=GetTextFromLanguageDB -ID "5_M_403" #"Hochzeits-Ort"
            $PartnerschaftsForm.Controls.Add($PartnerschaftsHochzeitsOrtLabel)

            $PartnerschaftsHochzeitsOrttextBox = New-Object System.Windows.Forms.TextBox
            $PartnerschaftsHochzeitsOrttextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
            $PartnerschaftsHochzeitsOrttextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
            $PartnerschaftsHochzeitsOrttextBox.TabIndex = 1
            $PartnerschaftsHochzeitsOrttextBox.add_Click($PartnerschaftsHochzeitsOrttextBox_onClick)
            $PartnerschaftsForm.Controls.Add($PartnerschaftsHochzeitsOrttextBox)

            $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
            # Label TrennungsDatum
            $PartnerschaftsTrennungsDatumLabel = New-Object System.Windows.Forms.Label
            $PartnerschaftsTrennungsDatumLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
            $PartnerschaftsTrennungsDatumLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
            $PartnerschaftsTrennungsDatumLabel.Text=GetTextFromLanguageDB -ID "5_M_404" #"Trennungs-Datum"
            $PartnerschaftsForm.Controls.Add($PartnerschaftsTrennungsDatumLabel)

            $PartnerschaftsTrennungsDatumtextBox = New-Object System.Windows.Forms.TextBox
            $PartnerschaftsTrennungsDatumtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
            $PartnerschaftsTrennungsDatumtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
            $PartnerschaftsTrennungsDatumtextBox.TabIndex = 2
            $PartnerschaftsForm.Controls.Add($PartnerschaftsTrennungsDatumtextBox)

            $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand


            $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
            $PartnerschaftsOKButtonBreite=($PartnerschaftsTrennungsDatumtextBox.left + $PartnerschaftsTrennungsDatumtextBox.width-$LabelLeft - $HorrAbstand)/2
            # Button "OK"                            
            $PartnerschaftsOKButton = New-Object System.Windows.Forms.Button
            # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
            $PartnerschaftsOKButton.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
            $PartnerschaftsOKButton.Size = New-Object System.Drawing.Size($PartnerschaftsOKButtonBreite,$LabelHeight)
            $PartnerschaftsOKButton.Text = GetTextFromLanguageDB -ID "5_M_405" #"OK"
            $PartnerschaftsOKButton.Name = "OK"
            $PartnerschaftsOKButton.TabIndex = 3
            #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
            $PartnerschaftsOKButton.add_Click($PartnerschaftsOKButton_OnClick)
            $PartnerschaftsForm.Controls.Add($PartnerschaftsOKButton)

            # Button "Abbruch"       
            $Tab=($PartnerschaftsTrennungsDatumtextBox.left + $PartnerschaftsTrennungsDatumtextBox.width-$LabelLeft)/2 +($HorrAbstand/2) +$LabelLeft                    
            $PartnerschaftsCancelButton = New-Object System.Windows.Forms.Button
            #Partnerschafts Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
            $PartnerschaftsCancelButton.Location = New-Object System.Drawing.Size($Tab,$ZeilenTop)
            $PartnerschaftsCancelButton.Size = New-Object System.Drawing.Size($PartnerschaftsOKButtonBreite,$LabelHeight)
            $PartnerschaftsCancelButton.Text = GetTextFromLanguageDB -ID "5_M_406" #"Abbrechen"
            $PartnerschaftsCancelButton.Name = "Abbrechen"
            $PartnerschaftsCancelButton.TabIndex = 4
            $PartnerschaftsCancelButton.DialogResult = "Cancel"
            #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
            $PartnerschaftsCancelButton.Add_Click({$PartnerschaftsForm.Close()})
            $PartnerschaftsForm.Controls.Add($PartnerschaftsCancelButton)
    
            $PartnerschaftsForm.height = ($ZeilenTop + $LabelHeight + $ZeilenAbstand + 40)

            #$SelectPersonLNRtextBox.Text=1
            PartnerschaftsFelderFuellen

            $Erfolg =  $PartnerschaftsForm.ShowDialog()

            #$global:AktPersonNr=$SelectPersonLNRtextBox.Text
      
            if ($DebugMode -eq "true") {$text="beende Sub Men� Partnerschafts. " ;Write-Host $Text}
            #return $global:AktPersonNr

            MainFormFelderFuellen
        }

    #endregion PartnerschaftsSettings

    $MainFormKi14PlusButton_OnClick={
        ##################################################
        # Version V01
        # vom 23.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"
        
        if ($DebugMode -eq "true") {$text="# MainFormKi14PlusButton_OnClick - startet"; Write-Host $text}

        $KinderAnzahl=FindKindAnz -PeKnotenLnr $global:AktKnoten
        
        if ($DebugMode -eq "true") {$text="# `t-- " + $KinderAnzahl + " Kinder" + ", global:GuiErstesKindNr:" + $global:GuiErstesKindNr; Write-Host $text}

        if (($KinderAnzahl-$global:GuiErstesKindNr) -gt 13) {
            $global:GuiErstesKindNr=$global:GuiErstesKindNr+7
        if ($DebugMode -eq "true") {$text="# `t-- rufe MainFormFelderFuellen mit global:GuiErstesKindNr: " + $global:GuiErstesKindNr; Write-Host $text}
            MainFormFelderFuellen
        }
        
        if ($DebugMode -eq "true") {$text="# MainFormKi14PlusButton_OnClick - endet"; Write-Host $text}
    }

    $MainFormKi14MinusButton_OnClick=  {
        if ($global:GuiErstesKindNr -gt 6) {
            $global:GuiErstesKindNr=$global:GuiErstesKindNr-7
            MainFormFelderFuellen
        }
    }

    function GetMainGuiLabelText() {
        param (
            $PersonenDaten=""
        )
        ##################################################
        # Version V01
        # vom 1.5.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$text="## GetLabelText startet `t- mit Parameter PersonenDaten: (" + $PersonenDaten + ")";Write-Host $text}
        
        $erg=""

        $DummySplit=$PersonenDaten.Split("`t")


        $Wert=$DummySplit[10]
        if ($Wert -ne "") {
            if ((IstZahl -DuTZahl $Wert) -eq $true) {
                    if ($DebugMode -eq "true") {$Text="Geb-Ort-Wert:"+ $Wert + "ist Integer";Write-Host $Text}
                    $geb=GetAdressMainGUISummary -WohnOrtNr $Wert
                } else {
                    if ($DebugMode -eq "true") {$Text="Geb-Ort-Wert:"+ $Wert + "ist String";Write-Host $Text}
                    $geb=$Wert
            }
        }

        $Wert=$DummySplit[11]
        if ($Wert -ne "") {
            if ((IstZahl -DuTZahl $Wert) -eq $true) {
                    $gst=GetAdressMainGUISummary -WohnOrtNr $Wert
                } else {
                    $gst=$Wert
            }
        }

        $Wert=$DummySplit[15]
        if ($Wert -ne "") {
            if ((IstZahl -DuTZahl $Wert) -eq $true) {
                    if ($DebugMode -eq "true") {$Text="Wohn-Ort-Wert:"+ $Wert + "ist Integer";Write-Host $Text}
                    $Wohn=GetAdressMainGUISummary -WohnOrtNr $Wert
                } else {
                    if ($DebugMode -eq "true") {$Text="Wohn-Ort-Wert:"+ $Wert + "ist String";Write-Host $Text}
                    $Wohn=$Wert
            }
        }

        $erg=$erg + $DummySplit[0] + "`n"  
        $erg=$erg + $DummySplit[1] + "`n" 
        $erg=$erg +  $DummySplit[7] + "`n" 
        $erg=$erg +  $DummySplit[2] + "`n"
        $erg=$erg +  $DummySplit[3] + "`n" 
        $erg=$erg +  $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $geb + "`n" 
        $erg=$erg +  $global:WohnhaftZeichen + ": " + $Wohn + "`n" 
        $erg=$erg +  $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $gst + "`n" 
        $erg=$erg +  $DummySplit[6]
        

        if ($DebugMode -eq "true") {$text="## GetLabelText endet `t- mit R�ckgabe-Parameter: (" + $erg + ")";Write-Host $text}
        return $erg
    }

    function MainFormFelderFuellen {
        ##################################################
        # Version V05
        # vom 1.5.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
     #   $DebugMode = "true"
        
        if ($DebugMode -eq "true") {$text="# MainFormFelderFuellen - startet"; Write-Host $text}

        # erst mal alles loeschen:
        $MainFormE1Label.Text=""
        $MainFormE2Label.Text=""
        $MainFormE3Label.Text=""
        $MainFormE4Label.Text=""
        $MainFormPeLabel.Text=""
        $MainFormPaLabel.Text=""
        $MainFormKnLabel.Text=""
        $MainFormK1Label.Text=""
        $MainFormK2Label.Text=""
        $MainFormK3Label.Text=""
        $MainFormK4Label.Text=""
        $MainFormK5Label.Text=""
        $MainFormK6Label.Text=""
        $MainFormK7Label.Text=""
        $MainFormK8Label.Text=""
        $MainFormK9Label.Text=""
        $MainFormK10Label.Text=""
        $MainFormK11Label.Text=""
        $MainFormK12Label.Text=""
        $MainFormK13Label.Text=""
        $MainFormK14Label.Text=""



        $KnotenDBZeilenSplit=$global:KnotenDB.Split("`n")
    
        $AktKnotenListe=FindeAlleKnotenVonPersonNr($global:AktPersonNr)
        if ($DebugMode -eq "true") {$text="# MainFormFelderFuellen - AktKnotenListe:`t" + $AktKnotenListe; Write-Host $text}
        if ($AktKnotenListe -like "*`t*") { 


                # KnotenAuswahl muss hier kommen!
                KnotenSelect

                #$global:AktKnoten=$AktKnotenListe.Split("`t")[0]
            } else {
                $global:AktKnoten=$AktKnotenListe
        }
        if ($DebugMode -eq "true") {$text="# MainFormFelderFuellen - AktKnoten:`t" + $global:AktKnoten; Write-Host $text}

        $KinderAnzahl=FindKindAnz -PeKnotenLnr $global:AktKnoten

        $KnotenDBSpaltenSplit=$KnotenDBZeilenSplit[$global:AktKnoten].Split("`t")

        if ($KnotenDBSpaltenSplit[4] -eq 0) {
                $PartnerKnotenDBSpalte="0"
                for($i=1; $i -lt $KnotenDBSpaltenSplit.count; $i++){
                    $PartnerKnotenDBSpalte=$PartnerKnotenDBSpalte + "`t0"
                }
                $PartnerKnotenDBSpaltenSplit=$PartnerKnotenDBSpalte.Split("`t")
            } else {
                $AktPartnerKnoten=0
                # hier geht es um die Eltern des Partners - also ist egal ob der Partnerknoten der passende zur aktuellen Person ist - also nehme ich den ersten!
                $AktPartnerKnotenListe=FindeAlleKnotenVonPersonNr($KnotenDBSpaltenSplit[4])
                if ($AktPartnerKnotenListe -like "*`t*") { 
                        if ($DebugMode -eq "true") { Write-Host "Tab drin"}
                        $AktPartnerKnoten=$AktPartnerKnotenListe.Split("`t")[0]
                        $AktPartnerKnotenListeSplit=$AktPartnerKnotenListe.Split("`t")
                        for($i=0; $i -lt $AktPartnerKnotenListeSplit.count; $i++){

                            if ($KnotenDBZeilenSplit[$AktPartnerKnotenListeSplit[$i]].Split("`t")[4] -eq $global:AktPersonNr) {$AktPartnerKnoten=$AktPartnerKnotenListeSplit[$i]}
                        }
                    } else {
                        if ($DebugMode -eq "true") { Write-Host "Kein Tab drin"}
                        $AktPartnerKnoten=$AktPartnerKnotenListe
                }
                if ($DebugMode -eq "true") { $Text= "AktPartnerKnoten:" + $AktPartnerKnoten; Write-Host $Text}
                if ($DebugMode -eq "true") { $Text= "KnotenDBZeilenSplit[AktPartnerKnoten]:" + $KnotenDBZeilenSplit[$AktPartnerKnoten]; Write-Host $Text}
                $PartnerKnotenDBSpaltenSplit=$KnotenDBZeilenSplit[$AktPartnerKnoten].Split("`t")
        }

        # achtung split[0] ist die lnr des Knotens, keine Person!
        # achtung Reihenfolge:
        # KnotenDaten:   LNr	PersonLNr	VaterLNr	MutterLNr	PartnerLNr	Knoten2LNr	Knoten3LNr	Knoten4LNr	Kind1LNr	Kind2LNr	Kind3LNr	Kind4LNr	Kind5LNr	Kind6LNr	Kind7LNr	Kind8LNr	Kind9LNr	Kind10LNr	Kind11LNr	Kind12LNr	Kind13LNr	Kind14LNr	StartDatum	EndDatum	Trau-Ort
        # $global:KnotenPersonen:	E1	E2	E3	E4	Pe	Pa	K1	k2	...	k14	Hochzeit	HochzeitsOrt	Trennung	PEKnotenNr	PaKnotenNr
       # $globalKnotenPersonen=($KnotenDBSpaltenSplit[2],$KnotenDBSpaltenSplit[3],$PartnerKnotenDBSpaltenSplit[2],$PartnerKnotenDBSpaltenSplit[3],$KnotenDBSpaltenSplit[1],$KnotenDBSpaltenSplit[4],$KnotenDBSpaltenSplit[8],$KnotenDBSpaltenSplit[9],$KnotenDBSpaltenSplit[10],$KnotenDBSpaltenSplit[11],$KnotenDBSpaltenSplit[12],$KnotenDBSpaltenSplit[13],$KnotenDBSpaltenSplit[14],$KnotenDBSpaltenSplit[15],$KnotenDBSpaltenSplit[16],$KnotenDBSpaltenSplit[17],$KnotenDBSpaltenSplit[18],$KnotenDBSpaltenSplit[19],$KnotenDBSpaltenSplit[20],$KnotenDBSpaltenSplit[21],$KnotenDBSpaltenSplit[22],$KnotenDBSpaltenSplit[23],$KnotenDBSpaltenSplit[24],$KnotenDBSpaltenSplit[25],$global:AktKnoten,$AktPartnerKnoten,"ende")
        
        
        if ($DebugMode -eq "true") { $Text= "global:KnotenPersonen frisch auff�llen"; Write-Host $Text}
        if ($DebugMode -eq "true") { $Text= "KnotenDBSpaltenAnz:" + $KnotenDBZeilenSplit[0].Split("`t").count; Write-Host $Text}
        if ($DebugMode -eq "true") { $Text= "alter Wert global:KnotenPersonen:" + $global:KnotenPersonen; Write-Host $Text}
        # 4Eltern, Pe und Pa einf�llen
        #$global:KnotenPersonen.Clear()
        $global:KnotenPersonen=@()
        $global:KnotenPersonen=$global:KnotenPersonen + $KnotenDBSpaltenSplit[2]
        $global:KnotenPersonen=$global:KnotenPersonen + $KnotenDBSpaltenSplit[3]
        $global:KnotenPersonen=$global:KnotenPersonen + $PartnerKnotenDBSpaltenSplit[2]
        $global:KnotenPersonen=$global:KnotenPersonen + $PartnerKnotenDBSpaltenSplit[3]
        $global:KnotenPersonen=$global:KnotenPersonen + $KnotenDBSpaltenSplit[1]
        $global:KnotenPersonen=$global:KnotenPersonen + $KnotenDBSpaltenSplit[4]
        # die ersten 14 Kinder dazu mit Hochzeit...
        for($i=8; $i -lt 25; $i++){
            $global:KnotenPersonen=$global:KnotenPersonen + $KnotenDBSpaltenSplit[$i]
        }
        $global:KnotenPersonen=$global:KnotenPersonen + ""
        $global:KnotenPersonen=$global:KnotenPersonen + $global:AktKnoten
        $global:KnotenPersonen=$global:KnotenPersonen + $AktPartnerKnoten

       # if ($DebugMode -eq "true") { $Text= "KinderAnzahl:" + $KinderAnzahl; Write-Host $Text}
        #if($KinderAnzahl -gt 14) {
            # restliche Kinder ab Nr 15
            $GesKnotenSpaltenAnz = $KnotenDBZeilenSplit[0].Split("`t").count
            if ($DebugMode -eq "true") { $Text= "KnotenDBSpaltenAnz:" + $GesKnotenSpaltenAnz; Write-Host $Text}
            for($i=25; $i -lt $GesKnotenSpaltenAnz; $i++){
                $Wert=0
                if ($KnotenDBSpaltenSplit[$i] -ne "") {$Wert = $KnotenDBSpaltenSplit[$i]}
                $global:KnotenPersonen=$global:KnotenPersonen + $Wert
                if ($DebugMode -eq "true") { $Text= "Wert:" + $Wert + ". jetzt global:KnotenPersonen:" + $global:KnotenPersonen; Write-Host $Text}
            }
       # }
        if ($DebugMode -eq "true") { $Text= "neuer Wert global:KnotenPersonen:" + $global:KnotenPersonen; Write-Host $Text}
        # Puffer an leeren Kindern
        for($i=1; $i -lt 15; $i++){
            $global:KnotenPersonen=$global:KnotenPersonen + 0
        }
        if ($DebugMode -eq "true") { $Text= "neuer Wert mit 14 Kinder als Puffer global:KnotenPersonen:" + $global:KnotenPersonen; Write-Host $Text}
        

        if ($DebugMode -eq "true") { $Text= "##`t-- global:KnotenPersonen:`t" + $global:KnotenPersonen; Write-Host $Text}


        if ($DebugMode -eq "true") {Write-Host "## MainFormFelderFuellen - KnotenPersonen:`t";  Write-Host  $global:KnotenPersonen}

        if ($KinderAnzahl -lt 14) {
            
                $MainFormKi14PlusButton.visible = $false
                $MainFormKi14MinusButton.visible = $false
            } else {
                $MainFormKi14PlusButton.visible = $true
                $MainFormKi14MinusButton.visible = $true

        } 

        # das "gestorben-Kreuz" ist ASCII 0x0134. kann auch 0x2020 oder 0x2663 sein
        # hier :
        # gestorben 0x2020
        # Hochzeit 0x26AD
        # Scheidung: 0x26AE
        # Nutzung: $text="`n" + $global:GestorbenZeichen + ": 01.01.2007" 

        ##################################################
        ### Eltern (4x)
        if ($global:KnotenPersonen[0] -ne 0) {
            $Dummy=GetPersonMitNr($global:KnotenPersonen[0])
            #$DummySplit=$Dummy.Split("`t")
            #$MainFormE1Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
            $MainFormE1Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            
        }
        if ($global:KnotenPersonen[1] -ne 0) {
            $Dummy=GetPersonMitNr($global:KnotenPersonen[1])
            #$DummySplit=$Dummy.Split("`t")
            #$MainFormE2Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen  + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
            $MainFormE2Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
        }       
        if ($global:KnotenPersonen[2] -ne 0) {
            $Dummy=GetPersonMitNr($global:KnotenPersonen[2])
            #$DummySplit=$Dummy.Split("`t")
            #$MainFormE3Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
            $MainFormE3Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
        }       
        if ($global:KnotenPersonen[3] -ne 0) {
            $Dummy=GetPersonMitNr($global:KnotenPersonen[3])
            #$DummySplit=$Dummy.Split("`t")
            #$MainFormE4Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
            $MainFormE4Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
        }       
        ##########################################
        ### Person, Knoten, Partner
        if ($global:KnotenPersonen[4] -ne 0) {
            $Dummy=GetPersonMitNr($global:KnotenPersonen[4])
            #$DummySplit=$Dummy.Split("`t")
            #$MainFormPeLabel.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
            $MainFormPeLabel.Text=GetMainGuiLabelText -PersonenDaten $Dummy

            ##########
            ## Knoten
            #$text =  $global:HochzeitZeichen + ":" +  $global:HochzeitZeichen;Write-Host $text
            $MainFormKnLabel.Text= "" + $KnotenDBZeilenSplit[$global:AktKnoten].Split("`t")[0] + "`n" + $global:HochzeitZeichen + " "
            if ($global:KnotenPersonen[20] -ne 0) {
                $MainFormKnLabel.Text= $MainFormKnLabel.Text + $global:KnotenPersonen[20]
            }
            $MainFormKnLabel.Text= $MainFormKnLabel.Text + ", "
            if ($global:KnotenPersonen[22] -ne 0) {
                $MainFormKnLabel.Text= $MainFormKnLabel.Text + $global:KnotenPersonen[22]
            }
            $MainFormKnLabel.Text= $MainFormKnLabel.Text + "`n" + $global:ScheidungsZeichen + " "
            if ($global:KnotenPersonen[21] -ne 0) {
                $MainFormKnLabel.Text= $MainFormKnLabel.Text + $global:KnotenPersonen[21]
            }
            ## Knoten
            ##########
        }   
        $KinderMoeglich=$false # kinder nur wenn Partner existiert!     
        if ($global:KnotenPersonen[5] -ne 0) {
            $Dummy=GetPersonMitNr($global:KnotenPersonen[5])
            #$DummySplit=$Dummy.Split("`t")
            #$MainFormPaLabel.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
            $MainFormPaLabel.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            $KinderMoeglich=$true
        } 

        ### Person, Knoten, Partner
        ##########################################


        ##########################################
        ### Kinder (14x)
        if ($KinderMoeglich -eq $true){

            $KindPosInKnotenPersonen=(6+$global:GuiErstesKindNr)
            if ($DebugMode -eq "true") { $Text= "KindPosInKnotenPersonen:" + $KindPosInKnotenPersonen; Write-Host $Text}

        
            if ($DebugMode -eq "true") { $Text= "Kind 1" ; Write-Host $Text}
            if ($KindPosInKnotenPersonen -gt 19) {$KnotenPersonenPos=$KindPosInKnotenPersonen + 6} else {$KnotenPersonenPos=$KindPosInKnotenPersonen}
            if ($DebugMode -eq "true") { $Text= "`t-- KnotenPersonenPos:" + $KnotenPersonenPos; Write-Host $Text}
            if ($DebugMode -eq "true") { $Text= "`t-- global:KnotenPersonen[KnotenPersonenPos]=0?:(" + $global:KnotenPersonen[$KnotenPersonenPos] + ")"; Write-Host $Text}
            if ($global:KnotenPersonen[$KnotenPersonenPos] -ne 0) {
                if ($DebugMode -eq "true") { $Text= "`t-- Ist nicht 0:" ; Write-Host $Text}

                $Dummy=GetPersonMitNr($global:KnotenPersonen[$KnotenPersonenPos])
                if ($DebugMode -eq "true") { $Text= "`t-- Dummy:" + $Dummy; Write-Host $Text}

                #$DummySplit=$Dummy.Split("`t")
                #$MainFormK1Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
                $MainFormK1Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            }    
           
            if ($DebugMode -eq "true") { $Text= "Kind 2" ; Write-Host $Text}
            $KindPosInKnotenPersonen=$KindPosInKnotenPersonen+1
            if ($KindPosInKnotenPersonen -gt 19) {$KnotenPersonenPos=$KindPosInKnotenPersonen + 6} else {$KnotenPersonenPos=$KindPosInKnotenPersonen}
            if ($DebugMode -eq "true") { $Text= "`t-- KnotenPersonenPos:" + $KnotenPersonenPos; Write-Host $Text}
            if ($DebugMode -eq "true") { $Text= "`t-- global:KnotenPersonen[KnotenPersonenPos]=0?:(" + $global:KnotenPersonen[$KnotenPersonenPos] + ")"; Write-Host $Text}
            if ($global:KnotenPersonen[$KnotenPersonenPos] -ne 0) {
                if ($DebugMode -eq "true") { $Text= "`t-- Ist nicht 0:" ; Write-Host $Text}

                $Dummy=GetPersonMitNr($global:KnotenPersonen[$KnotenPersonenPos])
                if ($DebugMode -eq "true") { $Text= "`t-- Dummy:" + $Dummy; Write-Host $Text}

                #$DummySplit=$Dummy.Split("`t")
                #$MainFormK2Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
                $MainFormK2Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            }    
            $KindPosInKnotenPersonen=$KindPosInKnotenPersonen+1
            if ($KindPosInKnotenPersonen -gt 19) {$KnotenPersonenPos=$KindPosInKnotenPersonen + 6} else {$KnotenPersonenPos=$KindPosInKnotenPersonen}
            if ($global:KnotenPersonen[$KnotenPersonenPos] -ne 0) {
                $Dummy=GetPersonMitNr($global:KnotenPersonen[$KnotenPersonenPos])

                #$DummySplit=$Dummy.Split("`t")
                #$MainFormK3Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
                $MainFormK3Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            }    
            $KindPosInKnotenPersonen=$KindPosInKnotenPersonen+1
            if ($KindPosInKnotenPersonen -gt 19) {$KnotenPersonenPos=$KindPosInKnotenPersonen + 6} else {$KnotenPersonenPos=$KindPosInKnotenPersonen}
            if ($global:KnotenPersonen[$KnotenPersonenPos] -ne 0) {
                $Dummy=GetPersonMitNr($global:KnotenPersonen[$KnotenPersonenPos])

                #$DummySplit=$Dummy.Split("`t")
                #$MainFormK4Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
                $MainFormK4Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            }    
            $KindPosInKnotenPersonen=$KindPosInKnotenPersonen+1
            if ($KindPosInKnotenPersonen -gt 19) {$KnotenPersonenPos=$KindPosInKnotenPersonen + 6} else {$KnotenPersonenPos=$KindPosInKnotenPersonen}
            if ($global:KnotenPersonen[$KnotenPersonenPos] -ne 0) {
                $Dummy=GetPersonMitNr($global:KnotenPersonen[$KnotenPersonenPos])

                #$DummySplit=$Dummy.Split("`t")
                #$MainFormK5Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
                $MainFormK5Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            }
           
            $KindPosInKnotenPersonen=$KindPosInKnotenPersonen+1
            if ($KindPosInKnotenPersonen -gt 19) {$KnotenPersonenPos=$KindPosInKnotenPersonen + 6} else {$KnotenPersonenPos=$KindPosInKnotenPersonen}
            if ($global:KnotenPersonen[$KnotenPersonenPos] -ne 0) {
                $Dummy=GetPersonMitNr($global:KnotenPersonen[$KnotenPersonenPos])

                #$DummySplit=$Dummy.Split("`t")
                #$MainFormK6Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
                $MainFormK6Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            }    
        
            if ($DebugMode -eq "true") { $Text= "Kind 7" ; Write-Host $Text}
            $KindPosInKnotenPersonen=$KindPosInKnotenPersonen+1
            if ($KindPosInKnotenPersonen -gt 19) {$KnotenPersonenPos=$KindPosInKnotenPersonen + 6} else {$KnotenPersonenPos=$KindPosInKnotenPersonen}
            if ($DebugMode -eq "true") { $Text= "`t-- KnotenPersonenPos:" + $KnotenPersonenPos; Write-Host $Text}
            if ($DebugMode -eq "true") { $Text= "`t-- global:KnotenPersonen[KnotenPersonenPos]=0?:(" + $global:KnotenPersonen[$KnotenPersonenPos] + ")"; Write-Host $Text}
            if ($global:KnotenPersonen[$KnotenPersonenPos] -ne 0) {
                if ($DebugMode -eq "true") { $Text= "`t-- Ist nicht 0:" ; Write-Host $Text}
                $Dummy=GetPersonMitNr($global:KnotenPersonen[$KnotenPersonenPos])
                if ($DebugMode -eq "true") { $Text= "`t-- Dummy:" + $Dummy; Write-Host $Text}

                #$DummySplit=$Dummy.Split("`t")
                #$MainFormK7Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
                $MainFormK7Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            }    
        
            if ($DebugMode -eq "true") { $Text= "Kind 8" ; Write-Host $Text}
            $KindPosInKnotenPersonen=$KindPosInKnotenPersonen+1
            if ($KindPosInKnotenPersonen -gt 19) {$KnotenPersonenPos=$KindPosInKnotenPersonen + 6} else {$KnotenPersonenPos=$KindPosInKnotenPersonen}
            if ($DebugMode -eq "true") { $Text= "`t-- KnotenPersonenPos:" + $KnotenPersonenPos; Write-Host $Text}
            if ($DebugMode -eq "true") { $Text= "`t-- global:KnotenPersonen[KnotenPersonenPos]=0?:(" + $global:KnotenPersonen[$KnotenPersonenPos] + ")"; Write-Host $Text}
            if ($global:KnotenPersonen[$KnotenPersonenPos] -ne 0) {
                if ($DebugMode -eq "true") { $Text= "`t-- Ist nicht 0:" ; Write-Host $Text}
                $Dummy=GetPersonMitNr($global:KnotenPersonen[$KnotenPersonenPos])
                if ($DebugMode -eq "true") { $Text= "`t-- Dummy:" + $Dummy; Write-Host $Text}

                #$DummySplit=$Dummy.Split("`t")
                #$MainFormK8Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
                $MainFormK8Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            }       
            $KindPosInKnotenPersonen=$KindPosInKnotenPersonen+1
            if ($KindPosInKnotenPersonen -gt 19) {$KnotenPersonenPos=$KindPosInKnotenPersonen + 6} else {$KnotenPersonenPos=$KindPosInKnotenPersonen}
            if ($global:KnotenPersonen[$KnotenPersonenPos] -ne 0) {
                $Dummy=GetPersonMitNr($global:KnotenPersonen[$KnotenPersonenPos])

                #$DummySplit=$Dummy.Split("`t")
                #$MainFormK9Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
                $MainFormK9Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            }       
            $KindPosInKnotenPersonen=$KindPosInKnotenPersonen+1
            if ($KindPosInKnotenPersonen -gt 19) {$KnotenPersonenPos=$KindPosInKnotenPersonen + 6} else {$KnotenPersonenPos=$KindPosInKnotenPersonen}
            if ($global:KnotenPersonen[$KnotenPersonenPos] -ne 0) {
                $Dummy=GetPersonMitNr($global:KnotenPersonen[$KnotenPersonenPos])

                #$DummySplit=$Dummy.Split("`t")
                #$MainFormK10Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
                $MainFormK10Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            }       
            $KindPosInKnotenPersonen=$KindPosInKnotenPersonen+1
            if ($KindPosInKnotenPersonen -gt 19) {$KnotenPersonenPos=$KindPosInKnotenPersonen + 6} else {$KnotenPersonenPos=$KindPosInKnotenPersonen}
            if ($global:KnotenPersonen[$KnotenPersonenPos] -ne 0) {
                $Dummy=GetPersonMitNr($global:KnotenPersonen[$KnotenPersonenPos])

                #$DummySplit=$Dummy.Split("`t")
                #$MainFormK11Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
                $MainFormK11Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            }       
            $KindPosInKnotenPersonen=$KindPosInKnotenPersonen+1
            if ($KindPosInKnotenPersonen -gt 19) {$KnotenPersonenPos=$KindPosInKnotenPersonen + 6} else {$KnotenPersonenPos=$KindPosInKnotenPersonen}
            if ($global:KnotenPersonen[$KnotenPersonenPos] -ne 0) {
                $Dummy=GetPersonMitNr($global:KnotenPersonen[$KnotenPersonenPos])

                #$DummySplit=$Dummy.Split("`t")
                #$MainFormK12Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
                $MainFormK12Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            }       
            $KindPosInKnotenPersonen=$KindPosInKnotenPersonen+1
            if ($KindPosInKnotenPersonen -gt 19) {$KnotenPersonenPos=$KindPosInKnotenPersonen + 6} else {$KnotenPersonenPos=$KindPosInKnotenPersonen}
            if ($global:KnotenPersonen[$KnotenPersonenPos] -ne 0) {
                $Dummy=GetPersonMitNr($global:KnotenPersonen[$KnotenPersonenPos])

                #$DummySplit=$Dummy.Split("`t")
                #$MainFormK13Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
                $MainFormK13Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            }   
                
            
            if ($DebugMode -eq "true") { $Text= "Kind 14" ; Write-Host $Text}
            $KindPosInKnotenPersonen=$KindPosInKnotenPersonen+1
            if ($KindPosInKnotenPersonen -gt 19) {$KnotenPersonenPos=$KindPosInKnotenPersonen + 6} else {$KnotenPersonenPos=$KindPosInKnotenPersonen}
            if ($DebugMode -eq "true") { $Text= "`t-- global:KnotenPersonen:      `t" + $global:KnotenPersonen; Write-Host $Text}
            if ($DebugMode -eq "true") { $Text= "`t-- global:KnotenPersonen.Anzahl:`t" + $global:KnotenPersonen.Count; Write-Host $Text}
            if ($DebugMode -eq "true") { $Text= "`t-- KnotenPersonenPos:          `t" + $KnotenPersonenPos; Write-Host $Text}
            if ($DebugMode -eq "true") { $Text= "`t-- global:KnotenPersonen[KnotenPersonenPos]=0?:(" + $global:KnotenPersonen[$KnotenPersonenPos] + ")"; Write-Host $Text}
            if ($global:KnotenPersonen[$KnotenPersonenPos] -ne 0) {
                if ($DebugMode -eq "true") { $Text= "`t-- Ist nicht 0:" ; Write-Host $Text}
                $Dummy=GetPersonMitNr($global:KnotenPersonen[$KnotenPersonenPos])
                if ($DebugMode -eq "true") { $Text= "`t-- Dummy:" + $Dummy; Write-Host $Text}

               # $DummySplit=$Dummy.Split("`t")
                #$MainFormK14Label.Text=$DummySplit[0] + "`n" + $DummySplit[1] + "`n" + $DummySplit[7] + "`n" + $DummySplit[2] + "`n" + $DummySplit[3] + "`n" + $global:GeborenZeichen + ": " + $DummySplit[4] + "," + $DummySplit[10] + "`n" + $global:GestorbenZeichen + ": " + $DummySplit[5] + "," + $DummySplit[11] + "`n" + $DummySplit[6]
                $MainFormK14Label.Text=GetMainGuiLabelText -PersonenDaten $Dummy
            }               
            
            
                
        }

        if ($DebugMode -eq "true") { $text="# MainFormFelderFuellen - endet"; Write-Host $text}
    }

    function MainForm{
        ##################################################
        # Version V04
        # vom 1.5.2023
        ##################################################

        if ($DebugMode -eq "true") {Write-Host "starte Sub Men� MainForm"}

        $HorrAbstand=5
        $ZeilenAbstand=10

        $LabelWidth=170
        $LabelHeight=100
        $LinkerRand=20
        $RechterRand=15
        $ObererRand=20
        $UntererRand=50
        $TextBoxLeft=$LabelLeft + $LabelWidth + $HorrAbstand
        $TextBoxWidth=200
        
        $ButtonHeight=20
        $ButtonWidth=3*($LabelWidth)+2*($HorrAbstand)
        $ButtonVerbindungWidth=2*($LabelWidth)+$HorrAbstand
    
        $Spalte1=$LinkerRand
        $Spalte2=$LinkerRand+$LabelWidth+$HorrAbstand
        $Spalte3=$LinkerRand+2*($LabelWidth+$HorrAbstand)
        $Spalte4=$LinkerRand+3*($LabelWidth+$HorrAbstand)
        $Spalte5=$LinkerRand+4*($LabelWidth+$HorrAbstand)
        $Spalte6=$LinkerRand+5*($LabelWidth+$HorrAbstand)
        $Spalte7=$LinkerRand+6*($LabelWidth+$HorrAbstand)

        $Zeile1=$ObererRand
        $Zeile2=$ObererRand+$LabelHeight+$ZeilenAbstand
        $Zeile3=$ObererRand+2*($LabelHeight+$ZeilenAbstand)
        $Zeile4=$ObererRand+3*($LabelHeight+$ZeilenAbstand)
        $Zeile5=$ObererRand+4*($LabelHeight+$ZeilenAbstand)
        

        $Zeile2a=$Zeile2 + (($Zeile3-$Zeile2)/5*1)
        $Zeile2b=$Zeile2 + (($Zeile3-$Zeile2)/5*3)

        # GUI erzeugen
        $MainFormForm = New-Object System.Windows.Forms.Form
        $MainFormForm.StartPosition = "CenterScreen"
        $MainFormForm.Text = GetTextFromLanguageDB -ID "5_1" # "Stammbaum Personen-Manager"
        $MainFormForm.width = ($Spalte7+$LabelWidth+$Spalte1 + $RechterRand)
        $MainFormForm.height = ($Zeile5+$UntererRand+$ButtonHeight)

        $MainFormE1Label = New-Object System.Windows.Forms.Label
        $MainFormE1Label.Location = New-Object System.Drawing.Size($Spalte1,$Zeile1)
        $MainFormE1Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormE1Label.Text=GetTextFromLanguageDB -ID "5_M_1" #"Eltern1`n2`nNN`ngeb`ngebDatum`nst`nbemerk"
        $MainFormE1Label.BackColor="DarkGray"
        $MainFormE1Label.TabIndex = 5
        $MainFormE1Label.Add_Click($MainFormE1_OnClick)
        $MainFormForm.Controls.Add($MainFormE1Label)

        $MainFormE2Label = New-Object System.Windows.Forms.Label
        $MainFormE2Label.Location = New-Object System.Drawing.Size($Spalte2,$Zeile1)
        $MainFormE2Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormE2Label.Text=GetTextFromLanguageDB -ID "5_M_2" #"Eltern2`nvom aktiven Person`nals Ein Objekt"
        $MainFormE2Label.BackColor="DarkGray"
        $MainFormE2Label.TabIndex = 6
        $MainFormE2Label.Add_Click($MainFormE2_OnClick)
        $MainFormForm.Controls.Add($MainFormE2Label)

        
        $MainFormE3Label = New-Object System.Windows.Forms.Label
        $MainFormE3Label.Location = New-Object System.Drawing.Size($Spalte6,$Zeile1)
        $MainFormE3Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormE3Label.Text=GetTextFromLanguageDB -ID "5_M_3" #"Eltern1`nvom aktiven Partner`nals Ein Objekt"
        $MainFormE3Label.BackColor="DarkGray"
        $MainFormE3Label.TabIndex = 7
        $MainFormE3Label.Add_Click($MainFormE3_OnClick)
        $MainFormForm.Controls.Add($MainFormE3Label)

        $MainFormE4Label = New-Object System.Windows.Forms.Label
        $MainFormE4Label.Location = New-Object System.Drawing.Size($Spalte7,$Zeile1)
        $MainFormE4Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormE4Label.Text=GetTextFromLanguageDB -ID "5_M_4" #"Eltern2`nvom aktiven Partner`nals Ein Objekt"
        $MainFormE4Label.BackColor="DarkGray"
        $MainFormE4Label.TabIndex = 8
        $MainFormE4Label.Add_Click($MainFormE4_OnClick)
        $MainFormForm.Controls.Add($MainFormE4Label)



        $MainFormPeLabel = New-Object System.Windows.Forms.Label
        $MainFormPeLabel.Location = New-Object System.Drawing.Size($Spalte3,$Zeile2)
        $MainFormPeLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormPeLabel.Text=GetTextFromLanguageDB -ID "5_M_5" #"Person`nals Ein Objekt"
        $MainFormPeLabel.TabIndex = 0
        $MainFormPeLabel.BackColor="lime"
        $MainFormPeLabel.Add_Click($MainFormPe_OnClick)
        $MainFormForm.Controls.Add($MainFormPeLabel)


        $MainFormKnLabel = New-Object System.Windows.Forms.Label
        $MainFormKnLabel.Location = New-Object System.Drawing.Size($Spalte4,$Zeile2)
        $MainFormKnLabel.Size = New-Object System.Drawing.Size($LabelWidth,(($Zeile2b-$Zeile2a)*2))
        $MainFormKnLabel.Text=GetTextFromLanguageDB -ID "5_M_6" #"Knoten`n2`n3"
        $MainFormKnLabel.TabIndex = 2
        $MainFormKnLabel.BackColor="lime"
        $MainFormKnLabel.Add_Click($MainFormKn_OnClick)
        $MainFormForm.Controls.Add($MainFormKnLabel)


        $MainFormPaLabel = New-Object System.Windows.Forms.Label
        $MainFormPaLabel.Location = New-Object System.Drawing.Size($Spalte5,$Zeile2)
        $MainFormPaLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormPaLabel.Text=GetTextFromLanguageDB -ID "5_M_7" #"Partner`nals Ein Objekt"
        $MainFormPaLabel.TabIndex = 1
        $MainFormPaLabel.BackColor="DarkGray"
        $MainFormPaLabel.Add_Click($MainFormPa_OnClick)
        $MainFormForm.Controls.Add($MainFormPaLabel)


        
        $MainFormK1Label = New-Object System.Windows.Forms.Label
        $MainFormK1Label.Location = New-Object System.Drawing.Size($Spalte1,$Zeile3)
        $MainFormK1Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormK1Label.Text=GetTextFromLanguageDB -ID "5_M_8" #"Kind 1`nals Ein Objekt"
        $MainFormK1Label.BackColor="DarkGray"
        $MainFormK1Label.TabIndex = 9
        $MainFormK1Label.Add_Click({MainFormKind_OnClick -KindButtonNr 1})
        $MainFormForm.Controls.Add($MainFormK1Label)

        $MainFormK2Label = New-Object System.Windows.Forms.Label
        $MainFormK2Label.Location = New-Object System.Drawing.Size($Spalte2,$Zeile3)
        $MainFormK2Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormK2Label.Text=GetTextFromLanguageDB -ID "5_M_9" #"Kind 2`nals Ein Objekt"
        $MainFormK2Label.BackColor="DarkGray"
        $MainFormK2Label.TabIndex = 10
        $MainFormK2Label.Add_Click({MainFormKind_OnClick -KindButtonNr 2})
        $MainFormForm.Controls.Add($MainFormK2Label)

        $MainFormK3Label = New-Object System.Windows.Forms.Label
        $MainFormK3Label.Location = New-Object System.Drawing.Size($Spalte3,$Zeile3)
        $MainFormK3Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormK3Label.Text=GetTextFromLanguageDB -ID "5_M_10" #"Kind 3`nals Ein Objekt"
        $MainFormK3Label.BackColor="DarkGray"
        $MainFormK3Label.TabIndex = 11
        $MainFormK3Label.Add_Click({MainFormKind_OnClick -KindButtonNr 3})
        $MainFormForm.Controls.Add($MainFormK3Label)

        
        $MainFormK4Label = New-Object System.Windows.Forms.Label
        $MainFormK4Label.Location = New-Object System.Drawing.Size($Spalte4,$Zeile3)
        $MainFormK4Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormK4Label.Text=GetTextFromLanguageDB -ID "5_M_11" #"Kind 4`nals Ein Objekt"
        $MainFormK4Label.BackColor="DarkGray"
        $MainFormK4Label.TabIndex = 12
        $MainFormK4Label.Add_Click({MainFormKind_OnClick -KindButtonNr 4})
        $MainFormForm.Controls.Add($MainFormK4Label)

        $MainFormK5Label = New-Object System.Windows.Forms.Label
        $MainFormK5Label.Location = New-Object System.Drawing.Size($Spalte5,$Zeile3)
        $MainFormK5Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormK5Label.Text=GetTextFromLanguageDB -ID "5_M_12" #"Kind 5`nals Ein Objekt"
        $MainFormK5Label.BackColor="DarkGray"
        $MainFormK5Label.TabIndex = 13
        $MainFormK5Label.Add_Click({MainFormKind_OnClick -KindButtonNr 5})
        $MainFormForm.Controls.Add($MainFormK5Label)

        # Farben: Black, DarkBlue, DarkGreen, DarkCyan, DarkRed, DarkMagenta, DarkYellow, Gray, DarkGray, Blue, Green, Cyan, Red, Magenta, Yellow, and White.
        # aber lime geht auch
        $MainFormK6Label = New-Object System.Windows.Forms.Label
        $MainFormK6Label.Location = New-Object System.Drawing.Size($Spalte6,$Zeile3)
        $MainFormK6Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormK6Label.Text=GetTextFromLanguageDB -ID "5_M_13" #"Kind 6`nals Ein Objekt"
        $MainFormK6Label.BackColor="DarkGray"
        $MainFormK6Label.TabIndex = 14
        #$MainFormK6Label.ForeColor = "yellow"
        $MainFormK6Label.Add_Click({MainFormKind_OnClick -KindButtonNr 6})
        $MainFormForm.Controls.Add($MainFormK6Label)

        $MainFormK7Label = New-Object System.Windows.Forms.Label
        $MainFormK7Label.Location = New-Object System.Drawing.Size($Spalte7,$Zeile3)
        $MainFormK7Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormK7Label.Text=GetTextFromLanguageDB -ID "5_M_14" #"Kind 7`nals Ein Objekt"
        $MainFormK7Label.BackColor="DarkGray"
        $MainFormK7Label.TabIndex = 15
        $MainFormK7Label.Add_Click({MainFormKind_OnClick -KindButtonNr 7})
        $MainFormForm.Controls.Add($MainFormK7Label)
    

        $MainFormK8Label = New-Object System.Windows.Forms.Label
        $MainFormK8Label.Location = New-Object System.Drawing.Size($Spalte1,$Zeile4)
        $MainFormK8Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormK8Label.Text=GetTextFromLanguageDB -ID "5_M_15" #"Kind 8`nals Ein Objekt"
        $MainFormK8Label.BackColor="DarkGray"
        $MainFormK8Label.TabIndex = 16
        $MainFormK8Label.Add_Click({MainFormKind_OnClick -KindButtonNr 8})
        $MainFormForm.Controls.Add($MainFormK8Label)
        
        $MainFormK9Label = New-Object System.Windows.Forms.Label
        $MainFormK9Label.Location = New-Object System.Drawing.Size($Spalte2,$Zeile4)
        $MainFormK9Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormK9Label.Text=GetTextFromLanguageDB -ID "5_M_16" #"Kind 9`nals Ein Objekt"
        $MainFormK9Label.BackColor="DarkGray"
        $MainFormK9Label.TabIndex = 17
        $MainFormK9Label.Add_Click({MainFormKind_OnClick -KindButtonNr 9})
        $MainFormForm.Controls.Add($MainFormK9Label)
        
        $MainFormK10Label = New-Object System.Windows.Forms.Label
        $MainFormK10Label.Location = New-Object System.Drawing.Size($Spalte3,$Zeile4)
        $MainFormK10Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormK10Label.Text=GetTextFromLanguageDB -ID "5_M_17" #"Kind 10`nals Ein Objekt"
        $MainFormK10Label.BackColor="DarkGray"
        $MainFormK10Label.TabIndex = 18
        $MainFormK10Label.Add_Click({MainFormKind_OnClick -KindButtonNr 10})
        $MainFormForm.Controls.Add($MainFormK10Label)
        
        $MainFormK11Label = New-Object System.Windows.Forms.Label
        $MainFormK11Label.Location = New-Object System.Drawing.Size($Spalte4,$Zeile4)
        $MainFormK11Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormK11Label.Text=GetTextFromLanguageDB -ID "5_M_18" #"Kind 11`nals Ein Objekt"
        $MainFormK11Label.BackColor="DarkGray"
        $MainFormK11Label.TabIndex = 19
        $MainFormK11Label.Add_Click({MainFormKind_OnClick -KindButtonNr 11})
        $MainFormForm.Controls.Add($MainFormK11Label)
        
        $MainFormK12Label = New-Object System.Windows.Forms.Label
        $MainFormK12Label.Location = New-Object System.Drawing.Size($Spalte5,$Zeile4)
        $MainFormK12Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormK12Label.Text=GetTextFromLanguageDB -ID "5_M_19" #"Kind 12`nals Ein Objekt"
        $MainFormK12Label.BackColor="DarkGray"
        $MainFormK12Label.TabIndex = 20
        $MainFormK12Label.Add_Click({MainFormKind_OnClick -KindButtonNr 12})
        $MainFormForm.Controls.Add($MainFormK12Label)
        
        $MainFormK13Label = New-Object System.Windows.Forms.Label
        $MainFormK13Label.Location = New-Object System.Drawing.Size($Spalte6,$Zeile4)
        $MainFormK13Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormK13Label.Text=GetTextFromLanguageDB -ID "5_M_20" #"Kind 13`nals Ein Objekt"
        $MainFormK13Label.BackColor="DarkGray"
        $MainFormK13Label.TabIndex = 21
        $MainFormK13Label.Add_Click({MainFormKind_OnClick -KindButtonNr 13})
        $MainFormForm.Controls.Add($MainFormK13Label)
        
        $MainFormK14Label = New-Object System.Windows.Forms.Label
        $MainFormK14Label.Location = New-Object System.Drawing.Size($Spalte7,$Zeile4)
        $MainFormK14Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $MainFormK14Label.Text=GetTextFromLanguageDB -ID "5_M_21" #"Kind 14`nals Ein Objekt"
        $MainFormK14Label.BackColor="DarkGray"
        $MainFormK14Label.TabIndex = 22
        $MainFormK14Label.Add_Click({MainFormKind_OnClick -KindButtonNr 14})
        $MainFormForm.Controls.Add($MainFormK14Label)

        $MainFormKi14PlusButton = New-Object System.Windows.Forms.Button
        $MainFormKi14PlusButton.Location = New-Object System.Drawing.Size(($Spalte7 + +$LabelWidth),$Zeile4)
        $MainFormKi14PlusButton.Size = New-Object System.Drawing.Size($Spalte1,$LabelHeight)
        $MainFormKi14PlusButton.Text = ">>"
        $MainFormKi14PlusButton.TabIndex = 23
        $MainFormKi14PlusButton.Name = "MehrKinder"
        $MainFormKi14PlusButton.Add_Click($MainFormKi14PlusButton_OnClick)
        $MainFormForm.Controls.Add($MainFormKi14PlusButton)

        $MainFormKi14MinusButton = New-Object System.Windows.Forms.Button
        $MainFormKi14MinusButton.Location = New-Object System.Drawing.Size(0,$Zeile3)
        $MainFormKi14MinusButton.Size = New-Object System.Drawing.Size($Spalte1,$LabelHeight)
        $MainFormKi14MinusButton.Text = "<<"
        $MainFormKi14MinusButton.TabIndex = 24
        $MainFormKi14MinusButton.Name = "WenigerKinder"
        $MainFormKi14MinusButton.Add_Click($MainFormKi14MinusButton_OnClick)
        $MainFormForm.Controls.Add($MainFormKi14MinusButton)

        $MainFormChKn1Button = New-Object System.Windows.Forms.Button
        $MainFormChKn1Button.Location = New-Object System.Drawing.Size($Spalte1,$Zeile2a)
        $MainFormChKn1Button.Size = New-Object System.Drawing.Size($ButtonVerbindungWidth,$ButtonHeight)
        $MainFormChKn1Button.Text = GetTextFromLanguageDB -ID "5_M_22" #"Verbindung wechseln"
        $MainFormChKn1Button.TabIndex = 3
        $MainFormChKn1Button.Name = "Verbindungwechseln1"
        $MainFormChKn1Button.Add_Click($MainFormChKn1_OnClick)
        $MainFormForm.Controls.Add($MainFormChKn1Button)

        $MainFormNewKn1Button = New-Object System.Windows.Forms.Button
        $MainFormNewKn1Button.Location = New-Object System.Drawing.Size($Spalte1,$Zeile2b)
        $MainFormNewKn1Button.Size = New-Object System.Drawing.Size($ButtonVerbindungWidth,$ButtonHeight)
        $MainFormNewKn1Button.Text =GetTextFromLanguageDB -ID "5_M_23" # "Neue Verbindung herstellen"
        $MainFormNewKn1Button.TabIndex = 4
        $MainFormNewKn1Button.Name = "NeueVerbindung1"
        #$MainFormCancelButton.DialogResult = "Cancel"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $MainFormNewKn1Button.Add_Click($MainFormNewKn1_OnClick)
        $MainFormForm.Controls.Add($MainFormNewKn1Button)



       # $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
       # $OKButtonBreite=($SelectPersonBemerkungtextBox.left + $SelectPersonBemerkungtextBox.width-$LabelLeft - $HorrAbstand)/2

        # Button "Abbruch"       
       # $Tab=($SelectPersonBemerkungtextBox.left + $SelectPersonBemerkungtextBox.width-$LabelLeft)/2 +($HorrAbstand/2) +$LabelLeft                    
        $MainFormCancelButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $MainFormCancelButton.Location = New-Object System.Drawing.Size($Spalte3,$Zeile5)
        $MainFormCancelButton.Size = New-Object System.Drawing.Size($ButtonWidth,$ButtonHeight)
        $MainFormCancelButton.Text = GetTextFromLanguageDB -ID "5_M_24" #"Beenden`nund schliessen`nsofort!"
        $MainFormCancelButton.Name = "Abbrechen"
        $MainFormCancelButton.TabIndex = 25
        $MainFormCancelButton.DialogResult = "Cancel"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $MainFormCancelButton.Add_Click({$MainFormForm.Close()})
        $MainFormForm.Controls.Add($MainFormCancelButton)
    

        #$SelectPersonLNRtextBox.Text=$global:AktPersonNr
        MainFormFelderFuellen

        $Erfolg =  $MainFormForm.ShowDialog()

        #$global:AktPersonNr=$SelectPersonLNRtextBox.Text
      
        if ($DebugMode -eq "true") {$text="beende Sub Men� MainForm. aktuelle Person:" + $global:AktPersonNr;Write-Host $Text}


    }

#endregion Sub Menue MainForm

#region Sub Menue PersonenDatenEditor

    $PersonenDatenSuchButton_onClick={

        $Treffer=PersonenSucheAusBestand
        if ($Treffer -eq 0) {
                if ($DebugMode -eq "true") {$Text= "Treffer:" + $Treffer + " - nix zu tun";Write-Host $Text}

            } else {
                if ($DebugMode -eq "true") {$Text= "Treffer:" + $Treffer + " PersonNr uebernehmen";Write-Host $Text}
                $PersonenDatenEditorLNRtextBox.Text =  $Treffer
                $PersonenDatenEditorForm.Close()
        }
    }


    $PersonenDatenEditorSterbeOrttextBox_onClick={
        ##################################################
        # Version V01
        # vom 01.05.2023
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
    #    $DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "PersonenDatenEditorSterbeOrttextBox_onClick startet";  Write-Host $Text}

        #AdressDatenEditor -DuTAdressNr $PersonenDatenEditorSterbeOrttextBox.Text
        if ($PersonenDatenEditorSterbeOrttextBox.Name -eq "") {$Wert=$PersonenDatenEditorSterbeOrttextBox.Text} else {$Wert=$PersonenDatenEditorSterbeOrttextBox.Name}
        $ErgWert=AdressDatenEditor -DuTAdressNr  $Wert
        ReplaceAdressDaten -NeueDaten $ErgWert
        $PersonenDatenEditorSterbeOrttextBox.Name=$ErgWert.Split("`t")[0]
        PersonenDatenSpeichern
        PersonenDatenEditorFelderFuellen
        
        if ($DebugMode -eq "true") {$Text= "PersonenDatenEditorSterbeOrttextBox_onClick endet";  Write-Host $Text}
    }

    $PersonenDatenEditorGeburtsOrttextBox_onClick={
        ##################################################
        # Version V01
        # vom 01.05.2023
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "PersonenDatenEditorGeburtsOrttextBox_onClick startet";  Write-Host $Text}
        
        #AdressDatenEditor -DuTAdressNr  $PersonenDatenEditorGeburtsOrttextBox.Text
        if ($PersonenDatenEditorGeburtsOrttextBox.Name -eq "") {$Wert=$PersonenDatenEditorGeburtsOrttextBox.Text} else {$Wert=$PersonenDatenEditorGeburtsOrttextBox.Name}
        $ErgWert=AdressDatenEditor -DuTAdressNr  $Wert
        ReplaceAdressDaten -NeueDaten $ErgWert
        $PersonenDatenEditorGeburtsOrttextBox.Name=$ErgWert.Split("`t")[0]
        PersonenDatenSpeichern
        PersonenDatenEditorFelderFuellen

        if ($DebugMode -eq "true") {$Text= "PersonenDatenEditorGeburtsOrttextBox_onClick endet";  Write-Host $Text}
    }

    $PersonenDatenEditorWohnOrttextBox_onClick={
        ##################################################
        # Version V01
        # vom 01.05.2023
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "PersonenDatenEditorWohnOrttextBox_onClick startet";  Write-Host $Text}

        if ($PersonenDatenEditorWohnOrttextBox.Name -eq "") {$Wert=$PersonenDatenEditorWohnOrttextBox.Text} else {$Wert=$PersonenDatenEditorWohnOrttextBox.Name}
        $ErgWert=AdressDatenEditor -DuTAdressNr  $Wert
        ReplaceAdressDaten -NeueDaten $ErgWert
        $PersonenDatenEditorWohnOrttextBox.Name=$ErgWert.Split("`t")[0]
        PersonenDatenSpeichern
        PersonenDatenEditorFelderFuellen

        if ($DebugMode -eq "true") {$Text= "PersonenDatenEditorWohnOrttextBox_onClick endet";  Write-Host $Text}
    }

    function PersonenDatenSammelnZumSpeichern() {
        ##################################################
        # Version V01
        # vom 01.05.2023
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "PersonenDatenSammelnZumSpeichern startet";  Write-Host $Text}


        $TransferDaten=$PersonenDatenEditorLNRtextBox.Text
        $Wert=$PersonenDatenEditorVornametextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
        $Wert=$PersonenDatenEditorNachnametextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
        $Wert=$PersonenDatenEditorGebNametextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
        $Wert=$PersonenDatenEditorGebDatumtextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
        $Wert=$PersonenDatenEditorSterbeDatumtextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
        $Wert=$PersonenDatenEditorBemerkungtextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
        $Wert=$PersonenDatenEditorZusatzVornamentextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}

        $TransferDaten=$TransferDaten + "`t" # mob
        $TransferDaten=$TransferDaten + "`t" # mail

        if ($PersonenDatenEditorGeburtsOrttextBox.Name -eq "") {
                $Wert=$PersonenDatenEditorGeburtsOrttextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
            } else {
                $Wert=$PersonenDatenEditorGeburtsOrttextBox.Name;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
        }
        if ($PersonenDatenEditorSterbeOrttextBox.Name -eq "") {
                $Wert=$PersonenDatenEditorSterbeOrttextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
            } else {
                $Wert=$PersonenDatenEditorSterbeOrttextBox.Name;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
        }
        #$Wert=$PersonenDatenEditorGeburtsOrttextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
        #$Wert=$PersonenDatenEditorSterbeOrttextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
        $Wert=$PersonenDatenEditorReligiontextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
        $Wert=$PersonenDatenEditorGeschltextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
        $Wert=$PersonenDatenEditorNationalitaettextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
            
        if ($PersonenDatenEditorWohnOrttextBox.Name -eq "") {
                $Wert=$PersonenDatenEditorWohnOrttextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
            } else {
                $Wert=$PersonenDatenEditorWohnOrttextBox.Name;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
        }

        if ($DebugMode -eq "true") {$Text= "PersonenDatenSammelnZumSpeichern endet mit R�ckgabeParameter:" + $TransferDaten;  Write-Host $Text}
        return $TransferDaten
    }


    function PersonenDatenSpeichern() {
        ##################################################
        # Version V01
        # vom 01.05.2023
        ##################################################
            
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "PersonenDatenSpeichern startet";  Write-Host $Text}


        $TransferDaten=PersonenDatenSammelnZumSpeichern

        if ($DebugMode -eq "true") {$Text= "TransferDaten:(" + $TransferDaten + ")";  Write-Host $Text}
        if ($TransferDaten -ne "") { 
            #Write-Host " 1 in PersonenDatenSpeichern : "
            ReplacePersonenDaten -NeueDaten $TransferDaten
        }

        if ($DebugMode -eq "true") {$Text= "PersonenDatenSpeichern endet";  Write-Host $Text}
    }

    function IstZahl(){
        param (
            $DuTZahl=""
        )
        ##################################################
        # Version V01
        # vom 1.5.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"
        
        if ($DebugMode -eq "true") {$Text= "IstZahl startet mit parameter DuTZahl:" + $DuTZahl; Write-Host $Text}

        $erg=$true
        Try {
            # [Int]$Variable = $DuTZahl
                [Int]$DuTZahl -is [Int]
            } Catch {
                $erg=$false
        }
        
        if ($DebugMode -eq "true") {$Text= "IstZahl endet mit R�ckgabeparameter:" + $erg; Write-Host $Text}
        return $erg
    }

    function PersonenDatenEditorFelderFuellen {
        ##################################################
        # Version V02
        # vom 1.5.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        $PersonLnr = $PersonenDatenEditorLNRtextBox.Text
    
        if ($DebugMode -eq "true") {$Text="hole Daten von Person Nr:" +  $PersonLnr;Write-Host $Text}
        $PersonenDaten=GetPersonMitNr($PersonLnr)
        if ($DebugMode -eq "true") {Write-Host "PersonenDaten:";Write-Host $PersonenDaten}

        if ($PersonenDaten -ne "") {
            $PersonenDatenSplit=$PersonenDaten.Split("`t")

            $PersonenDatenEditorLNRtextBox.Text             = $PersonenDatenSplit[0]
            $PersonenDatenEditorVornametextBox.Text         = $PersonenDatenSplit[1]
            $PersonenDatenEditorNachnametextBox.Text        = $PersonenDatenSplit[2]
            $PersonenDatenEditorGebNametextBox.Text         = $PersonenDatenSplit[3]
            $PersonenDatenEditorGebDatumtextBox.Text        = $PersonenDatenSplit[4]
            $PersonenDatenEditorSterbeDatumtextBox.Text     = $PersonenDatenSplit[5]
            $PersonenDatenEditorBemerkungtextBox.Text       = $PersonenDatenSplit[6]
            $PersonenDatenEditorZusatzVornamentextBox.Text  = $PersonenDatenSplit[7]

            #$Wert=0
            #$PersonenDatenEditorGeburtsOrttextBox.Text      = $PersonenDatenSplit[10]
            $Wert=$PersonenDatenSplit[10]
            if ($Wert -ne "") {
                if ((IstZahl -DuTZahl $Wert) -eq $true) {
                        if ($DebugMode -eq "true") {$Text="Geb-Ort-Wert:"+ $Wert + "ist Integer";Write-Host $Text}
                        $PersonenDatenEditorGeburtsOrttextBox.Text=GetAdressGUISummary -WohnOrtNr $Wert
                        $PersonenDatenEditorGeburtsOrttextBox.Name=$Wert
                    } else {
                        if ($DebugMode -eq "true") {$Text="Geb-Ort-Wert:"+ $Wert + "ist String";Write-Host $Text}
                        $PersonenDatenEditorGeburtsOrttextBox.Text=$Wert
                        $PersonenDatenEditorGeburtsOrttextBox.Name=""
                }
            }

           # $Wert=0
            #$PersonenDatenEditorSterbeOrttextBox.Text       = $PersonenDatenSplit[11]
            $Wert=$PersonenDatenSplit[11]
            if ($Wert -ne "") {
                if ((IstZahl -DuTZahl $Wert) -eq $true) {
                        $PersonenDatenEditorSterbeOrttextBox.Text=GetAdressGUISummary -WohnOrtNr $Wert
                        $PersonenDatenEditorSterbeOrttextBox.Name=$Wert
                    } else {
                        $PersonenDatenEditorSterbeOrttextBox.Text=$Wert
                        $PersonenDatenEditorSterbeOrttextBox.Name=""
                }
            }

            
            #$Wert=0
            #$PersonenDatenEditorWohnOrttextBox.Text       = $PersonenDatenSplit[15]
            $Wert=$PersonenDatenSplit[15]
            if ($Wert -ne "") {
                if ((IstZahl -DuTZahl $Wert) -eq $true) {
                        if ($DebugMode -eq "true") {$Text="Wohn-Ort-Wert:"+ $Wert + "ist Integer";Write-Host $Text}
                        $PersonenDatenEditorWohnOrttextBox.Text=GetAdressGUISummary -WohnOrtNr $Wert
                        $PersonenDatenEditorWohnOrttextBox.Name=$Wert
                    } else {
                        if ($DebugMode -eq "true") {$Text="Wohn-Ort-Wert:"+ $Wert + "ist String";Write-Host $Text}
                        $PersonenDatenEditorWohnOrttextBox.Text=$Wert
                        $PersonenDatenEditorWohnOrttextBox.Name=""
                }
            }

            $PersonenDatenEditorReligiontextBox.Text        = $PersonenDatenSplit[12]
            $PersonenDatenEditorGeschltextBox.Text          = $PersonenDatenSplit[13]
            $PersonenDatenEditorNationalitaettextBox.Text   = $PersonenDatenSplit[14]
        }
    } 

    function PersonenDatenEditor {
        param (
            $DuTPersonNr=0 # LNr der Person, die editiert wird. bei neuer Person ist es 0
        )
        ##################################################
        # Version V02
        # vom 1.5.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") {Write-Host "starte Sub Men� PersonenDatenEditor"}

        #$global:AktPersonNr=1

        $HorrAbstand=5
        $ZeilenAbstand=10

        $LabelWidth=100
        $LabelHeight=20
        $LabelLeft=20
        $TextBoxLeft=$LabelLeft + $LabelWidth + $HorrAbstand
        $TextBoxWidth=200
    
        # GUI erzeugen
        $PersonenDatenEditorForm = New-Object System.Windows.Forms.Form
        $PersonenDatenEditorForm.StartPosition = "CenterScreen"
        $PersonenDatenEditorForm.Text =  GetTextFromLanguageDB -ID "5_6" #"Stammbaum PersonenDatenEditor"
        $PersonenDatenEditorForm.width = ($LabelWidth+$TextBoxWidth+$HorrAbstand+$LabelLeft+30)

        $ZeilenTop=20
        # Label LNR
        $PersonenDatenEditorLNRLabel = New-Object System.Windows.Forms.Label
        $PersonenDatenEditorLNRLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenDatenEditorLNRLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenDatenEditorLNRLabel.Text= GetTextFromLanguageDB -ID "5_M_501" #"LNr"
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorLNRLabel)

        $PersonenDatenEditorLNRtextBox = New-Object System.Windows.Forms.TextBox
        $PersonenDatenEditorLNRtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenDatenEditorLNRtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenDatenEditorLNRtextBox.ReadOnly = 'true'
        $PersonenDatenEditorLNRtextBox.TabIndex = 100
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorLNRtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Vorname
        $PersonenDatenEditorVornameLabel = New-Object System.Windows.Forms.Label
        $PersonenDatenEditorVornameLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenDatenEditorVornameLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenDatenEditorVornameLabel.Text=GetTextFromLanguageDB -ID "5_M_502" #"Vorname"
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorVornameLabel)

        $PersonenDatenEditorVornametextBox = New-Object System.Windows.Forms.TextBox
        $PersonenDatenEditorVornametextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenDatenEditorVornametextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenDatenEditorVornametextBox.TabIndex = 0
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorVornametextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Nachname
        $PersonenDatenEditorNachnameLabel = New-Object System.Windows.Forms.Label
        $PersonenDatenEditorNachnameLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenDatenEditorNachnameLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenDatenEditorNachnameLabel.Text=GetTextFromLanguageDB -ID "5_M_503" #"Nachname"
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorNachnameLabel)

        $PersonenDatenEditorNachnametextBox = New-Object System.Windows.Forms.TextBox
        $PersonenDatenEditorNachnametextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenDatenEditorNachnametextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenDatenEditorNachnametextBox.TabIndex = 2
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorNachnametextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label GebName
        $PersonenDatenEditorGebNameLabel = New-Object System.Windows.Forms.Label
        $PersonenDatenEditorGebNameLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenDatenEditorGebNameLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenDatenEditorGebNameLabel.Text=GetTextFromLanguageDB -ID "5_M_504" #"Geburts-name"
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorGebNameLabel)

        $PersonenDatenEditorGebNametextBox = New-Object System.Windows.Forms.TextBox
        $PersonenDatenEditorGebNametextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenDatenEditorGebNametextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenDatenEditorGebNametextBox.TabIndex = 3
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorGebNametextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label GebDatum
        $PersonenDatenEditorGebDatumLabel = New-Object System.Windows.Forms.Label
        $PersonenDatenEditorGebDatumLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenDatenEditorGebDatumLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenDatenEditorGebDatumLabel.Text=GetTextFromLanguageDB -ID "5_M_505" #"Geburts-Datum"
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorGebDatumLabel)

        $PersonenDatenEditorGebDatumtextBox = New-Object System.Windows.Forms.TextBox
        $PersonenDatenEditorGebDatumtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenDatenEditorGebDatumtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenDatenEditorGebDatumtextBox.TabIndex = 4
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorGebDatumtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label GeburtsOrt
        $PersonenDatenEditorGeburtsOrtLabel = New-Object System.Windows.Forms.Label
        $PersonenDatenEditorGeburtsOrtLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenDatenEditorGeburtsOrtLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenDatenEditorGeburtsOrtLabel.Text=GetTextFromLanguageDB -ID "5_M_509" #"GeburtsOrt"
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorGeburtsOrtLabel)

        $PersonenDatenEditorGeburtsOrttextBox = New-Object System.Windows.Forms.TextBox
        $PersonenDatenEditorGeburtsOrttextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenDatenEditorGeburtsOrttextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenDatenEditorGeburtsOrttextBox.TabIndex = 5
        $PersonenDatenEditorGeburtsOrttextBox.add_Click($PersonenDatenEditorGeburtsOrttextBox_onClick)
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorGeburtsOrttextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label GeburtsOrt
        $PersonenDatenEditorWohnOrtLabel = New-Object System.Windows.Forms.Label
        $PersonenDatenEditorWohnOrtLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenDatenEditorWohnOrtLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenDatenEditorWohnOrtLabel.Text=GetTextFromLanguageDB -ID "5_M_517" #"WohnOrt"
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorWohnOrtLabel)

        $PersonenDatenEditorWohnOrttextBox = New-Object System.Windows.Forms.TextBox
        $PersonenDatenEditorWohnOrttextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenDatenEditorWohnOrttextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenDatenEditorWohnOrttextBox.TabIndex = 6
        $PersonenDatenEditorWohnOrttextBox.add_Click($PersonenDatenEditorWohnOrttextBox_onClick)
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorWohnOrttextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label SterbeDatum
        $PersonenDatenEditorSterbeDatumLabel = New-Object System.Windows.Forms.Label
        $PersonenDatenEditorSterbeDatumLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenDatenEditorSterbeDatumLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenDatenEditorSterbeDatumLabel.Text=GetTextFromLanguageDB -ID "5_M_506" #"Sterbe-Datum"
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorSterbeDatumLabel)

        $PersonenDatenEditorSterbeDatumtextBox = New-Object System.Windows.Forms.TextBox
        $PersonenDatenEditorSterbeDatumtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenDatenEditorSterbeDatumtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenDatenEditorSterbeDatumtextBox.TabIndex = 7
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorSterbeDatumtextBox)
        
        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label SterbeOrt
        $PersonenDatenEditorSterbeOrtLabel = New-Object System.Windows.Forms.Label
        $PersonenDatenEditorSterbeOrtLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenDatenEditorSterbeOrtLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenDatenEditorSterbeOrtLabel.Text=GetTextFromLanguageDB -ID "5_M_510" #"Sterbe-Ort"
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorSterbeOrtLabel)

        $PersonenDatenEditorSterbeOrttextBox = New-Object System.Windows.Forms.TextBox
        $PersonenDatenEditorSterbeOrttextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenDatenEditorSterbeOrttextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenDatenEditorSterbeOrttextBox.TabIndex = 8
        $PersonenDatenEditorSterbeOrttextBox.add_Click($PersonenDatenEditorSterbeOrttextBox_onClick)
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorSterbeOrttextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Bemerkung
        $PersonenDatenEditorBemerkungLabel = New-Object System.Windows.Forms.Label
        $PersonenDatenEditorBemerkungLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenDatenEditorBemerkungLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenDatenEditorBemerkungLabel.Text=GetTextFromLanguageDB -ID "5_M_507" #"Bemerkung"
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorBemerkungLabel)

        $PersonenDatenEditorBemerkungtextBox = New-Object System.Windows.Forms.TextBox
        $PersonenDatenEditorBemerkungtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenDatenEditorBemerkungtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenDatenEditorBemerkungtextBox.TabIndex = 9
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorBemerkungtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label ZusatzVornamen
        $PersonenDatenEditorZusatzVornamenLabel = New-Object System.Windows.Forms.Label
        $PersonenDatenEditorZusatzVornamenLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenDatenEditorZusatzVornamenLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenDatenEditorZusatzVornamenLabel.Text=GetTextFromLanguageDB -ID "5_M_508" #"Zusatz-Vornamen"
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorZusatzVornamenLabel)

        $PersonenDatenEditorZusatzVornamentextBox = New-Object System.Windows.Forms.TextBox
        $PersonenDatenEditorZusatzVornamentextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenDatenEditorZusatzVornamentextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenDatenEditorZusatzVornamentextBox.TabIndex = 10
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorZusatzVornamentextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Religion
        $PersonenDatenEditorReligionLabel = New-Object System.Windows.Forms.Label
        $PersonenDatenEditorReligionLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenDatenEditorReligionLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenDatenEditorReligionLabel.Text=GetTextFromLanguageDB -ID "5_M_511" #"Religion"
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorReligionLabel)

        $PersonenDatenEditorReligiontextBox = New-Object System.Windows.Forms.TextBox
        $PersonenDatenEditorReligiontextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenDatenEditorReligiontextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenDatenEditorReligiontextBox.TabIndex = 11
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorReligiontextBox)
        
        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Geschlecht
        $PersonenDatenEditorGeschlLabel = New-Object System.Windows.Forms.Label
        $PersonenDatenEditorGeschlLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenDatenEditorGeschlLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenDatenEditorGeschlLabel.Text=GetTextFromLanguageDB -ID "5_M_512" #Geschlecht"
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorGeschlLabel)

        $PersonenDatenEditorGeschltextBox = New-Object System.Windows.Forms.TextBox
        $PersonenDatenEditorGeschltextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenDatenEditorGeschltextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenDatenEditorGeschltextBox.TabIndex = 12
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorGeschltextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Nationalitaet
        $PersonenDatenEditorNationalitaetLabel = New-Object System.Windows.Forms.Label
        $PersonenDatenEditorNationalitaetLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenDatenEditorNationalitaetLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PersonenDatenEditorNationalitaetLabel.Text=GetTextFromLanguageDB -ID "5_M_513" #"Nationalit�t"
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorNationalitaetLabel)

        $PersonenDatenEditorNationalitaettextBox = New-Object System.Windows.Forms.TextBox
        $PersonenDatenEditorNationalitaettextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $PersonenDatenEditorNationalitaettextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $PersonenDatenEditorNationalitaettextBox.TabIndex = 13
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenEditorNationalitaettextBox)


    
        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
       # $Tab=($PersonenDatenEditorBemerkungtextBox.left + $PersonenDatenEditorBemerkungtextBox.width-$LabelLeft-(3*$HorrAbstand))/4
        #$SuchButtonBreite=($PersonenDatenEditorBemerkungtextBox.left + $PersonenDatenEditorBemerkungtextBox.width-$LabelLeft - $HorrAbstand)/2
        # Button "OK"                            
        $PersonenDatenSuchButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $PersonenDatenSuchButton.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $PersonenDatenSuchButton.Size = New-Object System.Drawing.Size(($PersonenDatenEditorBemerkungtextBox.left + $PersonenDatenEditorBemerkungtextBox.width-$LabelLeft),$LabelHeight)
        $PersonenDatenSuchButton.Text = GetTextFromLanguageDB -ID "5_M_514" #"Suche in Personen-Bestand"
        $PersonenDatenSuchButton.Name = "Suche"
        #$PersonenDatenSuchButton.DialogResult = "OK"
        $PersonenDatenSuchButton.TabIndex = 14
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $PersonenDatenSuchButton.add_Click($PersonenDatenSuchButton_onClick)
        $PersonenDatenEditorForm.Controls.Add($PersonenDatenSuchButton)


    
        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        $Tab=($PersonenDatenEditorBemerkungtextBox.left + $PersonenDatenEditorBemerkungtextBox.width-$LabelLeft-(3*$HorrAbstand))/4
        $OKButtonBreite=($PersonenDatenEditorBemerkungtextBox.left + $PersonenDatenEditorBemerkungtextBox.width-$LabelLeft - $HorrAbstand)/2
        # Button "OK"                            
        $OKButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $OKButton.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $OKButton.Size = New-Object System.Drawing.Size($OKButtonBreite,$LabelHeight)
        $OKButton.Text = GetTextFromLanguageDB -ID "5_M_515" #"OK"
        $OKButton.TabIndex = 15
        $OKButton.Name = "OK"
        $OKButton.DialogResult = "OK"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $OKButton.add_Click({$PersonenDatenEditorForm.Close()})
        $PersonenDatenEditorForm.Controls.Add($OKButton)

        # Button "Abbruch"       
        $Tab=($PersonenDatenEditorBemerkungtextBox.left + $PersonenDatenEditorBemerkungtextBox.width-$LabelLeft)/2 +($HorrAbstand/2) +$LabelLeft                    
        $CancelButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $CancelButton.Location = New-Object System.Drawing.Size($Tab,$ZeilenTop)
        $CancelButton.Size = New-Object System.Drawing.Size($OKButtonBreite,$LabelHeight)
        $CancelButton.Text = GetTextFromLanguageDB -ID "5_M_516" #"Abbrechen"
        $CancelButton.TabIndex = 16
        $CancelButton.Name = "Abbrechen"
        $CancelButton.DialogResult = "Cancel"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $CancelButton.Add_Click({$PersonenDatenEditorForm.Close()})
        $PersonenDatenEditorForm.Controls.Add($CancelButton)
    
        $PersonenDatenEditorForm.height = ($ZeilenTop + $LabelHeight + $ZeilenAbstand + 40)

        $PersonenDatenEditorLNRtextBox.Text=$DuTPersonNr
        PersonenDatenEditorFelderFuellen

        $Erfolg =  $PersonenDatenEditorForm.ShowDialog()
        if ($DebugMode -eq "true") {$Text= "#########################################################`n###  Erfolg:`t" + $Erfolg;Write-Host $Text}

       
        if ($Erfolg -eq "OK") {
            # OK
            $TransferDaten=PersonenDatenSammelnZumSpeichern
        } Else {
            # Abbruch
            $TransferDaten="" 
        }
        
        if ($DebugMode -eq "true") {$Text= "### R�ckgabe-Parameter:`n" + $TransferDaten;Write-Host $Text}
        if ($DebugMode -eq "true") {$text="beende Sub Men� PersonenDatenEditor.";Write-Host $Text}
        return $TransferDaten
    }

#endregion Sub Menue PersonenDatenEditor


#region Sub Menue AdressDatenEditor

    function AdressDatenEditorFelderFuellen {
        ##################################################
        # Version V01
        # vom 1.5.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
      #  $DebugMode = "true"
            
        if ($DebugMode -eq "true") {$Text="AdressDatenEditorFelderFuellen startet" ;Write-Host $Text}


        $Wert=$AdressDatenEditorLNRtextBox.Text
        if ($DebugMode -eq "true") {$Text="Wert:"+ $Wert ;Write-Host $Text}

        if ($Wert -ne "") {
            if ($DebugMode -eq "true") {$Text="AdressDatenEditorLNRtextBox.Text:"+ $AdressDatenEditorLNRtextBox.Text ;Write-Host $Text}
            if ((IstZahl -DuTZahl $Wert) -eq $true) {
                    if ($DebugMode -eq "true") {$Text="Ort-Wert:"+ $Wert + "ist Integer";Write-Host $Text}
                    $AdressLnr=$Wert

                    if ($DebugMode -eq "true") {$Text="hole Daten von Adresse Nr:" +  $AdressLnr;Write-Host $Text}
                    $AdressDaten=GetWohnort($AdressLnr)
                    if ($DebugMode -eq "true") {Write-Host "AdressDaten:";Write-Host $AdressDaten}

                    if ($AdressDaten -ne "") {
                        $AdressDatenSplit=$AdressDaten.Split("`t")

                        $AdressDatenEditorLNRtextBox.Text        = $AdressDatenSplit[0]
                        $AdressDatenEditorStrassetextBox.Text    = $AdressDatenSplit[2]
                        $AdressDatenEditorHausnummertextBox.Text = $AdressDatenSplit[3]
                        $AdressDatenEditorPLZtextBox.Text        = $AdressDatenSplit[4]
                        $AdressDatenEditorStadttextBox.Text      = $AdressDatenSplit[5]
                        $AdressDatenEditorOrttextBox.Text        = $AdressDatenSplit[6]
                        $AdressDatenEditorLandtextBox.Text       = $AdressDatenSplit[7]
                        $AdressDatenEditorTeltextBox.Text        = $AdressDatenSplit[8]
                        $AdressDatenEditorMobtextBox.Text        = $AdressDatenSplit[9]
                        $AdressDatenEditorMailtextBox.Text       = $AdressDatenSplit[10]
                        $AdressDatenEditorLattextBox.Text        = $AdressDatenSplit[11]
                        $AdressDatenEditorLontextBox.Text        = $AdressDatenSplit[12]

                    }
                } else {
                    if ($DebugMode -eq "true") {$Text="Ort-Wert:"+ $Wert + " ist String";Write-Host $Text}
                    $Lnr=GetNextFreeAdressLnr
                    $Stadt=$Wert
                    
                    $AdressDatenEditorLNRtextBox.Text        = $Lnr
                    $AdressDatenEditorStrassetextBox.Text    = ""
                    $AdressDatenEditorHausnummertextBox.Text = ""
                    $AdressDatenEditorPLZtextBox.Text        = ""
                    $AdressDatenEditorStadttextBox.Text      = $Stadt
                    $AdressDatenEditorOrttextBox.Text        = ""
                    $AdressDatenEditorLandtextBox.Text       = ""
                    $AdressDatenEditorTeltextBox.Text        = ""
                    $AdressDatenEditorMobtextBox.Text        = ""
                    $AdressDatenEditorMailtextBox.Text       = ""
                    $AdressDatenEditorLattextBox.Text        = ""
                    $AdressDatenEditorLontextBox.Text        = ""
            }
        } else {
            # $Wert=""
                    if ($DebugMode -eq "true") {$Text="Ort-Wert: ist leer => neu erstellen";Write-Host $Text}
                    $Lnr=GetNextFreeAdressLnr
                    
                    $AdressDatenEditorLNRtextBox.Text        = $Lnr
                    $AdressDatenEditorStrassetextBox.Text    = ""
                    $AdressDatenEditorHausnummertextBox.Text = ""
                    $AdressDatenEditorPLZtextBox.Text        = ""
                    $AdressDatenEditorStadttextBox.Text      = ""
                    $AdressDatenEditorOrttextBox.Text        = ""
                    $AdressDatenEditorLandtextBox.Text       = ""
                    $AdressDatenEditorTeltextBox.Text        = ""
                    $AdressDatenEditorMobtextBox.Text        = ""
                    $AdressDatenEditorMailtextBox.Text       = ""
                    $AdressDatenEditorLattextBox.Text        = ""
                    $AdressDatenEditorLontextBox.Text        = ""
        }

        if ($DebugMode -eq "true") {$Text="AdressDatenEditorFelderFuellen endet" ;Write-Host $Text}
    } 
 
    function AdressDatenEditor {
        param (
            $DuTAdressNr=0 # LNr der ADresse, die editiert wird. bei neuer Adresse ist es 0
        )
        ##################################################
        # Version V01
        # vom 1.5.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$Text= "Sub Men� AdressDatenEditor startet mit Parameter DuTAdressNr" + $DuTAdressNr;Write-Host $Text}

        #$global:AktPersonNr=1

        $HorrAbstand=5
        $ZeilenAbstand=10

        $LabelWidth=100
        $LabelHeight=20
        $LabelLeft=20
        $TextBoxLeft=$LabelLeft + $LabelWidth + $HorrAbstand
        $TextBoxWidth=200
    
        # GUI erzeugen
        $AdressDatenEditorForm = New-Object System.Windows.Forms.Form
        $AdressDatenEditorForm.StartPosition = "CenterScreen"
        $AdressDatenEditorForm.Text =  GetTextFromLanguageDB -ID "5_7" #"Stammbaum Adress-Editor"
        $AdressDatenEditorForm.width = ($LabelWidth+$TextBoxWidth+$HorrAbstand+$LabelLeft+30)

        $ZeilenTop=20
        # Label LNR
        $AdressDatenEditorLNRLabel = New-Object System.Windows.Forms.Label
        $AdressDatenEditorLNRLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $AdressDatenEditorLNRLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $AdressDatenEditorLNRLabel.Text= GetTextFromLanguageDB -ID "5_M_601" #"LNr"
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorLNRLabel)

        $AdressDatenEditorLNRtextBox = New-Object System.Windows.Forms.TextBox
        $AdressDatenEditorLNRtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $AdressDatenEditorLNRtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $AdressDatenEditorLNRtextBox.ReadOnly = 'true'
        $AdressDatenEditorLNRtextBox.TabIndex = 100
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorLNRtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Vorname
        $AdressDatenEditorStrasseLabel = New-Object System.Windows.Forms.Label
        $AdressDatenEditorStrasseLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $AdressDatenEditorStrasseLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $AdressDatenEditorStrasseLabel.Text=GetTextFromLanguageDB -ID "5_M_602" #"Strasse"
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorStrasseLabel)

        $AdressDatenEditorStrassetextBox = New-Object System.Windows.Forms.TextBox
        $AdressDatenEditorStrassetextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $AdressDatenEditorStrassetextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $AdressDatenEditorStrassetextBox.TabIndex = 0
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorStrassetextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Nachname
        $AdressDatenEditorHausnummerLabel = New-Object System.Windows.Forms.Label
        $AdressDatenEditorHausnummerLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $AdressDatenEditorHausnummerLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $AdressDatenEditorHausnummerLabel.Text=GetTextFromLanguageDB -ID "5_M_603" #"Hausnummer"
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorHausnummerLabel)

        $AdressDatenEditorHausnummertextBox = New-Object System.Windows.Forms.TextBox
        $AdressDatenEditorHausnummertextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $AdressDatenEditorHausnummertextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $AdressDatenEditorHausnummertextBox.TabIndex = 1
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorHausnummertextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label GebName
        $AdressDatenEditorPLZLabel = New-Object System.Windows.Forms.Label
        $AdressDatenEditorPLZLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $AdressDatenEditorPLZLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $AdressDatenEditorPLZLabel.Text=GetTextFromLanguageDB -ID "5_M_604" #"PLZ"
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorPLZLabel)

        $AdressDatenEditorPLZtextBox = New-Object System.Windows.Forms.TextBox
        $AdressDatenEditorPLZtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $AdressDatenEditorPLZtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $AdressDatenEditorPLZtextBox.TabIndex = 2
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorPLZtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Stadt
        $AdressDatenEditorStadtLabel = New-Object System.Windows.Forms.Label
        $AdressDatenEditorStadtLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $AdressDatenEditorStadtLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $AdressDatenEditorStadtLabel.Text=GetTextFromLanguageDB -ID "5_M_605" #"Stadt"
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorStadtLabel)

        $AdressDatenEditorStadttextBox = New-Object System.Windows.Forms.TextBox
        $AdressDatenEditorStadttextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $AdressDatenEditorStadttextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $AdressDatenEditorStadttextBox.TabIndex = 3
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorStadttextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Ort
        $AdressDatenEditorOrtLabel = New-Object System.Windows.Forms.Label
        $AdressDatenEditorOrtLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $AdressDatenEditorOrtLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $AdressDatenEditorOrtLabel.Text=GetTextFromLanguageDB -ID "5_M_606" #"Ort"
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorOrtLabel)

        $AdressDatenEditorOrttextBox = New-Object System.Windows.Forms.TextBox
        $AdressDatenEditorOrttextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $AdressDatenEditorOrttextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $AdressDatenEditorOrttextBox.TabIndex = 4
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorOrttextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Land
        $AdressDatenEditorLandLabel = New-Object System.Windows.Forms.Label
        $AdressDatenEditorLandLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $AdressDatenEditorLandLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $AdressDatenEditorLandLabel.Text=GetTextFromLanguageDB -ID "5_M_607" #"Land"
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorLandLabel)

        $AdressDatenEditorLandtextBox = New-Object System.Windows.Forms.TextBox
        $AdressDatenEditorLandtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $AdressDatenEditorLandtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $AdressDatenEditorLandtextBox.TabIndex = 5
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorLandtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Tel
        $AdressDatenEditorTelLabel = New-Object System.Windows.Forms.Label
        $AdressDatenEditorTelLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $AdressDatenEditorTelLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $AdressDatenEditorTelLabel.Text=GetTextFromLanguageDB -ID "5_M_608" #"Tel"
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorTelLabel)

        $AdressDatenEditorTeltextBox = New-Object System.Windows.Forms.TextBox
        $AdressDatenEditorTeltextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $AdressDatenEditorTeltextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $AdressDatenEditorTeltextBox.TabIndex = 6
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorTeltextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Mob
        $AdressDatenEditorMobLabel = New-Object System.Windows.Forms.Label
        $AdressDatenEditorMobLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $AdressDatenEditorMobLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $AdressDatenEditorMobLabel.Text=GetTextFromLanguageDB -ID "5_M_609" #"Mob"
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorMobLabel)

        $AdressDatenEditorMobtextBox = New-Object System.Windows.Forms.TextBox
        $AdressDatenEditorMobtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $AdressDatenEditorMobtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $AdressDatenEditorMobtextBox.TabIndex = 10
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorMobtextBox)
        
        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Mail
        $AdressDatenEditorMailLabel = New-Object System.Windows.Forms.Label
        $AdressDatenEditorMailLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $AdressDatenEditorMailLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $AdressDatenEditorMailLabel.Text=GetTextFromLanguageDB -ID "5_M_610" #Mail"
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorMailLabel)

        $AdressDatenEditorMailtextBox = New-Object System.Windows.Forms.TextBox
        $AdressDatenEditorMailtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $AdressDatenEditorMailtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $AdressDatenEditorMailtextBox.TabIndex = 11
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorMailtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Lat
        $AdressDatenEditorLatLabel = New-Object System.Windows.Forms.Label
        $AdressDatenEditorLatLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $AdressDatenEditorLatLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $AdressDatenEditorLatLabel.Text=GetTextFromLanguageDB -ID "5_M_611" #"Lat"
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorLatLabel)

        $AdressDatenEditorLattextBox = New-Object System.Windows.Forms.TextBox
        $AdressDatenEditorLattextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $AdressDatenEditorLattextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $AdressDatenEditorLattextBox.TabIndex = 12
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorLattextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Lon
        $AdressDatenEditorLonLabel = New-Object System.Windows.Forms.Label
        $AdressDatenEditorLonLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $AdressDatenEditorLonLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $AdressDatenEditorLonLabel.Text=GetTextFromLanguageDB -ID "5_M_612" #"Lon"
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorLonLabel)

        $AdressDatenEditorLontextBox = New-Object System.Windows.Forms.TextBox
        $AdressDatenEditorLontextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $AdressDatenEditorLontextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $AdressDatenEditorLontextBox.TabIndex = 13
        $AdressDatenEditorForm.Controls.Add($AdressDatenEditorLontextBox)


        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        $Tab=($TextBoxLeft + $TextBoxWidth-$LabelLeft-(3*$HorrAbstand))/4
        $OKButtonBreite=($TextBoxLeft + $TextBoxWidth-$LabelLeft - $HorrAbstand)/2
        # Button "OK"                            
        $OKButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $OKButton.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $OKButton.Size = New-Object System.Drawing.Size($OKButtonBreite,$LabelHeight)
        $OKButton.Text = GetTextFromLanguageDB -ID "5_M_613" #"OK"
        $OKButton.TabIndex = 14
        $OKButton.Name = "OK"
        $OKButton.DialogResult = "OK"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $OKButton.add_Click({$AdressDatenEditorForm.Close()})
        $AdressDatenEditorForm.Controls.Add($OKButton)

        # Button "Abbruch"       
        $Tab=($TextBoxLeft + $TextBoxWidth-$LabelLeft)/2 +($HorrAbstand/2) +$LabelLeft                    
        $CancelButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $CancelButton.Location = New-Object System.Drawing.Size($Tab,$ZeilenTop)
        $CancelButton.Size = New-Object System.Drawing.Size($OKButtonBreite,$LabelHeight)
        $CancelButton.Text = GetTextFromLanguageDB -ID "5_M_614" #"Abbrechen"
        $CancelButton.TabIndex = 15
        $CancelButton.Name = "Abbrechen"
        $CancelButton.DialogResult = "Cancel"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $CancelButton.Add_Click({$AdressDatenEditorForm.Close()})
        $AdressDatenEditorForm.Controls.Add($CancelButton)
    
        $AdressDatenEditorForm.height = ($ZeilenTop + $LabelHeight + $ZeilenAbstand + 40)


        $AdressDatenEditorLNRtextBox.Text=$DuTAdressNr
        AdressDatenEditorFelderFuellen

        $Erfolg =  $AdressDatenEditorForm.ShowDialog()

        if ($DebugMode -eq "true") {$Text= "#########################################################`n###  Erfolg:`t" + $Erfolg;Write-Host $Text}


        if ($Erfolg -eq "OK") {
            # Daten zusammenstellen
            $TransferDaten=$AdressDatenEditorLNRtextBox.Text + "`t" # Tab f�r die alte Spalte PersonLnrListe
            $Wert=$AdressDatenEditorStrassetextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
            $Wert=$AdressDatenEditorHausnummertextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
            $Wert=$AdressDatenEditorPLZtextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
            $Wert=$AdressDatenEditorStadttextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
            $Wert=$AdressDatenEditorOrttextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
            $Wert=$AdressDatenEditorLandtextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}

            $Wert=$AdressDatenEditorTeltextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
            $Wert=$AdressDatenEditorMobtextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
            $Wert=$AdressDatenEditorMailtextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}

            $Wert=$AdressDatenEditorLattextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}
            $Wert=$AdressDatenEditorLontextBox.Text;if ($Wert -eq "") {$TransferDaten=$TransferDaten + "`t"} else {$TransferDaten=$TransferDaten + "`t" + $Wert}


        } Else {
            # Abbruch
            $TransferDaten="" 
        }


        if ($DebugMode -eq "true") {$Text= "Sub Men� AdressDatenEditor endet mit R�ckgabe-Parameter" + $TransferDaten;Write-Host $Text}
        return $TransferDaten 
    }

#endregion Sub Menue AdressDatenEditor

#region Main

    $DebugMode = "false"
    if ($Global:DebugMode -eq "true"){$DebugMode="true"}
    #$DebugMode="true"


    if ($GetVersionInfo -eq "true") {            
            $ErgText=$ErgText + "Version:`t" + $Version + "`n"
            $ErgText=$ErgText + "Stand:`t" + $Stand + "`n"
            $ErgText=$ErgText + "Developper:`t" + $Developper + "`n"
            return  $ErgText

        } else {

            $global:PersonenDB=""
            $global:KnotenDB=""
            $global:AktPersonNr=0
            $global:AktKnoten=0

            $global:AdressDB=""

            # $global:KnotenPersonen:	E1	E2	E3	E4	Pe	Pa	K1	k2	...	k14	Hochzeit	HochzeitsOrt	Trennung	PEKnotenNr	PaKnotenNr
            # Achtung: 
            # 	PEKnotenNr	PaKnotenNr werden als DB-Position benutzt - nicht als LNR!!!

            $global:KnotenPersonen=@()

            $global:SettingsData=""
            $Global:SettingsDataFile=""
            $global:BasisPfad=""
            $Global:LogMode = ""
            $Global:DebugMode = "false"
            $Global:Language=""
            $Global:SprachDB=""

            $global:KindStartNr=0
            $global:KnotenHeaderListe=@()


            $global:GuiErstesKindNr=0

            $global:GestorbenZeichen=""
            $global:GeborenZeichen=""
            $global:HochzeitZeichen=""
            $global:ScheidungsZeichen=""

            SetGlobalParameterDE


            #################################################
            # Forms und Drawings laden - sonst tut keine GUI

            [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
            [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
    
            # Forms und Drawings laden - sonst tut keine GUI
            #################################################


            $PeAnz=($global:PersonenDB.split("`n").count-1)
            if ($DebugMode -eq "true") {$text="global:PersonenDB.Length:`t" + $global:PersonenDB.split("`n").count;  Write-Host $text}
            if ($DebugMode -eq "true") {$text="PeAnz:`t" + $PeAnz;  Write-Host $text}

            if ($DebugMode -eq "true") {$text="Anzahl Personen in der Datenbank:`t" + ($global:PersonenDB.split("`n").count);  Write-Host $text}# Ueberschrift und letzte leere Zeile => -2
            if ($global:PersonenDB.split("`n").count -gt 1){
                    SelectPerson
                } else {
                    ErstePerson
                    #$global:AktPersonNr=1 # nur eine Person gibt es nicht (nur als Kind) - es gibt immer einen Partner dazu sonst wirds nie ein Stammbaum. unbekannte Personen werden als leere person angelegt. Hauptsache sie existiert und hat eine lnr.
                    # jetzt muss direkt die EingabeMaske fuer eine neue Person auf gehen - ohne Inhalt
            }
            if ($DebugMode -eq "true") {$text="gestartet wird mit Person mit Nr:`t" + $global:AktPersonNr;  Write-Host $text}

            # bei Abbruch in SelectPerson wird $global:AktPersonNr = 0 gesetzt!
            if ( $global:AktPersonNr -gt 0) {
                MainForm
            }

    }
#endregion Main
