param (
    $DebugMode="false",
    $GetVersionInfo="false"
)

cls

##################################################
$Version="0.35"
$Stand="03.05.2023"
$Developper="na ich"
##################################################

if ($DebugMode -eq "true") { $text="Debugmode:`t" + $DebugMode; Write-Host $text; read-host �Press ENTER to continue...�}


#region Tools

    function DetectScriptPath {
        Param(
            $PowershellVersion
        )
        ##################################################
        # Version V02
        # vom 8.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        if ($DebugMode -eq "true") {
            $text="DetectScriptPath Startet mit Parameter`nPowershellVersion:`t" + $PowershellVersion + "`nDebugMode:`t" + $DebugMode + "`n"
            Write-Host  $Text
        }

        # gezielte Versuch anhand der installierten PS-Version den Script-Pfad zu ermitteln
        if ($PowershellVersion -gt 2){
            $BasisPfad=$PSScriptRoot
        }
        if ($PowershellVersion -gt 1){
            $BasisPfad=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath('.\')
        }

        # falls nichts funktioniert, dann wird stumpf versucht
        if ($BasisPfad -eq ""){
            $BasisPfad=$PSScriptRoot
        }
        if ($BasisPfad -eq ""){
            $BasisPfad=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath('.\')
        }
        if ($BasisPfad -eq ""){
            $BasisPfad=split-path -parent $MyInvocation.MyCommand.Definition
        }

        if ($DebugMode -eq "true") {
            $a=$PSScriptRoot
            $b=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath('.\')
            $c=split-path -parent $MyInvocation.MyCommand.Definition

            $Text="Ermitteln des ScriptPfades`n Methode 1: " + $a + "`n" + "Methode 2: " + $b + "`n" + "Methode 3: " + $c + "`n"
            $text=$Text + "DetectScriptPath endet mit Rueckgabe-Parameter`nBasisPfad:`t" + $BasisPfad + "`n"
            Write-Host  $Text
        }
        return $BasisPfad
}

    function DetectPSVersion() {
        
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        $PSVersion=""
        $PSVersion=$PSVersionTable.PSVersion.Major

        return $PSVersion
    }   

    function GetSettingsData {
        Param(
            $SourceDataFile
        )

        ##################################################
        # Version V03
        # vom 8.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        if ($DebugMode -eq "true") {$Text="## GetSettingsData startet `t- mit Parameter SourceDataFile: (" + $SourceDataFile + ")";Write-Host $text}
        $SourceData=Get-Content $SourceDataFile

        if ($SourceData.Length -eq 0){
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei existiert nicht/oder ist leer"}

            # Standard-Trennzeichen ist TAB ( `t )
            $SourceData="Lnr	Kategorie	Namen	Wert	Beschreibung" + "`n"
            $SourceData=$SourceData + "1`tallgemein`tDatenquelle`t1`tSpeicherort der Daten, 1=interne ExcelSheets (noch nicht verf�gber: , 2=SQL-DB, 3=Spreadsheet-Datei)" + "`n"
            $SourceData=$SourceData + "2`tallgemein`tFeldTrenner`tTAB`tSpalten-Trennzeichen aller interner Datens�tze" + "`n"
            $SourceData=$SourceData + "3`tFileSystem`tExportZielPfad`t" +  $BasisPfad + "`tZielordner f�r DatenExporte" + "`n"
            $SourceData=$SourceData + "4`tDarstellung`tNodeBreite`t120`tBreite der Person bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "5`tDarstellung`tNodeHoehe`t100`tH�he der Person bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "6`tDarstellung`tPersonBreite`t100`tBreite der Verbindungsk�sten bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "7`tDarstellung`tPersonHoehe`t130`tH�he der Verbindungsk�sten bei Objektbasierter Darstellung" + "`n"
            $SourceData=$SourceData + "8`tDebugging`tDebugMode`tWAHR`tDebug-Log-Datei wird erzeugt" + "`n"
            $SourceData=$SourceData + "9`tDebugging`tDebugZielPfad`t" +  $BasisPfad + "`tSpeicherPfad der Debug-Log-Datei" + "`n"
            $SourceData=$SourceData + "10`tDebugging`tDebugZielDateiname`tDebugLog.log`tDateiname der Debug-Log-Datei" + "`n"
            $SourceData=$SourceData + "11`tFileSystem`tDatenZielPfad`t" +  $BasisPfad + "\DBDaten`tOrdner der DB-Daten" + "`n"
            $SourceData=$SourceData + "12`tFileSystem`tPersonenDatei`tPersonen.sdb`tDB-Datei f�r Personendaten" + "`n"
            $SourceData=$SourceData + "13`tFileSystem`tKnotenDatei`tKnoten.sdb`tDB-Datei f�r Knotendaten" + "`n"
            $SourceData=$SourceData + "14`tFileSystem`tAdresseDatei`tAdressen.sdb`tDB-Datei f�r Adressdaten" + "`n"


            $SourceData| Out-File -FilePath $SourceDataFile
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei wurde erzeugt"}
        
            $SourceData=Get-Content $SourceDataFile
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei wurde frisch eingelesen"}

            if ($SourceData.Length -eq 0){
                if ($DebugMode -eq "true") {Write-Host "Settings-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!"}
                #read-host �Press ENTER to continue...�
                $erg=[System.Windows.Forms.MessageBox]::Show("Settings-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!", "FileSystem Zugriffs-Fehler", "1", "None" )
                $host.Exit()
            }
        }
        
        if ($DebugMode -eq "true") {$text= "## GetSettingsData endet `t- mit R�ckgabe-Parameter SourceData: (" + $SourceData + ")";Write-Host $text}
        return $SourceData
    }

    function GetParameterFromSettings {
        param (
            $Parametername=""
        )
        ##################################################
        # Version V02
        # vom 7.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
            
        if ($DebugMode -eq "true") {$text= "## GetParameterFromSettings startet `t- mit Parameter Parametername: (" + $Parametername + ")";Write-Host $text}

        $DummyText=""
        # Achtung Namensaenderung!
        $SourceDataZeilenSpit=$global:SettingsData.Split("`n")

        for($i=0; $i -lt $SourceDataZeilenSpit.count; $i++){

                if ($SourceDataZeilenSpit[$i].length -ne 0)                            
                {
                    $SourceDataSplit=$SourceDataZeilenSpit[$i].Split("`t")

                    if ($DebugMode -eq "true") { $text="Parmeter " + $SourceDataSplit[2];Write-Host $text}
                    if ($Parametername -eq $SourceDataSplit[2]){
                        
                        $DummyText=$SourceDataSplit[3]

                        if ($Parametername -eq "LogMode"){
                            if ($SourceDataSplit[3] -eq "wahr"){
                                    $DummyText="true"
                                } elseif ($SourceDataSplit[3] -eq "true"){
                                    $DummyText="true"
                                }elseif ($SourceDataSplit[3] -eq "falsch"){
                                    $DummyText="false"
                                } elseif ($SourceDataSplit[3] -eq "false"){
                                    $DummyText="false"
                            }
                        } 
                        if ($Parametername -eq "DebugMode"){
                            if ($SourceDataSplit[3] -eq "wahr"){
                                    $DummyText="true"
                                } elseif ($SourceDataSplit[3] -eq "true"){
                                    $DummyText="true"
                                } elseif ($SourceDataSplit[3] -eq "falsch"){
                                    $DummyText="false"
                                } elseif ($SourceDataSplit[3] -eq "false"){
                                    $DummyText="false"
                            }
                        } 
                    }
                }   
        } 
    
        if ($DebugMode -eq "true") {$text="## GetParameterFromSettings endet `t- mit R�ckgabe-Parameter DummyText: (" + $DummyText + ")";Write-Host $text}
        return $DummyText
    }
        
    function DetectOsUserLanguage() {
        
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        $UserLanguageList=Get-WinUserLanguageList
        $MainLanguage=$UserLanguageList[0].languagetag.ToUpper()

        return $MainLanguage
    }

    function GetLanguageFileName() {
        Param(
            $ActiveLanguage
        )
        ##################################################
        # Version V02
        # vom 11.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        
        if ($DebugMode -eq "true") {$text="## GetLanguageFileName startet `t- mit Parameter ActiveLanguage: (" + $ActiveLanguage + ")";Write-Host $text}

        $DBPfad=GetParameterFromSettings -Parametername "DatenZielPfad"

        if (Test-Path -Path $DBPfad) {
            } else {
                $DBPfad = $global:BasisPfad + "\DBDaten"
                if (Test-Path -Path $DBPfad) {
                    } else {
                        $DBPfad = $global:BasisPfad
                }
        }

        if ($ActiveLanguage -eq "DE-DE") {$LanguageFileName=$DBPfad + "\SprachPaket_DE.sdb"}
        if ($ActiveLanguage -eq "EN-EN") {$LanguageFileName=$DBPfad + "\SprachPaket_EN.sdb"}

        if ($LanguageFileName -eq "") {$LanguageFileName=$DBPfad + "\SprachPaket_EN.sdb"}

        if (Test-Path -Path $LanguageFileName) {
            } else {
                $text="LanguageFile: (" + $LanguageFileName + ") nicht gefunden!";Write-Host $text
        }
                        
        if ($DebugMode -eq "true") {$text="## GetLanguageFileName endet `t- mit R�ckgabe-Parameter LanguageFileName: (" + $LanguageFileName + ")";Write-Host $text}
        return $LanguageFileName
    }

    function GetLanguageData {
        Param(
            $LanguageDBFileName
        )
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") {$text="## GetLanguageData startet `t- mit Parameter LanguageDBFileName: (" + $LanguageDBFileName + ")";Write-Host $text}

        $SourceData=""
        if ($LanguageDBFileName -ne "") {
            $SourceData=Get-Content $LanguageDBFileName
        }

        if ($SourceData.Length -eq 0){
            if ($DebugMode -eq "true") {Write-Host "Settings-Datei existiert nicht/oder ist leer"}
        }
        
        if ($DebugMode -eq "true") {$text="## GetLanguageData endet `t- mit R�ckgabe-Parameter SourceData: (" + $SourceData + ")";Write-Host $text}
        return $SourceData
    }

    function GetTextFromLanguageDB {
        param (
            $ID=""
        )
        ##################################################
        # Version V01
        # vom 8.4.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        if ($DebugMode -eq "true") { $text="## GetTextFromLanguageDB startet zum Auslesen von ID:`t" + $ID;Write-Host $text}

        $DummyText=""
        # Achtung Namensaenderung!
        $SourceDataZeilenSpit=$Global:SprachDB.Split("`n")

        for($i=0; $i -lt $SourceDataZeilenSpit.count; $i++){

                if ($SourceDataZeilenSpit[$i].length -ne 0)                            
                {
                    $SourceDataSplit=$SourceDataZeilenSpit[$i].Split("`t")

                    if ($DebugMode -eq "true") { $text="Pr�fe Parmeter (`t" + $SourceDataSplit[1] + ") hat Wert:(`t" + $SourceDataSplit[2] + ")";Write-Host $text}
                    if ($ID -eq $SourceDataSplit[1]){
                        $DummyText=$SourceDataSplit[2]
                        $i = $SourceDataZeilenSpit.count
                    }
                }   
        } 
    
        if ($DebugMode -eq "true") {Write-Host "## GetTextFromLanguageDB endet `t- mit R�ckgabe-Parameter DummyText: (" + $DummyText + ")"}
        return $DummyText
    }

    function DataInit () {
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################
        $global:AktPersonNr=0
        #$global:PersonenDB=""
       # $global:KnotenDB=""
        $Global:PersonenDrawListe=""
        $Global:KnotenCheckListe=""
        $Global:AktPersonenDrawListeLnr=1
        $Global:DrawPosListex=""
        $Global:MinusDrawPosListex=""
        $Global:Route=""
        #DatenEinlesen

        $Global:MaxSpaltenPos=0
        $Global:MaxZeilenPos=0
    }

    function GetPersonenData {
        ##################################################
        # Version V03
        # vom 11.4.2023
        ##################################################

        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {Write-Host "DBOrdner:`t";  Write-Host  $DBOrdner}
        $PersonenDBDateiName=GetParameterFromSettings ("PersonenDatei")
        if ($DebugMode -eq "true") {Write-Host "PersonenDBDateiName:`t";  Write-Host  $PersonenDBDateiName}
        $PersonenDBDatei=$DBOrdner + "\" + $PersonenDBDateiName

        $Neu=""
        if (Test-Path -Path $PersonenDBDatei) {


                $PersonenDB=Get-Content $PersonenDBDatei

                if ($PersonenDB.Length -eq 0){
                    if ($DebugMode -eq "true") {Write-Host "Personen-DB-Datei existiert nicht/oder ist leer"}

                    # Standard-Trennzeichen ist TAB ( `t )
                    $SourceData="LNr`tVorname`tName`tGeburtsname`tGeburtsdatum`tSterbedatum`tBemerkung`tZusatzVornamen`tmobil`tmail`tGeburtsOrt`tSterbeOrt/Friedhof`treligion`tgeschl`tnationalit�t`t(HeinzStammbaumLnr)" + "`n"


                    $SourceData| Out-File -FilePath $PersonenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Personen-DB-Datei wurde erzeugt"}
        
                    $PersonenDB=Get-Content $PersonenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Personen-DB-Datei wurde frisch eingelesen"}

                    if ($PersonenDB.Length -eq 0){
                        if ($DebugMode -eq "true") {Write-Host "Personen-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!"}
                        #read-host �Press ENTER to continue...�
                        $erg=[System.Windows.Forms.MessageBox]::Show("Personen-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!", "FileSystem Zugriffs-Fehler", "1", "None" )
                        $host.Exit()
                    }
                }

                # Cleanup
                $ErgText=""
                $PersonenDBSplit=$PersonenDB.split("`n")
                for($i=0; $i -lt $PersonenDBSplit.count; $i++){
                    if ($DebugMode -eq "true") {$Text="Cleanup Person " + $i + " : " + $PersonenDBSplit[$i]; Write-Host $Text}
                    if ($PersonenDBSplit[$i] -ne ""){
                        if ($ErgText -eq "") {
                                $ErgText="" + $PersonenDBSplit[$i]
                            } else {
                                $ErgText=$ErgText + "`n" + $PersonenDBSplit[$i]
                        }
                    }
                    if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}
                }
        
                if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}

                $ErgText| Out-File -FilePath $PersonenDBDatei

                $Neu=Get-Content $PersonenDBDatei
            } else {
                $text="PersonenDB-Datei: (" + $PersonenDBDatei + ") nicht gefunden!";Write-Host $text

        }

        return $Neu
    }

    function GetKnotenData {
        ##################################################
        # Version V03
        # vom 11.4.2023
        ##################################################

        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {Write-Host "DBOrdner:`t";  Write-Host  $DBOrdner}
        $KnotenDBDateiName=GetParameterFromSettings ("KnotenDatei")
        if ($DebugMode -eq "true") {Write-Host "KnotenDateiName:`t";  Write-Host  $KnotenDBDateiName}
        $KnotenDBDatei=$DBOrdner + "\" + $KnotenDBDateiName

        
        $Neu=""
        if (Test-Path -Path $KnotenDBDatei) {


                $KnotenDB=Get-Content $KnotenDBDatei

                if ($KnotenDB.Length -eq 0){
                    if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei existiert nicht/oder ist leer"}

                    # Standard-Trennzeichen ist TAB ( `t )
                    $SourceData="LNr`tPersonLNr`tVaterLNr`tMutterLNr`tPartnerLNr`tKnoten2LNr`tKnoten3LNr`tKnoten4LNr`tKind1LNr`tKind2LNr`tKind3LNr`tKind4LNr`tKind5LNr`tKind6LNr`tKind7LNr`tKind8LNr`tKind9LNr`tKind10LNr`tKind11LNr`tKind12LNr`tKind13LNr`tKind14LNr`tStartDatum`tEndDatum`tTrau-Ort" + "`n"

                    $SourceData| Out-File -FilePath $KnotenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde erzeugt"}
        
                    $KnotenDB=Get-Content $KnotenDBDatei
                    if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei wurde frisch eingelesen"}

                    if ($KnotenDB.Length -eq 0){
                        if ($DebugMode -eq "true") {Write-Host "Knoten-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!"}
                        #read-host �Press ENTER to continue...�
                        $erg=[System.Windows.Forms.MessageBox]::Show("Knoten-DB-Datei konnte nicht eingelesen werden - Probleme mit dem Filesystem!!!", "FileSystem Zugriffs-Fehler", "1", "None" )
                        $host.Exit()
                    }
                }
    

    
                # Cleanup
                $ErgText=""
                $KnotenDBSplit=$KnotenDB.split("`n")
                for($i=0; $i -lt $KnotenDBSplit.count; $i++){
                    if ($DebugMode -eq "true") {$Text="Cleanup Person " + $i + " : " + $KnotenDBSplit[$i]; Write-Host $Text}
                    if ($KnotenDBSplit[$i] -ne ""){
                        if ($ErgText -eq "") {
                                $ErgText="" + $KnotenDBSplit[$i]
                            } else {
                                $ErgText=$ErgText + "`n" + $KnotenDBSplit[$i]
                        }
                    }
                    if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}
                }
        
                if ($DebugMode -eq "true") {$Text="ErgText " + $ErgText; Write-Host $Text}

                $ErgText| Out-File -FilePath $KnotenDBDatei

                $Neu=Get-Content $KnotenDBDatei
            } else {
                $text="KnotenDB-Datei: (" + $KnotenDBDatei + ") nicht gefunden!";Write-Host $text

        }
        return $Neu
    }
    
    function GetKnotenHeaderListe(){
        ##################################################
        # Version V02
        # vom 14.4.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
       # $DebugMode = "true"

        if ($DebugMode -eq "true") { $text="## GetKnotenHeaderListe startet ";Write-Host $text}

        $KnotenHeaderListe=@()
        $KnotenDBSplit=$Global:KnotenDB.Split("`n")
        $KnotenheaderSplit=$KnotenDBSplit[0].Split("`t")
        # leere Liste erzeugen
        for($i=0; $i -lt $KnotenheaderSplit.count+$global:KindStartNr; $i++){
            $KnotenHeaderListe=$KnotenHeaderListe + 0
        }

        if ($DebugMode -eq "true") { $text="## GetKnotenHeaderListe `t-- leere KnotenHeaderListe: [" +  $KnotenHeaderListe + "]";Write-Host $text}
        
        # Liste fuellen
        $MaxKindNr=0
        for($i=0; $i -lt $KnotenheaderSplit.count; $i++){
            if ($DebugMode -eq "true") { $text=" `t-- Element [" + $i + "] : [" +  $KnotenheaderSplit[$i] + "]";Write-Host $text}
            switch ( $KnotenheaderSplit[$i].ToUpper() ) {
                "LNR".ToUpper() {       $KnotenHeaderListe[0] = $i}
                "PersonLNr".ToUpper() { $KnotenHeaderListe[1] = $i}
                "VaterLNr".ToUpper() {  $KnotenHeaderListe[2] = $i}
                "MutterLNr".ToUpper() { $KnotenHeaderListe[3] = $i}
                "PartnerLNr".ToUpper() {$KnotenHeaderListe[4] = $i}
                "StartDatum".ToUpper() {$KnotenHeaderListe[5] = $i}
                "EndDatum".ToUpper() {  $KnotenHeaderListe[6] = $i}
                "Trau-Ort".ToUpper() {  $KnotenHeaderListe[7] = $i}
            }
            $Dummy2=""
            $dummy=$KnotenheaderSplit[$i].ToUpper() + "D"
            if ($DebugMode -eq "true") { $text=" `t-- Kind : [" +  $KnotenheaderSplit[$i] + "]";Write-Host $text}
            $KindSplit=$dummy.split("D")
            if ($KindSplit.count -gt 1) {
                if ($DebugMode -eq "true") { $text=" `t-- KindSplit[1] : [" +  $KindSplit[1] + "]";Write-Host $text}
                $Dummy2=$KindSplit[1] + "L"
                $KindNrSplit=$Dummy2.split("L")
                if ($DebugMode -eq "true") { $text=" `t-- KindNrSplit[1] : [" +  $KindNrSplit[1] + "]";Write-Host $text}
                if ($DebugMode -eq "true") { $text=" `t-- KindNrSplit.count : [" +  $KindNrSplit.count + "]";Write-Host $text}
                if ($KindNrSplit.count -eq 3) { 
                    if ($KindNrSplit[1] -eq "NR") {
                        if ($DebugMode -eq "true") { $text=" `t-- KindNr : [" +  $KindNrSplit[0] + "] - MaxKindNr:" + $MaxKindNr;Write-Host $text}
                        [int]$KindNr=$KindNrSplit[0]
                        $KnotenHeaderListe[$global:KindStartNr + $KindNr-1]=$i
                        if ($DebugMode -eq "true") { $text=" `t-- KindNr : [" +  $KindNr + "] - MaxKindNr:[" + $MaxKindNr + "]";Write-Host $text}
                        if ($MaxKindNr -lt $KindNr) {
                                $MaxKindNr = $KindNr
                                if ($DebugMode -eq "true") { $text=" `t-- Ja! MaxKindNr:[" + $MaxKindNr + "]";Write-Host $text}
                            } else {
                                if ($DebugMode -eq "true") { $text=" `t-- N�! KindNr : [" +  $KindNr + "] - MaxKindNr:[" + $MaxKindNr + "]";Write-Host $text}
                        }
                    }
                }
            }
        }

        if ($DebugMode -eq "true") { $text="## GetKnotenHeaderListe `t-- bef�llte KnotenHeaderListe: [" +  $KnotenHeaderListe + "]";Write-Host $text}

        if ($DebugMode -eq "true") { $text="## GetKnotenHeaderListe `t-- Anzahl Stellen: [" +  ($global:KindStartNr + $MaxKindNr) + "]";Write-Host $text}

        $NeueListe="" + $KnotenHeaderListe[0]
        for($i=1; $i -lt ($global:KindStartNr + $MaxKindNr); $i++){

            $NeueListe=$NeueListe + "`t" + $KnotenHeaderListe[$i]
        }

        if ($DebugMode -eq "true") { $text="## GetKnotenHeaderListe endet mit R�ckgabe der KnotenHeaderListe: [" + $NeueListe + "]";Write-Host $text}
        return $NeueListe
    }

    function GetPersonMitNr {
        param (
            $PersonLnr="0"
        )
        ##################################################
        # Version V02
        # vom 7.4.2023
        ##################################################
    
        if ($DebugMode -eq "true") { Write-Host "PersonenDB:";Write-Host $global:PersonenDB}
    
        $PersonenDBZeilenSplit=$global:PersonenDB.Split("`n")

        #$PersonenDB
        $ErgText=""
    
        if ($DebugMode -eq "true") {$Text="Suche Daten von Person Nr:" +  $PersonLnr;Write-Host $Text}
        if ($PersonenDBZeilenSplit.count -gt 1) {
            for($i=1; $i -lt $PersonenDBZeilenSplit.count; $i++){
                if ($DebugMode -eq "true") {$Text="Eintrag:" +  $i + " von " + $global:PersonenDB.count + " : " + $global:PersonenDB[$i];Write-Host $Text}

                if ($PersonenDBZeilenSplit[$i] -ne "")                            
                {
                    $PersonenDBSplit=$PersonenDBZeilenSplit[$i].Split("`t")
                
                    if ($DebugMode -eq "true") {$Text="Treffer wenn :" +  $PersonLnr + " == " + $PersonenDBSplit[0];Write-Host $Text}
                    if ($PersonLnr -eq $PersonenDBSplit[0]) {
                        if ($DebugMode -eq "true") {Write-Host "getroffen"}
                        $ErgText=$PersonenDBZeilenSplit[$i]
                    }
                }   
            } 
        }

        if ($DebugMode -eq "true") {$Text="ErgText:" +  $ErgText;Write-Host $Text}
        return $ErgText
    }
    
    function FindeAlleKnotenVonPersonNr {
        param (
            $PersonLnr="0"
        )
        ##################################################
        # Version V02
        # vom 14.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true") {$Text= Write-Host "starte FindeAlleKnotenVonPersonNr mit Person Nr.:" + $PersonLnr;Write-Host $Text}


        #$global:KindStartNr=0
        #$global:KnotenHeaderListe=@()
        
        if ($DebugMode -eq "true") {$Text="global:KnotenHeaderListe:" +  $global:KnotenHeaderListe;Write-Host $Text}
        $KnotenHeaderListeSplit=$global:KnotenHeaderListe.split("`t")

        $ErgText=""
    
        if ($DebugMode -eq "true") {$Text="Suche Knoten von Person Nr:" +  $PersonLnr;Write-Host $Text}
        for($i=0; $i -lt $global:KnotenDB.count; $i++){
            if ($DebugMode -eq "true") {$Text="Eintrag:" +  $i + " von " + $global:KnotenDB.count + " : " + $global:KnotenDB[$i];Write-Host $Text}

                if ($global:KnotenDB[$i].length -ne 0)                            
                {
                    $KnotenDBSplit=$global:KnotenDB[$i].Split("`t")
                
                    if ($DebugMode -eq "true") {$Text="Treffer wenn :" +  $PersonLnr + " == " + $KnotenDBSplit[0];Write-Host $Text}
                    $KnotenDBPersonPos=$KnotenHeaderListeSplit[1]
                    if ($PersonLnr -eq $KnotenDBSplit[$KnotenDBPersonPos]) {

                        if ($DebugMode -eq "true") {Write-Host "getroffen"}
                        if ($ErgText -eq "") {
                                $ErgText = "" + $i
                            } else{
                                $ErgText=$ErgText + "`t" + $i
                        }
                    }
                }   
        } 
    
        if ($DebugMode -eq "true") {$Text="ErgText:" +  $ErgText;Write-Host $Text}
        return $ErgText
    }

    function FindePartnerKnotenVonKnoten {
        param (
            $KnotenNr="0"
        )
        ##################################################
        # Version V02
        # vom 14.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        $PaKnoten=0
        
        $KnotenHeaderListeSplit=$global:KnotenHeaderListe.split("`t")

        if ($KnotenNr -gt 0) {
            $KnotenDBSplit=$global:KnotenDB.split("`n")
            $KnotenSplit=$KnotenDBSplit[$KnotenNr].split("`t")
            $KnotenDBPePos=$KnotenHeaderListeSplit[1]
            $KnotenDBPaPos=$KnotenHeaderListeSplit[4]
            $PeNr=$KnotenSplit[$KnotenDBPePos]
            $PaNr=$KnotenSplit[$KnotenDBPaPos]
            
            $PaKnotenListe=FindeAlleKnotenVonPersonNr($PaNr)   

            if ($PaKnotenListe -ne "") {
                $PaKnotenListeSplit = ($PaKnotenListe + "`t").split("`t")

                for($i=0; $i -lt $PaKnotenListeSplit.count; $i++){
                    $MglPaKnotenNr=$PaKnotenListeSplit[$i]
                    $MglPaKnotenSplit=$KnotenDBSplit[$MglPaKnotenNr].split("`t")
                    if ($MglPaKnotenSplit[$KnotenDBPaPos] -eq $PeNr) {
                        $PaKnoten=$MglPaKnotenNr
                    }
                }
            }

        }
        if ($DebugMode -eq "true"){$Text="Knoten (" + $PaKnoten + ") ist gefundener PartnerKnoten zu Knoten (" + $KnotenNr + ")";Write-Host $Text}
        return $PaKnoten
    }

    function WritePersonenData() {
        param (
            $NeueDaten=""
        )
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################

        # Neue Personendb speichern
        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {Write-Host "DBOrdner:`t";  Write-Host  $DBOrdner}
        $PersonenDBDateiName=GetParameterFromSettings ("PersonenDatei")
        if ($DebugMode -eq "true") {Write-Host "PersonenDBDateiName:`t";  Write-Host  $PersonenDBDateiName}
        $PersonenDBDatei=$DBOrdner + "\" + $PersonenDBDateiName
        $NeueDaten| Out-File -FilePath $PersonenDBDatei

    }

    function WriteKnotenData() {
        param (
            $NeueDaten=""
        )
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################

        # Neue Personendb speichern
        $DBOrdner=GetParameterFromSettings ("DatenZielPfad")
        if ($DebugMode -eq "true") {Write-Host "DBOrdner:`t";  Write-Host  $DBOrdner}

        $KnotenDBDateiName=GetParameterFromSettings ("KnotenDatei")
        if ($DebugMode -eq "true") {Write-Host "KnotenDateiName:`t";  Write-Host  $KnotenDBDateiName}
        $KnotenDBDatei=$DBOrdner + "\" + $KnotenDBDateiName

        $NeueDaten| Out-File -FilePath $KnotenDBDatei

    }

    function SetGlobalParameterEM(){
        
        ##################################################
        # Version V01
        # vom 10.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        $global:BasisPfad=DetectScriptPath -PowershellVersion  DetectPSVersion

        $Global:SettingsDataFile = $global:BasisPfad + "\Settings.def"

        if ($DebugMode -eq "true") {
            $Text="## SetGlobalParameter`t- gesetzte globale Parameter" + "`n"
            $text=$Text + "`t`t- global:BasisPfad:`t" + $global:BasisPfad + "`n"
            $text=$Text + "`t`t- Global:SettingsDataFile:`t" + $Global:SettingsDataFile + "`n"
            $text=$Text +  "`n"
            Write-Host  $Text
        }

        $Global:SettingsData=GetSettingsData -SourceDataFile $Global:SettingsDataFile
        if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:SettingsData :(" + $Global:SettingsData + ")";Write-Host $Text}

        $DebugDummy=GetParameterFromSettings -Parametername "DebugMode"
        if ($DebugDummy -eq "1") {$Global:DebugMode= "true"}
        $LogDummy=GetParameterFromSettings -Parametername "LogMode"
        if ($LogDummy -eq "1") {$Global:LogMode= "true"}

        $Language=GetParameterFromSettings -Parametername "Sprache"
        if ($Language -eq "") {
                $Global:Language=DetectOsUserLanguage 
                if ($DebugMode -eq "true") { $text="## `t- Sprach-Feld in den Settings ist leer => erkannte User-Profil-Haupt-Sprache:`t" + $Global:Language + " wird benutzt"; Write-Host $text}
            } else {
                $Global:Language=$Language.ToUpper()
                if ($DebugMode -eq "true") { $text="## `t- Sprach-Feld in den Settings ist definiert:`t" + $Global:Language + " wird benutzt"; Write-Host $text}
        }

        $SprachDBFileName=GetLanguageFileName -ActiveLanguage $Global:Language
        if ($DebugMode -eq "true") {$Text="## `t- Parameter SprachDBFileName :(" + $SprachDBFileName + ")";Write-Host $Text}
        $Global:SprachDB=GetLanguageData -LanguageDBFileName  $SprachDBFileName
        if ($DebugMode -eq "true") {$Text="## `t- Parameter Global:SprachDB :(" + $Global:SprachDB + ")";Write-Host $Text}



        $Dummy=GetParameterFromSettings -Parametername "GestorbenZeichen"
        if ($Dummy.StartsWith("[char]0x") -eq $true) {
                $global:GestorbenZeichen=([char][int]$dummy.SubString(6))
            } else {
                $global:GestorbenZeichen=$Dummy
        }
        $Dummy=GetParameterFromSettings -Parametername "GeborenZeichen"
        if ($Dummy.StartsWith("[char]0x") -eq $true) {
                $global:GeborenZeichen=([char][int]$dummy.SubString(6))
            } else {
                $global:GeborenZeichen=$Dummy
        }
        $Dummy=GetParameterFromSettings -Parametername "HochzeitZeichen"
        if ($Dummy.StartsWith("[char]0x") -eq $true) {
                $global:HochzeitZeichen=([char][int]$dummy.SubString(6))
            } else {
                $global:HochzeitZeichen=$Dummy
        }
        $Dummy=GetParameterFromSettings -Parametername "ScheidungsZeichen"
        if ($Dummy.StartsWith("[char]0x") -eq $true) {
                $global:ScheidungsZeichen=([char][int]$dummy.SubString(6))
            } else {
                $global:ScheidungsZeichen=$Dummy
        }


        $global:PersonenDB=GetPersonenData
        if ($DebugMode -eq "true") {Write-Host "PersonenDB:`t";  Write-Host $global:PersonenDB}

        $global:KnotenDB=GetKnotenData
        if ($DebugMode -eq "true") {Write-Host "KnotenDB:`t";  Write-Host $global:KnotenDB}

        
        $global:KindStartNr=10
        $global:KnotenHeaderListe=GetKnotenHeaderListe
        if ($DebugMode -eq "true") {$Text= "KnotenHeaderListe:`t" + $global:KnotenHeaderListe;  Write-Host $Text}


        if ($DebugMode -eq "true") {$text="Notbremse"; read-host $Text}
        
        if ($DebugMode -eq "true") {$text="## SetGlobalParameterTM endet ";Write-Host $text}
    }
 

#endregion Tools


#region PrepareDrawListe

    function CheckKnoten() {
        param (
            [int]$KnotenLnr=0
        )
        ##################################################
        # Version V02
        # vom 15.4.2023
        ##################################################
        #
        # markiert den aktuellen Knoten in der KnotenCheck-Liste als erledigt
        #
        ##################################################


        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        # Formatierungen ausschalten [char]2=[int]50
        #if ($KnotenLnr -gt 48) {$KnotenLnr=$KnotenLnr-48}
        if ($DebugMode -eq "true"){$Text= "## CheckKnoten - Start-Parameter`n`t--`tGlobal:KnotenCheckListe:`t" + $Global:KnotenCheckListe + "`n`t--`tKnotenLnr:`t" + $KnotenLnr; Write-Host $Text}

        $KnotenCheckSplit=$Global:KnotenCheckListe.split("`t")
        $NeueListe=""

        if ($DebugMode -eq "true"){$Text= "## CheckKnoten - KnotenLnr:`t" + $KnotenLnr + "`n`t--`tKnotenLnr:`t" + $KnotenLnr; Write-Host $Text}

        for([int]$i=1; $i -lt $KnotenCheckSplit.count; $i++){
            if ($i -eq $KnotenLnr) {
                    if ($DebugMode -eq "true"){Write-Host "ja"}
                    $Wert="1"
                } else {
                    if ($DebugMode -eq "true"){Write-Host "nein"}
                    $Wert=$KnotenCheckSplit[($i)]
            }
            if ($DebugMode -eq "true"){$Text= "## CheckKnoten - Wert:`t" + $Wert; Write-Host $Text}
            
            $NeueListe=$NeueListe + "`t"+ $Wert


        }
        $Global:KnotenCheckListe=$NeueListe

        if ($DebugMode -eq "true"){$Text= "## CheckKnoten - Rueckgabe`n`t--`tGlobal:KnotenCheckListe:`t" + $Global:KnotenCheckListe; Write-Host $Text}

    }

    function IncPosWertInListe() {
        param (
            [int]$Pos=-1,
            $Liste=""
        )
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        # Listen-Wert an Position Pos um 1 erhoehen

                if ($DebugMode -eq "true"){$Text= "`n##################################`n## IncPosWertInListe startet - Parameter`n`t--`tListe:`t[" + $Liste + "]`n`t--`Pos:`t" + $Pos; Write-Host $Text}
                $Dummy=""
                $Dummy1=""

                $ListeSplit=$Liste.split("`t")
                if ($Pos -gt -1) { # nur zur Sicherheit - sollte immer so sein
                    
                    # alle Elemente vor der pos werden kopiert (wenn pos=0 ist nix zu tun)
                    if ($Pos -gt 0) { # nur zur Sicherheit - sollte immer so sein
                        $Dummy1 = $ListeSplit[0]
                        for($i=1; $i -lt $Pos; $i++){
                            $Dummy1=$Dummy1 + "`t" + $ListeSplit[$i]
                            if ($DebugMode -eq "true"){$Text= "`t--`ti:`t" + $i + "`t--`tListe[i]:`t[" + $ListeSplit[$i] + "]`tDummy1:`t" + $Dummy1; Write-Host $Text}
                        }
                    }

                    # gesuchtes Element erhoehen
                    [int]$AltWert=[int]$ListeSplit[$Pos]
                    $NeuWert=$AltWert + 1
                    if ($Dummy1 -eq "") {
                            $Dummy2="" + $NeuWert 
                        } else {
                            $Dummy2="" + "`t" + $NeuWert 
                    }
                    if ($DebugMode -eq "true"){$Text= "`t--`tWert wurde von AltWert:`t" + $AltWert + "`t zu NeuWert:`t" + $NeuWert + "`t=> Dummy2:`t[" + $Dummy2 + "]"; Write-Host $Text}

                    
                    # alle restlichen Elemente hinter der pos werden kopiert
                    for($i=($Pos + 1); $i -lt ($ListeSplit.count); $i++){
                        #if ($DebugMode -eq "true"){$Text= "`t--`ti:`t" + $i + "`t--`tDrawPosListexSplit[i]:`t" + $DrawPosListexSplit[$i] + "`tDummy3:`t[" + $Dummy3 + "]"; Write-Host $Text}
                        $Dummy3=$dummy3 + "`t" + $ListeSplit[$i]
                        if ($DebugMode -eq "true"){$Text= "`t--`ti:`t" + $i + "`t--`tListe[i]:`t[" + $ListeSplit[$i] + "]`tDummy3:`t" + $Dummy3; Write-Host $Text}
                    }
        
                    $Dummy=$Dummy1 + $Dummy2 + $Dummy3
                    if ($DebugMode -eq "true"){$Text= "## IncPosWertInListe --`tR�ckgabe von Dummy:[`t" + $Dummy + "]"; Write-Host $Text}

                } else {if ($DebugMode -eq "true"){$Text= "## IncPosWertInListe`t--`tFehler! Position ist negativ! darf so nicht sein - muss die Negativ-Liste benutzt werden!"; Write-Host $Text}}

            if ($DebugMode -eq "true"){$Text= "## IncPosWertInListe endet`t--`tR�ckgabeParameter Dummy:`t[" + $Dummy + "]`n###############################################`n"; Write-Host $Text}
            return $Dummy
     }

    function FindNeueSpalte_V2() {
        param (
            [int]$DrawSpalte=0,
            [int]$DrawZeile=0
        )
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        $DuTListe=""
        [int]$DuTZeile=0
        [int]$DuTSpalte=0

        if ($DebugMode -eq "true"){$Text= "`n######################################################`n## FindSpalte startet`t-- Parameter`n`t`tGlobal:DrawPosListexAnz:`t[" + $Global:DrawPosListex.split("`t").Count + "]`n`t`tGlobal:DrawPosListex:`t[" + $Global:DrawPosListex + "]"; Write-Host $Text}
        if ($DebugMode -eq "true"){$Text= "`t`tGlobal:MinusDrawPosListex:`t[" + $Global:MinusDrawPosListex.split("`t").Count + "]`n`t`tGlobal:MinusDrawPosListex:`t[" + $Global:MinusDrawPosListex + "]"; Write-Host $Text}
        if ($DebugMode -eq "true"){$Text= "`t`tDrawSpalte:`t[" + $DrawSpalte + "]`n`t`tDrawZeile:`t[" + $DrawZeile + "]"; Write-Host $Text}
        
        if ($DrawZeile -lt 0) 
            {
                if ($DebugMode -eq "true"){$Text= "## FindSpalte`t-- DrawZeile ist negativ - in Minus-Liste kucken"; Write-Host $Text}

                $DuTListe=$Global:MinusDrawPosListex
                $DuTZeile=-$DrawZeile
                $DuTSpalte=$DrawSpalte

            } 
            else 
            {
                if ($DebugMode -eq "true"){$Text= "## FindSpalte`t-- DrawZeile ist positiv - in Plus-Liste kucken"; Write-Host $Text}

                $DuTListe=$Global:DrawPosListex
                $DuTZeile=$DrawZeile
                $DuTSpalte=$DrawSpalte
            }


        # Neue Zeile noetig ?
        if ($DebugMode -eq "true"){$Text= "## FindSpalte`t-- DuTZeile:[" + $DuTZeile + "]>=DuTListe.split(""`t"").Count:[" + $DuTListe.split("`t").Count + "] ??"; Write-Host $Text}
        if ($DuTZeile -ge $DuTListe.split("`t").Count) {
            if ($DebugMode -eq "true"){$Text= "## FindSpalte`t-- Ja! => DuTListe wird um neue Zeile erweitert"; Write-Host $Text}
            $DuTListe=$DuTListe + "`t0"
            if ($DebugMode -eq "true"){$Text= "`t-- DuTListe:`t[" + $DuTListe + "]"; Write-Host $Text}
        } else { if ($DebugMode -eq "true"){$Text= "## FindSpalte`t-- Nein!"; Write-Host $Text}}

        # angefragte Spalte groesser als max spalte in Liste ( sollte immer so sein!)
        if ($DebugMode -eq "true"){$Text= "## FindSpalte`t-- DuTSpalte:[" + $DuTSpalte + "]>=DuTListe.split(""`t"")[$DuTZeile]:[" + $DuTListe.split("`t")[$DuTZeile] + "] ??"; Write-Host $Text}
        if ($DuTSpalte -ge $DuTListe.split("`t")[$DuTZeile]) {
                    
            if ($DebugMode -eq "true"){$Text= "## FindSpalte`t-- Ja! => SpaltenWert in DuTListe wird erweitert"; Write-Host $Text}
            $ErgListe = IncPosWertInListe -Pos $DuTZeile -Liste $DuTListe
            if ($DebugMode -eq "true"){$Text= "`t-- Ergebnis: ErgListe:`t[" + $ErgListe + "]"; Write-Host $Text}
            $DuTListe = $ErgListe
            if ($DebugMode -eq "true"){$Text= "`t-- => DuTListe:`t[" + $DuTListe + "]"; Write-Host $Text}

            #Neuen Wert aus Liste auslesen
            $DuTSpalte=$DuTListe.split("`t")[$DuTZeile]
            if ($DebugMode -eq "true"){$Text= "`t--DuTSpalte korrigiert`tDuTSpalte:`t" + $DuTSpalte; Write-Host $Text}
        } else { if ($DebugMode -eq "true"){$Text= "## FindSpalte`t-- Nein!"; Write-Host $Text}}
        
  
        if ($DrawZeile -lt 0) 
            {
                if ($DebugMode -eq "true"){$Text= "## FindSpalte`t-- DrawZeile ist negativ - in Minus-Liste zur�ckspeichern"; Write-Host $Text}

                $Global:MinusDrawPosListex=$DuTListe

            } 
            else 
            {
                if ($DebugMode -eq "true"){$Text= "## FindSpalte`t-- DrawZeile ist positiv - in Plus-Liste zur�ckspeichern"; Write-Host $Text}

                $Global:DrawPosListex=$DuTListe
            }       


        if ($DebugMode -eq "true"){$Text= "## FindSpalte endet`t--`tR�ckgabeParameter DuTSpalte:`t[" + $DuTSpalte + "]`n###############################################`n"; Write-Host $Text}
        return $DuTSpalte
    }

    function DefinePersonHtmlID() {
        param (
            $PersonLnr=0,
            $KnotenLnr=0,
            $Wdh="false"
        )
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        # Pe knoten oder Pa Knoten ==> der kleinere wird benutzt 
        $AktKnNr=$KnotenLnr

        $PaKn=FindePartnerKnotenVonKnoten -KnotenNr $KnotenLnr
        
        if ($PaKn -ne 0) {
            if ($PaKn -lt $KnotenLnr) {
                $AktKnNr=$PaKn
            }
        }

        if ($Wdh -eq"false") {
                $NewID="P_" + $PersonLnr + "-K_" + $AktKnNr
            } else {
                $NewID="DP_" + $PersonLnr + "-K_" + $AktKnNr
        }

        return $NewID
    }

    function DefineKnotenHtmlID() {
        param (
            $KnotenLnr=0
        )
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################

        $NewID="K_" + $KnotenLnr

        return $NewID
    }

    function FindPersonAusDrawListe() {
        param (
             $PersonLnr=0
        )
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        $Treffer=-1


        $ListeSplit=$Global:PersonenDrawListe.split("`n")
        if ($DebugMode -eq "true"){$Text= "## FindPersonAusDrawListe - suche Person " + $PersonLnr + " in DrawListe";Write-Host $Text}
        for($i=0; $i -lt $ListeSplit.count; $i++){
            
            if ($DebugMode -eq "true"){$Text= "`t--`ti:" + $i + ", Typ (ListeSplit[$i].split(""`t"")[6]): " + $ListeSplit[$i].split("`t")[5] ;Write-Host $Text}

            if ($ListeSplit[$i].split("`t")[6] -eq "P"){
            
                if ($DebugMode -eq "true"){$Text= "`t--`tTyp (ListeSplit[$i].split(""`t"")[2]): " + $ListeSplit[$i].split("`t")[2] ;Write-Host $Text}
                if ($ListeSplit[$i].split("`t")[2] -eq $PersonLnr) {
                
                    if ($DebugMode -eq "true"){$Text= "`t--`tTreffer!" ;Write-Host $Text}
                    $Treffer=$i
                    $i=$ListeSplit.count
                }
            }
        }
        return $Treffer
    }

    function RecursivKnotenPrepare(){
        param (
            [int]$KnotenLnr=0,
            $Wdh="false",
            [int]$DrawZeile=0,
            [int]$DrawSpalte=0,
            $SingleTree = "false"
        )
        ##################################################
        # Version V02
        # vom 15.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        $LandeSpalte=0
        [int]$PaKnotenLnr=0
        
        $KnotenHeaderListeSplit=$global:KnotenHeaderListe.split("`t")
        
        if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - Parameter"; Write-Host $Text}
        if ($DebugMode -eq "true"){$Text= "`t--`tKnotenLnr:`t" + $KnotenLnr + "`t--`tWdh:`t" + $Wdh + "`t--`tDrawZeile:`t" + $DrawZeile + "`t--`tDrawSpalte:`t" + $DrawSpalte + "`t--`tSingleTree:`t" + $SingleTree; Write-Host $Text}

        StatusUpdate -ProgressLnr 1

        if ($KnotenLnr -gt 0){
            # Pruefen ob Knoten schon erledigt ist
            if ($Global:KnotenCheckListe.split("`t")[$KnotenLnr] -eq "0") {
                
                if ($DebugMode -eq "true"){$text="## RecursivKnotenPrepare - KnotenCheckListe[Nr]=0"; Write-Host $text}

                $DrawSpalte=FindNeueSpalte_V2 -DrawSpalte $DrawSpalte -DrawZeile $DrawZeile
                    

                # Knoten als erledigt markieren
                CheckKnoten -KnotenLnr $KnotenLnr

                $PeNr=$global:KnotenDB.split("`n")[$KnotenLnr].split("`t")[$KnotenHeaderListeSplit[1]]
                $PeBezeichnung=DefinePersonHtmlID -PersonLnr $PeNr -KnotenLnr $KnotenLnr -Wdh $Wdh
                #$DrawSpalte=1
                #$DrawZeile=1
            
                if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - `n`t--`tGlobal:KnotenCheckListe:`t" + $Global:KnotenCheckListe + "`n`t--`tPeNr:`t" + $PeNr + "`n`t--`tPeBezeichnung:`t" + $PeBezeichnung + "`n`t--`tDrawSpalte:`t" + $DrawSpalte + "`n`t--`tDrawZeile:`t" + $DrawZeile; Write-Host $Text}

                # Format der $Global:PersonenDrawListe 
                # Person: Lnr	KnotenNr	PeNr	Spalte	Zeile	Html-ID	Typ P(erson)/D(oppel)P(erson)	LNr	Vorname	Name	Geburtsname	Geburtsdatum	Sterbedatum	Bemerkung	ZusatzVornamen	mobil	mail	GeburtsOrt	SterbeOrt/Friedhof	religion	geschl	nationalit�t
                # Knoten: Lnr	KnotenNr	-	Spalte	Zeile	Html-ID	Typ K(noten) LNr	PersonLNr	VaterLNr	MutterLNr	PartnerLNr	Knoten2LNr	Knoten3LNr	Knoten4LNr	Kind1LNr	Kind2LNr	Kind3LNr	Kind4LNr	Kind5LNr	Kind6LNr	Kind7LNr	Kind8LNr	Kind9LNr	Kind10LNr	Kind11LNr	Kind12LNr	Kind13LNr	Kind14LNr	StartDatum	EndDatum	Trau-Ort
                # Linien: Lnr	-	-	QuellSpalte	QuellZeile	Html-ID	Typ L(ine)	ZielSpalte	ZielZeile	Quell-ID	Ziel-ID

                if ($Global:PersonenDrawListe -eq "") {
                        $PersonenDrawListeAnz=1
                        $Global:PersonenDrawListe="Lnr" + "`t" + "KnotenNr/KnotenNr/-" + "`t" + "PeNr/-/-" + "`t" + "Spalte/Spalte/QuellSpalte" + "`t" + "Zeile/Zeile/QuellZeile" + "`t" + "Html-ID" + "`t" + "Typ P(erson)/K(noten)/D(oppel)P(erson)/L(ine)"  + "`t" + "LNr/LNr/ZielSpalte" + "`t" + "Vorname/LNrPersonLNr/ZielZeile" + "`t" + "Name/VaterLNr/Quell-ID" + "`t" + "Geburtsname/MutterLNr/Ziel-ID" + "`t" + "Geburtsdatum/PartnerLNr/-" + "`t" + "Sterbedatum/Knoten2LNr/-" + "`t" + "Bemerkung/Knoten3LNr/-" + "`t" + "ZusatzVornamen/Knoten4LNr/-" + "`t" + "mobil/Kind1LNr/-" + "`t" + "mail/Kind2LNr/-" + "`t" + "GeburtsOrt/Kind3LNr/-" + "`t" + "SterbeOrt_Friedhof/Kind4LNr/-" + "`t" + "religion/Kind5LNr/-" + "`t" + "geschl/Kind6LNr/-" + "`t" + "nationalit�t/Kind7LNr/-" + "`t" + "-/Kind8LNr/-" + "`t" + "-/Kind9LNr/-" + "`t" + "-/Kind10LNr/-" + "`t" + "-/Kind11LNr/-" + "`t" + "-/Kind12LNr/-" + "`t" + "-/Kind13LNr/-" + "`t" + "-/Kind14LNr/-" + "`t" + "-/StartDatum/-" + "`t" + "-/EndDatum/-" + "`t" + "-/Trau-Ort/-"+"`n"
                    } else {                    
                        $PersonenDrawListeAnz=($Global:PersonenDrawListe.split("`n").count-1)
                }

                if($wdh -eq "true") {$TypBez="DP"} else {$TypBez="P"}
                $DrawDummy="" + $PersonenDrawListeAnz + "`t" + $KnotenLnr + "`t" + $PeNr + "`t" + $DrawSpalte + "`t" + $DrawZeile + "`t" + $PeBezeichnung + "`t" + $TypBez + "`t" + (GetPersonMitNr  -PersonLnr $PeNr) #$global:PersonenDB[$PeNr]
                if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - DrawDummy:`t" + $DrawDummy;Write-Host $Text}
                
                $Global:Route = $Global:Route + "`n" + "schreibe Person " + $PeNr + ", Spalte " + $DrawSpalte + ", Zeile " + $DrawZeile + ", KnotenLnr " + $KnotenLnr
                $Global:PersonenDrawListe=$Global:PersonenDrawListe + $DrawDummy + "`n"
                if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - Global:PersonenDrawListe:`n" + $Global:PersonenDrawListe;Write-Host $Text}


                #Eltern
                $E1Nr=$global:KnotenDB.split("`n")[$KnotenLnr].split("`t")[$KnotenHeaderListeSplit[2]]
                $E2Nr=$global:KnotenDB.split("`n")[$KnotenLnr].split("`t")[$KnotenHeaderListeSplit[3]]
                #Partner
                $PaNr=$global:KnotenDB.split("`n")[$KnotenLnr].split("`t")[$KnotenHeaderListeSplit[4]]

                if ($PaNr -ne 0) {
                    if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - PartnerNr:`t" + $PaNr;Write-Host $Text}  
                    # hole alle Knoten von Partner
                    $DebugMode="false"
                    $PaKnotenListe=FindeAlleKnotenVonPersonNr($PaNr)
                    $DebugMode=$LocalDebugMode

                    if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - PaKnotenListe:`t" + $PaKnotenListe;Write-Host $Text}  
                    
                    # einen Tab dazu dass auf jeden Fall 2 Spakten existieren
                    $PaKnotenListe=$PaKnotenListe + ("`t")
                    $PaKnotenListeSplit=$PaKnotenListe.split("`t")
                    if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - Anzahl gefundene Knoten in KnotenListe`t:" + $PaKnotenListeSplit.count;Write-Host $Text} 
                    # alle Partner-Knoten durchsuchen, der mit $PeNr als Partner ist der aktuelle Gegenknoten
                    for($i=0; $i -lt ($PaKnotenListeSplit.count-1); $i++){
                        # aktuellen Knoten nicht nochmal aufrufen
                        if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - i`t:" + $i;Write-Host $Text} 
                        if ($DebugMode -eq "true"){$Text= "--      PeNr:`t" + $PeNr;Write-Host $Text} 
                        if ($DebugMode -eq "true"){$Text= "--      PaKnotenListe[i]]:" + $PaKnotenListe.split("`t")[$i];Write-Host $Text} 
                        if ($DebugMode -eq "true"){$Text= "--      global:KnotenDB[" + $PaKnotenListe.split("`t")[$i] + "]:`t" + $global:KnotenDB.split("`n")[$PaKnotenListe.split("`t")[$i]];Write-Host $Text} 
                        if ($DebugMode -eq "true"){$Text= "--      global:KnotenDB[" + $PaKnotenListe.split("`t")[$i] + "][4]:`t" + $global:KnotenDB.split("`n")[$PaKnotenListe.split("`t")[$i]].split("`t")[4];Write-Host $Text} 

                        
                        $DuTPartnerKnoten=$PaKnotenListeSplit[$i]
                        if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - teste Knoten aus  KnotenListe mit nr`t:" + $DuTPartnerKnoten;Write-Host $Text} 

                        $KnotenSplit=$global:KnotenDB.split("`n")
                        $DutKnoten=$KnotenSplit[$DuTPartnerKnoten]
                        if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - Inhalt des DB-Knotens des aktuellen Knotens aus KnotenListe`t:" + $DutKnoten;Write-Host $Text} 

                        $DutKnotenSplit=$DutKnoten.split("`t")
                        $PartnerVomPartner=$DutKnotenSplit[4]
                        if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - PartnerVomPartner`t:" + $PartnerVomPartner + "`n`t--`tPeNr:`t" + $PeNr;Write-Host $Text} 

                        if ($DutKnotenSplit[4] -eq $PeNr) {
                            if ($DebugMode -eq "true"){$Text= "`t--`tsind gleich";Write-Host $Text} 
                            $PaKnotenLnr=$DuTPartnerKnoten
                        }
                    }
                    if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - PaKnotenListe:`t" + $PaKnotenListe;Write-Host $Text} 
                    if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - Richtiger PaKnoten(PaKnotenLnr):`t" + $PaKnotenLnr;Write-Host $Text} 

                    CheckKnoten -KnotenLnr $PaKnotenLnr
                    if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - Global:KnotenCheckListe:" + $Global:KnotenCheckListe;Write-Host $Text} 

                    # Knoten einfuegen
                    $KnBezeichnung=DefineKnotenHtmlID -KnotenLnr $KnotenLnr
                    if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - KnotenLnr:" + $KnotenLnr;Write-Host $Text} 
                                   
                    # richtige Spalte ermitteln lassen
                    $KnSpalte=FindNeueSpalte_V2 -DrawSpalte ($DrawSpalte+1) -DrawZeile $DrawZeile
                    $DrawDummy="" + ($Global:PersonenDrawListe.split("`n").count-1) + "`t" + $KnotenLnr + "`t" + "0" + "`t" + $KnSpalte + "`t" + $DrawZeile + "`t" + $KnBezeichnung + "`t" + "K" + "`t" + $global:KnotenDB[$KnotenLnr]
                    
                    $Global:Route = $Global:Route + "`n" + "schreibe Knoten " + $KnotenLnr + ", Spalte " + ($DrawSpalte + 1) + ", Zeile " + $DrawZeile + ", KnotenLnr " + $KnotenLnr
                    $Global:PersonenDrawListe=$Global:PersonenDrawListe + $DrawDummy + "`n"

                    # MaxSpaltenWert  anpassen

                    #if ($DrawSpalte -ge $Global:DrawPosListex.split("`t")[$DrawZeile]) {
                    #    IncDrawPosListexX -DrawZeile $DrawZeile
                    #}
                    #if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - DrawZeile:`t" + $DrawZeile;Write-Host $Text}
                
                    # Partner einfuegen
                    $PaBezeichnung=DefinePersonHtmlID -PersonLnr $PaNr -KnotenLnr $KnotenLnr -Wdh "false"

                    # richtige Spalte ermitteln lassen
                    $PaSpalte=FindNeueSpalte_V2 -DrawSpalte ($DrawSpalte+2) -DrawZeile $DrawZeile
                    $DrawDummy="" + ($Global:PersonenDrawListe.split("`n").count-1) + "`t" + $KnotenLnr + "`t" + $PaNr + "`t" + $PaSpalte + "`t" + $DrawZeile + "`t" + $PaBezeichnung + "`t" + "P" + "`t" + (GetPersonMitNr  -PersonLnr $PaNr) #$global:PersonenDB[$PaNr]
            
                    if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - DrawDummy:`t" + $DrawDummy;Write-Host $Text}
                    
                    $Global:Route = $Global:Route + "`n" + "schreibe Partner " + $PaNr + ", Spalte " + ($DrawSpalte + 2) + ", Zeile " + $DrawZeile + ", KnotenLnr " + $KnotenLnr
                    $Global:PersonenDrawListe=$Global:PersonenDrawListe + $DrawDummy + "`n"


                    ######  Verbindungen
                    # Linien: Lnr	-	-	QuellSpalte	QuellZeile	Html-ID	Typ L(ine)	ZielSpalte	ZielZeile	Quell-ID	Ziel-ID
                    # Pe zu KN
                    $DrawDummy="" + ($Global:PersonenDrawListe.split("`n").count-1) + "`t0`t0`t" + $DrawSpalte + "`t" + $DrawZeile + "`t" + "Line-PeKn" + "`t" + "L" + "`t" + ($DrawSpalte + 1) + "`t" + $DrawZeile + "`t" + $PeBezeichnung + "`t" + $KnBezeichnung
                    $Global:PersonenDrawListe=$Global:PersonenDrawListe + $DrawDummy + "`n"
                    # Kn zu Pa
                    $DrawDummy="" + ($Global:PersonenDrawListe.split("`n").count-1) + "`t0`t0`t" + ($DrawSpalte + 1) + "`t" + $DrawZeile + "`t" + "Line-KnPa" + "`t" + "L" + "`t" + ($DrawSpalte + 2) + "`t" + $DrawZeile + "`t" + $KnBezeichnung + "`t" + $PaBezeichnung
                    $Global:PersonenDrawListe=$Global:PersonenDrawListe + $DrawDummy + "`n"


                    # MaxSpaltenWert  anpassen
                    #if ($DrawSpalte -ge $Global:DrawPosListex.split("`t")[$DrawZeile]) {
                    #    IncDrawPosListexX -DrawZeile $DrawZeile
                    #}
                    #if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - DrawZeile:`t" + $DrawZeile;Write-Host $Text}

                    # Partner-Eltern
                    $PaE1Nr=$global:KnotenDB.split("`n")[$PaKnotenLnr].split("`t")[$KnotenHeaderListeSplit[2]]
                    $PaE2Nr=$global:KnotenDB.split("`n")[$PaKnotenLnr].split("`t")[$KnotenHeaderListeSplit[3]]



                    if ($DebugMode -eq "true"){$text="## --------------------------------------------------------------------`n## PrepareDrawListe - Alle Kinder durchgehen"; Write-Host $text}
                    # alle Kinder
                    for($i=$global:KindStartNr; $i -lt $KnotenHeaderListeSplit.count; $i++){
                   # for($i=0; $i -lt (14); $i++){
                        $KindLnr=$global:KnotenDB.split("`n")[$KnotenLnr].split("`t")[$KnotenHeaderListeSplit[$i]]
                        if ($DebugMode -eq "true"){$text="## --++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++`n## PrepareDrawListe - Alle Kinder von Eltern-Knoten " + $KnotenLnr + " durchgehen"; Write-Host $text}

                        if ($KindLnr -eq 0) {
                            # Kinder sind fortlaufend gefuellt - sobale ne 0 kommt, kommt kein weitere Kind mehr
                            if ($DebugMode -eq "true"){$text="## PrepareDrawListe - ab Kind Nr " + $KindLnr + " kommt kein weiteres => abbruch"; Write-Host $text}

                            $i=$KnotenHeaderListeSplit.count
                        } else {
                            if ($DebugMode -eq "true"){$text="`tAlle Knoten von Kind " + ($i+1) + " mit PersonLnr " + $KindLnr + " durchgehen"; Write-Host $text}
                            $DebugMode="false"
                            $KiKnotenListe=FindeAlleKnotenVonPersonNr($KindLnr)
                            $DebugMode=$LocalDebugMode
                            if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - KindKnotenListe:`t" + $KiKnotenListe;Write-Host $Text} 

                            # alle anderen Knoten dieser Person durchlaufen als Wiederholungsknoten, der mit $PeNr als Partner aber als Aktiver Knoten
                            $KiKnotenListe=$KiKnotenListe + ("`t")
                            $KiKnotenListeSplit=$KiKnotenListe.split("`t")

                            # bei Kindern reicht der erste KindKnoten!!
                            $Global:Route = $Global:Route + "`n" + "Gehe zu " + $i + "-tem Kind (KN " + $KiKnotenListeSplit[0] + "), Spalte " + "99999" + ", Zeile " + ([int]$DrawZeile + 1)
                            RecursivKnotenPrepare -KnotenLnr $KiKnotenListeSplit[0] -Wdh "false" -DrawSpalte (99999) -DrawZeile ([int]$DrawZeile + 1) -SingleTree $SingleTree
                            if ($DebugMode -eq "true"){$Text="Landespalte:" + $LandeSpalte;Write-Host $Text}
                            $KindBezeichnung=DefinePersonHtmlID -PersonLnr $KindLnr -KnotenLnr $KiKnotenListeSplit[0] -Wdh "false"
                            $KindDrawZeile=([int]$DrawZeile + 1)
                            #hier
                            # Achtung - wenn Kind schon existiert dann muss Spalten-position aus Draw-Liste genommen werden
                            # Suche Kind in PersonenDrawListe
                            $PersonTreffer=FindPersonAusDrawListe -PersonLnr $KindLnr
                            #$DebugMode="true"
                            if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - Kind in Drawliste gefunden in Zeile:`t" + $PersonTreffer;Write-Host $Text}
                            if ($PersonTreffer -eq -1) {
                                    # neues Kind
                                    if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - neues Kind";Write-Host $Text}
                                    #$KindDrawSpalte=$Global:DrawPosListex.split("`t")[$KindDrawZeile]
                                    
                                    $KindDrawSpalte=FindNeueSpalte_V2 -DrawSpalte (99999) -DrawZeile $KindDrawZeile
                                } else {
                                    # Kind ist schon in Liste
                                    if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - existierendes Kind";Write-Host $Text}
                                    $DrawListenEintragZeile=$Global:PersonenDrawListe.split("`n")[$PersonTreffer]
                                    if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - DrawListenEintragZeile:`t" + $DrawListenEintragZeile;Write-Host $Text}
                                    $ZeilenSplit=$DrawListenEintragZeile.split("`t")
                                    $KindDrawSpalte=$ZeilenSplit[3]
                                    if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - KindDrawSpalte:`t" + $KindDrawSpalte;Write-Host $Text}
                            }
                            
                            $DebugMode="false"
                            ######  Verbindungen
                            # Linien: Lnr	-	-	QuellSpalte	QuellZeile	Html-ID	Typ L(ine)	ZielSpalte	ZielZeile	Quell-ID	Ziel-ID
                            # Kn zu Kind
                            $DrawDummy="" + ($Global:PersonenDrawListe.split("`n").count-1) + "`t0`t0`t" + ($DrawSpalte + 1) + "`t" + $DrawZeile + "`t" + "Line-KnKi" + "`t" + "L" + "`t" + $KindDrawSpalte + "`t" + $KindDrawZeile + "`t" + $KnBezeichnung + "`t" + $KindBezeichnung
                            $Global:PersonenDrawListe=$Global:PersonenDrawListe + $DrawDummy + "`n"

                        }
                    }
                    



                    if ($DebugMode -eq "true"){$text="## --------------------------------------------------------------------`n## PrepareDrawListe - Alle Knoten von Person " + $PeNr + " durchgehen"; Write-Host $text}

                    # hole alle Knoten von Person
                    $DebugMode="false"
                    $PeKnotenListe=FindeAlleKnotenVonPersonNr($PeNr)
                    $DebugMode=$LocalDebugMode
                    if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - PeKnotenListe:`t" + $PeKnotenListe;Write-Host $Text} 

                    # alle anderen Knoten dieser Person durchlaufen als Wiederholungsknoten
                    $PeKnotenListe=$PeKnotenListe + ("`t")
                    $PeKnotenListeSplit=$PeKnotenListe.split("`t")

                    #$PeKnotenListeSplit=$PeKnotenListe.split
                    for($i=0; $i -lt $PeKnotenListeSplit.count; $i++){
                        $NeuerAltPe="false"
                        # aktuellen Knoten nicht nochmal aufrufen
                        if ($PeKnotenListeSplit[$i] -ne $KnotenLnr) {
                            if ($Global:KnotenCheckListe.split("`t")[$PeKnotenListeSplit[$i]] -eq "0") {$NeuerAltPe="true"}else{} 
                            if ($PeKnotenListeSplit.count -le $i) {$NeuerAltPe="true"}else{} 

                            $LandungsSpalte=RecursivKnotenPrepare -KnotenLnr $PeKnotenListeSplit[$i] -Wdh "true" -DrawSpalte (9999) -DrawZeile $DrawZeile -SingleTree $SingleTree


                            #$Text= "##################################################################";Write-Host $Text
                            if ($DebugMode -eq "true"){$Text= "##############           hier                  ###################";Write-Host $Text}
                            if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - LandeSpalte:" + $LandungsSpalte;Write-Host $Text}

                            $LandungsText=" " + $LandungsSpalte + " "

                            $LandeSpalteSplit=$LandungsText.split(" ")
                            if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - LandeSpalte[0]:" + $LandeSpalteSplit[0];Write-Host $Text}
                            if ($DebugMode -eq "true"){$Text= "---------------------------------------1--" + $LandeSpalteSplit[1];Write-Host $Text}
                            if ($DebugMode -eq "true"){$Text= "---------------------------------------2--" + $LandeSpalteSplit[2];Write-Host $Text}
                            if ($DebugMode -eq "true"){$Text= "------------------------------count:" + $LandeSpalteSplit.count;Write-Host $Text}

                            if ($LandeSpalteSplit.count -gt 3){
                                    $LandeSpalte=[int]$LandeSpalteSplit[($LandeSpalteSplit.count-2)]
                                } else {
                                    $LandeSpalte=[int]$LandungsSpalte
                            }
                            if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - LandeSpalte:" + $LandeSpalte;Write-Host $Text}


                            $Global:Route = $Global:Route + "`n" + "Gehe zu " + $i + "-tem Alternativ-Person " + $PeKnotenListeSplit[$i] + ", Spalte " + $LandeSpalte + ", Zeile " + $DrawZeile
                            
                            if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - NeuerAltPe:`t[" + $NeuerAltPe + "]";Write-Host $Text }
                            # wenn neuer Knoten noch fehlt, dann DPe-Strich malen
                            if ($Global:KnotenCheckListe.split("`t")[$PeKnotenListeSplit[$i]] -eq "0") {$NeuerAltPe="true"}else{} 
                            if ($PeKnotenListeSplit.count -le $i) {$NeuerAltPe="true"}else{} 
                            if ($NeuerAltPe -eq "true") {
                                ######  Verbindungen
                                # Linien: Lnr	-	-	QuellSpalte	QuellZeile	Html-ID	Typ L(ine)	ZielSpalte	ZielZeile	Quell-ID	Ziel-ID
                                # Pe zu KN
                                if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - �ber PersonKnotenliste, in Spalte:" + $LandeSpalte;Write-Host $Text}
                                $DPeBezeichnung=DefinePersonHtmlID -PersonLnr $PeNr -KnotenLnr $PeKnotenListeSplit[$i] -Wdh "true"
                                $DrawDummy="" + ($Global:PersonenDrawListe.split("`n").count-1) + "`t0`t0`t" + $DrawSpalte + "`t" + $DrawZeile + "`t" + "Line-PeDPe" + "`t" + "L" + "`t" + $LandeSpalte + "`t" + $DrawZeile + "`t" + $PeBezeichnung + "`t" + $DPeBezeichnung
                                $Global:PersonenDrawListe=$Global:PersonenDrawListe + $DrawDummy + "`tPeDoppel`n"
                            }
                        }
                    }

                    #if ($SingleTree -eq "false") {
                    if ($DebugMode -eq "true"){$text="## --------------------------------------------------------------------`n## PrepareDrawListe - Alle Knoten von Partner " + $PaNr + " durchgehen"; Write-Host $text}
                    # hole alle Knoten von Partner

                    # PartnerAlternativ-Verbindungen interessieren nicht bei Einzelb�umen
                    if ($SingleTree -ne "true") {
                        $PaKnotenListe=FindeAlleKnotenVonPersonNr($PaNr)
                        $DebugMode=$LocalDebugMode
                        if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - PaKnotenListe:`t" + $PaKnotenListe;Write-Host $Text} 

                        # alle anderen Knoten dieser Person durchlaufen als Wiederholungsknoten, der mit $PeNr als Partner aber als Aktiver Knoten
                        $PaKnotenListe=$PaKnotenListe + ("`t")
                        $PaKnotenListeSplit=$PaKnotenListe.split("`t")

                        for($i=0; $i -lt $PaKnotenListeSplit.count; $i++){
                            $NeuerAltPe="false"
                            # aktuellen Knoten nicht nochmal aufrufen
                            if ($PaKnotenListeSplit[$i] -ne $PaKnotenLnr) {
                                if ($Global:KnotenCheckListe.split("`t")[$PaKnotenListeSplit[$i]] -eq "0") {$NeuerAltPe="true"}else{} 
                                if ($PaKnotenListeSplit.count -le $i) {$NeuerAltPe="true"}else{} 
                                #$Text= "## RecursivKnotenPrepare - PaKnotenListe:`t[" + $PaKnotenListe + "]";Write-Host $Text 
                                #$Text= "## RecursivKnotenPrepare - PaKnotenListeSplit.count:`t[" + $PaKnotenListeSplit.count + "]";Write-Host $Text 
                                #$Text= "## RecursivKnotenPrepare - PaKnotenListeSplit[$i]:`t[" + $PaKnotenListeSplit[$i] + "]";Write-Host $Text 
                                #$Text= "## RecursivKnotenPrepare - Global:KnotenCheckListe.split(""`t"")[PaKnotenListeSplit[$i]]:`t[" + $Global:KnotenCheckListe.split("`t")[$PaKnotenListeSplit[$i]] + "]";Write-Host $Text 
                                #$Text= "## RecursivKnotenPrepare - NeuerAltPe:`t[" + $NeuerAltPe + "]";Write-Host $Text 

                                #$PaXDrawSpalte=$Global:KnotenCheckListe.split("`t")[$DrawZeile] # ($PaSpalte + 1 + $i) # FindNeueSpalte_V2 -DrawSpalte (99999) -DrawZeile $DrawZeile
                                $LandungsSpalte=RecursivKnotenPrepare -KnotenLnr $PaKnotenListeSplit[$i] -Wdh "true" -DrawSpalte (99999) -DrawZeile $DrawZeile -SingleTree $SingleTree

                                #$Text= "##################################################################";Write-Host $Text
                                if ($DebugMode -eq "true"){$Text= "##############           hier                  ###################";Write-Host $Text}
                                if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - LandeSpalte:" + $LandungsSpalte;Write-Host $Text}

                                $LandungsText=" " + $LandungsSpalte + " "

                                $LandeSpalteSplit=$LandungsText.split(" ")
                                if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - LandeSpalte[0]:" + $LandeSpalteSplit[0];Write-Host $Text}
                                if ($DebugMode -eq "true"){$Text= "---------------------------------------1--" + $LandeSpalteSplit[1];Write-Host $Text}
                                if ($DebugMode -eq "true"){$Text= "---------------------------------------2--" + $LandeSpalteSplit[2];Write-Host $Text}
                                if ($DebugMode -eq "true"){$Text= "------------------------------count:" + $LandeSpalteSplit.count;Write-Host $Text}

                                if ($LandeSpalteSplit.count -gt 3){
                                        $LandeSpalte=[int]$LandeSpalteSplit[($LandeSpalteSplit.count-2)]
                                    } else {
                                        $LandeSpalte=[int]$LandungsSpalte
                                }
                                if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - LandeSpalte:" + $LandeSpalte;Write-Host $Text}

                                $Global:Route = $Global:Route + "`n" + "Gehe zu " + $i + "-tem Alternativ-Partner (KN " + $PaKnotenListeSplit[$i] + "), Spalte " + $LandeSpalte + ", Zeile " + $DrawZeile
                                #$Text= "## RecursivKnotenPrepare - NeuerAltPe:`t[" + $NeuerAltPe + "]";Write-Host $Text 
                            
                                # wenn neuer Knoten noch fehlt, dann DPe-Strich malen
                                if ($Global:KnotenCheckListe.split("`t")[$PaKnotenListeSplit[$i]] -eq "0") {$NeuerAltPe="true"}else{} 
                                if ($PaKnotenListeSplit.count -le $i) {$NeuerAltPe="true"}else{} 

                                if ($NeuerAltPe -eq "true") {
                                    ######  Verbindungen
                                    # Linien: Lnr	-	-	QuellSpalte	QuellZeile	Html-ID	Typ L(ine)	ZielSpalte	ZielZeile	Quell-ID	Ziel-ID
                                    # Pe zu KN
                                    if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - �ber PartnerKnotenliste, in SPalte:" + $LandeSpalte;Write-Host $Text}
                                    $DPeBezeichnung=DefinePersonHtmlID -PersonLnr $PaNr -KnotenLnr $PaKnotenListeSplit[$i] -Wdh "true"
                                    $DrawDummy="" + ($Global:PersonenDrawListe.split("`n").count-1) + "`t0`t0`t" + $PaSpalte + "`t" + $DrawZeile + "`t" + "Line-PeDPe" + "`t" + "L" + "`t" + $LandeSpalte + "`t" + $DrawZeile + "`t" + $PaBezeichnung + "`t" + $DPeBezeichnung
                                    $Global:PersonenDrawListe=$Global:PersonenDrawListe + $DrawDummy + "`tPeDoppel`n"
                                }
                            }
                        }
                    }
                }

                #$Text= "## RecursivKnotenPrepare - SingleTree:`t" + $SingleTree;Write-Host $Text
                if ($SingleTree -eq "false") {
                    #$Text= "## RecursivKnotenPrepare - suche eltern";Write-Host $Text
                    if ($DebugMode -eq "true"){$text="## --------------------------------------------------------------------`n## PrepareDrawListe - Eltern von Person  mit Lnr " + $PeNr + " durchgehen"; Write-Host $text}
                    # hole alle Knoten von Partner


                    # Eltern von Person
                    if ($E1Nr -ne 0) {
                        $DebugMode="false"
                        $E1KnotenListe=FindeAlleKnotenVonPersonNr($E1Nr)
                        $DebugMode=$LocalDebugMode
                        if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - E1KnotenListe:`t" + $E1KnotenListe;Write-Host $Text} 

                        # alle anderen Knoten dieser Person durchlaufen als Wiederholungsknoten, der mit $PeNr als Partner aber als Aktiver Knoten
                        $E1KnotenListe=$E1KnotenListe + ("`t")
                        $E1KnotenListeSplit=$E1KnotenListe.split("`t")
                        # erster Eltern1-Knoten reicht zum Start
                        #$ElternZeile=([int]$DrawZeile - 1)
                        #$ElternSpalte=99999
                        $Global:Route = $Global:Route + "`n" + "Gehe zu Person-Eltern1 (KN " + $E1KnotenListeSplit[0] + "), Spalte " + "99999" + ", Zeile " + ([int]$DrawZeile - 1)
                        $LandeSpalte=RecursivKnotenPrepare -KnotenLnr $E1KnotenListeSplit[0] -Wdh "false"  -DrawSpalte (99999) -DrawZeile ([int]$DrawZeile - 1) -SingleTree $SingleTree
                    }
                    # Eltern von Person
                    if ($E2Nr -ne 0) {
                        $DebugMode="false"
                        $E2KnotenListe=FindeAlleKnotenVonPersonNr($E2Nr)
                        $DebugMode=$LocalDebugMode
                        if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - E2KnotenListe:`t" + $E2KnotenListe;Write-Host $Text} 

                        # alle anderen Knoten dieser Person durchlaufen als Wiederholungsknoten, der mit $PeNr als Partner aber als Aktiver Knoten
                        $E2KnotenListe=$E2KnotenListe + ("`t")
                        $E2KnotenListeSplit=$E2KnotenListe.split("`t")
                        # erster Eltern1-Knoten reicht zum Start
                        $Global:Route = $Global:Route + "`n" + "Gehe zu Person-Eltern2 (KN " + $E2KnotenListeSplit[0] + "), Spalte " + "99999" + ", Zeile " + ([int]$DrawZeile - 1)
                        $LandeSpalte=RecursivKnotenPrepare -KnotenLnr $E2KnotenListeSplit[0] -Wdh "false" -DrawSpalte (99999) -DrawZeile ([int]$DrawZeile - 1) -SingleTree $SingleTree
                    }

                    if ($PaNr -ne 0) {                
                        if ($DebugMode -eq "true"){$text="## --------------------------------------------------------------------`n## PrepareDrawListe - Eltern von Partner mit Lnr " + $PaNr + " durchgehen"; Write-Host $text}
                        # Eltern von Partner
                        if ($PaE1Nr -ne 0) {
                            $DebugMode="false"
                            $PaE1KnotenListe=FindeAlleKnotenVonPersonNr($PaE1Nr)
                            $DebugMode=$LocalDebugMode
                            if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - PaE1KnotenListe:`t" + $PaE1KnotenListe;Write-Host $Text} 

                            # alle anderen Knoten dieser Person durchlaufen als Wiederholungsknoten, der mit $PeNr als Partner aber als Aktiver Knoten
                            $PaE1KnotenListe=$PaE1KnotenListe + ("`t")
                            $PaE1KnotenListeSplit=$PaE1KnotenListe.split("`t")
                            # erster Eltern1-Knoten reicht zum Start
                            $Global:Route = $Global:Route + "`n" + "Gehe zu Partner-Eltern1 (KN " + $PaE1KnotenListeSplit[0] + "), Spalte " + "99999" + ", Zeile " + ([int]$DrawZeile - 1)
                            $LandeSpalte=RecursivKnotenPrepare -KnotenLnr $PaE1KnotenListeSplit[0] -Wdh "false" -DrawSpalte (99999) -DrawZeile ([int]$DrawZeile - 1) -SingleTree $SingleTree
                        }
                        # Eltern von Person
                        if ($PaE2Nr -ne 0) {
                            $DebugMode="false"
                            $PaE2KnotenListe=FindeAlleKnotenVonPersonNr($PaE2Nr)
                            $DebugMode=$LocalDebugMode
                            if ($DebugMode -eq "true"){$Text= "## RecursivKnotenPrepare - PaE2KnotenListe:`t" + $PaE2KnotenListe;Write-Host $Text} 

                            # alle anderen Knoten dieser Person durchlaufen als Wiederholungsknoten, der mit $PeNr als Partner aber als Aktiver Knoten
                            $PaE2KnotenListe=$PaE2KnotenListe + ("`t")
                            $PaE2KnotenListeSplit=$PaE2KnotenListe.split("`t")
                            # erster Eltern1-Knoten reicht zum Start
                            $Global:Route = $Global:Route + "`n" + "Gehe zu Partner-Eltern2 (KN " + $PaE2KnotenListeSplit[0] + "), Spalte " + "99999" + ", Zeile " + ([int]$DrawZeile - 1)
                            $LandeSpalte=RecursivKnotenPrepare -KnotenLnr $PaE2KnotenListeSplit[0] -Wdh "false" -DrawSpalte (99999) -DrawZeile ([int]$DrawZeile - 1) -SingleTree $SingleTree
                        }

                    }
                }

            }
        }

        if ($DebugMode -eq "true"){$Text="R�ckgabe:" + $DrawSpalte;Write-Host $Text}
        return $DrawSpalte
    }
    
    function PrepareDrawListe() {
        param (
            $SingleTreeStartNode=0
        )
        ##################################################
        # Version V02
        # vom 15.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true"){$text="########################################################################################`n## PrepareDrawListe -- start mit Paraeter`n`t`tSingleTreeStartNode:`t(" + $SingleTreeStartNode + ")"; Write-Host $text}
        # erzeuge KnotenFortschrittsListe - erstes Element ist leer, das entspricht der Ueberschrift-Zeile in den DBs
        $KnotenANz=$global:KnotenDB.split("`n").count
        #$Global:KnotenCheckListe=""
        for($i=0; $i -lt ($KnotenANz-1); $i++){
            $Global:KnotenCheckListe=$Global:KnotenCheckListe + "`t0"
        }

        # durchlaufe die komplette KnotenDB
        $DrawZeile=1
        $DrawSpalte=1
        $Global:DrawPosListex="0`t0"
        $Global:MinusDrawPosListex="0`t0" # Element 0 wird nie benutzt, muss aber da sein wegen Zaehlerei
        if ($DebugMode -eq "true"){$text="## PrepareDrawListe - Global:DrawPosListex initialisiert:`t" + $Global:DrawPosListex; Write-Host $text}
        if ($DebugMode -eq "true"){$text="## PrepareDrawListe - Global:MinusDrawPosListex initialisiert:`t" + $Global:MinusDrawPosListex; Write-Host $text}
        
        if ($SingleTreeStartNode -gt 0) {
        
                if ($DebugMode -eq "true"){$text="########################################################################################`n## PrepareDrawListe - starte RecursivKnotenPrepare als ""SingleTree"" mit Knoten " + $SingleTreeStartNode; Write-Host $text}

                $LandeSpalte=RecursivKnotenPrepare -KnotenLnr $SingleTreeStartNode -Wdh "false" -DrawZeile $DrawZeile -DrawSpalte $DrawSpalte -SingleTree "true"

                if ($DebugMode -eq "true"){$text="## PrepareDrawListe - zur�ck von RecursivKnotenPrepare als ""SingleTree"" mit Knoten " + $SingleTreeStartNode + "`n########################################################################################"; Write-Host $text}
       
            } else {    
                if ($DebugMode -eq "true"){$text="########################################################################################`n## PrepareDrawListe - starte Schleife �ber alle Knoten als ""volle Tapete"""; Write-Host $text}

                for($i=1; $i -lt $KnotenANz; $i++){
            
                    if ($DebugMode -eq "true"){$text="## PrepareDrawListe -- pr�fe Status von Knoten(" + $i + "):`t" + $Global:KnotenCheckListe.split("`t")[$i]; Write-Host $text}
                    if ($Global:KnotenCheckListe.split("`t")[$i] -eq "0") {
                            if ($i -eq 1) {
                                    # erster Knoten - ok
                                    if ($DebugMode -eq "true"){$text="## PrepareDrawListe -- Knoten(" + $i + ") mu� noch ..." ; Write-Host $text}
                                    if ($Global:Route -eq "") {
                                            $Global:Route = $Global:Route + "Start neuen Baum mit Knoten " + $i + ", Spalte " + $DrawSpalte + ", Zeile " + $DrawZeile
                                        } else {
                                            $Global:Route = $Global:Route + "`n`n" + "Start neuen Baum mit Knoten " + $i + ", Spalte " + $DrawSpalte + ", Zeile " + $DrawZeile
                                    }

                                    $LandeSpalte=RecursivKnotenPrepare -KnotenLnr $i -Wdh "false" -DrawZeile $DrawZeile -DrawSpalte $DrawSpalte -SingleTree "false"
                                } else {
                                    # nicht erster Knoten - sollte alles schon erledigt sein - wenn es kein extra baum ist

                                    if ($DebugMode -eq "true"){$text="##!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!`n## PrepareDrawListe - Dieser Knoten wurde noch nicht behandelt - muss ein Fehler in DB sein - KnotenLnr" + $i + "`n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"; Write-Host $text}
                                    $text="### !!! ### !!!`t## PrepareDrawListe - Dieser Knoten wurde noch nicht behandelt - muss ein Fehler in DB sein - KnotenLnr" + $i + "`t!!! ### !!! ###"; Write-Host $text
                            }
                        } else {

                            # Knoten ist schon erledigt
                    }

                }
                if ($DebugMode -eq "true"){$text="## PrepareDrawListe - Schleife �ber alle Knoten als ""volle Tapete"" ist beendet`n########################################################################################"; Write-Host $text}
        }

        
    }


    function AddValueToValueOnCollumnX() {
        param (
            $DuTZeile=0,
            [int]$DuTSpalte=0,
            [int]$AddWert=0
        )
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        
        if ($DebugMode -eq "true"){$Text= "## AddValueToValueOnCollumnX - Parameter`n`t--`tDuTZeile:`t[" + $DuTZeile + "]`n`t--`tDuTSpalte:`t[" + $DuTSpalte + "]`n`t--`tAddWert:`t" + $AddWert; Write-Host $Text}

        $Dummy1=""

        $DuTZeileSplit=$DuTZeile.split("`t")
        $Dummy1 = $DuTZeileSplit[0]
        for($i=1; $i -lt ([int]$DuTSpalte); $i++){
            if ($DebugMode -eq "true"){$Text= "`t--`ti:`t" + $i + "`t--`tDuTZeileSplit[i]:`t[" + $DuTZeileSplit[$i] + "]`tDummy1:`t" + $Dummy1; Write-Host $Text}
            $Dummy1=$Dummy1 + "`t" + $DuTZeileSplit[$i]
        }

        [int]$AltWert=$DuTZeileSplit[$DuTSpalte]
        [int]$NeuWert=$AltWert + $AddWert
        $Dummy2="" + "`t" + $NeuWert 
        if ($DebugMode -eq "true"){$Text= "`t--`tDuTSpalte:`t" + ($DuTSpalte) + "`t--`tAltWert:`t" + $AltWert + "`t--`tNeuWert:`t" + $NeuWert + "`tDummy2:`t[" + $Dummy2 + "]"; Write-Host $Text}


        for($i=($DuTSpalte+1); $i -lt ($DuTZeileSplit.count); $i++){
            if ($DebugMode -eq "true"){$Text= "`t--`ti:`t" + $i + "`t--`DuTZeileSplit[i]:`t" + $DuTZeileSplit[$i] + "`tDummy3:`t[" + $Dummy3 + "]"; Write-Host $Text}
            $Dummy3=$dummy3 + "`t" + $DuTZeileSplit[$i]
        }
        
        $Dummy=$Dummy1 + $Dummy2 + $Dummy3
        if ($DebugMode -eq "true"){$Text= "## AddValueToValueOnCollumnX - R�ckgabewert`n`t--`tDummy:`t" + $Dummy ; Write-Host $Text}

        return $Dummy
            
    }

    function PlaceOnPaper() {
        param (
            $ProzessNr=0,
            $ProzessMax=0,
            $ProzessBereichStart=0, # Start-Wert des verfuegbaren Teil-Bereich des Fortschritts
            $ProzessBereich=0 # verfuegbarer Teil-Bereich des Fortschritts
        )
    
        ##################################################
        # Version V03
        # vom 15.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        [int]$KleinsteZeile=99
    
        $AnzTeilBereiche=2
        $ProzessBereiche=$ProzessBereich/$AnzTeilBereiche


        if ($DebugMode -eq "true"){$Text= "## PlaceOnPaper";Write-Host $Text} 
        $ListeSplit=$Global:PersonenDrawListe.split("`n")
        
        if ($DebugMode -eq "true"){$Text= "## PlaceOnPaper - `tsuche kleinste Zeile";Write-Host $Text}
        $AktProzessBereich=0
        for($i=1; $i -lt $ListeSplit.count; $i++){
            if ($ListeSplit[$i] -ne ""){
                [int]$AktWert=($ProzessBereichStart + $AktProzessBereich*$ProzessBereiche + ($ProzessBereiche)*($i/($ListeSplit.count-1)))
                ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert

                $Zeile=$ListeSplit[$i]
            
                if ($DebugMode -eq "true"){$Text= "## PlaceOnPaper - `tZeile:`t" + $Zeile;Write-Host $Text} 
                $ZeileSplit=$Zeile.split("`t")

                [int]$ZeileNr=$ZeileSplit[4]
                if ($DebugMode -eq "true"){$Text= "## PlaceOnPaper - `tZeileNr:`t" + $ZeileNr + "`tKleinsteZeile:`t" + $KleinsteZeile;Write-Host $Text} 
                if ($ZeileNr -lt $KleinsteZeile){
                    $KleinsteZeile = $ZeileNr
                    if ($DebugMode -eq "true"){$Text= "## PlaceOnPaper - `tZeileNr �bernehmen aus DrawListe von Zeile" + $i;Write-Host $Text} 
                }
                $typ=$ZeileSplit[6]
                if ($typ -eq "L"){
                    [int]$ZielZeile=$ZeileSplit[8]
                    if ($DebugMode -eq "true"){$Text= "## PlaceOnPaper - `tZielZeile:`t" + $ZielZeile + "`tKleinsteZeile:`t" + $KleinsteZeile;Write-Host $Text} 
                    if ($ZielZeile -lt $KleinsteZeile){
                        $KleinsteZeile = $ZielZeile
                        if ($DebugMode -eq "true"){$Text= "## PlaceOnPaper - `tZeileNr �bernehmen aus DrawListe von Zeile" + $i;Write-Host $Text} 
                    }
                }
            }
        }

        if ($DebugMode -eq "true"){$Text= "## PlaceOnPaper - `tfertig. KleinsteZeile:`t" + $KleinsteZeile;Write-Host $Text}     

        if ($KleinsteZeile -lt 1) {

            $Offset = 1 - $KleinsteZeile
            if ($DebugMode -eq "true"){$Text= "## PlaceOnPaper - `tKleinsteZeile:`t" + $KleinsteZeile + " - Offset:`t" + $Offset;Write-Host $Text}

            if ($DebugMode -eq "true"){$Text= "## PlaceOnPaper - `talles um Offset " + $Offset + " Zeilen nach oben schieben";Write-Host $Text} 
            $NeueListe=$ListeSplit[0]
            $AktProzessBereich=$AktProzessBereich + 1
            for($i=1; $i -lt $ListeSplit.count; $i++){
                [int]$AktWert=($ProzessBereichStart + $AktProzessBereich*$ProzessBereiche + ($ProzessBereiche)*($i/($ListeSplit.count-1)) )
                ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert

                $Zeile=$ListeSplit[$i]
            
                if ($Zeile -ne "") {
                    $NeueZeile=AddValueToValueOnCollumnX -DuTZeile $Zeile -DuTSpalte 4 -AddWert $Offset

                    if ($DebugMode -eq "true"){$Text= "## PlaceOnPaper - `tZeile:`t" + $Zeile;Write-Host $Text} 
                    $ZeileSplit=$Zeile.split("`t")
                    $typ=$ZeileSplit[6]
                    if ($typ -eq "L"){

            
                        $NeueZeile=AddValueToValueOnCollumnX -DuTZeile $NeueZeile -DuTSpalte 8 -AddWert $Offset

                    }
            

                    $NeueListe=$NeueListe + "`n" + $NeueZeile
                }
            }
        
            #ProgressStatus -ProgressLnr 2 -MaxValue 2 -ActValue 2

            $Global:PersonenDrawListe = $NeueListe
        } else {if ($DebugMode -eq "true"){$Text= "## PlaceOnPaper - `tKleinsteZeile:`t" + $KleinsteZeile + " - Nix zu tun!";Write-Host $Text}}
        
    }


    function KleinFamilienGruppierenKinderUnterEltern () {
        param (
            $ProzessNr=0,
            $ProzessMax=0,
            $ProzessBereichStart=0, # Start-Wert des verfuegbaren Teil-Bereich des Fortschritts
            $ProzessBereich=0 # verfuegbarer Teil-Bereich des Fortschritts
        )
    
        ##################################################
        # Version V03
        # vom 15.4.2023
        ##################################################

        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true"){$Text= "## KleinFamilienGruppierenKinderUnterEltern startet";Write-Host $Text} 

        #########################################
        ## Fortschritt
        $AnzTeilBereiche=5
        $ProzessBereiche=$ProzessBereich/$AnzTeilBereiche
        #########################################

        $veraendert="false"

        $DLZeilenSplit=$Global:PersonenDrawListe.split("`n")


     
        # Finde Anzahl Zeilen und MaxSpaltenAnzahl
        [int]$DrawZeilenAnz=0
        [int]$MaxSpaltenAnz=0
        for($i=1; $i -lt $DLZeilenSplit.count; $i++){
            $DLSpaltenSplit=$DLZeilenSplit[$i].split("`t")
            [int]$Zeile=[int]$DLSpaltenSplit[4]
            if ($Zeile -gt $DrawZeilenAnz) {$DrawZeilenAnz = $Zeile}

            [int]$Spalte = [int]$DLSpaltenSplit[3]
            if ($Spalte -gt $MaxSpaltenAnz) {$MaxSpaltenAnz = $Spalte}
        }
        if ($DebugMode -eq "true"){$Text= "## ErzeugeMatrix -- in DrawListe gefundene Anz Zeilen:`t" + $DrawZeilenAnz + " und MaxAnzahlSpalten:`t" + $MaxSpaltenAnz;Write-Host $Text} 

        #Puffer dazu
        $MaxSpaltenAnz=$MaxSpaltenAnz + 3
        if ($DebugMode -eq "true"){$Text= "`t`t`t mit Puffer - MaxAnzahlSpalten:`t" + $MaxSpaltenAnz;Write-Host $Text} 
        
        [int]$AktWert=($ProzessBereiche/3)
        ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert

        # baue leere PositionsMatrix
        $PositionsMatrix=@()
        [int]$NullWert=0
        for($i=0; $i -lt $DrawZeilenAnz+2; $i++){
            $ListenZeile=@()
            $ListenZeile = $ListenZeile + ("Z" + $i)
            for($o=0; $o -lt $MaxSpaltenAnz; $o++){
                $ListenZeile = $ListenZeile + $NullWert
            }
            $PositionsMatrix=$PositionsMatrix + $ListenZeile
            if ($DebugMode -eq "true"){$Text= "`t`tPositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text} 
        }
        
        
        [int]$AktWert=(2*$ProzessBereiche/3)
        ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert

        # alle Personen und Knoten in PositionsMatrix einpflegen
        for($i=1; $i -lt $DLZeilenSplit.count; $i++){
            if ($DLZeilenSplit[$i] -ne "") {
                $DLSpaltenSplit=$DLZeilenSplit[$i].split("`t")
            
                [int]$Lnr = [int]$DLSpaltenSplit[0]
                [int]$Zeile=[int]$DLSpaltenSplit[4]
                [int]$Spalte = [int]$DLSpaltenSplit[3]
                $Typ = $DLSpaltenSplit[6]

                if ($Typ -ne "L") {
                    $PositionsMatrixPos=($Zeile * ($MaxSpaltenAnz+1)) + $Spalte
                    $PositionsMatrix[$PositionsMatrixPos]=$Lnr
                }
            }
        }                

        if ($DebugMode -eq "true"){$Text= "`t`tStart-PositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text} 
           
           
        # Matrix von hinten her durchlaufen       
        $AktProzessBereich=$AktProzessBereich + 1
        for($Mi=0; $Mi -lt ($DrawZeilenAnz+1); $Mi++){
            $AktMZeile=$DrawZeilenAnz + 1 - $Mi # von unten nach oben
            
            [int]$AktWert=($ProzessBereichStart + $AktProzessBereich*$ProzessBereiche + ($ProzessBereiche)*($Mi/($DrawZeilenAnz.count+1)))
            ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert

            for($Mo=0; $Mo -lt ($MaxSpaltenAnz ); $Mo++){
                $AktMSpalte=($MaxSpaltenAnz) - $Mo # von rechts nach links

                $PositionsMatrixPos=($AktMZeile * ($MaxSpaltenAnz+1)) + $AktMSpalte
                $DuT=$PositionsMatrix[$PositionsMatrixPos]

                if ($DebugMode -eq "true"){$Text= "`t`tuntersuche DrawlisteZeile:`t" + $DuT + " von MatrixPos " + $AktMZeile + "/" + $AktMSpalte;Write-Host $Text}
                
                if ($DuT -gt 0) {
                    # Auslesen der HTML-ID der Person/knoten von DrawListe Zeile $DuT
                    $DuTZeile=$DLZeilenSplit[$DuT]
                    if ($DebugMode -eq "true"){$Text= "`t`tuntersuche DrawlisteZeile:`t" + $DuT + ", DuTZeile:`t" + $DuTZeile ;Write-Host $Text}
                    $DuTZeileSplit=$DuTZeile.split("`t")
                    $DuTHtmlID=$DuTZeileSplit[5]
                    if ($DebugMode -eq "true"){$Text= "`t`tuntersuche DrawlisteZeile:`t" + $DuT + ", DuTHtmlID:`t" + $DuTHtmlID ;Write-Host $Text}
                 
                    # passende Linie(n) suchen

                    # von unten alle Eltern/Kind Positionen pr�fen
                    for($i=1; $i -lt $DLZeilenSplit.count; $i++){
            
                        $DLSpaltenSplit=$DLZeilenSplit[$i].split("`t")
                        $Typ = $DLSpaltenSplit[6]

                        if ($Typ -eq "L") {

                            $StartID=$DLSpaltenSplit[9]
                            $EndID=$DLSpaltenSplit[10]

                            [int]$StartZeile=[int]$DLSpaltenSplit[4]
                            [int]$EndZeile=[int]$DLSpaltenSplit[8]

                            [int]$StartSpalte=[int]$DLSpaltenSplit[3]
                            [int]$EndSpalte=[int]$DLSpaltenSplit[7]

                            # Start-Punkt trifft Knoten
                            if ($DebugMode -eq "true"){$Text = "`t|<-``ttZeile;`t" + $i + "`t ID-Check StartID:`t" + $StartID+"`tDuTHtmlID:`t" + $DuTHtmlID;Write-Host $Text}
                            if ($StartID -eq $DuTHtmlID) {
                            
                                if ($DebugMode -eq "true"){$Text= "`t`tZeilen-Check StartZeile:`t" + $StartZeile+" EndZeile:`t" + $EndZeile;Write-Host $Text}
                                if ($StartZeile -gt $EndZeile) {
                                    # EndZeile kleiner Startzeile kommt unten ==> Verbindung von aktueller Zeile nach oben
                                    
                                    if ($DebugMode -eq "true"){$Text= "`t`tSpalten-Check AktMSpalte:`t" + $AktMSpalte+" EndSpalte:`t" + $EndSpalte;Write-Host $Text}
                                    if ($AktMSpalte -lt $EndSpalte) {
                                
                                        if ($DebugMode -eq "true"){$Text= "`t`tRechtsWackel startet EndSpalte " + $EndSpalte + " - AktMSpalte " + $AktMSpalte + " = " + ($EndSpalte-$AktMSpalte);Write-Host $Text}
                                        
                                        $WackelIstOk="false"
                                        if ($PositionsMatrix[$PositionsMatrixPos+1] -eq 0) { 
                                                # Pos+1 ist frei - alles ok - es kann gewackelt werden
                                                $WackelIstOk="true"
                                            } else { 
                                                if ($PositionsMatrix[$PositionsMatrixPos+3] -eq 0) { 
                                                        # pos+1 ist besetzt, Pos+3 ist frei => wenn passender Knoten auf +1 und Partner audf +2 - dann alle 3 wackeln
                                                        
                                                        $DuTPos1=$PositionsMatrix[$PositionsMatrixPos+1] # Knoten ?
                                                        $DuTPos2=$PositionsMatrix[$PositionsMatrixPos+2] # Partner ?

                                                        #$DLSpaltenSplit=$DLZeilenSplit[$i].split("`t")
                                                        $DLZeile1=$DLZeilenSplit[$DuTPos1]
                                                        $DLZeile2=$DLZeilenSplit[$DuTPos2]

                                                        $DLZeile1SpaltenSplit=$DLZeile1.split("`t")
                                                        $DLZeile2SpaltenSplit=$DLZeile2.split("`t")

                                                        if ($DLZeile1SpaltenSplit[6] -eq "K") {
                                                            # +1 ist ein Knoten
                                                            $KnotenID=$DLZeile1SpaltenSplit[5]
                                                            $PaID= $DLZeile2SpaltenSplit[5]
                                                            $PeID=$EndID

                                                            $PeIDSplit=$PeID.split("-")
                                                            $PaIDSplit=$PaID.split("-")
                                                            if ($PeIDSplit[1] -eq $KnotenID) {
                                                                if ($PaIDSplit[1] -eq $KnotenID) {
                                                                    # alle 3 Knoten geh�ren zusammen!

                                                                    # wackel Partner nach rechts
                                                                    for($w=1; $w -lt ($StartSpalte-$AktMSpalte)+1; $w++){
                                                                        $RPosDuT1=$PositionsMatrix[$PositionsMatrixPos+$w]
                                                                        $RPosDuT2=$PositionsMatrix[$PositionsMatrixPos+$w+1]
                                                                        $RPosDuT3=$PositionsMatrix[$PositionsMatrixPos+$w+2]
                                                                        if ($DebugMode -eq "true"){$Text= "`t`t3-fach Rechtswackel - RPosDuT1:`t" + $RPosDuT1 + "RPosDuT2:`t" + $RPosDuT2 + "RPosDuT3:`t" + $RPosDuT3;Write-Host $Text}
                                                                        if ($RPosDuT3 -eq 0) {    
                                                                                $veraendert="true"
                                                                                $PositionsMatrixPos=($AktMZeile * ($MaxSpaltenAnz+1)) + $AktMSpalte
                                                                                $PositionsMatrix[$PositionsMatrixPos+$w+2]=$PositionsMatrix[$PositionsMatrixPos+$w+1]
                                                                                $PositionsMatrix[$PositionsMatrixPos+$w+1]=$PositionsMatrix[$PositionsMatrixPos+$w]
                                                                                $PositionsMatrix[$PositionsMatrixPos+$w]=$DuT
                                                                                $PositionsMatrix[$PositionsMatrixPos+$w-1]=0
                                                                                if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel von DuT:`t" + $DuT+" =>PositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text}
                                                                            } else {
                                                                                $w= ($StartSpalte-$AktMSpalte)+1
                                                                        }
                                                                    }



                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        # mit Sicherheit kann nicht gewackelt werden
                                                }
                                        }
                                        if ($WackelIstOk -eq "true") {
                                            # wackel nach rechts
                                            for($w=1; $w -lt ($EndSpalte-$AktMSpalte)+1; $w++){
                                                $RPosDuT=$PositionsMatrix[$PositionsMatrixPos+$w]
                                                if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel - RPosDuT:`t" + $RPosDuT;Write-Host $Text}
                                                if ($RPosDuT -eq 0) {        
                                                        $veraendert="true"
                                                        $PositionsMatrixPos=($AktMZeile * ($MaxSpaltenAnz+1)) + $AktMSpalte
                                                        $PositionsMatrix[$PositionsMatrixPos+$w]=$DuT
                                                        $PositionsMatrix[$PositionsMatrixPos+$w-1]=0
                                                        if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel von DuT:`t" + $DuT+" =>PositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text}
                                                    } else {
                                                        $w= ($StartSpalte-$AktMSpalte)+1
                                                }
                                            }
                                        }
                                    }
                                }
                            }


                            # End-Punkt trifft Knoten
                            if ($DebugMode -eq "true"){$Text = "`t`t->|`tZeile;`t" + $i + "`t ID-Check EndID:`t" + $EndID+" DuTHtmlID:`t" + $DuTHtmlID;Write-Host $Text}
                            if ($EndID -eq $DuTHtmlID) {
                            
                                if ($DebugMode -eq "true"){$Text= "`t`tZeilen-Check StartZeile:`t" + $StartZeile+" EndZeile:`t" + $EndZeile;Write-Host $Text}
                                if ($EndZeile -gt $StartZeile) {
                                    # EndZeile kleiner Startzeile kommt unten ==> Verbindung von aktueller Zeile nach oben
                                    
                                    if ($DebugMode -eq "true"){$Text= "`t`tSpalten-Check AktMSpalte:`t" + $AktMSpalte+" StartSpalte:`t" + $StartSpalte;Write-Host $Text}
                                    if ($AktMSpalte -lt $StartSpalte) {
                                
                                        if ($DebugMode -eq "true"){$Text= "`t`tRechtsWackel startet StartSpalte " + $StartSpalte + " - AktMSpalte " + $AktMSpalte + " = " + ($StartSpalte-$AktMSpalte);Write-Host $Text}

                                        
                                        $WackelIstOk="false"
                                        if ($DebugMode -eq "true"){$text="Wert auf Pos(" + $PositionsMatrixPos + ")+1:" + $PositionsMatrix[$PositionsMatrixPos+1];Write-Host $text}
                                        if ($PositionsMatrix[$PositionsMatrixPos+1] -eq 0) { 
                                                # Pos+1 ist frei - alles ok - es kann gewackelt werden
                                                $WackelIstOk="true"
                                            } else { 
                                                if ($PositionsMatrix[$PositionsMatrixPos+3] -eq 0) { 
                                                        # pos+1 ist besetzt, Pos+3 ist frei => wenn passender Knoten auf +1 und Partner audf +2 - dann alle 3 wackeln
                                                        $DuTPos1=$PositionsMatrix[$PositionsMatrixPos+1] # Knoten ?
                                                        $DuTPos2=$PositionsMatrix[$PositionsMatrixPos+2] # Partner ?

                                                        #$DLSpaltenSplit=$DLZeilenSplit[$i].split("`t")
                                                        $DLZeile1=$DLZeilenSplit[$DuTPos1]
                                                        $DLZeile2=$DLZeilenSplit[$DuTPos2]

                                                        $DLZeile1SpaltenSplit=$DLZeile1.split("`t")
                                                        $DLZeile2SpaltenSplit=$DLZeile2.split("`t")

                                                        if ($DLZeile1SpaltenSplit[6] -eq "K") {
                                                            # +1 ist ein Knoten
                                                            $KnotenID=$DLZeile1SpaltenSplit[5]
                                                            $PaID= $DLZeile2SpaltenSplit[5]
                                                            $PeID=$EndID

                                                            $PeIDSplit=$PeID.split("-")
                                                            $PaIDSplit=$PaID.split("-")
                                                            if ($PeIDSplit[1] -eq $KnotenID) {
                                                                if ($PaIDSplit[1] -eq $KnotenID) {
                                                                    # alle 3 Knoten geh�ren zusammen!

                                                                    # wackel Partner nach rechts
                                                                    for($w=1; $w -lt ($StartSpalte-$AktMSpalte)+1; $w++){
                                                                        $RPosDuT1=$PositionsMatrix[$PositionsMatrixPos+$w]
                                                                        $RPosDuT2=$PositionsMatrix[$PositionsMatrixPos+$w+1]
                                                                        $RPosDuT3=$PositionsMatrix[$PositionsMatrixPos+$w+2]
                                                                        if ($DebugMode -eq "true"){$Text= "`t`t3-fach Rechtswackel - RPosDuT1:`t" + $RPosDuT1 + "RPosDuT2:`t" + $RPosDuT2 + "RPosDuT3:`t" + $RPosDuT3;Write-Host $Text}
                                                                        if ($RPosDuT3 -eq 0) {    
                                                                                $veraendert="true"
                                                                                $PositionsMatrixPos=($AktMZeile * ($MaxSpaltenAnz+1)) + $AktMSpalte
                                                                                $PositionsMatrix[$PositionsMatrixPos+$w+2]=$PositionsMatrix[$PositionsMatrixPos+$w+1]
                                                                                $PositionsMatrix[$PositionsMatrixPos+$w+1]=$PositionsMatrix[$PositionsMatrixPos+$w]
                                                                                $PositionsMatrix[$PositionsMatrixPos+$w]=$DuT
                                                                                $PositionsMatrix[$PositionsMatrixPos+$w-1]=0
                                                                                if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel von DuT:`t" + $DuT+" =>PositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text}
                                                                            } else {
                                                                                $w= ($StartSpalte-$AktMSpalte)+1
                                                                        }
                                                                    }



                                                                }
                                                            }
                                                        }


                                                    } else {
                                                        # mit Sicherheit kann nicht gewackelt werden
                                                }
                                        }
                                        if ($WackelIstOk -eq "true") {
                                            # wackel nach rechts
                                            for($w=1; $w -lt ($StartSpalte-$AktMSpalte)+1; $w++){
                                                $RPosDuT=$PositionsMatrix[$PositionsMatrixPos+$w]
                                                if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel - RPosDuT:`t" + $RPosDuT;Write-Host $Text}
                                                if ($RPosDuT -eq 0) {    
                                                        $veraendert="true"
                                                        $PositionsMatrixPos=($AktMZeile * ($MaxSpaltenAnz+1)) + $AktMSpalte
                                                        $PositionsMatrix[$PositionsMatrixPos+$w]=$DuT
                                                        $PositionsMatrix[$PositionsMatrixPos+$w-1]=0
                                                        if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel von DuT:`t" + $DuT+" =>PositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text}
                                                    } else {
                                                        $w= ($StartSpalte-$AktMSpalte)+1
                                                }
                                            }
                                        }

                                    }
                                }
                            }

                        }
                    }
                }
            }
        }
        if ($DebugMode -eq "true"){$Text= "`t`tfertig gewackelt => PositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text}
        


        $neueListe=""
        if ($veraendert -eq "true") {
                #PositionsMatrix:	Z0 0 0 0 0 0 0 0 0 0 Z1 1 2 3 0 0 0 0 0 0 Z2 6 7 8 16 17 18 0 0 0 Z3 11 13 0 21 23 0 0 0 0 Z4 0 0 0 0 0 0 0 0 0


            # erst alle Personen und Knoten in neue Liste aufnehmen
            $neueListe=$DLZeilenSplit[0] # Header
            # alle TextFelder neu anordnen in neuer Liste
            # Matrix durchlaufen       
            $AktProzessBereich=$AktProzessBereich + 1
            for($Mi=0; $Mi -lt ($DrawZeilenAnz+1); $Mi++){
                $AktMZeile=$Mi # von oben nach unten

                
                [int]$AktWert=($ProzessBereichStart + $AktProzessBereich*$ProzessBereiche + ($ProzessBereiche)*($Mi/($DrawZeilenAnz.count+1)))
                ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert

                for($Mo=1; $Mo -lt ($MaxSpaltenAnz ); $Mo++){
                    $AktMSpalte= $Mo # von links nach rechts

                    # aktuelles Matrix-Element
                    $PositionsMatrixPos=($AktMZeile * ($MaxSpaltenAnz+1)) + $AktMSpalte
                    $DuT=$PositionsMatrix[$PositionsMatrixPos]

                    if ($DebugMode -eq "true"){$Text= "`t`tuntersuche DrawlisteZeile:`t" + $DuT + " von MatrixPos " + $AktMZeile + "/" + $AktMSpalte;Write-Host $Text}
                    
                    # Matrix-Element aus Drawliste auslesen
                    if ($DuT -gt 0) {
                        # Auslesen der HTML-ID der Person/knoten von DrawListe Zeile $DuT
                        $DuTZeile=$DLZeilenSplit[$DuT]
                        $DLSpaltenSplit=$DuTZeile.split("`t")

                        [int]$StartSpalte=[int]$DLSpaltenSplit[3]
                        [int]$StartZeile=[int]$DLSpaltenSplit[4]

                        $GleicheZeile="false"
                        if ($DebugMode -eq "true"){$Text= "`t`tWerteVergleich: StartZeile:`t" + $StartZeile + " Mi:`t" + $Mi + ", StartSpalte:`t" + "`t" + $StartSpalte + " Mo:`t" + $Mo;Write-Host $Text}
                        if ($StartZeile -eq $Mi) {if ($StartSpalte -eq $Mo){
                            if ($DebugMode -eq "true"){$Text= "`t`tWerte identisch => Zeile komplett �bernehmen";Write-Host $Text}
                                $neueListe=$neueListe + "`n" + $DuTZeile
                                $GleicheZeile="true"
                        }}
                        if ($GleicheZeile -eq "false") {
                            if ($DebugMode -eq "true"){$Text= "`t`tWerte nicht identisch => Pos-Werte ersetzen";Write-Host $Text}
                                $NeueZeile=$DLSpaltenSplit[0] # erster Wert ist LNR
                                for($Sp=1; $Sp -lt $DLSpaltenSplit.count; $Sp++){
                                    if ($Sp -eq 3) {
                                            $NeueZeile =  $NeueZeile + "`t" + $Mo # MatrixSpalte
                                        } elseif ($Sp -eq 4) {
                                            $NeueZeile =  $NeueZeile + "`t" + $Mi # MatrixZeile
                                        } else {
                                            $NeueZeile =  $NeueZeile + "`t" + $DLSpaltenSplit[$Sp] # alter Wert 
                                    }
                                }
                                $neueListe=$neueListe + "`n" + $NeueZeile
                        }
                    }
                }
            }
            
            if ($DebugMode -eq "true"){$Text= "## neueListe mit Knoten und Personen gef�llt => neueListe:`t" + $neueListe; Write-Host $Text}


            # dann alle Linien aufnehmen
            # neue Positions-Referenz der Personen und Knoten ist jetzt neue Liste
            $NeueListeSplit=$neueListe.split("`n")

            $AktProzessBereich=$AktProzessBereich + 1
            for($i=1; $i -lt $DLZeilenSplit.count; $i++){
            
                [int]$AktWert=($ProzessBereichStart + $AktProzessBereich*$ProzessBereiche + ($ProzessBereiche)*($i/($DLZeilenSplit.count-1)))
                ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert

                $DLSpaltenSplit=$DLZeilenSplit[$i].split("`t")
                $Typ=$DLSpaltenSplit[6]
                if ($Typ -eq "L") {
                    
                    [int]$StartSpalte = [int]$DLSpaltenSplit[3]
                    [int]$StartZeile=[int]$DLSpaltenSplit[4]
                    [int]$EndeSpalte = [int]$DLSpaltenSplit[7]
                    [int]$EndeZeile=[int]$DLSpaltenSplit[8]
                    $StartID =  $DLSpaltenSplit[9]
                    $EndeID = $DLSpaltenSplit[10]

                
                    [int]$NLStartSpalte=0
                    [int]$NLStartZeile=0
                    [int]$NLEndeSpalte=0
                    [int]$NLEndeZeile=0

                    # suche StartID/EndeID in NeueListeSplit
                    for($NLI=1; $NLI -lt $NeueListeSplit.count; $NLI++){
                        $NeueListeSpaltenSplit=$NeueListeSplit[$NLI].split("`t")
                        if ($NeueListeSpaltenSplit[5] -eq $StartID) {
                            $NLStartSpalte=[int]$NeueListeSpaltenSplit[3]
                            $NLStartZeile=[int]$NeueListeSpaltenSplit[4]
                        }
                        if ($NeueListeSpaltenSplit[5] -eq $EndeID) {
                            $NLEndeSpalte=[int]$NeueListeSpaltenSplit[3]
                            $NLEndeZeile=[int]$NeueListeSpaltenSplit[4]
                        }                
                    }


                    $GleicheZeile="false"
                    if ($DebugMode -eq "true"){$Text= "`t`tWerteVergleich f�r ID (" + $StartID + ") StartZeile:`t" + $StartZeile + " NLStartZeile:`t" + $NLStartZeile + ", StartSpalte:`t" + "`t" + $StartSpalte + " NLStartSpalte:`t" + $NLStartSpalte;Write-Host $Text}
                    if ($DebugMode -eq "true"){$Text= "`t`t               f�r ID (" + $EndeID + ") EndeZeile:`t" + $EndeZeile + " NLEndeZeile:`t" + $NLEndeZeile + ", EndeSpalte:`t" + "`t" + $EndeSpalte + " NLEndeSpalte:`t" + $NLEndeSpalte;Write-Host $Text}

                    if ($StartZeile -eq $NLStartZeile) {if ($StartSpalte -eq $NLStartSpalte){if ($EndeZeile -eq $NLEndeZeile) {if ($EndeSpalte -eq $NLEndeSpalte){
                        if ($DebugMode -eq "true"){$Text= "`t`tWerte identisch => Zeile komplett �bernehmen";Write-Host $Text}
                        $neueListe=$neueListe + "`n" + $DLZeilenSplit[$i]
                        $GleicheZeile="true"
                    }}}}

                    if ($GleicheZeile -eq "false") {
                        if ($DebugMode -eq "true"){$Text= "`t`tWerte nicht identisch => Pos-Werte ersetzen";Write-Host $Text}
                        $NeueZeile=$DLSpaltenSplit[0] # erster Wert ist LNR
                        for($Sp=1; $Sp -lt $DLSpaltenSplit.count; $Sp++){
                            if ($Sp -eq 3) {
                                    $NeueZeile =  $NeueZeile + "`t" + $NLStartSpalte # MatrixSpalte
                                } elseif ($Sp -eq 4) {
                                    $NeueZeile =  $NeueZeile + "`t" + $NLStartZeile # MatrixZeile
                                } elseif ($Sp -eq 7) {
                                    $NeueZeile =  $NeueZeile + "`t" + $NLEndeSpalte # MatrixSpalte
                                } elseif ($Sp -eq 8) {
                                    $NeueZeile =  $NeueZeile + "`t" + $NLEndeZeile # MatrixZeile
                                } else {
                                    $NeueZeile =  $NeueZeile + "`t" + $DLSpaltenSplit[$Sp] # alter Wert 
                            }
                        }
                        $neueListe=$neueListe + "`n" + $NeueZeile
                    }



                }
            }

            
            # jetzt noch die neue Liste nach ZeilenNummern sortieren
            $NeueListeSplit=$neueListe.split("`n")

            #leere Liste erzeugen
            $SortListe=@()
            for($S=0; $S -lt $NeueListeSplit.count+5; $S++){
                $SortListe=$SortListe+0
            }
            
            $AktProzessBereich=$AktProzessBereich + 1
            [int]$AktWert=($ProzessBereichStart + $AktProzessBereich*$ProzessBereiche + $ProzessBereiche/3)
            ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert

            # Liste mit ZeilenNummern fuellen
            for($S=1; $S -lt $NeueListeSplit.count; $S++){
                $NeueListeZeile=$NeueListeSplit[$s]
                $NeueListeZeileSplit=$NeueListeZeile.split("`t")
                $NeueListeZeileZeileNr=$NeueListeZeileSplit[0]
                $SortListe[$NeueListeZeileZeileNr]=$S
            }
            
            
            [int]$AktWert=($ProzessBereichStart + $AktProzessBereich*$ProzessBereiche + 2*$ProzessBereiche/3)
            ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert
            if ($DebugMode -eq "true"){$Text= "`t`tfertige Anordnungs-Liste:`t" + $SortListe;Write-Host $Text}

            $FertigeListe=$NeueListeSplit[0]
            for($S=1; $S -lt $NeueListeSplit.count; $S++){
                $FertigeListe=$FertigeListe + "`n" + $NeueListeSplit[$SortListe[$s]]
            }
            $neueListe=$FertigeListe
        }

        
        ProgressStatus -ProgressLnr $ProzessNr -MaxValue 100 -ActValue 100
        
        if ($DebugMode -eq "true"){$Text= "## KleinFamilienGruppierenKinderUnterEltern fertig => neueListe:`t" + $neueListe;Write-Host $Text}
        return $neueListe
        
    }

    function KleinFamilienGruppierenElternUeberKinder () {
        param (
            $ProzessNr=0,
            $ProzessMax=0,
            $ProzessBereichStart=0, # Start-Wert des verfuegbaren Teil-Bereich des Fortschritts
            $ProzessBereich=0 # verfuegbarer Teil-Bereich des Fortschritts
        )
    
        ##################################################
        # Version V03
        # vom 15.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}
        #$DebugMode = "true"

        if ($DebugMode -eq "true"){$Text= "## KleinFamilienGruppierenKinderUnterEltern startet";Write-Host $Text} 

        #########################################
        ## Fortschritt
        $AnzTeilBereiche=5
        $ProzessBereiche=$ProzessBereich/$AnzTeilBereiche
        $AktProzessBereich=0
        if ($DebugMode -eq "true"){$Text= "## KleinFamilienGruppierenElternUeberKinder Progress-Parameter `t-- ProzessNr:`t" + $ProzessNr + "`tProzessMax:`t" + $ProzessMax+ "`tProzessBereichStart:`t" + $ProzessBereichStart+ "`tProzessBereich:`t" + $ProzessBereich;Write-Host $Text}
        if ($DebugMode -eq "true"){$Text= "##                                                             `t-- AnzTeilBereiche:`t" + $AnzTeilBereiche + "`tProzessBereiche:`t" + $ProzessBereiche;Write-Host $Text}
        #########################################


        $veraendert="false"

        $DLZeilenSplit=$Global:PersonenDrawListe.split("`n")


     
        # Finde Anzahl Zeilen und MaxSpaltenAnzahl
        [int]$DrawZeilenAnz=0
        [int]$MaxSpaltenAnz=0
        for($i=1; $i -lt $DLZeilenSplit.count; $i++){
            $DLSpaltenSplit=$DLZeilenSplit[$i].split("`t")
            [int]$Zeile=[int]$DLSpaltenSplit[4]
            if ($Zeile -gt $DrawZeilenAnz) {$DrawZeilenAnz = $Zeile}

            [int]$Spalte = [int]$DLSpaltenSplit[3]
            if ($Spalte -gt $MaxSpaltenAnz) {$MaxSpaltenAnz = $Spalte}
        }
        if ($DebugMode -eq "true"){$Text= "## ErzeugeMatrix -- in DrawListe gefundene Anz Zeilen:`t" + $DrawZeilenAnz + " und MaxAnzahlSpalten:`t" + $MaxSpaltenAnz;Write-Host $Text} 

        #Puffer dazu
        $MaxSpaltenAnz=$MaxSpaltenAnz + 3
        if ($DebugMode -eq "true"){$Text= "`t`t`t mit Puffer - MaxAnzahlSpalten:`t" + $MaxSpaltenAnz;Write-Host $Text} 
        
        
        [int]$AktWert=($ProzessBereiche/3)
        if ($DebugMode -eq "true"){$Text= "##                      Bereich 1 --"  + "`tAktProzessBereich:`t" + $AktProzessBereich + "AktWert:`t" + $AktWert ;Write-Host $Text}
        ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert

        # baue leere PositionsMatrix
        $PositionsMatrix=@()
        [int]$NullWert=0
        for($i=0; $i -lt $DrawZeilenAnz+2; $i++){
            $ListenZeile=@()
            $ListenZeile = $ListenZeile + ("Z" + $i)
            for($o=0; $o -lt $MaxSpaltenAnz; $o++){
                $ListenZeile = $ListenZeile + $NullWert
            }
            $PositionsMatrix=$PositionsMatrix + $ListenZeile
            if ($DebugMode -eq "true"){$Text= "`t`tPositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text} 
        }
        
        
        [int]$AktWert=(2*$ProzessBereiche/3)
        if ($DebugMode -eq "true"){$Text= "##                      Bereich 1 --"  + "`tAktProzessBereich:`t" + $AktProzessBereich + "AktWert:`t" + $AktWert ;Write-Host $Text}
        ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert

        # alle Personen und Knoten in PositionsMatrix einpflegen
        for($i=1; $i -lt $DLZeilenSplit.count; $i++){
            if ($DLZeilenSplit[$i] -ne "") {
                $DLSpaltenSplit=$DLZeilenSplit[$i].split("`t")
            
                [int]$Lnr = [int]$DLSpaltenSplit[0]
                [int]$Zeile=[int]$DLSpaltenSplit[4]
                [int]$Spalte = [int]$DLSpaltenSplit[3]
                $Typ = $DLSpaltenSplit[6]

                if ($Typ -ne "L") {
                    $PositionsMatrixPos=($Zeile * ($MaxSpaltenAnz+1)) + $Spalte
                    $PositionsMatrix[$PositionsMatrixPos]=$Lnr
                }
            }
        }                

        if ($DebugMode -eq "true"){$Text= "`t`tStart-PositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text} 
                  
        # Matrix von oben her durchlaufen       
        $AktProzessBereich=$AktProzessBereich + 1
        for($Mi=0; $Mi -lt ($DrawZeilenAnz+1); $Mi++){
            $AktMZeile=$Mi # von unten nach oben

            [int]$AktWert=($ProzessBereichStart + $AktProzessBereich*$ProzessBereiche + ($ProzessBereiche)*($Mi/($DrawZeilenAnz.count+1)))
            if ($DebugMode -eq "true"){$Text= "##                      Bereich 2 --"  + "`tAktProzessBereich:`t" + $AktProzessBereich + "AktWert:`t" + $AktWert ;Write-Host $Text}
            ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert

            for($Mo=0; $Mo -lt ($MaxSpaltenAnz ); $Mo++){
                $AktMSpalte=($MaxSpaltenAnz) - $Mo # von rechts nach links

                $PositionsMatrixPos=($AktMZeile * ($MaxSpaltenAnz+1)) + $AktMSpalte
                $DuT=$PositionsMatrix[$PositionsMatrixPos]

                if ($DebugMode -eq "true"){$Text= "`t`tuntersuche DrawlisteZeile:`t" + $DuT + " von MatrixPos " + $AktMZeile + "/" + $AktMSpalte;Write-Host $Text}
                
                if ($DuT -gt 0) {
                    # Auslesen der HTML-ID der Person/knoten von DrawListe Zeile $DuT
                    $DuTZeile=$DLZeilenSplit[$DuT]
                    if ($DebugMode -eq "true"){$Text= "`t`tuntersuche DrawlisteZeile:`t" + $DuT + ", DuTZeile:`t" + $DuTZeile ;Write-Host $Text}
                    $DuTZeileSplit=$DuTZeile.split("`t")
                    $DuTHtmlID=$DuTZeileSplit[5]
                    if ($DebugMode -eq "true"){$Text= "`t`tuntersuche DrawlisteZeile:`t" + $DuT + ", DuTHtmlID:`t" + $DuTHtmlID ;Write-Host $Text}
                 
                    # passende Linie(n) suchen
                    for($i=1; $i -lt $DLZeilenSplit.count; $i++){
            
                        $DLSpaltenSplit=$DLZeilenSplit[$i].split("`t")
                        $Typ = $DLSpaltenSplit[6]

                        if ($Typ -eq "L") {

                            $StartID=$DLSpaltenSplit[9]
                            $EndID=$DLSpaltenSplit[10]

                            [int]$StartZeile=[int]$DLSpaltenSplit[4]
                            [int]$EndZeile=[int]$DLSpaltenSplit[8]

                            [int]$StartSpalte=[int]$DLSpaltenSplit[3]
                            [int]$EndSpalte=[int]$DLSpaltenSplit[7]

                            # Start-Punkt trifft Knoten
                            if ($DebugMode -eq "true"){$Text = "`t ### Start-Punkt trifft Knoten ###";Write-Host $Text}
                            if ($DebugMode -eq "true"){$Text = "`t|<-``ttZeile;`t" + $i + "`t ID-Check StartID:`t" + $StartID+"`tDuTHtmlID:`t" + $DuTHtmlID;Write-Host $Text}
                            if ($StartID -eq $DuTHtmlID) {
                            
                                if ($DebugMode -eq "true"){$Text= "`t`tZeilen-Check StartZeile:`t" + $StartZeile+" EndZeile:`t" + $EndZeile;Write-Host $Text}
                                if ($StartZeile -lt $EndZeile) {
                                    # EndZeile kleiner Startzeile kommt unten ==> Verbindung von aktueller Zeile nach oben
                                    
                                    if ($DebugMode -eq "true"){$Text= "`t`tSpalten-Check AktMSpalte:`t" + $AktMSpalte+" EndSpalte:`t" + $EndSpalte;Write-Host $Text}
                                    if ($AktMSpalte -lt $EndSpalte) {
                                
                                        if ($DebugMode -eq "true"){$Text= "`t`tRechtsWackel startet EndSpalte " + $EndSpalte + " - AktMSpalte " + $AktMSpalte + " = " + ($EndSpalte-$AktMSpalte);Write-Host $Text}
                                        
                                        $WackelIstOk="false"
                                        if ($PositionsMatrix[$PositionsMatrixPos+2] -eq 0) { 
                                                # Pos+2 (weil knoten hat immer auch Partner) ist frei - alles ok - es kann gewackelt werden
                                                $WackelIstOk="true"
                                            
                                        }
                                        if ($WackelIstOk -eq "true") {
                                            # wackel nach rechts
                                            for($w=1; $w -lt (($EndSpalte-$AktMSpalte)+1); $w++){
                                                $RPosDuTR=$PositionsMatrix[$PositionsMatrixPos+$w+1]
                                                if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel - RPosDuTR:`t" + $RPosDuTR;Write-Host $Text}
                                                if ($RPosDuTR -eq 0) {        
                                                        $veraendert="true"
                                                        $PositionsMatrixPos=($AktMZeile * ($MaxSpaltenAnz+1)) + $AktMSpalte
                                                        $PositionsMatrix[$PositionsMatrixPos+$w+1]=$PositionsMatrix[$PositionsMatrixPos+$w]
                                                        $PositionsMatrix[$PositionsMatrixPos+$w]=0
                                                        if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel von DuT:`t" + $DuT+" =>PositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text}
                                                    } else {
                                                        $w= (($EndSpalte-$AktMSpalte)+1)
                                                }
                                                $RPosDuT=$PositionsMatrix[$PositionsMatrixPos+$w]
                                                if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel - RPosDuT:`t" + $RPosDuT;Write-Host $Text}
                                                if ($RPosDuT -eq 0) {        
                                                        $veraendert="true"
                                                        $PositionsMatrixPos=($AktMZeile * ($MaxSpaltenAnz+1)) + $AktMSpalte
                                                        $PositionsMatrix[$PositionsMatrixPos+$w]=$PositionsMatrix[$PositionsMatrixPos+$w-1]
                                                        $PositionsMatrix[$PositionsMatrixPos+$w-1]=0
                                                        if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel von DuT:`t" + $DuT+" =>PositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text}
                                                    } else {
                                                        $w= (($EndSpalte-$AktMSpalte)+1)
                                                }
                                                $RPosDuTL=$PositionsMatrix[$PositionsMatrixPos+$w-1]
                                                if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel - RPosDuTL:`t" + $RPosDuTL;Write-Host $Text}
                                                if ($RPosDuTL -eq 0) {        
                                                        $veraendert="true"
                                                        $PositionsMatrixPos=($AktMZeile * ($MaxSpaltenAnz+1)) + $AktMSpalte
                                                        $PositionsMatrix[$PositionsMatrixPos+$w-1]=$PositionsMatrix[$PositionsMatrixPos+$w-2]
                                                        $PositionsMatrix[$PositionsMatrixPos+$w-2]=0
                                                        if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel von DuT:`t" + $DuT+" =>PositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text}
                                                    } else {
                                                        $w= (($EndSpalte-$AktMSpalte)+1)
                                                }
                                            }
                                        }
                                    }
                                }
                            }


                            # End-Punkt trifft Knoten
                            if ($DebugMode -eq "true"){$Text = "`t ### End-Punkt trifft Knoten ###";Write-Host $Text}
                            if ($DebugMode -eq "true"){$Text = "`t`t->|`tZeile;`t" + $i + "`t ID-Check EndID:`t" + $EndID+" DuTHtmlID:`t" + $DuTHtmlID;Write-Host $Text}
                            if ($EndID -eq $DuTHtmlID) {
                            
                                if ($DebugMode -eq "true"){$Text= "`t`tZeilen-Check StartZeile:`t" + $StartZeile+" EndZeile:`t" + $EndZeile;Write-Host $Text}
                                if ($EndZeile -lt $StartZeile) {
                                    # EndZeile kleiner Startzeile kommt unten ==> Verbindung von aktueller Zeile nach oben
                                    
                                    if ($DebugMode -eq "true"){$Text= "`t`tSpalten-Check AktMSpalte:`t" + $AktMSpalte+" StartSpalte:`t" + $StartSpalte;Write-Host $Text}
                                    if ($AktMSpalte -lt $StartSpalte) {
                                
                                        if ($DebugMode -eq "true"){$Text= "`t`tRechtsWackel startet StartSpalte " + $StartSpalte + " - AktMSpalte " + $AktMSpalte + " = " + ($StartSpalte-$AktMSpalte);Write-Host $Text}

                                        
                                        $WackelIstOk="false"
                                        if ($DebugMode -eq "true"){$text="Wert auf Pos(" + $PositionsMatrixPos + ")+1:" + $PositionsMatrix[$PositionsMatrixPos+1];Write-Host $text}
                                        if ($PositionsMatrix[$PositionsMatrixPos+1] -eq 0) { 
                                                # Pos+1 ist frei - alles ok - es kann gewackelt werden
                                                $WackelIstOk="true"
                                            
                                        }
                                        if ($WackelIstOk -eq "true") {
                                            # wackel nach rechts
                                            for($w=1; $w -lt ($StartSpalte-$AktMSpalte)+1; $w++){
                                                $RPosDuTR=$PositionsMatrix[$PositionsMatrixPos+$w+1]
                                                if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel - RPosDuTR:`t" + $RPosDuTR;Write-Host $Text}
                                                if ($RPosDuTR -eq 0) {    
                                                        $veraendert="true"
                                                        $PositionsMatrixPos=($AktMZeile * ($MaxSpaltenAnz+1)) + $AktMSpalte
                                                        $PositionsMatrix[$PositionsMatrixPos+$w+1]=$PositionsMatrix[$PositionsMatrixPos+$w]
                                                        $PositionsMatrix[$PositionsMatrixPos+$w]=0
                                                        if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel von DuT:`t" + $DuT+" =>PositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text}
                                                    } else {
                                                        $w= ($StartSpalte-$AktMSpalte)+1
                                                }
                                                $RPosDuT=$PositionsMatrix[$PositionsMatrixPos+$w]
                                                if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel - RPosDuT:`t" + $RPosDuT;Write-Host $Text}
                                                if ($RPosDuT -eq 0) {    
                                                        $veraendert="true"
                                                        $PositionsMatrixPos=($AktMZeile * ($MaxSpaltenAnz+1)) + $AktMSpalte
                                                        $PositionsMatrix[$PositionsMatrixPos+$w]=$PositionsMatrix[$PositionsMatrixPos+$w-1]
                                                        $PositionsMatrix[$PositionsMatrixPos+$w-1]=0
                                                        if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel von DuT:`t" + $DuT+" =>PositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text}
                                                    } else {
                                                        $w= ($StartSpalte-$AktMSpalte)+1
                                                }
                                                $RPosDuTL=$PositionsMatrix[$PositionsMatrixPos+$w-1]
                                                if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel - RPosDuTL:`t" + $RPosDuTL;Write-Host $Text}
                                                if ($RPosDuTL -eq 0) {    
                                                        $veraendert="true"
                                                        $PositionsMatrixPos=($AktMZeile * ($MaxSpaltenAnz+1)) + $AktMSpalte
                                                        $PositionsMatrix[$PositionsMatrixPos+$w-1]=$PositionsMatrix[$PositionsMatrixPos+$w-2]
                                                        $PositionsMatrix[$PositionsMatrixPos+$w-2]=0
                                                        if ($DebugMode -eq "true"){$Text= "`t`tRechtswackel von DuT:`t" + $DuT+" =>PositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text}
                                                    } else {
                                                        $w= ($StartSpalte-$AktMSpalte)+1
                                                }
                                            }
                                        }

                                    }
                                }
                            }

                        }
                    }
                }
            }
        }
        if ($DebugMode -eq "true"){$Text= "`t`tfertig gewackelt => PositionsMatrix:`t" + $PositionsMatrix;Write-Host $Text}
          

        $neueListe=""
        if ($veraendert -eq "true") {
                #PositionsMatrix:	Z0 0 0 0 0 0 0 0 0 0 Z1 1 2 3 0 0 0 0 0 0 Z2 6 7 8 16 17 18 0 0 0 Z3 11 13 0 21 23 0 0 0 0 Z4 0 0 0 0 0 0 0 0 0


            # erst alle Personen und Knoten in neue Liste aufnehmen
            $neueListe=$DLZeilenSplit[0] # Header
            # alle TextFelder neu anordnen in neuer Liste
            # Matrix durchlaufen    
            $AktProzessBereich=$AktProzessBereich + 1   
            for($Mi=0; $Mi -lt ($DrawZeilenAnz+1); $Mi++){
                $AktMZeile=$Mi # von oben nach unten

                [int]$AktWert=($ProzessBereichStart + $AktProzessBereich*$ProzessBereiche + ($ProzessBereiche)*($Mi/($DrawZeilenAnz.count+1)))
                if ($DebugMode -eq "true"){$Text= "##                      Bereich 3 --"  + "`tAktProzessBereich:`t" + $AktProzessBereich + "AktWert:`t" + $AktWert ;Write-Host $Text}
                ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert

                for($Mo=1; $Mo -lt ($MaxSpaltenAnz ); $Mo++){
                    $AktMSpalte= $Mo # von links nach rechts

                    # aktuelles Matrix-Element
                    $PositionsMatrixPos=($AktMZeile * ($MaxSpaltenAnz+1)) + $AktMSpalte
                    $DuT=$PositionsMatrix[$PositionsMatrixPos]

                    if ($DebugMode -eq "true"){$Text= "`t`tuntersuche DrawlisteZeile:`t" + $DuT + " von MatrixPos " + $AktMZeile + "/" + $AktMSpalte;Write-Host $Text}
                    
                    # Matrix-Element aus Drawliste auslesen
                    if ($DuT -gt 0) {
                        # Auslesen der HTML-ID der Person/knoten von DrawListe Zeile $DuT
                        $DuTZeile=$DLZeilenSplit[$DuT]
                        $DLSpaltenSplit=$DuTZeile.split("`t")

                        [int]$StartSpalte=[int]$DLSpaltenSplit[3]
                        [int]$StartZeile=[int]$DLSpaltenSplit[4]

                        $GleicheZeile="false"
                        if ($DebugMode -eq "true"){$Text= "`t`tWerteVergleich: StartZeile:`t" + $StartZeile + " Mi:`t" + $Mi + ", StartSpalte:`t" + "`t" + $StartSpalte + " Mo:`t" + $Mo;Write-Host $Text}
                        if ($StartZeile -eq $Mi) {if ($StartSpalte -eq $Mo){
                            if ($DebugMode -eq "true"){$Text= "`t`tWerte identisch => Zeile komplett �bernehmen";Write-Host $Text}
                                $neueListe=$neueListe + "`n" + $DuTZeile
                                $GleicheZeile="true"
                        }}
                        if ($GleicheZeile -eq "false") {
                            if ($DebugMode -eq "true"){$Text= "`t`tWerte nicht identisch => Pos-Werte ersetzen";Write-Host $Text}
                                $NeueZeile=$DLSpaltenSplit[0] # erster Wert ist LNR
                                for($Sp=1; $Sp -lt $DLSpaltenSplit.count; $Sp++){
                                    if ($Sp -eq 3) {
                                            $NeueZeile =  $NeueZeile + "`t" + $Mo # MatrixSpalte
                                        } elseif ($Sp -eq 4) {
                                            $NeueZeile =  $NeueZeile + "`t" + $Mi # MatrixZeile
                                        } else {
                                            $NeueZeile =  $NeueZeile + "`t" + $DLSpaltenSplit[$Sp] # alter Wert 
                                    }
                                }
                                $neueListe=$neueListe + "`n" + $NeueZeile
                        }
                    }
                }
            }
            
            if ($DebugMode -eq "true"){$Text= "## neueListe mit Knoten und Personen gef�llt => neueListe:`t" + $neueListe; Write-Host $Text}


            # dann alle Linien aufnehmen
            # neue Positions-Referenz der Personen und Knoten ist jetzt neue Liste
            $NeueListeSplit=$neueListe.split("`n")

            $AktProzessBereich=$AktProzessBereich + 1
            for($i=1; $i -lt $DLZeilenSplit.count; $i++){
            
                [int]$AktWert=($ProzessBereichStart + $AktProzessBereich*$ProzessBereiche + ($ProzessBereiche)*($i/($DLZeilenSplit.count)))
                if ($DebugMode -eq "true"){$Text= "##                      Bereich 4 --"  + "`tAktProzessBereich:`t" + $AktProzessBereich + "AktWert:`t" + $AktWert ;Write-Host $Text}
                ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert

                $DLSpaltenSplit=$DLZeilenSplit[$i].split("`t")
                $Typ=$DLSpaltenSplit[6]
                if ($Typ -eq "L") {
                    
                    [int]$StartSpalte = [int]$DLSpaltenSplit[3]
                    [int]$StartZeile=[int]$DLSpaltenSplit[4]
                    [int]$EndeSpalte = [int]$DLSpaltenSplit[7]
                    [int]$EndeZeile=[int]$DLSpaltenSplit[8]
                    $StartID =  $DLSpaltenSplit[9]
                    $EndeID = $DLSpaltenSplit[10]

                
                    [int]$NLStartSpalte=0
                    [int]$NLStartZeile=0
                    [int]$NLEndeSpalte=0
                    [int]$NLEndeZeile=0

                    # suche StartID/EndeID in NeueListeSplit
                    for($NLI=1; $NLI -lt $NeueListeSplit.count; $NLI++){
                        $NeueListeSpaltenSplit=$NeueListeSplit[$NLI].split("`t")
                        if ($NeueListeSpaltenSplit[5] -eq $StartID) {
                            $NLStartSpalte=[int]$NeueListeSpaltenSplit[3]
                            $NLStartZeile=[int]$NeueListeSpaltenSplit[4]
                        }
                        if ($NeueListeSpaltenSplit[5] -eq $EndeID) {
                            $NLEndeSpalte=[int]$NeueListeSpaltenSplit[3]
                            $NLEndeZeile=[int]$NeueListeSpaltenSplit[4]
                        }                
                    }


                    $GleicheZeile="false"
                    if ($DebugMode -eq "true"){$Text= "`t`tWerteVergleich f�r ID (" + $StartID + ") StartZeile:`t" + $StartZeile + " NLStartZeile:`t" + $NLStartZeile + ", StartSpalte:`t" + "`t" + $StartSpalte + " NLStartSpalte:`t" + $NLStartSpalte;Write-Host $Text}
                    if ($DebugMode -eq "true"){$Text= "`t`t               f�r ID (" + $EndeID + ") EndeZeile:`t" + $EndeZeile + " NLEndeZeile:`t" + $NLEndeZeile + ", EndeSpalte:`t" + "`t" + $EndeSpalte + " NLEndeSpalte:`t" + $NLEndeSpalte;Write-Host $Text}

                    if ($StartZeile -eq $NLStartZeile) {if ($StartSpalte -eq $NLStartSpalte){if ($EndeZeile -eq $NLEndeZeile) {if ($EndeSpalte -eq $NLEndeSpalte){
                        if ($DebugMode -eq "true"){$Text= "`t`tWerte identisch => Zeile komplett �bernehmen";Write-Host $Text}
                        $neueListe=$neueListe + "`n" + $DLZeilenSplit[$i]
                        $GleicheZeile="true"
                    }}}}

                    if ($GleicheZeile -eq "false") {
                        if ($DebugMode -eq "true"){$Text= "`t`tWerte nicht identisch => Pos-Werte ersetzen";Write-Host $Text}
                        $NeueZeile=$DLSpaltenSplit[0] # erster Wert ist LNR
                        for($Sp=1; $Sp -lt $DLSpaltenSplit.count; $Sp++){
                            if ($Sp -eq 3) {
                                    $NeueZeile =  $NeueZeile + "`t" + $NLStartSpalte # MatrixSpalte
                                } elseif ($Sp -eq 4) {
                                    $NeueZeile =  $NeueZeile + "`t" + $NLStartZeile # MatrixZeile
                                } elseif ($Sp -eq 7) {
                                    $NeueZeile =  $NeueZeile + "`t" + $NLEndeSpalte # MatrixSpalte
                                } elseif ($Sp -eq 8) {
                                    $NeueZeile =  $NeueZeile + "`t" + $NLEndeZeile # MatrixZeile
                                } else {
                                    $NeueZeile =  $NeueZeile + "`t" + $DLSpaltenSplit[$Sp] # alter Wert 
                            }
                        }
                        $neueListe=$neueListe + "`n" + $NeueZeile
                    }



                }
            }

            
            # jetzt noch die neue Liste nach ZeilenNummern sortieren
            $NeueListeSplit=$neueListe.split("`n")

            #leere Liste erzeugen
            $SortListe=@()
            for($S=0; $S -lt $NeueListeSplit.count+5; $S++){
                $SortListe=$SortListe+0
            }
            
            $AktProzessBereich=$AktProzessBereich + 1
            [int]$AktWert=($ProzessBereichStart + $AktProzessBereich*$ProzessBereiche + $AktProzessBereich/3)
            if ($DebugMode -eq "true"){$Text= "##                      Bereich 5 --"  + "`tAktProzessBereich:`t" + $AktProzessBereich + "AktWert:`t" + $AktWert ;Write-Host $Text}
            ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert

            # Liste mit ZeilenNummern fuellen
            for($S=1; $S -lt $NeueListeSplit.count; $S++){
                $NeueListeZeile=$NeueListeSplit[$s]
                $NeueListeZeileSplit=$NeueListeZeile.split("`t")
                $NeueListeZeileZeileNr=$NeueListeZeileSplit[0]
                $SortListe[$NeueListeZeileZeileNr]=$S
            }
            
            [int]$AktWert=($ProzessBereichStart + $AktProzessBereich*$ProzessBereiche + 2*$AktProzessBereich/3)
            if ($DebugMode -eq "true"){$Text= "##                      Bereich 5 --"  + "`tAktProzessBereich:`t" + $AktProzessBereich + "AktWert:`t" + $AktWert ;Write-Host $Text}
            ProgressStatus -ProgressLnr $ProzessNr -MaxValue $ProzessMax -ActValue $AktWert

            if ($DebugMode -eq "true"){$Text= "`t`tfertige Anordnungs-Liste:`t" + $SortListe;Write-Host $Text}

            $FertigeListe=$NeueListeSplit[0]
            for($S=1; $S -lt $NeueListeSplit.count; $S++){
                $FertigeListe=$FertigeListe + "`n" + $NeueListeSplit[$SortListe[$s]]
            }
            $neueListe=$FertigeListe
        }

        
        ProgressStatus -ProgressLnr $ProzessNr -MaxValue 100 -ActValue 100
        
        if ($DebugMode -eq "true"){$Text= "## KleinFamilienGruppierenKinderUnterEltern fertig => neueListe:`t" + $neueListe;Write-Host $Text}

        return $neueListe

    }

#endregion PrepareDrawListe


#region PrepareHtmlCode


    function GetHtmlBodyLine() {
        param (
             $Left1=0,
             $Top1=0,
             $W1=0,
             $H1=0,
             $Left2=0,
             $Top2=0,
             $W2=0,
             $H2=0,
             $ID,
             $StrichDicke
         )
        ##################################################
        # Version V02
        # vom 15.4.2023
        ##################################################

        # $Left, $Top, $KnBoxWidth, $KnBoxHeight, $PeLeft, $PeTop ,$PeBoxWidth, $PeBoxHeight 
        if ($DebugMode -eq "true") {$Text="�bergabe-Parameter: Left1:"+$Left1;Write-Host $Text}
        if ($DebugMode -eq "true") {$Text="�bergabe-Parameter: Top1:"+$Top1;Write-Host $Text}
        if ($DebugMode -eq "true") {$Text="�bergabe-Parameter: W1:"+$W1;Write-Host $Text}
        if ($DebugMode -eq "true") {$Text="�bergabe-Parameter: H1:"+$H1;Write-Host $Text}
        if ($DebugMode -eq "true") {$Text="�bergabe-Parameter: Left2:"+$Left2;Write-Host $Text}
        if ($DebugMode -eq "true") {$Text="�bergabe-Parameter: Top2:"+$Top2;Write-Host $Text}
        if ($DebugMode -eq "true") {$Text="�bergabe-Parameter: W2:"+$W2;Write-Host $Text}
        if ($DebugMode -eq "true") {$Text="�bergabe-Parameter: H2:"+$H2;Write-Host $Text}
        if ($DebugMode -eq "true") {$Text="�bergabe-Parameter: ID:"+$ID;Write-Host $Text}

        $x1=0
        $x2=0
        $y1=0
        $y2=0

        if ($Top1 -eq $Top2) {
                # Verbindung links/rechts

                if($Left1 -lt $Left2) {
                        #1 ist links von 2
                        $x1=($Left1 + $W1)
                        $y1=($Top1+($H1/2))

                        $X2=$Left2
                        $y2=($Top2+($H2/2))
                    } else {
                        #2 ist links von 1
                        $x1=$Left1 
                        $y1=($Top1+($H1/2))

                        $X2=$Left2 + $W2
                        $y2=($Top2+($H2/2))
                }

             } else {
                if($Top1 -lt $Top2) {
                        #1 ist hoeher als 2
                        $x1=($Left1 + ($W1/2))
                        $y1=($Top1+$H1)
                    
                        $x2=($Left2 + ($W2/2))
                        $y2=$Top2
                    } else {
                        #2 ist hoeher als 1
                        $x1=($Left1 + ($W1/2))
                        $y1=$Top1
                    
                        $x2=($Left2 + ($W2/2))
                        $y2=($Top2+$H2)
                }
         }

        if ($DebugMode -eq "true") {$Text="�bergabe-Parameter: x1:"+$x1;Write-Host $Text}
        if ($DebugMode -eq "true") {$Text="�bergabe-Parameter: y1:"+$y1;Write-Host $Text}
        if ($DebugMode -eq "true") {$Text="�bergabe-Parameter: x2:"+$x2;Write-Host $Text}
        if ($DebugMode -eq "true") {$Text="�bergabe-Parameter: y2:"+$y2;Write-Host $Text}

        # distance
        $length = [math]::sqrt(($y1-$y2)*($y1-$y2)+($x1-$x2)*($x1-$x2))
        if ($DebugMode -eq "true") {$Text="Distanz=sqrt((x2-x1)^2 + (y2-y1)^2): sqrt("+ $x2 + "-" + $x1 + ")^2 + ("+ $y2 + "-" + $y1 + ")^2) = sqrt(" + (($x1-$x2)*($x1-$x2)) + ") + (" + (($y1-$y2)*($y1-$y2)) + ") = " + $length;Write-Host $Text}
        # center
        $cx = (($x1 + $x2) / 2) - ($length / 2)
        $cy = (($y1 + $y2) / 2) - ($StrichDicke / 2)
        if ($DebugMode -eq "true") {$Text="cx=(($x1 + $x2) / 2) - ($length / 2): (("+ $x1 + "+" + $x2 + ")/2 - ("+ $length + "/2)) = (" + (($x1 + $x2) / 2) + ")-(" + ($length / 2) + ") = " + $cx;Write-Host $Text}
        if ($DebugMode -eq "true") {$Text="cy=(($y1 + $y2) / 2) - ($StrichDicke / 2): (("+ $y1 + "+" + $y2 + ")/2 - ("+ $StrichDicke + "/2)) = (" + (($y1 + $y2) / 2) + ")-(" + ($StrichDicke / 2) + ") = " + $cy;Write-Host $Text}
        # angle
        $angle = [math]::atan2(($y1-$y2),($x1-$x2))*(180/[math]::pi)
        # make hr
        $Klasse="Linie"
        if ($ID[0] -eq "D") {if ($ID[1] -eq "_") {$Klasse="WdhLinie" }}
        $htmlLine = "<div id=""" + $ID + """ class=""" + $Klasse + """ style='left:" + $cx + "px; top:" + $cy + "px; width:" + $length + "px; -moz-transform:rotate(" + $angle + "deg); -webkit-transform:rotate(" + $angle + "deg); -o-transform:rotate(" + $angle + "deg); -ms-transform:rotate(" + $angle + "deg); transform:rotate(" + $angle + "deg);' ></div>"


        return $htmlLine

    }

    function GetHtmlBody() {
        param (
            $PeBoxWidth=0,
            $PeBoxHeight=0,
            $KnBoxWidth=0,
            $KnBoxHeight=0,
            $StrichFarbe=$black,
            $StrichDicke=1,
            $TopRand=30,
            $LeftRand=30,
            $ZeilenAbstand=10,
            $SpaltenAbstand=10
        )
        
        ##################################################
        # Version V03
        # vom 15.4.2023
        ##################################################

        $OldDebugMode=$DebugMode
        $DebugMode="false"


        if ($DebugMode -eq "true"){
            $text="## GetHtmlBody`t-`tParameter`n`t-`t`tPeBoxWidth:`t" + $PeBoxWidth
            $text=$text + "`n`t-`t`PeBoxHeight:`t" + $PeBoxHeight
            $text=$text + "`n`t-`t`KnBoxWidth:`t" + $KnBoxWidth
            $text=$text + "`n`t-`t`KnBoxHeight:`t" + $KnBoxHeight
            $text=$text + "`n`t-`t`StrichFarbe:`t" + $StrichFarbe
            $text=$text + "`n`t-`t`StrichDicke:`t" + $StrichDicke
            $text=$text + "`n`t-`t`TopRand:`t" + $TopRand
            $text=$text + "`n`t-`t`LeftRand:`t" + $LeftRand
            $text=$text + "`n`t-`t`ZeilenAbstand:`t" + $ZeilenAbstand
            $text=$text + "`n`t-`t`SpaltenAbstand:`t" + $SpaltenAbstand
            Write-Host $text
        }

        # gestorben 0x2020
        # Hochzeit 0x26AD
        # Scheidung: 0x26AE
        # Nutzung: $text="gestorben:" + [char]0x2020 + ": 01.01.2007" 
        # Nutzung: $text="Hochzeit:" + [char]0x26AD + ": 01.01.2007" 
        # Nutzung: $text="Scheidung:" + [char]0x26AE + ": 01.01.2007" 

        $LinienDrawListe=""

        
        $PersonInhalt=GetParameterFromSettings -Parametername "PersonInhalt"
        $KnotenInhalt=GetParameterFromSettings -Parametername "KnotenInhalt"

        $PersonRezeptsplit=$PersonInhalt.split(",")
        $KnotenRezeptsplit=$KnotenInhalt.split(",")

        # fuer Positionierung wird Abstand aufgrund der breitesten Elemente berechnet
        $UniversalWidth=$PeBoxWidth
        if ($PeBoxWidth -lt $KnBoxWidth) {$UniversalWidth=$KnBoxWidth}

        
        # fuer Positionierung wird Abstand aufgrund der hoechsten Elemente berechnet
        $UniversalHeight=$PeBoxHeight
        if ($PeBoxHeight -lt $KnBoxHeight) {$UniversalHeight=$KnBoxHeight}


        $PersonenDrawListe=$Global:PersonenDrawListe
        $PersonenDrawListeSplit=$PersonenDrawListe.split("`n")
               
        # (Lnr von Person oder Knoten, Spalte, Zeile, Namen (Kombination aus Person und zugehioerigem Knoten), Kennzeichnung P oder K oder PD bei Zweit-Ehe, ... restliche Daten)
        # prod:Lnr	KnotenNr	PeNr	DrawSpalte	DrawZeile	Html-ID	Typ (P/K/DP)	LNr	Vorname	Name
        for($i=1; $i -lt $PersonenDrawListeSplit.count; $i++){      

            ProgressStatus -ProgressLnr 3 -MaxValue $PersonenDrawListeSplit.count -ActValue $i

            $PersonenDrawListeZeile=$PersonenDrawListeSplit[$i]
            if ($DebugMode -eq "true"){$text="## GetHtmlBody`t-`tPersonenDrawListeZeile:`t" + $PersonenDrawListeZeile; Write-Host $text}

            if ($PersonenDrawListeZeile -ne "") {
                $PersonenDrawListeZeileSplit=$PersonenDrawListeZeile.split("`t")

                $ID=$PersonenDrawListeZeileSplit[5]

                if ($PersonenDrawListeZeileSplit[6] -eq "L") {
                
                        # Person/Knoten-Classe
                        $Classe="Linie"


                        $ID1=$PersonenDrawListeZeileSplit[9]
                        $ID2=$PersonenDrawListeZeileSplit[10]

                        if ($ID1[0] -eq "K") {
                                # Knoten

                                # ZeilenPosition
                                $Top=0 + $TopRand + ([int]$PersonenDrawListeZeileSplit[4] * ($UniversalHeight + $ZeilenAbstand))
                                # SpaltenPosition
                                $Left=0 + $LeftRand  + ([int]$PersonenDrawListeZeileSplit[3] * ($UniversalWidth + $SpaltenAbstand)) 
                                if ($UniversalWidth -gt $KnBoxWidth) {$Left=$Left + ($UniversalWidth - $KnBoxWidth)/2}

                                $Width1=$KnBoxWidth
                                $Height1=$KnBoxHeight
                            } else {
                                # Person/Partner

                                # ZeilenPosition
                                $Top=0 + $TopRand + ([int]$PersonenDrawListeZeileSplit[4] * ($UniversalHeight + $ZeilenAbstand))
                                # SpaltenPosition
                                $Left=0 + $LeftRand  + ([int]$PersonenDrawListeZeileSplit[3] * ($UniversalWidth + $SpaltenAbstand))
                                if ($UniversalWidth -gt $PeBoxWidth) {$Left=$Left + ($UniversalWidth - $PeBoxWidth)/2}

                                $Width1=$PeBoxWidth
                                $Height1=$PeBoxHeight
                        }

                        if ($ID2[0] -eq "K") {
                                # Knoten

                                # ZeilenPosition
                                $DTop=0 + $TopRand + ([int]$PersonenDrawListeZeileSplit[8] * ($UniversalHeight + $ZeilenAbstand))
                                # SpaltenPosition
                                $DLeft=0 + $LeftRand  + ([int]$PersonenDrawListeZeileSplit[7] * ($UniversalWidth + $SpaltenAbstand))
                                if ($UniversalWidth -gt $KnBoxWidth) {$DLeft=$DLeft + ($UniversalWidth - $KnBoxWidth)/2}
                                $Width2=$KnBoxWidth
                                $Height2=$KnBoxHeight
                            } else {
                                # Person/Partner

                                # ZeilenPosition
                                $DTop=0 + $TopRand + ([int]$PersonenDrawListeZeileSplit[8] * ($UniversalHeight + $ZeilenAbstand))
                                # SpaltenPosition
                                $DLeft=0 + $LeftRand  + ([int]$PersonenDrawListeZeileSplit[7] * ($UniversalWidth + $SpaltenAbstand))
                                if ($UniversalWidth -gt $PeBoxWidth) {$DLeft=$DLeft + ($UniversalWidth - $PeBoxWidth)/2}
                                $Width2=$PeBoxWidth
                                $Height2=$PeBoxHeight

                        }

                        $DpP = $false
                        if ($ID1[0] -eq "D") {if ($ID2[0] -eq "P") {$DpP = $true }}
                        if ($ID2[0] -eq "D") {if ($ID1[0] -eq "P") {$DpP = $true }}

                        
                        # Max-Pse-Werte setzen
                        if ($Top -gt $Global:MaxZeilenPos) {$Global:MaxZeilenPos = $Top}
                        if ($DTop -gt $Global:MaxZeilenPos) {$Global:MaxZeilenPos = $DTop}
                        if ($Left -gt $Global:MaxSpaltenPos) {$Global:MaxSpaltenPos = $Left}
                        if ($DLeft -gt $Global:MaxSpaltenPos) {$Global:MaxSpaltenPos = $DLeft}
                        
                        if ($DpP -eq $true) {
                                # Linie von Person zu Doppel-Person
                                #$text="Treffer"; Write-Host $text
                                $DStrichDicke=(4*$StrichDicke)
                                $NeueStrichID="D_" + $ID1 + "<->" + $ID2
                                #$LineText=GetHtmlBodyLine -Left1 $Left -Top1 $Top -W1 $Width1 -H1 $Height1 -Left2 $DLeft -Top2 $DTop -W2 $Width2 -H2 $Height2 -ID ($KnID + "<->" + $PeID) -StrichDicke $StrichDicke
                                $LineText=GetHtmlBodyLine -Left1 $Left -Top1 $Top -W1 $Width1 -H1 $DStrichDicke -Left2 $DLeft -Top2 $DTop -W2 $Width2 -H2 $DStrichDicke  -ID $NeueStrichID -StrichDicke $DStrichDicke 
                                $LineText="<!-- GetHtmlBodyLine -Left1 $Left -Top1 $Top -W1 $Width1 -H1 " + $DStrichDicke  + " -Left2 $DLeft -Top2 $DTop -W2 $Width2 -H2 " + $DStrichDicke  + " -ID " + $NeueStrichID + " -StrichDicke " + $DStrichDicke  + " -->"  + "`n" + $LineText
                                $HtmlBody=$LineText + "`n" + $HtmlBody
                            } else {
                                #$LineText=GetHtmlBodyLine -Left1 $Left -Top1 $Top -W1 $Width1 -H1 $Height1 -Left2 $DLeft -Top2 $DTop -W2 $Width2 -H2 $Height2 -ID ($KnID + "<->" + $PeID) -StrichDicke $StrichDicke
                                $LineText=GetHtmlBodyLine -Left1 $Left -Top1 $Top -W1 $Width1 -H1 $Height1 -Left2 $DLeft -Top2 $DTop -W2 $Width2 -H2 $Height2 -ID ($ID1 + "<->" + $ID2) -StrichDicke $StrichDicke
                                $LineText="<!-- GetHtmlBodyLine -Left1 $Left -Top1 $Top -W1 $Width1 -H1 $Height1 -Left2 $DLeft -Top2 $DTop -W2 $Width2 -H2 $Height2 -ID (" + $ID1 + " + ""<->"" + " + $ID2 + ") -StrichDicke $StrichDicke -->"  + "`n" + $LineText
                                $HtmlBody=$HtmlBody + "`n" + $LineText
                        }

                    } else { 
                        if ($PersonenDrawListeZeileSplit[6] -eq "K") {
                                # ZeilenPosition
                                $Top=0 + $TopRand + ([int]$PersonenDrawListeZeileSplit[4] * ($UniversalHeight + $ZeilenAbstand))

                                # SpaltenPosition
                                $Left=0 + $LeftRand  + ([int]$PersonenDrawListeZeileSplit[3] * ($UniversalWidth + $SpaltenAbstand))
                                if ($UniversalWidth -gt $KnBoxWidth) {$Left=$Left + ($UniversalWidth - $KnBoxWidth)/2}

                                $Classe="BoxKnoten"
                                # Kn-Text
                                $TextListe=""
                                
                                if ($KnotenRezeptsplit[0] -eq "+") {$TextListe=$TextListe + "`t" + $PersonenDrawListeZeileSplit[1]}
                                if ($KnotenRezeptsplit[1] -eq "+") {$TextListe=$TextListe + "`t" + $global:HochzeitZeichen + $PersonenDrawListeZeileSplit[29]}
                                if ($KnotenRezeptsplit[2] -eq "+") {$TextListe=$TextListe + "`t" + $PersonenDrawListeZeileSplit[31]}
                                if ($KnotenRezeptsplit[3] -eq "+") {$TextListe=$TextListe + "`t" + $global:ScheidungsZeichen + $PersonenDrawListeZeileSplit[30]}

                                $TextListeSplit=$TextListe.split("`t")
                                $HText=""
                                for([int]$T=1; $T -lt $TextListeSplit.count; $T++){   
                                    if ($T -gt 1) {$HText=$HText + "<br>"}
                                    $HText=$HText + $TextListeSplit[$T]
                                }
                                #Write-Host ("neu:[" + $HText + "]")
                                #$HTextOld="" + $PersonenDrawListeZeileSplit[29] + "<br>" + $PersonenDrawListeZeileSplit[31] + "<br>" + $PersonenDrawListeZeileSplit[30]
                                #Write-Host ("alt:[" + $HTextOld + "]")
                            } else {
                                # ZeilenPosition
                                $Top=0 + $TopRand + ([int]$PersonenDrawListeZeileSplit[4] * ($UniversalHeight + $ZeilenAbstand))

                                # SpaltenPosition
                                $Left=0 + $LeftRand  + ([int]$PersonenDrawListeZeileSplit[3] * ($UniversalWidth + $SpaltenAbstand))
                                if ($UniversalWidth -gt $PeBoxWidth) {$Left=$Left + ($UniversalWidth - $PeBoxWidth)/2}

                                # Person/Knoten-Classe
                                if ($PersonenDrawListeZeileSplit[6] -eq "P") {$Classe="BoxPerson"}
                                if ($PersonenDrawListeZeileSplit[6] -eq "DP") {$Classe="BoxWdhPerson"}

                                # Text
                                $TextListe=""
                               # Vorname, ZusatzVorname,Nachname,GebName,GebDatum,GeburtsOrt,Sterbedatum,SterbeOrt_Friedhof,Bemerkung,religion,geschl,nationalit�t
                                if ($PersonRezeptsplit[0] -eq "+") {$TextListe=$TextListe + "`t" + $PersonenDrawListeZeileSplit[7]} #Lnr
                                if ($PersonRezeptsplit[1] -eq "+") {$TextListe=$TextListe + "`t" + $PersonenDrawListeZeileSplit[8]} #Vorname
                                if ($PersonRezeptsplit[2] -eq "+") {$TextListe=$TextListe + "`t" + $PersonenDrawListeZeileSplit[14]} #ZusatzVorname
                                if ($PersonRezeptsplit[3] -eq "+") {$TextListe=$TextListe + "`t" + $PersonenDrawListeZeileSplit[9]} #Nachname
                                if ($PersonRezeptsplit[4] -eq "+") {$TextListe=$TextListe + "`t" + $global:GeborenZeichen + $PersonenDrawListeZeileSplit[10]} #GebName
                                if ($PersonRezeptsplit[5] -eq "+") {$TextListe=$TextListe + "`t" + $global:GeborenZeichen + $PersonenDrawListeZeileSplit[11]} #GebDatum
                                if ($PersonRezeptsplit[6] -eq "+") {$TextListe=$TextListe + "`t" + $PersonenDrawListeZeileSplit[15]} #GeburtsOrt
                                if ($PersonRezeptsplit[7] -eq "+") {$TextListe=$TextListe + "`t" + $global:GestorbenZeichen + $PersonenDrawListeZeileSplit[12]} #Sterbedatum
                                if ($PersonRezeptsplit[8] -eq "+") {$TextListe=$TextListe + "`t" + $PersonenDrawListeZeileSplit[15]} #SterbeOrt_Friedhof
                                if ($PersonRezeptsplit[9] -eq "+") {$TextListe=$TextListe + "`t" + $PersonenDrawListeZeileSplit[13]} #Bemerkung
                                if ($PersonRezeptsplit[10] -eq "+") {$TextListe=$TextListe + "`t" + $PersonenDrawListeZeileSplit[15]} #religion
                                if ($PersonRezeptsplit[11] -eq "+") {$TextListe=$TextListe + "`t" + $PersonenDrawListeZeileSplit[15]} #geschl
                                if ($PersonRezeptsplit[12] -eq "+") {$TextListe=$TextListe + "`t" + $PersonenDrawListeZeileSplit[15]} #nationalit�t

                                $TextListeSplit=$TextListe.split("`t")
                                $HText=""
                                for([int]$T=1; $T -lt $TextListeSplit.count; $T++){   
                                    if ($T -gt 1) {$HText=$HText + "<br>"}
                                    $HText=$HText + $TextListeSplit[$T]
                                }

                                #$HText="" + $PersonenDrawListeZeileSplit[7] + "<br>" + $PersonenDrawListeZeileSplit[8] + "<br>" + $PersonenDrawListeZeileSplit[9]
                        }

                        # Max-Pos-Werte setzen
                        if ($Top -gt $Global:MaxZeilenPos) {$Global:MaxZeilenPos = $Top}
                        if ($DTop -gt $Global:MaxZeilenPos) {$Global:MaxZeilenPos = $DTop}
                        if ($Left -gt $Global:MaxSpaltenPos) {$Global:MaxSpaltenPos = $Left}
                        if ($DLeft -gt $Global:MaxSpaltenPos) {$Global:MaxSpaltenPos = $DLeft}

                        $HtmlBody=$HtmlBody + "`n<div id=`"" + $ID + "`" class=`"" + $Classe + "`" style=`"top: " + $Top + "px; left: " + $Left + "px;`">" + $HText + "</div>"
                }
            
                        # Max-Pos-Werte setzen
                        if ($Top -gt $Global:MaxZeilenPos) {$Global:MaxZeilenPos = $Top}
                        if ($DTop -gt $Global:MaxZeilenPos) {$Global:MaxZeilenPos = $DTop}
                        if ($Left -gt $Global:MaxSpaltenPos) {$Global:MaxSpaltenPos = $Left}
                        if ($DLeft -gt $Global:MaxSpaltenPos) {$Global:MaxSpaltenPos = $DLeft}
                if ($DebugMode -eq "true"){$text="## GetHtmlBody`n`t-`tID:`t" + $ID + "`n`t-`tTop:`t" + $Top + "`n`t-`tLeft:`t" + $Left + "`n`t-`tHText:`t" + $HText; Write-Host $text}



            }

        }
        ProgressStatus -ProgressLnr 3 -MaxValue 100 -ActValue 99

        return $HtmlBody

        $DebugMode=$OldDebugMode

    }

    function GetHeader() {
        param (
            $HTMLTitel="",
            $PeBoxWidth=0,
            $PeBoxHeight=0,
            $KnBoxWidth=0,
            $KnBoxHeight=0,
            $StrichFarbe=$black,
            $StrichDicke=1
        )
        ##################################################
        # Version V02
        # vom 10.4.2023
        ##################################################

        $PeFarbe=GetParameterFromSettings -Parametername "PersonenFarbe"
        $WdhPeFarbe=GetParameterFromSettings -Parametername "WdhPersonenFarbe"
        $KnFarbe=GetParameterFromSettings -Parametername "KnotenFarbe"
        $PeSchriftFarbe=GetParameterFromSettings -Parametername "PersonenSchriftFarbe"
        $WdhPeSchriftFarbe=GetParameterFromSettings -Parametername "WdhPersonenSchriftFarbe"
        $KnSchriftFarbe=GetParameterFromSettings -Parametername "KnotenSchriftFarbe"
        $PeSchriftGroesse=GetParameterFromSettings -Parametername "PersonenSchriftGroesse"
        $WdhPeSchriftGroesse=GetParameterFromSettings -Parametername "WdhPersonenSchriftGroesse"
        $KnSchriftGroesse=GetParameterFromSettings -Parametername "KnotenSchriftGroesse"
        $HintergrundFarbe=GetParameterFromSettings -Parametername "HintergrundFarbe"

        $HtmlHeader="<!DOCTYPE HTML>
                 <html>

                 <head>
                     <title>"  + $HTMLTitel + "</title>
             
                     <style>
	                    .BoxPerson
	                    {
		                    position:absolute; 
		                    background-color:" + $PeFarbe + ";
                            color:" + $PeSchriftFarbe + ";
				            width:" + $PeBoxWidth + "px;
				            height:" + $PeBoxHeight + "px;
                            text-align: center;
                            font-size:" + $PeSchriftGroesse + "px;
		                    padding:0px; 
		                    margin:0px;
	                    }
	                    .BoxWdhPerson
	                    {
		                    position:absolute; 
		                    background-color:" + $WdhPeFarbe + ";
                            color:" + $WdhPeSchriftFarbe + ";
				            width:" + $PeBoxWidth + "px;
				            height:" + $PeBoxHeight + "px;
                            text-align: center;
                            font-size:" + $WdhPeSchriftGroesse + "px;
		                    padding:0px; 
		                    margin:0px;
	                    }
	                    .BoxKnoten
	                    {
		                    position:absolute; 
		                    background-color:" + $KnFarbe + ";
                            color:" + $KnSchriftFarbe + ";
				            width:" + $KnBoxWidth + "px;
				            height:" + $KnBoxHeight + "px;
                            text-align: center;
                            font-size:" + $KnSchriftGroesse + "px;
		                    padding:0px; 
		                    margin:0px;
	                    }
	                    .Linie
	                    { 
		                    background-color:" + $StrichFarbe + ";
				            height:" + $StrichDicke + "px;
                            position:absolute;
                            padding:0px; 
                            margin:0px; 
                            line-height:1px;

	                    }
	                    .WdhLinie
	                    { 
		                    background-color:" + $WdhPeFarbe + ";
				            height:" + (4*$StrichDicke) + "px;
                            position:absolute;
                            padding:0px; 
                            margin:0px; 
                            line-height:1px;

	                    }
	                    .Background
	                    { 
		                    background-color:" + $HintergrundFarbe + ";
                            position:absolute;
                            padding:10px; 
                            margin:10px; 
                            line-height:0px;
                            opacity: 0.1;
	                    }

                    </style>

                    <script>  </script>
                </head>

                <body>

                 "
        # opacity: 0.1; # Transparenz

        return $HtmlHeader

    }

    function GetHtmlFooder() {
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################
        $HtmlFooder=" 
                <script> </script>

            </body>
            </html>
                "

        return $HtmlFooder
    }

    function PrepareHtmlCode() {
    
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################

        if ($DebugMode -eq "true"){Write-Host "## PrepareHtmlCode -- startet"}

        
        [int]$PeBoxWidth=GetParameterFromSettings -Parametername "PersonBreite"
        [int]$PeBoxHeight=GetParameterFromSettings -Parametername "PersonHoehe"
        [int]$KnBoxWidth=GetParameterFromSettings -Parametername "NodeBreite"
        [int]$KnBoxHeight=GetParameterFromSettings -Parametername "NodeHoehe"

        #$PeBoxWidth=70#70
        #$PeBoxHeight=70
        #$KnBoxWidth=70 #70
        #$KnBoxHeight=70
        $StrichDicke=5
        $StrichFarbe="#0F0"

        $TopRand=30
        $LeftRand=30
        [int]$ZeilenAbstand=GetParameterFromSettings -Parametername "Zeilenabstand"
       # $ZeilenAbstand=50#10
        [int]$SpaltenAbstand=GetParameterFromSettings -Parametername "SpaltenAbstand"
        #$SpaltenAbstand=80#10

        $HTMLTitel="MeinHtmlExport-Test"

        if ($DebugMode -eq "true"){Write-Host "baue header"} 
        $HtmlHeader=GetHeader -HTMLTitel $HTMLTitel -PeBoxWidth $PeBoxWidth -PeBoxHeight $PeBoxHeight -KnBoxWidth $KnBoxWidth -KnBoxHeight $KnBoxHeight -StrichFarbe $StrichFarbe -StrichDicke $StrichDicke
        
        if ($DebugMode -eq "true"){Write-Host "baue body"}
        $HtmlBody=GetHtmlBody -PeBoxWidth $PeBoxWidth -PeBoxHeight $PeBoxHeight -KnBoxWidth $KnBoxWidth -KnBoxHeight $KnBoxHeight -StrichFarbe $StrichFarbe -StrichDicke $StrichDicke  -TopRand $TopRand -LeftRand $LeftRand -ZeilenAbstand $ZeilenAbstand -SpaltenAbstand $SpaltenAbstand      
        
        # HintergrundBox
        # breiteste Box-breite finden
        $BoxBreite=0
        if ($PeBoxWidth -gt $KnBoxWidth) {$BoxBreite=$PeBoxWidth} else {$BoxBreite = $KnBoxWidth}
        # hoechste Box-H�he finden
        $Boxhoehe=0
        if ($PeBoxheight -gt $KnBoxheight) {$Boxhoehe=$PeBoxheight} else {$Boxhoehe = $KnBoxheight}

        $MaxWidth=$Global:MaxSpaltenPos + $BoxBreite + $SpaltenAbstand
        $Maxheight=$Global:MaxZeilenPos + $Boxhoehe + $ZeilenAbstand
        $Hintergrund = "<div id=""Hintergrund"" class=""Background"" style=""top: 20px; left: 20px;width:" + $MaxWidth + "px;height:" + $Maxheight + "px;""></div>`n"

        if ($DebugMode -eq "true"){Write-Host "baue fooder"}
        $HtmlFooder=GetHtmlFooder


        $HtmlCode=$HtmlHeader + $Hintergrund + $HtmlBody  + $HtmlFooder

        if ($DebugMode -eq "true"){Write-Host "## beende PrepareHtmlCode"}
        return $HtmlCode
    }
#endregion PrepareHtmlCode

#region Export grafisch
    function ExportAsHtmlAllIn() {
        ##################################################
        # Version V03
        # vom 10.4.2023
        ##################################################
    
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        if ($DebugMode -eq "true") { $text="## ExportAsHtmlAllIn startet";Write-Host $text}


        $PB4Max=4
        
        ProgressStatus -ProgressLnr 1 -MaxValue 100 -ActValue 0
        ProgressStatus -ProgressLnr 2 -MaxValue 100 -ActValue 0
        ProgressStatus -ProgressLnr 3 -MaxValue 100 -ActValue 0

        ProgressStatus -ProgressLnr 4 -MaxValue $PB4Max -ActValue 1
        PrepareDrawListe

        $SourceDataFolder=GetParameterFromSettings -Parametername "ExportZielPfad"

        if ($Global:LogMode -eq "true"){
            $RouteFile=$SourceDataFolder + "\PersonenDrawListe_Full.sdb"
            $Global:Route| Out-File -FilePath $RouteFile
        
            $PersonenDrawRawListeFile=$SourceDataFolder + "\PersonenDrawListe_raw_Full.sdb"
            $Global:PersonenDrawListe| Out-File -FilePath $PersonenDrawRawListeFile
        }
        
        $PB2Label.text=GetTextFromLanguageDB -ID "4_M_RES_1" #"Zeichnungs-H�he einpassen"
        ProgressStatus -ProgressLnr 4 -MaxValue $PB4Max -ActValue 2        
        PlaceOnPaper -ProzessNr 2 -ProzessMax 100 -ProzessBereichStart 0 -ProzessBereich 100
        
        if ($Global:LogMode -eq "true"){
            $PersonenDrawListeFile=$SourceDataFolder + "\PersonenDrawListe" + $StartPersonNr + ".sdb"
            $Global:PersonenDrawListe| Out-File -FilePath $PersonenDrawListeFile
        }

        if ($global:Spaltenwackeln -eq "true") {
            $WackelLnr1=0
            $WackelLnr2=0
            $WackelLnr=0
            $veraendert="true"
            while($veraendert -eq "true") 
            { 
                $WackelLnr=$WackelLnr+1    
                if ($DebugMode -eq "true"){Write-Host "WackelLnr: $WackelLnr"  }

                $KuEveraendert="true"
                while($KuEveraendert -eq "true") 
                {        
                    $WackelLnr1=$WackelLnr1+1    
                    if ($DebugMode -eq "true"){Write-Host "WackelLnr1: $WackelLnr1"     }
                                        
                    $PB2Label.text=GetTextFromLanguageDB -ID "4_M_RES_2" #"Kinder unter Eltern plazieren"

                    $NeueListeGewackelt=KleinFamilienGruppierenKinderUnterEltern -ProzessNr 2 -ProzessMax 100 -ProzessBereichStart 0 -ProzessBereich 100

                    if ($NeueListeGewackelt -ne "") {
                            if ($Global:LogMode -eq "true"){
                                $neueListeFile=$SourceDataFolder + "\PersonenDrawListe_Gewackelt" + $StartPersonNr + "W1_" + $WackelLnr1 + ".sdb"
                                if ($DebugMode -eq "true"){Write-Host "neueListeFile: $neueListeFile"}
                                $NeueListeGewackelt| Out-File -FilePath $neueListeFile
                            }
                            $Global:PersonenDrawListe = $NeueListeGewackelt

                        } else {
                            $KuEveraendert="false"
                    }
                }

                $EuKveraendert="true"
                while($EuKveraendert -eq "true") 
                {     
                    $WackelLnr2=$WackelLnr2+1 
                    if ($DebugMode -eq "true"){Write-Host "WackelLnr2: $WackelLnr2"}
                    
                    $PB2Label.text=GetTextFromLanguageDB -ID "4_M_RES_3" #"Eltern �ber Kinder plazieren"
                    $NeueListeGewackelt=KleinFamilienGruppierenElternUeberKinder -ProzessNr 2 -ProzessMax 100 -ProzessBereichStart 0 -ProzessBereich 100

                    if ($NeueListeGewackelt -ne "") {
                            if ($Global:LogMode -eq "true"){
                                $neueListeFile=$SourceDataFolder + "\PersonenDrawListe_Gewackelt" + $StartPersonNr + "W2_" + $WackelLnr2  + ".sdb"
                                if ($DebugMode -eq "true"){Write-Host "neueListeFile: $neueListeFile"     }
                                $NeueListeGewackelt| Out-File -FilePath $neueListeFile
                            }
                            $Global:PersonenDrawListe = $NeueListeGewackelt
                            #$veraendert="true"
                           # $EuKveraendert="true"
                        } else {
                            $EuKveraendert="false"
                    }
                }

                if ($KuEveraendert -eq "false"){if ($EuKveraendert -eq "false"){  $veraendert="false"}}
                            
            }

        }

        ProgressStatus -ProgressLnr 4 -MaxValue $PB4Max -ActValue 3
        $HtmlCode=PrepareHtmlCode
        
        
        $SourceDataFile=$SourceDataFolder + "\Export_Full.html"
        $HtmlCode| Out-File -FilePath $SourceDataFile

        ProgressStatus -ProgressLnr 4 -MaxValue $PB4Max -ActValue 4
        return $SourceDataFile
    }

    function ExportAsHtmlSingleTree() {
    
        ##################################################
        # Version V02
        # vom 7.4.2023
        ##################################################
        if ($DebugMode -eq "true"){$Text= "## ExportAsHtmlSingleTree - startet";Write-Host $Text} 
        $PB4Max=6

        ProgressStatus -ProgressLnr 1 -MaxValue 100 -ActValue 0
        ProgressStatus -ProgressLnr 2 -MaxValue 100 -ActValue 0
        ProgressStatus -ProgressLnr 3 -MaxValue 100 -ActValue 0
        ProgressStatus -ProgressLnr 4 -MaxValue $PB4Max -ActValue 1

        $StartPersonNr = SelectPerson2

        if ($DebugMode -eq "true"){$Text= "## ExportAsHtmlSingleTree - ausgew�hlte Start-Person:`t" + $StartPersonNr;Write-Host $Text}
        
        ProgressStatus -ProgressLnr 4 -MaxValue $PB4Max -ActValue 2
        $KnListe=FindeAlleKnotenVonPersonNr -PersonLnr $StartPersonNr

        if ($DebugMode -eq "true"){$Text= "## ExportAsHtmlSingleTree - KnotenListe der Start-Person:`t" + $KnListe;Write-Host $Text}
        
        ProgressStatus -ProgressLnr 4 -MaxValue $PB4Max -ActValue 3
        if ($DebugMode -eq "true"){$Text= "## ExportAsHtmlSingleTree - Aufruf von PrepareDrawListe mit StartKnoten:`t" + $KnListe.split("`t")[0];Write-Host $Text} 
        PrepareDrawListe -SingleTreeStartNode $KnListe.split("`t")[0]

        ProgressStatus -ProgressLnr 1 -MaxValue 100 -ActValue 100


        $SourceDataFolder=GetParameterFromSettings -Parametername "ExportZielPfad"

        #Write-Host "LogMode:$Global:LogMode"
        if ($Global:LogMode -eq "true"){
            $RouteFile=$SourceDataFolder + "\Route" + $StartPersonNr + ".sdb"
            $Global:Route| Out-File -FilePath $RouteFile
        
            $PersonenDrawRawListeFile=$SourceDataFolder + "\PersonenDrawListe_raw" + $StartPersonNr + ".sdb"
            $Global:PersonenDrawListe| Out-File -FilePath $PersonenDrawRawListeFile
        }

        ProgressStatus -ProgressLnr 4 -MaxValue $PB4Max -ActValue 4
        PlaceOnPaper

        
        if ($Global:LogMode -eq "true"){
            $PersonenDrawListeFile=$SourceDataFolder + "\PersonenDrawListe" + $StartPersonNr + ".sdb"
            $Global:PersonenDrawListe| Out-File -FilePath $PersonenDrawListeFile
        }

        if ($global:Spaltenwackeln -eq "true") {
            $WackelLnr1=0
            $WackelLnr2=0
            $WackelLnr=0
            $veraendert="true"
            while($veraendert -eq "true") 
            { 
                $WackelLnr=$WackelLnr+1    
                if ($DebugMode -eq "true"){Write-Host "WackelLnr: $WackelLnr"  }

                $KuEveraendert="true"
                while($KuEveraendert -eq "true") 
                {        
                    $WackelLnr1=$WackelLnr1+1    
                    if ($DebugMode -eq "true"){Write-Host "WackelLnr1: $WackelLnr1"     }
                                        
                    $PB2Label.text=GetTextFromLanguageDB -ID "4_M_RES_2" #"Kinder unter Eltern plazieren"

                    $NeueListeGewackelt=KleinFamilienGruppierenKinderUnterEltern -ProzessNr 2 -ProzessMax 100 -ProzessBereichStart 0 -ProzessBereich 100

                    if ($NeueListeGewackelt -ne "") {
                        
                            if ($Global:LogMode -eq "true"){
                                $neueListeFile=$SourceDataFolder + "\PersonenDrawListe_Gewackelt" + $StartPersonNr + "W1_" + $WackelLnr1 + ".sdb"
                                if ($DebugMode -eq "true"){Write-Host "neueListeFile: $neueListeFile"     }
                                $NeueListeGewackelt| Out-File -FilePath $neueListeFile
                            }

                            $Global:PersonenDrawListe = $NeueListeGewackelt

                        } else {
                            $KuEveraendert="false"
                    }
                }

                $EuKveraendert="true"
                while($EuKveraendert -eq "true") 
                {     
                    $WackelLnr2=$WackelLnr2+1 
                    if ($DebugMode -eq "true"){Write-Host "WackelLnr2: $WackelLnr2"}
                    
                    $PB2Label.text=GetTextFromLanguageDB -ID "4_M_RES_3" #"Eltern �ber Kinder plazieren"
                    $NeueListeGewackelt=KleinFamilienGruppierenElternUeberKinder -ProzessNr 2 -ProzessMax 100 -ProzessBereichStart 0 -ProzessBereich 100

                    if ($NeueListeGewackelt -ne "") {
                            if ($Global:LogMode -eq "true"){
                                $neueListeFile=$SourceDataFolder + "\PersonenDrawListe_Gewackelt" + $StartPersonNr + "W2_" + $WackelLnr2  + ".sdb"
                                if ($DebugMode -eq "true"){Write-Host "neueListeFile: $neueListeFile"     }
                                $NeueListeGewackelt| Out-File -FilePath $neueListeFile
                            }

                            $Global:PersonenDrawListe = $NeueListeGewackelt
                            #$veraendert="true"
                           # $EuKveraendert="true"
                        } else {
                            $EuKveraendert="false"
                    }
                }

                if ($KuEveraendert -eq "false"){if ($EuKveraendert -eq "false"){  $veraendert="false"}}
                            
            }

        }
        
        ProgressStatus -ProgressLnr 2 -MaxValue 100 -ActValue 100
        ProgressStatus -ProgressLnr 4 -MaxValue $PB4Max -ActValue 5
        

        $HtmlCode=PrepareHtmlCode
        
        ProgressStatus -ProgressLnr 3 -MaxValue 100 -ActValue 100
        ProgressStatus -ProgressLnr 4 -MaxValue $PB4Max -ActValue 6
        
        
        $SourceDataFile=$SourceDataFolder + "\Export" + $StartPersonNr + ".html"
        $HtmlCode| Out-File -FilePath $SourceDataFile

        return $SourceDataFile
    }

    function ExportAsHtmlAllTopTrees() {
        ##################################################
        # Version V02
        # vom 7.4.2023
        ##################################################

        if ($DebugMode -eq "true"){$Text= "## ExportAsHtmlAllTopTrees - startet";Write-Host $Text} 
        
        
        # suche alle elternlose Top-Tree-Knoten
        $TopKnotenListe=""
        $KnotenDBSplit=$global:KnotenDB.split("`n")
        # ProgressBalken4 = GesamtStatus aller TopLevel-Trees - jeder einzelne Tree ist im ProgressBalken1
        ProgressStatus -ProgressLnr 4 -MaxValue $KnotenDBSplit.count -ActValue 1
        for([int]$i=1; $i -lt $KnotenDBSplit.count; $i++){
            
            ProgressStatus -ProgressLnr 1 -MaxValue $KnotenDBSplit.count -ActValue $i
            $DebugMode="false"

            $StartKnoten=$i
            $PaKnoten=FindePartnerKnotenVonKnoten -KnotenNr $StartKnoten
            if ($PaKnoten -ne 0) {
                $PeKnoten=FindePartnerKnotenVonKnoten -KnotenNr $PaKnoten
                if ($PeKnoten -eq $StartKnoten) {
                    if ($DebugMode -eq "true"){$Text= "## ExportAsHtmlAllTopTrees - Treffer! AktKnoten " + $StartKnoten + " hat Partnerknoten " + $PaKnoten;Write-Host $Text} 
                
                    if($PaKnoten -gt $StartKnoten) {
                        # wenn $StartKnoten > als $PaKnoten, dann ist $PaKnoten schon in Liste ==> nix  zu tun

                        $KnotenSplit=$KnotenDBSplit[$i].split("`t")

                        $Pe=$KnotenSplit[1]
                        $EPe1=$KnotenSplit[2]
                        $EPe2=$KnotenSplit[3]
                        $Pa=$KnotenSplit[4]

                        $PaKnotenSplit=$KnotenDBSplit[$PaKnoten].split("`t")
                        $EPa1=$PaKnotenSplit[2]
                        $EPa2=$PaKnotenSplit[3]

                        if ($DebugMode -eq "true"){$Text= "## ExportAsHtmlAllTopTrees - Pe:`t" + $Pe + "`tEPe1:" + $EPe1 + "`tEPe2:" + $EPe2 + "`tPa:" + $Pa + "`tEPa1:" + $EPa1 + "`tEPa2:" + $EPa2 ;Write-Host $Text}
                        # nur wenn beide Partner elternlos sind Baum erstellen
                        if ($EPe1 -eq 0) { if ($EPe2 -eq 0){if ($EPa1 -eq 0) { if ($EPa2 -eq 0){if ($Pe -ne 0) { if ($Pa -ne 0){
                            $TopKnotenListe=$TopKnotenListe + "`t" + $i
                            if ($DebugMode -eq "true"){$Text= "## ExportAsHtmlAllTopTrees - Passt -> TopKnotenListe:`t" + $TopKnotenListe;Write-Host $Text}
                        }}}}}}

                    }


                }
            }

        }
        if ($DebugMode -eq "true"){$Text= "## ExportAsHtmlAllTopTrees - TrefferListe:`t" + $TopKnotenListe;Write-Host $Text}
        
        $TopKnotenListeSplit=$TopKnotenListe.split("`t")
        for([int]$i=1; $i -lt $TopKnotenListeSplit.count; $i++){

            ProgressStatus -ProgressLnr 1 -MaxValue 100 -ActValue 1
            ProgressStatus -ProgressLnr 2 -MaxValue 100 -ActValue 1
            ProgressStatus -ProgressLnr 3 -MaxValue 100 -ActValue 1
            ProgressStatus -ProgressLnr 4 -MaxValue ($TopKnotenListeSplit.count + 1 ) -ActValue (1 + $i)
            $DebugMode="false"
                
            if ($DebugMode -eq "true"){$Text= "## ExportAsHtmlAllTopTrees - Aufruf von PrepareDrawListe mit " + $i + "-tem StartKnoten:`t" + $TopKnotenListeSplit[$i];Write-Host $Text} 
            
            # Baum erstellen (Route Planen)
            DataInit
            PrepareDrawListe -SingleTreeStartNode $TopKnotenListeSplit[$i]


            if ($Global:PersonenDrawListe -ne "") {


                
                if ($Global:LogMode -eq "true"){
                    $SourceDataFolder=GetParameterFromSettings -Parametername "ExportZielPfad"
                    #$SourceDataFolder="D:\_Stammbaum_Zeugs\NeuMitPowershell\ZielDateien"
                   # $SourceDataFolder="D:\_Stammbaum_Zeugs\NeuMitPowershell"
                    $RouteFile=$SourceDataFolder + "\Route" + $TopKnotenListeSplit[$i] + ".sdb"
                    $Global:Route| Out-File -FilePath $RouteFile

                    #$SourceDataFolder="D:\_Stammbaum_Zeugs\NeuMitPowershell"
                    $PersonenDrawListeFile=$SourceDataFolder + "\PersonenDrawListe_raw" + $TopKnotenListeSplit[$i] + ".sdb"
                    $Global:PersonenDrawListe| Out-File -FilePath $PersonenDrawListeFile
                }

                ProgressStatus -ProgressLnr 1 -MaxValue 100 -ActValue 100
            
                # auf Papier positionieren (Minus-Zeilen eliminieren)
                PlaceOnPaper

                
                if ($Global:LogMode -eq "true"){
                    $PersonenDrawListeFile=$SourceDataFolder + "\PersonenDrawListe" + $StartPersonNr + ".sdb"
                    $Global:PersonenDrawListe| Out-File -FilePath $PersonenDrawListeFile
                }

                if ($global:Spaltenwackeln -eq "true") {
                    $WackelLnr1=0
                    $WackelLnr2=0
                    $WackelLnr=0
                    $veraendert="true"
                    while($veraendert -eq "true") 
                    { 
                        $WackelLnr=$WackelLnr+1    
                        if ($DebugMode -eq "true"){Write-Host "WackelLnr: $WackelLnr"  }

                        $KuEveraendert="true"
                        while($KuEveraendert -eq "true") 
                        {        
                            $WackelLnr1=$WackelLnr1+1    
                            if ($DebugMode -eq "true"){Write-Host "WackelLnr1: $WackelLnr1"     }
                                        
                            $PB2Label.text=GetTextFromLanguageDB -ID "4_M_RES_2" #"Kinder unter Eltern plazieren"

                            $NeueListeGewackelt=KleinFamilienGruppierenKinderUnterEltern -ProzessNr 2 -ProzessMax 100 -ProzessBereichStart 0 -ProzessBereich 100

                            if ($NeueListeGewackelt -ne "") {
                                
                                    if ($Global:LogMode -eq "true"){
                                        $neueListeFile=$SourceDataFolder + "\PersonenDrawListe_Gewackelt" + $StartPersonNr + "W1_" + $WackelLnr1 + ".sdb"
                                        if ($DebugMode -eq "true"){Write-Host "neueListeFile: $neueListeFile"     }
                                        $NeueListeGewackelt| Out-File -FilePath $neueListeFile
                                    }

                                    $Global:PersonenDrawListe = $NeueListeGewackelt

                                } else {
                                    $KuEveraendert="false"
                            }
                        }

                        $EuKveraendert="true"
                        while($EuKveraendert -eq "true") 
                        {     
                            $WackelLnr2=$WackelLnr2+1 
                            if ($DebugMode -eq "true"){Write-Host "WackelLnr2: $WackelLnr2"}
                    
                            $PB2Label.text=GetTextFromLanguageDB -ID "4_M_RES_3" #"Eltern �ber Kinder plazieren"
                            $NeueListeGewackelt=KleinFamilienGruppierenElternUeberKinder -ProzessNr 2 -ProzessMax 100 -ProzessBereichStart 0 -ProzessBereich 100

                            if ($NeueListeGewackelt -ne "") {
                            
                                    if ($Global:LogMode -eq "true"){
                                        $neueListeFile=$SourceDataFolder + "\PersonenDrawListe_Gewackelt" + $StartPersonNr + "W2_" + $WackelLnr2  + ".sdb"
                                        if ($DebugMode -eq "true"){Write-Host "neueListeFile: $neueListeFile"     }
                                        $NeueListeGewackelt| Out-File -FilePath $neueListeFile
                                    }

                                    $Global:PersonenDrawListe = $NeueListeGewackelt
                                    #$veraendert="true"
                                   # $EuKveraendert="true"
                                } else {
                                    $EuKveraendert="false"
                            }
                        }

                        if ($KuEveraendert -eq "false"){if ($EuKveraendert -eq "false"){  $veraendert="false"}}
                            
                    }

                }



                ProgressStatus -ProgressLnr 2 -MaxValue 100 -ActValue 100
            
                # auf Draw-Liste HTML-Seite erstellen
                $HtmlCode=""
                $HtmlCode=PrepareHtmlCode
        
                ProgressStatus -ProgressLnr 3 -MaxValue 100 -ActValue 100
        
                $SourceDataFile=$SourceDataFolder + "\ExportTopKnoten" + $TopKnotenListeSplit[$i] + ".html"
                $HtmlCode| Out-File -FilePath $SourceDataFile
            }
        }

        ProgressStatus -ProgressLnr 4 -MaxValue 100 -ActValue 100

        return $SourceDataFolder
    }

#endregion Export grafisch


#region GUI

[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")


#region Sub Menue SelectPerson
    ##############################################################
    ### Sub Menue SelectPerson
    $SelectPersonForm_ErsterButton_OnClick={
        $SelectPersonLNRtextBox.Text=1
        SelectPersonFelderFuellen
    }

    $SelectPersonForm_LetzterButton_OnClick={
        $SelectPersonLNRtextBox.Text=$global:PersonenDB.Length-1
        SelectPersonFelderFuellen
    }   

    $SelectPersonForm_RueckButton_OnClick={
        [int]$dummy=$SelectPersonLNRtextBox.Text
        if ($dummy -gt 1) { $SelectPersonLNRtextBox.Text=$dummy - 1}
        SelectPersonFelderFuellen
    }  

    $SelectPersonForm_VorButton_OnClick={
        [int]$dummy=$SelectPersonLNRtextBox.Text
        if ($dummy -lt $global:PersonenDB.Length - 1){$SelectPersonLNRtextBox.Text=$dummy + 1}
        SelectPersonFelderFuellen
    }   

    function SelectPersonFelderFuellen {
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################
    
        $PersonLnr = $SelectPersonLNRtextBox.Text

    
        if ($DebugMode -eq "true") {$Text="hole Daten von Person Nr:" +  $PersonLnr;Write-Host $Text}
        $PersonenDaten=GetPersonMitNr($PersonLnr)
        if ($DebugMode -eq "true") {Write-Host "PersonenDaten:";Write-Host $PersonenDaten}

        if ($PersonenDaten -ne "") {
            $PersonenDatenSplit=$PersonenDaten.Split("`t")

            $SelectPersonLNRtextBox.Text         = $PersonenDatenSplit[0]
            $SelectPersonVornametextBox.Text     = $PersonenDatenSplit[1]
            $SelectPersonNachnametextBox.Text    = $PersonenDatenSplit[2]
            $SelectPersonGebNametextBox.Text     = $PersonenDatenSplit[3]
            $SelectPersonGebDatumtextBox.Text    = $PersonenDatenSplit[4]
            $SelectPersonSterbeDatumtextBox.Text = $PersonenDatenSplit[5]
            $SelectPersonBemerkungtextBox.Text   = $PersonenDatenSplit[6]
        }
    }

    function SelectPerson2 {
        ##################################################
        # Version V02
        # vom 10.4.2023
        # == Version V01 von Stammbaum_DatenEingabe_V11.ps1 aber mit "OK"-Dialog-Result
        ##################################################

        if ($DebugMode -eq "true") {Write-Host "starte Sub Men� SelectPerson"}

        $global:AktPersonNr=1

        $HorrAbstand=5
        $ZeilenAbstand=10

        $LabelWidth=100
        $LabelHeight=20
        $LabelLeft=20
        $TextBoxLeft=$LabelLeft + $LabelWidth + $HorrAbstand
        $TextBoxWidth=200
    
        # GUI erzeugen
        $SelectPersonForm = New-Object System.Windows.Forms.Form
        $SelectPersonForm.StartPosition = "CenterScreen"
        $SelectPersonForm.Text = GetTextFromLanguageDB -ID "4_2" #"Stammbaum Settings-Manager"
        $SelectPersonForm.width = ($LabelWidth+$TextBoxWidth+$HorrAbstand+$LabelLeft+30)

        $ZeilenTop=20
        # Label LNR
        $SelectPersonLNRLabel = New-Object System.Windows.Forms.Label
        $SelectPersonLNRLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $SelectPersonLNRLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $SelectPersonLNRLabel.Text=GetTextFromLanguageDB -ID "4_M_101" #"LNr"
        $SelectPersonForm.Controls.Add($SelectPersonLNRLabel)

        $SelectPersonLNRtextBox = New-Object System.Windows.Forms.TextBox
        $SelectPersonLNRtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $SelectPersonLNRtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $SelectPersonForm.Controls.Add($SelectPersonLNRtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Vorname
        $SelectPersonVornameLabel = New-Object System.Windows.Forms.Label
        $SelectPersonVornameLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $SelectPersonVornameLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $SelectPersonVornameLabel.Text=GetTextFromLanguageDB -ID "4_M_102" #"Vorname"
        $SelectPersonForm.Controls.Add($SelectPersonVornameLabel)

        $SelectPersonVornametextBox = New-Object System.Windows.Forms.TextBox
        $SelectPersonVornametextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $SelectPersonVornametextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $SelectPersonForm.Controls.Add($SelectPersonVornametextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Nachname
        $SelectPersonNachnameLabel = New-Object System.Windows.Forms.Label
        $SelectPersonNachnameLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $SelectPersonNachnameLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $SelectPersonNachnameLabel.Text=GetTextFromLanguageDB -ID "4_M_103" #"Nachname"
        $SelectPersonForm.Controls.Add($SelectPersonNachnameLabel)

        $SelectPersonNachnametextBox = New-Object System.Windows.Forms.TextBox
        $SelectPersonNachnametextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $SelectPersonNachnametextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $SelectPersonForm.Controls.Add($SelectPersonNachnametextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label GebName
        $SelectPersonGebNameLabel = New-Object System.Windows.Forms.Label
        $SelectPersonGebNameLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $SelectPersonGebNameLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $SelectPersonGebNameLabel.Text=GetTextFromLanguageDB -ID "4_M_104" #"Geburts-name"
        $SelectPersonForm.Controls.Add($SelectPersonGebNameLabel)

        $SelectPersonGebNametextBox = New-Object System.Windows.Forms.TextBox
        $SelectPersonGebNametextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $SelectPersonGebNametextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $SelectPersonForm.Controls.Add($SelectPersonGebNametextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label GebDatum
        $SelectPersonGebDatumLabel = New-Object System.Windows.Forms.Label
        $SelectPersonGebDatumLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $SelectPersonGebDatumLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $SelectPersonGebDatumLabel.Text=GetTextFromLanguageDB -ID "4_M_105" #"Geburts-Datum"
        $SelectPersonForm.Controls.Add($SelectPersonGebDatumLabel)

        $SelectPersonGebDatumtextBox = New-Object System.Windows.Forms.TextBox
        $SelectPersonGebDatumtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $SelectPersonGebDatumtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $SelectPersonForm.Controls.Add($SelectPersonGebDatumtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label SterbeDatum
        $SelectPersonSterbeDatumLabel = New-Object System.Windows.Forms.Label
        $SelectPersonSterbeDatumLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $SelectPersonSterbeDatumLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $SelectPersonSterbeDatumLabel.Text=GetTextFromLanguageDB -ID "4_M_106" #"Sterbe-Datum"
        $SelectPersonForm.Controls.Add($SelectPersonSterbeDatumLabel)

        $SelectPersonSterbeDatumtextBox = New-Object System.Windows.Forms.TextBox
        $SelectPersonSterbeDatumtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $SelectPersonSterbeDatumtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $SelectPersonForm.Controls.Add($SelectPersonSterbeDatumtextBox)

        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        # Label Bemerkung
        $SelectPersonBemerkungLabel = New-Object System.Windows.Forms.Label
        $SelectPersonBemerkungLabel.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $SelectPersonBemerkungLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $SelectPersonBemerkungLabel.Text=GetTextFromLanguageDB -ID "4_M_107" #"Bemerkung"
        $SelectPersonForm.Controls.Add($SelectPersonBemerkungLabel)

        $SelectPersonBemerkungtextBox = New-Object System.Windows.Forms.TextBox
        $SelectPersonBemerkungtextBox.Location = New-Object System.Drawing.Point($TextBoxLeft, $ZeilenTop)
        $SelectPersonBemerkungtextBox.Size = New-Object System.Drawing.Size($TextBoxWidth,$LabelHeight)
        $SelectPersonForm.Controls.Add($SelectPersonBemerkungtextBox)
    
    
        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        $Tab=($SelectPersonBemerkungtextBox.left + $SelectPersonBemerkungtextBox.width-$LabelLeft-(3*$HorrAbstand))/4
        # Button "Erster"                            
        $ErsterButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $ErsterButton.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $ErsterButton.Size = New-Object System.Drawing.Size($Tab,$LabelHeight)
        $ErsterButton.Text = GetTextFromLanguageDB -ID "4_M_108" #"|<-"
        $ErsterButton.Name = "Erster"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $ErsterButton.add_Click($SelectPersonForm_ErsterButton_OnClick)
        $SelectPersonForm.Controls.Add($ErsterButton)

        # Button "Rueck"                            
        $RueckButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $RueckButton.Location = New-Object System.Drawing.Size(($LabelLeft+$HorrAbstand+$Tab),$ZeilenTop)
        $RueckButton.Size = New-Object System.Drawing.Size($Tab,$LabelHeight)
        $RueckButton.Text = GetTextFromLanguageDB -ID "4_M_109" #"<-"
        $RueckButton.Name = "Rueck"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $RueckButton.add_Click($SelectPersonForm_RueckButton_OnClick)
        $SelectPersonForm.Controls.Add($RueckButton)

        # Button "Vor"                            
        $VorButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $VorButton.Location = New-Object System.Drawing.Size(($LabelLeft+2*($HorrAbstand+$Tab)),$ZeilenTop)
        $VorButton.Size = New-Object System.Drawing.Size($Tab,$LabelHeight)
        $VorButton.Text = GetTextFromLanguageDB -ID "4_M_110" #"->"
        $VorButton.Name = "vor"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $VorButton.add_Click($SelectPersonForm_VorButton_OnClick)
        $SelectPersonForm.Controls.Add($VorButton)

        # Button "Erster"                            
        $LetzterButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $LetzterButton.Location = New-Object System.Drawing.Size(($LabelLeft+3*($HorrAbstand+$Tab)),$ZeilenTop)
        $LetzterButton.Size = New-Object System.Drawing.Size($Tab,$LabelHeight)
        $LetzterButton.Text = GetTextFromLanguageDB -ID "4_M_111" #"->|"
        $LetzterButton.Name = "Letzter"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $LetzterButton.add_Click($SelectPersonForm_LetzterButton_OnClick)
        $SelectPersonForm.Controls.Add($LetzterButton)

    
        $ZeilenTop=$ZeilenTop + $LabelHeight + $ZeilenAbstand
        $OKButtonBreite=($SelectPersonBemerkungtextBox.left + $SelectPersonBemerkungtextBox.width-$LabelLeft - $HorrAbstand)/2
        # Button "OK"                            
        $OKButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $OKButton.Location = New-Object System.Drawing.Size($LabelLeft,$ZeilenTop)
        $OKButton.Size = New-Object System.Drawing.Size($OKButtonBreite,$LabelHeight)
        $OKButton.Text = GetTextFromLanguageDB -ID "4_M_112" #"OK"
        $OKButton.Name = "OK"
        $OKButton.DialogResult = "OK"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $OKButton.add_Click({$SelectPersonForm.Close()})
        $SelectPersonForm.Controls.Add($OKButton)

        # Button "Abbruch"       
        $Tab=($SelectPersonBemerkungtextBox.left + $SelectPersonBemerkungtextBox.width-$LabelLeft)/2 +($HorrAbstand/2) +$LabelLeft                    
        $CancelButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $CancelButton.Location = New-Object System.Drawing.Size($Tab,$ZeilenTop)
        $CancelButton.Size = New-Object System.Drawing.Size($OKButtonBreite,$LabelHeight)
        $CancelButton.Text = GetTextFromLanguageDB -ID "4_M_113" #"Abbrechen"
        $CancelButton.Name = "Abbrechen"
        $CancelButton.DialogResult = "Cancel"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $CancelButton.Add_Click({$SelectPersonLNRtextBox.Text=0;$SelectPersonForm.Close()})
        $SelectPersonForm.Controls.Add($CancelButton)
    
        $SelectPersonForm.height = ($ZeilenTop + $LabelHeight + $ZeilenAbstand + 40)

        $SelectPersonLNRtextBox.Text=1
        SelectPersonFelderFuellen

        $Erfolg =  $SelectPersonForm.ShowDialog()

        
        if ($DebugMode -eq "true") {$text="beende Sub Men� SelectPerson. Erfolg:" + $Erfolg;Write-Host $Text}
        #$global:AktPersonNr=$SelectPersonLNRtextBox.Text
        $global:AktPersonNr = 0

        if ($Erfolg -eq "OK") {
            $global:AktPersonNr=$SelectPersonLNRtextBox.Text
        }

        if ($DebugMode -eq "true") {$text="beende Sub Men� SelectPerson. gefundene Person:" + $global:AktPersonNr;Write-Host $Text}
        return $global:AktPersonNr
    }

    ### Sub Menue SelectPerson
    ##############################################################
#endregion Sub Menue SelectPerson


#region MainMenu
    function prepareTgGui() {
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################
        if ($DebugMode -eq "true"){$Text= "## prepareTgGui startet"; Write-Host $Text}
        
        $TGSelected = $TGComboBox.SelectedIndex
        if ($DebugMode -eq "true"){$Text= "## prepareTgGui`t--`tAuswahl:`t" + $TGSelected + " (" + $TGComboBox.selecteditem + ")"; Write-Host $Text}
        
        if ($TGSelected -eq 0) {
                $DAGComboBox.hide()
                $DAGComboBox.SelectedIndex=-1
                $DATComboBox.show()
            } elseif ($TGSelected -eq 1) {
                $DATComboBox.hide()
                $DATComboBox.SelectedIndex=-1
                $DAGComboBox.show()
        }
    }

    function EnableStatusButtons() {
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################
        
        if ($DebugMode -eq "true"){$Text= "## EnableStatusButtons startet"; Write-Host $Text}
        $PB1Label.show()
        $PB2Label.show()
        $PB3Label.show()
        $PB4Label.show()
        $ZielOeffnenButton.show()
        $erglabel.show()

        
        $PB1Label.Text=GetTextFromLanguageDB -ID "4_M_RES_10" #"PrepareDrawListe"
        $PB2Label.Text=GetTextFromLanguageDB -ID "4_M_RES_11" #"PlaceOnPaper"
        $PB3Label.Text=GetTextFromLanguageDB -ID "4_M_RES_12" #"PrepareHtmlCode"

        #$ProgressBar1.visible
        $ProgressBar1.show()
        $ProgressBar1.Maximum = 100
        $ProgressBar1.Minimum = 0

        #$ProgressBar2.visible
        $ProgressBar2.show()
        $ProgressBar2.Maximum = 2
        $ProgressBar2.Minimum = 0

        #$ProgressBar3.visible
        $ProgressBar3.show()
        $ProgressBar3.Maximum = 100
        $ProgressBar3.Minimum = 0

        #$ProgressBar3.visible
        $ProgressBar4.show()
        $ProgressBar4.Maximum = 100
        $ProgressBar4.Minimum = 0
        
        $MainMenuForm.Refresh()
    }

    function ProgressStatus() {
        param (
            [int]$ProgressLnr=0,
            [int]$MaxValue=0,
            [int]$ActValue=0
        )

        ##################################################
        # Version V03
        # vom 10.4.2023
        ##################################################
        
        $DebugMode = "false"
        if ($Global:DebugMode -eq "true") {$DebugMode = "true"}

        if ($DebugMode -eq "true"){$Text= "## ProgressStatus startet`t--`tParameter:`n`t`t`tProgressLnr:`t" + $ProgressLnr + "`n`t`t`tMaxValue:`t" + $MaxValue + "`n`t`t`tActValue:`t" + $ActValue; Write-Host $Text}

        # Notbremse gegen Fehlermeldung
        if ($MaxValue -lt $ActValue ) {$ActValue = $MaxValue}


        if ($ProgressLnr -eq 1) {
        
            #$ProgressBar1.show()
            $ProgressBar1.Maximum=$MaxValue
            $ProgressBar1.value=$ActValue
        }
        if ($ProgressLnr -eq 2) {
        
            #$ProgressBar2.show()
            $ProgressBar2.Maximum=$MaxValue
            $ProgressBar2.value=$ActValue
        }
        if ($ProgressLnr -eq 3) {
        
            #$ProgressBar3.show()
            $ProgressBar3.Maximum=$MaxValue
            $ProgressBar3.value=$ActValue
        }        
        if ($ProgressLnr -eq 4) {
        
            #$ProgressBar3.show()
            $ProgressBar4.Maximum=$MaxValue
            $ProgressBar4.value=$ActValue
        }
        $MainMenuForm.Refresh()
    }

    function StatusUpdate() {
        param (
            $ProgressLnr=0
        )
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################

        #$DebugMode="true"
        if ($DebugMode -eq "true"){$Text= "## StatusUpdate startet"; Write-Host $Text}
        #$DebugMode="false"

        if ($ProgressLnr -eq 1) {
            $KnotenCheckListeSplit=$Global:KnotenCheckListe.split("`t")
        
            $Summe=0
            for($i=0; $i -lt $KnotenCheckListeSplit.count; $i++){
                if ($KnotenCheckListeSplit[$i] -eq 1) {$Summe=$Summe+1}
            }
            ProgressStatus -ProgressLnr $ProgressLnr -MaxValue $KnotenCheckListeSplit.count -ActValue $Summe
            if ($DebugMode -eq "true"){$Text= "## StatusUpdate " + $ProgressLnr + " KnotenCheckListeAnz:" + $KnotenCheckListeSplit.count + " Treffer: " + $Summe; Write-Host $Text}
        }

        if ($ProgressLnr -eq 2) {

            
        }
        if ($ProgressLnr -eq 3) {

            
        }        
        if ($ProgressLnr -eq 4) {

            
        }
    }
    
    
    $ZielOeffnenButton_OnClick={
        $File=$erglabel.Text
        Invoke-Item $File

    }

    $StartButton_OnClick={
        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick startet"; Write-Host $Text}
        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DATComboBox.SelectedIndex + " (" + $DATComboBox.selecteditem + ")`n`t--`tDAG-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
        
        #DatenEinlesen

        if ($TGComboBox.SelectedIndex -eq 0) {
                #if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")"; Write-Host $Text}
                
                # Text
                if ($DATComboBox.SelectedIndex -eq 0) {
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DATComboBox.SelectedIndex + " (" + $DATComboBox.selecteditem + ")"; Write-Host $Text}
                        

                    } elseif ($DATComboBox.SelectedIndex -eq 1) {
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DATComboBox.SelectedIndex + " (" + $DATComboBox.selecteditem + ")"; Write-Host $Text}

                    } elseif ($DATComboBox.SelectedIndex -eq 2) {
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DATComboBox.SelectedIndex + " (" + $DATComboBox.selecteditem + ")"; Write-Host $Text}

                    } elseif ($DATComboBox.SelectedIndex -eq 3) {
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DATComboBox.SelectedIndex + " (" + $DATComboBox.selecteditem + ")"; Write-Host $Text}

                }

            } elseif ($TGComboBox.SelectedIndex -eq 1) {
                #if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")"; Write-Host $Text}

                # grafisch
                if ($DAGComboBox.SelectedIndex -eq 0) {

                        DataInit                       
                        EnableStatusButtons
                        $SourceDataFile=ExportAsHtmlSingleTree
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        $erglabel.Text=$SourceDataFile
                        $MainMenuForm.Refresh()

                    } elseif ($DAGComboBox.SelectedIndex -eq 1) {
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        DataInit
                        EnableStatusButtons
                        $SourceDataFile=ExportAsHtmlAllTopTrees
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        $erglabel.Text=$SourceDataFile
                        $MainMenuForm.Refresh()

                    } elseif ($DAGComboBox.SelectedIndex -eq 2) {
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        
                        DataInit
                        EnableStatusButtons
                        $SourceDataFile=ExportAsHtmlAllIn
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tErgebnis-Datei:`t(" + $SourceDataFile + ")"; Write-Host $Text}
                        $erglabel.Text=$SourceDataFile
                        $MainMenuForm.Refresh()

                    } elseif ($DAGComboBox.SelectedIndex -eq 3) {
                        if ($DebugMode -eq "true"){$Text= "## StartButton_OnClick`t--`tTG-Auswahl:`t" + $TGComboBox.SelectedIndex + " (" + $TGComboBox.selecteditem + ")`n`t--`tDAT-Auswahl:`t" + $DAGComboBox.SelectedIndex + " (" + $DAGComboBox.selecteditem + ")"; Write-Host $Text}
                        # kommt vielleicht noch was ...
                }
        }

    }

    function MainMenuEM() {
    
        ##################################################
        # Version V01
        # vom 7.4.2023
        ##################################################

        #$DebugMode="true"

        $LinkerRand=20
        $RechterRand=35
        $ObererRand=20
        $UntererRand=50

        $SpaltenAbstand=0
        $ZeienAbstand=5

        $ListenHeight=20
        $ListenWidth=400

        $LabelHeight=20
        $LabelWidth=400

        
        $PBHeight=20
        $PBWidth=400

        $OKButtonTop=420

        $TGSelected=0

        # GUI erzeugen
        $MainMenuForm = New-Object System.Windows.Forms.Form
        $MainMenuForm.StartPosition = "CenterScreen"
        $MainMenuForm.Text = GetTextFromLanguageDB -ID  ("4_1") #"Stammbaum Export-Manager"

        ### Text/Grafik ###
        $AktLeft=$LinkerRand
        $AktTop=$ObererRand

        # Label Settings-Werte LNR
        $TGLabel = New-Object System.Windows.Forms.Label
        $TGLabel.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $TGLabel.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $TGLabel.Text =  GetTextFromLanguageDB -ID  ("4_M_1") #"Ausgabe-Form"
        $MainMenuForm.Controls.Add($TGLabel)
        

        $AktLeft=$LinkerRand 
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        # Liste Settings-Werte LNR
        $TGComboBox = New-Object system.Windows.Forms.ComboBox
        $TGComboBox.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $TGComboBox.Size = New-Object System.Drawing.Size($ListenWidth,$ListenHeight)
        #$TGListbox.Add_DoubleClick($LNR_OnDblClick)
        #$TGListbox.Add_Click($LNR_OnClick)
        $TGComboBox.Font = �Microsoft Sans Serif,10�
        $TGComboBox.Items.Clear()
        [void] $TGComboBox.Items.Add((GetTextFromLanguageDB -ID  ("4_M_TG_1"))) # "als Text")
        [void] $TGComboBox.Items.Add((GetTextFromLanguageDB -ID  ("4_M_TG_2"))) #"grafisch als html")
        $TGComboBox.SelectedIndex=-1
        $TGComboBox.add_SelectedIndexChanged({
            prepareTgGui
        })
        $MainMenuForm.Controls.Add($TGComboBox)


        $AktLeft=$LinkerRand 
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        # ComboBox Design-Art Text
        $DATComboBox = New-Object system.Windows.Forms.ComboBox
        $DATComboBox.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $DATComboBox.Size = New-Object System.Drawing.Size($ListenWidth,$ListenHeight)
        #$DATComboBox.Add_DoubleClick($LNR_OnDblClick)
        #$DATComboBox.Add_Click($LNR_OnClick)
        $DATComboBox.Font = �Microsoft Sans Serif,10�
        $DATComboBox.Items.Clear()
        [void] $DATComboBox.Items.Add((GetTextFromLanguageDB -ID  ("4_M_DAT_1"))) #"Minimal")
        [void] $DATComboBox.Items.Add((GetTextFromLanguageDB -ID  ("4_M_DAT_2"))) #"Erweitert")
        $DATComboBox.SelectedIndex=-1
        $DATComboBox.add_SelectedIndexChanged({prepareTgGui})
        $DATComboBox.Hide()
        $MainMenuForm.Controls.Add($DATComboBox)

        # ComboBox Design-Art Grafisch
        $DAGComboBox = New-Object system.Windows.Forms.ComboBox
        $DAGComboBox.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $DAGComboBox.Size = New-Object System.Drawing.Size($ListenWidth,$ListenHeight)
        #$DAGComboBox.Add_DoubleClick($LNR_OnDblClick)
        #$DAGComboBox.Add_Click($LNR_OnClick)
        $DAGComboBox.Font = �Microsoft Sans Serif,10�
        $DAGComboBox.Items.Clear()
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID  ("4_M_DAG_1"))) #"klassisch (Top/Down)")
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID  ("4_M_DAG_2"))) #"alle ""Tops"" klassisch")
        [void] $DAGComboBox.Items.Add((GetTextFromLanguageDB -ID  ("4_M_DAG_3"))) #"Volle Tapete")
        $DAGComboBox.SelectedIndex=-1
        $DAGComboBox.Hide()
        $MainMenuForm.Controls.Add($DAGComboBox)

        $AktLeft=$LinkerRand
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        # Label Settings-Werte LNR
        $PB1Label = New-Object System.Windows.Forms.Label
        $PB1Label.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $PB1Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PB1Label.Text = GetTextFromLanguageDB -ID  ("4_M_2")# "erster Schritt"
        $PB1Label.Hide()
        $MainMenuForm.Controls.Add($PB1Label)
        
        $AktLeft=$LinkerRand 
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        $ProgressBar1 = New-Object System.Windows.Forms.ProgressBar
        $ProgressBar1.Location = New-Object System.Drawing.Point($AktLeft,$AktTop)
        $ProgressBar1.Size = New-Object System.Drawing.Size($PBWidth, $LabelHeight)
        $ProgressBar1.Style="Continuous"
        $ProgressBar1.value=0
        $ProgressBar1.Maximum=100
        $ProgressBar1.Hide()
        $MainMenuForm.Controls.Add($ProgressBar1);

        
        $AktLeft=$LinkerRand
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        # Label Settings-Werte LNR
        $PB2Label = New-Object System.Windows.Forms.Label
        $PB2Label.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $PB2Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PB2Label.Text = GetTextFromLanguageDB -ID  ("4_M_3")#"zweiter Schritt"
        $PB2Label.Hide()
        $MainMenuForm.Controls.Add($PB2Label)


        $AktLeft=$LinkerRand 
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        $ProgressBar2 = New-Object System.Windows.Forms.ProgressBar
        $ProgressBar2.Location = New-Object System.Drawing.Point($AktLeft,$AktTop)
        $ProgressBar2.Size = New-Object System.Drawing.Size($PBWidth, $LabelHeight)
        $ProgressBar2.Style = "Continuous"
        $ProgressBar2.value=0
        $ProgressBar2.Maximum=100
        $ProgressBar2.Hide()
        $MainMenuForm.Controls.Add($ProgressBar2);

        
        $AktLeft=$LinkerRand
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        # Label Settings-Werte LNR
        $PB3Label = New-Object System.Windows.Forms.Label
        $PB3Label.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $PB3Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PB3Label.Text = GetTextFromLanguageDB -ID  ("4_M_4")#"dritter Schritt"
        $PB3Label.Hide()
        $MainMenuForm.Controls.Add($PB3Label)

        $AktLeft=$LinkerRand 
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        $ProgressBar3 = New-Object System.Windows.Forms.ProgressBar
        $ProgressBar3.Location = New-Object System.Drawing.Point($AktLeft,$AktTop)
        $ProgressBar3.Size = New-Object System.Drawing.Size($PBWidth,$LabelHeight)
        $ProgressBar3.Style = "Continuous"
        $ProgressBar3.value=0
        $ProgressBar3.Maximum=100
        $ProgressBar3.Hide()
        $MainMenuForm.Controls.Add($ProgressBar3);



        
        $AktLeft=$LinkerRand
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        # Label Settings-Werte LNR
        $PB4Label = New-Object System.Windows.Forms.Label
        $PB4Label.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $PB4Label.Size = New-Object System.Drawing.Size($LabelWidth,$LabelHeight)
        $PB4Label.Text = GetTextFromLanguageDB -ID  ("4_M_5")# "Komplett-Fortschritt"
        $PB4Label.Hide()
        $MainMenuForm.Controls.Add($PB4Label)

        $AktLeft=$LinkerRand 
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand        

        $ProgressBar4 = New-Object System.Windows.Forms.ProgressBar
        $ProgressBar4.Location = New-Object System.Drawing.Point($AktLeft,$AktTop)
        $ProgressBar4.Size = New-Object System.Drawing.Size($PBWidth,$LabelHeight)
        $ProgressBar4.Style = "Continuous"
        $ProgressBar4.value=0
        $ProgressBar4.Maximum=100
        $ProgressBar4.Hide()
        $MainMenuForm.Controls.Add($ProgressBar4);

        $AktLeft=$LinkerRand
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        # Label Settings-Werte LNR
        $ErgLabel = New-Object System.Windows.Forms.Label
        $ErgLabel.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $ErgLabel.Size = New-Object System.Drawing.Size($PBWidth,$LabelHeight)
        $ErgLabel.Text = GetTextFromLanguageDB -ID  ("4_M_6")# "Ziel-Datei"
        $ErgLabel.Hide()
        $MainMenuForm.Controls.Add($ErgLabel)
        
        $AktLeft=$LinkerRand
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        # Button "Zieldatei �ffnen"                            
        $ZielOeffnenButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $ZielOeffnenButton.Location = New-Object System.Drawing.Size($AktLeft,$AktTop)
        $ZielOeffnenButton.Size = New-Object System.Drawing.Size($PBWidth,$LabelHeight)
        $ZielOeffnenButton.Text = GetTextFromLanguageDB -ID  ("4_M_7")#"Ziel-Datei �ffnen"
        $ZielOeffnenButton.Name = "OpenGoal"
        $ZielOeffnenButton.Hide()
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $ZielOeffnenButton.add_Click($ZielOeffnenButton_OnClick)
        $MainMenuForm.Controls.Add($ZielOeffnenButton)

        
        $AktLeft=$LinkerRand
        $AktTop=$AktTop+$LabelHeight+$ZeienAbstand

        # Button "Speichern"                            
        $StartButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $StartButton.Location = New-Object System.Drawing.Size(100,$AktTop)
        $StartButton.Size = New-Object System.Drawing.Size(100,23)
        $StartButton.Text = GetTextFromLanguageDB -ID  ("4_M_8")#"Start"
        $StartButton.Name = "Start"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $StartButton.add_Click($StartButton_OnClick)
        $MainMenuForm.Controls.Add($StartButton)

        # Button "Abbruch"                            
        $CancelButton = New-Object System.Windows.Forms.Button
        # Die n�chsten beiden Zeilen legen die Position und die Gr��e des Buttons fest
        $CancelButton.Location = New-Object System.Drawing.Size(300,$AktTop)
        $CancelButton.Size = New-Object System.Drawing.Size(100,23)
        $CancelButton.Text = GetTextFromLanguageDB -ID  ("4_M_9")#"Beenden"
        $CancelButton.Name = "Beenden"
        $CancelButton.DialogResult = "Cancel"
        #Die folgende Zeile ordnet dem Click-Event die Schlie�en-Funktion f�r das Formular zu
        $CancelButton.Add_Click({$MainMenuForm.Close()})
        $MainMenuForm.Controls.Add($CancelButton)

        
        #$MainMenuForm.Size = New-Object System.Drawing.Size(750,500)
        $MainMenuBreite=$ListenWidth + $RechterRand + $LinkerRand
        $MainMenuHoehe=$CancelButton.Top + $CancelButton.Height + $UntererRand
        $MainMenuForm.Size = New-Object System.Drawing.Size($MainMenuBreite,$MainMenuHoehe)
        
        $StartButton.Width=$MainMenuBreite/5
        $CancelButton.Width=$MainMenuBreite/5
        
        $StartButton.Left=$MainMenuBreite/5
        $CancelButton.Left=$MainMenuBreite/5*3

        [void] $MainMenuForm.ShowDialog()
    }

#endregion MainMenu

#endregion GUI

#region Main

    $DebugMode = "false"
    if ($Global:DebugMode -eq "true"){$DebugMode="true"}
    #$DebugMode="true"


    if ($GetVersionInfo -eq "true") {            
            $ErgText=$ErgText + "Version:`t" + $Version + "`n"
            $ErgText=$ErgText + "Stand:`t" + $Stand + "`n"
            $ErgText=$ErgText + "Developper:`t" + $Developper + "`n"
            return  $ErgText

        } else {


            $global:Spaltenwackeln="true"
            $global:SettingsData=""
            $Global:SettingsDataFile=""
            $global:BasisPfad=""
            $global:AktPersonNr=0
            $global:PersonenDB=""
            $global:KnotenDB=""
            $Global:PersonenDrawListe=""
            $Global:KnotenCheckListe=""
            $Global:AktPersonenDrawListeLnr=1
            $Global:DrawPosListex=""
            $Global:MinusDrawPosListex=""
            $Global:Route=""
            $Global:LogMode = ""
            $Global:DebugMode = ""
            $Global:Language = ""
            $Global:SprachDB = ""

            $Global:MaxSpaltenPos=0
            $Global:MaxZeilenPos=0

            $global:GestorbenZeichen=""
            $global:GeborenZeichen=""
            $global:HochzeitZeichen=""
            $global:ScheidungsZeichen=""

            $global:KindStartNr=0
            $global:KnotenHeaderListe=@()

            SetGlobalParameterEM 

            MainMenuEM
    }
#endregion Main